"""前衛（および介入者）の状態遷移。

READY → INTERVENING → GUARDING → RECOVERING → READY
介入直後に瞬間移動で持ち場へ戻る処理は存在しない。
復帰のタイミングは RecoveryStrategy（rules/recovery.py）が決める。
"""
from __future__ import annotations

from ..model.enums import Stance

_ALLOWED = {
    Stance.READY: {Stance.INTERVENING, Stance.DOWN, Stance.DIVING},
    Stance.DIVING: {Stance.READY, Stance.DOWN},     # Ver0.15（PA-201）
    Stance.INTERVENING: {Stance.GUARDING, Stance.DOWN},
    Stance.GUARDING: {Stance.RECOVERING, Stance.DOWN},
    Stance.RECOVERING: {Stance.READY, Stance.DOWN},
    Stance.DOWN: {Stance.READY},   # Ver0.10.2 暫定: 治療による戦闘復帰（incap_healable のときだけ起きる, PA-110）
}


class StanceError(RuntimeError):
    pass


def transition(c, new: Stance, emit=None, reason: str = ""):
    old = c.stance
    if new is old:
        return
    if new not in _ALLOWED[old]:
        raise StanceError(f"{c.name}: {old.value} → {new.value} は不正な遷移")
    c.stance = new
    if new is Stance.INTERVENING or new is Stance.DIVING:
        c.displaced = True
    elif new is Stance.READY:
        c.displaced = False
    if emit:
        emit("stance", unit=c.id, old=old.value, new=new.value, reason=reason)
