from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .enums import ActionKind, Reach


@dataclass(frozen=True)
class ActionDef:
    id: str
    name: str
    kind: ActionKind
    reach: Optional[Reach] = None
    source: str = "power"      # power / magic
    coef: float = 1.0
    ep_cost: int = 0
    amount: int = 0            # EP補給量など
    uses: Optional[int] = None  # 使用回数上限（None=無制限）
    heal_ratio: float = 0.0     # Ver0.5: 対象の最大HPに対する治療割合（0なら魔法能力×係数）
    area: str = "single"        # Ver0.8 実験: "all"=到達できる敵全員（介入なし, PA-71）
    special: str = ""           # Ver0.15: dive / flank / pin / push / hold / howl / observe（PA-201〜208）

    @property
    def targets_enemy(self) -> bool:
        return self.kind is ActionKind.ATTACK


def load_actions(cfg: dict) -> dict[str, ActionDef]:
    out = {}
    for aid, a in cfg.items():
        out[aid] = ActionDef(
            id=aid,
            name=a.get("name", aid),
            kind=ActionKind(a["kind"]),
            reach=Reach(a["reach"]) if a.get("reach") else None,
            source=a.get("source", "power"),
            coef=float(a.get("coef", 1.0)),
            ep_cost=int(a.get("ep_cost", 0)),
            amount=int(a.get("amount", 0)),
            uses=a.get("uses"),
            heal_ratio=float(a.get("heal_ratio", 0.0)),
            area=a.get("area", "single"),
            special=a.get("special", ""),
        )
    return out
