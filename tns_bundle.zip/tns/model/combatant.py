"""戦闘参加者。静的定義(CombatantDef)と戦闘中の状態(Combatant)を分ける。
UE5移植時: CombatantDef → DataAsset / DataTable 行、Combatant → ランタイムオブジェクト。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .enums import Rank, Side, Stance


@dataclass(frozen=True)
class CombatantDef:
    id: str
    name: str
    side: Side
    rank: Rank
    hp_max: int
    ep_max: int
    power: int
    body: int      # 肉体強度
    magic: int     # 魔法能力
    speed: int     # 行動速度
    action_ids: tuple[str, ...]
    actions_per_round: int = 1
    intelligence: Optional[int] = None   # 敵のみ 0..3
    group: Optional[str] = None
    is_leader: bool = False
    role: str = ""

    @staticmethod
    def from_cfg(u: dict, side: Side) -> "CombatantDef":
        return CombatantDef(
            id=u["id"], name=u.get("name", u["id"]), side=side, rank=Rank(u["rank"]),
            hp_max=int(u["hp"]), ep_max=int(u["ep"]), power=int(u.get("power", 0)),
            body=int(u.get("body", 0)), magic=int(u.get("magic", 0)), speed=int(u.get("speed", 0)),
            action_ids=tuple(u.get("actions", ["wait"])),
            actions_per_round=int(u.get("actions_per_round", 1)),
            intelligence=u.get("intelligence"), group=u.get("group"),
            is_leader=bool(u.get("leader", False)), role=u.get("role", ""),
        )


@dataclass
class Combatant:
    d: CombatantDef
    hp: int = 0
    ep: int = 0
    stance: Stance = Stance.READY
    displaced: bool = False          # 持ち場を離れているか
    recover_ticks: int = 0           # RecoveryStrategy(ticks)用
    intel_effective: Optional[int] = None
    uses: dict = field(default_factory=dict)
    ward: int = 0                    # Ver0.8 実験M3: EPのうち防御専用の外殻（ep の内数）
    incap_ratio: float = 0.0         # Ver0.7 PA-61: 現在HP/最大HP がこれ以下で戦闘不能（0=なし）

    @classmethod
    def spawn(cls, d: CombatantDef, intel_override: Optional[int] = None) -> "Combatant":
        intel = d.intelligence
        if intel is not None and intel_override is not None:
            intel = intel_override
        return cls(d=d, hp=d.hp_max, ep=d.ep_max, intel_effective=intel)

    # 便利プロパティ
    @property
    def id(self) -> str: return self.d.id
    @property
    def name(self) -> str: return self.d.name
    @property
    def side(self) -> Side: return self.d.side
    @property
    def rank(self) -> Rank: return self.d.rank
    @property
    def alive(self) -> bool:
        """戦闘に参加できる状態。Ver0.7: HP0（死亡）または HP率≦incap_ratio（戦闘不能）で False。"""
        if self.hp <= 0:
            return False
        return not (self.incap_ratio > 0 and self.hp / self.d.hp_max <= self.incap_ratio)
    @property
    def dead(self) -> bool: return self.hp <= 0
    @property
    def incapacitated(self) -> bool: return self.hp > 0 and not self.alive
    @property
    def hp_ratio(self) -> float: return self.hp / self.d.hp_max if self.d.hp_max else 0.0
    @property
    def ep_ratio(self) -> float: return self.ep / self.d.ep_max if self.d.ep_max else 0.0
    @property
    def can_intervene(self) -> bool:
        return self.alive and self.stance is Stance.READY and not self.displaced

    def short(self) -> str:
        return f"{self.name}[HP{self.hp}/{self.d.hp_max} EP{self.ep}/{self.d.ep_max} {self.stance.value}]"
