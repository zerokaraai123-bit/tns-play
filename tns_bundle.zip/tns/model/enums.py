from enum import Enum


class Side(str, Enum):
    ALLY = "ally"
    ENEMY = "enemy"

    @property
    def other(self) -> "Side":
        return Side.ENEMY if self is Side.ALLY else Side.ALLY


class Rank(str, Enum):
    """隊列。第1試作は2列のみ。MIDDLE等は将来ここに追加する。"""
    FRONT = "FRONT"
    REAR = "REAR"


class Reach(str, Enum):
    """攻撃到達タイプ。将来 AERIAL / AREA などを追加できる。"""
    MELEE = "MELEE"
    RANGED = "RANGED"


class Stance(str, Enum):
    READY = "READY"              # 持ち場にいて経路をBLOCK・介入可能
    INTERVENING = "INTERVENING"  # 介入のため移動中（持ち場は空く）
    GUARDING = "GUARDING"        # 介入先で受けた直後（持ち場は空いたまま・再介入不可）
    RECOVERING = "RECOVERING"    # 持ち場へ戻る途中（持ち場は空いたまま・再介入不可）
    DOWN = "DOWN"                # 戦闘不能
    DIVING = "DIVING"            # Ver0.15（PA-201）: 突撃・回り込みで相手の後衛へ踏み込んでいる（持ち場は空く・防御は可・介入不可）


class ActionKind(str, Enum):
    ATTACK = "attack"
    HEAL = "heal"
    EP_SUPPLY = "ep_supply"
    WAIT = "wait"
    COVER = "cover"          # Ver0.8 実験M4: 庇護の構え
    SPECIAL = "special"      # Ver0.15: 攻撃しない特殊行動（死守・遠吠え・観測）。中身は ActionDef.special


INTEL_NAMES = {0: "低知能", 1: "通常", 2: "高知能", 3: "戦術的"}
