"""イベント → 人間が「なぜそうなったか」を追える日本語テキスト。"""
from __future__ import annotations

import json

from ..model.enums import INTEL_NAMES


def _n(engine, uid):
    return engine.u(uid).name if uid else "-"


def _reasons(ev):
    rs = ev.get("reasons") or []
    return "".join(f"\n      └ {r}" for r in rs)


def render(ev: dict, engine) -> str | None:
    t = ev["t"]
    N = lambda k: _n(engine, ev.get(k))
    if t == "battle_start":
        rs = " / ".join(f"{k}:{v}" for k, v in ev["routes"].items())
        return f"=== 戦闘開始 ===  経路 {rs}"
    if t == "round_start":
        q = " → ".join(_n(engine, x) for x in ev["queue"])
        return f"\n――― 第{ev['round']}巡 ―――\n  行動順: {q}"
    if t == "turn_start":
        intel = f" 知能:{INTEL_NAMES[ev['intel']]}" if ev.get("intel") is not None else ""
        nxt = "・".join(_n(engine, x) for x in ev["upcoming"])
        rs = " ".join(f"{k}:{v}" for k, v in ev.get("routes", {}).items())
        return f"\n▶ {ev['snap']}{intel}   (この後: {nxt})  [{rs}]"
    if t == "turn_skipped":
        return f"  {N('unit')}: 行動なし（{ev['reason']}）"
    if t == "ai_consider":
        return f"  [AI] {N('unit')} → {ev['text']}"
    if t == "plan":
        return f"  [連携計画] {ev['text']}"
    if t == "attack_declared":
        a = engine.actions[ev["action"]]
        via = f"  経路:{ev['via_route']}" if ev.get("via_route") else ""
        return (f"  {N('unit')} → {N('target')} に{a.name}({ev['reach']})  到達判定: {ev['reach_reason']}{via}"
                + _reasons(ev))
    if t == "attack_failed":
        return f"  ✕ 攻撃不成立: {ev['reason']}"
    if t == "intrusion":
        cause = f"（{_n(engine, ev['caused_by'])}の介入で開いた穴）" if ev.get("caused_by") else ""
        return f"  ⚠ 侵入: {N('unit')} が経路{ev['route']}から後衛{N('target')}へ{cause}"
    if t == "intervention_window":
        el = "・".join(_n(engine, x) for x in ev["eligible"])
        return f"  ◇ 介入機会: {N('target')}への攻撃 / 介入可能: {el}"
    if t == "intervened":
        return f"  ◆ {N('unit')} が介入！ 標的を{N('target')}→{N('unit')}へ変更 (防いだ見込み {ev['prevented_est']}){_reasons(ev)}"
    if t == "no_intervention":
        return f"  ◇ 介入なし{_reasons(ev)}"
    if t == "stance":
        return f"    {N('unit')}: {ev['old']} → {ev['new']}  ({ev['reason']})"
    if t == "route_change":
        return f"    経路{ev['route']}: {ev['status']}  ({ev['cause']})"
    if t == "damage":
        mode = ev.get("mode", "reduced")
        if not ev["defense"]:
            d = f"防御なし[{ev['defense_reason']}]"
        elif mode == "full":
            d = f"エーテル防御 完全防御 EP-{ev.get('ep_spent')}"
        elif mode == "partial":
            d = f"エーテル防御 部分防御 EP-{ev.get('ep_spent')}で{int(ev['reduction']*100)}%防ぎ、残りが肉体へ貫通"
        else:
            d = f"エーテル防御 展開 軽減{int(ev['reduction']*100)}%"
        return f"  → {N('unit')} に {ev['dmg']} ダメージ ({d})  HP{ev['hp']} EP{ev['ep']}"
    if t == "heal":
        return f"  ✚ {N('unit')} → {N('target')} 治癒魔法 +{ev['amount']} (EP-{ev['ep_cost']})  HP{ev['hp']}{_reasons(ev)}"
    if t == "ep_supply":
        return f"  ⛽ {N('unit')} → {N('target')} EP補給 +{ev['amount']}  EP{ev['ep']} (残り{ev['uses_left']}回){_reasons(ev)}"
    if t == "wait":
        return f"  {N('unit')}: 待機{_reasons(ev)}"
    if t == "ep_exhausted":
        return f"  ⚡ {N('unit')} EP枯渇（エーテル防御を展開できない） EP{ev['ep']}"
    if t == "ko":
        return f"  ✖ {N('unit')} 戦闘不能"
    if t == "intel_down":
        return f"  ▼ 知能DOWN: {N('unit')} {INTEL_NAMES[ev['old']]} → {INTEL_NAMES[ev['new']]}（{N('leader')}撃破）"
    if t == "battle_end":
        w = {"ally": "味方の勝利", "enemy": "敵の勝利", "draw": "引き分け"}[ev["winner"]]
        return f"\n=== 戦闘終了: {w}（{ev['rounds']}巡） ==="
    return json.dumps(ev, ensure_ascii=False)


def printer(ev, engine):
    s = render(ev, engine)
    if s:
        print(s)


def render_all(engine) -> str:
    return "\n".join(filter(None, (render(e, engine) for e in engine.events)))
