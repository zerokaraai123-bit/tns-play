"""Ver0.6 追跡調査（続き）: 「介入する頃には前衛のEPがかなり減っている」理由を、戦闘開始から追う。

主実験（前衛HP×1.75・16条件・各1,000戦）を同じシードで再実行し、イベントを聞き取るだけ。
ルール・AI・数値は一切変更しない。

出力:
  out/v06_early_battles.csv  1戦1行（最初の介入まで・初撃の扱い・初撃介入エピソード）
  out/v06_early_units.csv    1戦×前衛1体ごと（最初の介入までの自己防御・EP）
  out/v06_early_attacks.csv  敵の攻撃1件ごと（開始から10件目まで）: 狙い・介入可否・介入しなかった理由
"""
from __future__ import annotations

import csv
import os
import re
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..config_loader import load_battle_config
from ..model.enums import Side
from .csv_export import write_csv
from .runner import make_engine

DS = ("D1", "D15", "D2", "D3")
PS = ("P0", "P1", "P2", "P3")
N_EARLY = 10
MARGIN = 0.02   # ally_policies.yaml の situational.margin（読むだけ）

RE_NO = re.compile(r"介入しない損失([\d.]+)")
RE_OPT = re.compile(r"介入 ([\d.]+)\(被弾([\d.]+)(\+穴リスク([\d.]+))?")


def classify_no_iv(reasons):
    """状況判断で介入しなかった理由を、AIが出した数値から分類する（判断の再計算はしない）。"""
    txt = " ".join(reasons or [])
    m = RE_NO.search(txt)
    if not m:
        return "不明", None, None, None
    loss_no = float(m.group(1))
    opts = [(float(a), float(b), float(d) if d else 0.0) for a, b, _, d in RE_OPT.findall(txt)]
    if not opts:
        return "不明", loss_no, None, None
    tot, take, hole = min(opts)
    if loss_no <= MARGIN:
        cat = "対象が自分で防げる見込み（放置しても損失≈0）"
    elif take + MARGIN >= loss_no:
        cat = "介入役の被弾見込みの方が重い"
    else:
        cat = "穴リスクを足すと損"
    return cat, loss_no, take, hole


class EarlyTracer:
    def __init__(self, eng):
        self.eng = eng
        self.enemy_turns = 0
        self.enemy_attacks = 0
        self.first_iv = None                 # 戦闘で最初の味方前衛の介入
        self.attacks = []                    # 敵攻撃（先頭 N_EARLY 件）
        self.cur = None                      # 処理中の敵攻撃
        self.units = {}
        for u in eng.state.units.values() if isinstance(eng.state.units, dict) else eng.state.units:
            if u.side is Side.ALLY and u.rank.value == "FRONT":
                self.units[u.id] = {"unit": u.id, "ep_max": u.d.ep_max, "hp_max": u.d.hp_max,
                                    "targeted_before": 0, "selfdef_before": 0, "selfdef_ep_before": 0,
                                    "selfdef_full_before": 0, "body_hits_before": 0,
                                    "iv": 0, "first_iv_enemy_turns": "", "first_iv_enemy_attacks": "",
                                    "first_iv_ep": "", "first_iv_hp": "", "first_iv_target_rank": "",
                                    "ep_spent_selfdef_total": 0, "ep_spent_iv_total": 0, "died": 0}
        self.first_atk = None                # 初撃の扱い
        self.ep_track = None                 # 初撃介入エピソード

    def _front_states(self):
        out = []
        for uid in self.units:
            u = self.eng.u(uid)
            if not u.alive:
                out.append("死亡")
            elif u.displaced or u.stance.value != "READY":
                out.append("離脱/" + u.stance.value)
            else:
                out.append("可")
        return out

    def __call__(self, ev, eng):
        t = ev["t"]
        if t == "turn_start":
            if eng.u(ev["unit"]).side is Side.ENEMY:
                self.enemy_turns += 1
            return
        if t == "attack_declared":
            atk = eng.u(ev["unit"])
            if atk.side is not Side.ENEMY:
                self.cur = None
                return
            self.enemy_attacks += 1
            tgt = eng.u(ev["target"])
            row = {"attack_no": self.enemy_attacks, "enemy_turn_no": self.enemy_turns, "round": ev["round"],
                   "attacker": atk.id, "attacker_rank": atk.rank.value, "reach": ev["reach"],
                   "target": tgt.id, "target_rank": tgt.rank.value, "target_ep": tgt.ep,
                   "target_hp_ratio": round(tgt.hp / tgt.d.hp_max, 3),
                   "reach_ok": int(bool(ev["reach_ok"])), "via_route": ev.get("via_route") or "",
                   "front_states": "/".join(self._front_states()),
                   "window": 0, "front_eligible": 0, "intervened": 0, "iv_unit": "", "no_iv_cat": "",
                   "loss_no": "", "best_take": "", "best_hole": "", "target_defended": "", "dmg": "",
                   "before_first_iv": int(self.first_iv is None)}
            self.cur = row
            if self.enemy_attacks <= N_EARLY:
                self.attacks.append(row)
            if tgt.side is Side.ALLY and tgt.rank.value == "FRONT" and self.first_iv is None:
                self.units[tgt.id]["targeted_before"] += 1
            if self.first_atk is None:
                self.first_atk = row
            return
        if t == "intervention_window":
            if self.cur is not None and eng.u(ev["target"]).side is Side.ALLY:
                self.cur["window"] = 1
                self.cur["front_eligible"] = sum(1 for x in ev["eligible"] if eng.u(x).rank.value == "FRONT")
            return
        if t == "no_intervention":
            if self.cur is not None and eng.u(ev["target"]).side is Side.ALLY:
                cat, ln, tk, hl = classify_no_iv(ev.get("reasons"))
                self.cur.update(no_iv_cat=cat, loss_no=ln if ln is not None else "",
                                best_take=tk if tk is not None else "", best_hole=hl if hl is not None else "")
            return
        if t == "intervened":
            u = eng.u(ev["unit"])
            if u.side is not Side.ALLY:
                return
            tgt = eng.u(ev["target"])
            if self.cur is not None:
                self.cur["intervened"] = 1
                self.cur["iv_unit"] = u.id
            rec = self.units.get(u.id)
            if rec is not None:
                rec["iv"] += 1
                if rec["first_iv_ep"] == "":
                    rec.update(first_iv_enemy_turns=self.enemy_turns, first_iv_enemy_attacks=self.enemy_attacks,
                               first_iv_ep=u.ep, first_iv_hp=u.hp, first_iv_target_rank=tgt.rank.value)
            if self.first_iv is None and rec is not None:
                self.first_iv = {"unit": u.id, "enemy_turns": self.enemy_turns, "enemy_attacks": self.enemy_attacks,
                                 "ep": u.ep, "ep_max": u.d.ep_max, "hp": u.hp, "hp_max": u.d.hp_max,
                                 "target_rank": tgt.rank.value, "round": ev["round"]}
            # 初撃に対する介入なら、そのエピソードを追う
            if self.first_atk is not None and self.cur is self.first_atk and rec is not None:
                self.ep_track = {"unit": u.id, "phase": "iv", "post_iv_ep": None, "post_iv_hp": None,
                                 "disp_hits": 0, "disp_hit_ep": 0, "w75": 0, "w50": 0, "w25": 0,
                                 "returned": 0, "ret_ep": "", "ret_hp_ratio": "", "died": 0}
            return
        if t == "damage":
            u = eng.u(ev["unit"])
            if self.cur is not None and ev["unit"] == self.cur["target"]:
                self.cur["target_defended"] = int(bool(ev["defense"]))
                self.cur["dmg"] = ev["dmg"]
            if self.cur is not None and self.cur["intervened"] and ev["unit"] == self.cur["iv_unit"]:
                self.cur["dmg"] = ev["dmg"]
            rec = self.units.get(u.id)
            if rec is not None:
                spent = ev.get("ep_spent", 0) or 0
                is_iv_hit = self.cur is not None and self.cur["intervened"] and self.cur["iv_unit"] == u.id
                if ev["defense"]:
                    if is_iv_hit:
                        rec["ep_spent_iv_total"] += spent
                    else:
                        rec["ep_spent_selfdef_total"] += spent
                        if rec["first_iv_ep"] == "":
                            rec["selfdef_before"] += 1
                            rec["selfdef_ep_before"] += spent
                            if ev.get("mode") == "full":
                                rec["selfdef_full_before"] += 1
                if not is_iv_hit and ev["dmg"] > 0 and rec["first_iv_ep"] == "":
                    rec["body_hits_before"] += 1
                if ev["hp"] <= 0:
                    rec["died"] = 1
            tr = self.ep_track
            if tr is not None and ev["unit"] == tr["unit"] and tr["phase"] in ("iv", "disp"):
                if tr["phase"] == "iv":
                    tr["post_iv_ep"], tr["post_iv_hp"] = ev["ep"], ev["hp"]
                    tr["phase"] = "disp"
                else:
                    tr["disp_hits"] += 1
                    if ev["ep"] > 0:
                        tr["disp_hit_ep"] += 1
                self._mark(tr, u, ev["hp"], ev["ep"])
                if ev["hp"] <= 0:
                    tr["died"] = 1
                    tr["phase"] = "done"
            return
        if t == "stance":
            tr = self.ep_track
            if tr is not None and ev["unit"] == tr["unit"] and tr["phase"] == "disp" and ev["new"] == "READY":
                u = eng.u(ev["unit"])
                tr.update(returned=1, ret_ep=u.ep, ret_hp_ratio=round(u.hp / u.d.hp_max, 3), phase="done")
                self._mark(tr, u, u.hp, u.ep)
            return

    @staticmethod
    def _mark(tr, u, hp, ep):
        if hp <= 0 or ep <= 0:
            return
        r = hp / u.d.hp_max
        for th, k in ((0.75, "w75"), (0.5, "w50"), (0.25, "w25")):
            if r <= th:
                tr[k] = 1


def _one(args):
    tag, rules, seed, policy, intel = args
    cfg = load_battle_config(party="party_v05_C0", rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    eng = make_engine(cfg, seed, policy, intel)
    tr = EarlyTracer(eng)
    eng.listeners.append(tr)
    eng.run()
    D, P = tag.split("_")[:2]
    meta = {"D": D, "P": P, "enemy_intel": intel, "seed": seed, "winner": eng.stats.winner}
    fi = tr.first_iv or {}
    fa = tr.first_atk or {}
    ep = tr.ep_track or {}
    b = dict(meta,
             total_enemy_turns=tr.enemy_turns, total_enemy_attacks=tr.enemy_attacks,
             has_iv=int(bool(fi)),
             fi_unit=fi.get("unit", ""), fi_enemy_turns=fi.get("enemy_turns", ""),
             fi_enemy_attacks=fi.get("enemy_attacks", ""), fi_ep=fi.get("ep", ""), fi_ep_max=fi.get("ep_max", ""),
             fi_hp=fi.get("hp", ""), fi_hp_max=fi.get("hp_max", ""), fi_target_rank=fi.get("target_rank", ""),
             fi_round=fi.get("round", ""),
             fa_attacker=fa.get("attacker", ""), fa_target_rank=fa.get("target_rank", ""),
             fa_reach_ok=fa.get("reach_ok", ""), fa_window=fa.get("window", ""), fa_intervened=fa.get("intervened", ""),
             fa_no_iv_cat=fa.get("no_iv_cat", ""), fa_target_ep=fa.get("target_ep", ""),
             fe_unit=ep.get("unit", ""), fe_post_iv_ep=ep.get("post_iv_ep", ""), fe_post_iv_hp=ep.get("post_iv_hp", ""),
             fe_disp_hits=ep.get("disp_hits", ""), fe_disp_hit_ep=ep.get("disp_hit_ep", ""),
             fe_w75=ep.get("w75", ""), fe_w50=ep.get("w50", ""), fe_w25=ep.get("w25", ""),
             fe_returned=ep.get("returned", ""), fe_ret_ep=ep.get("ret_ep", ""),
             fe_ret_hp_ratio=ep.get("ret_hp_ratio", ""), fe_died=ep.get("died", ""))
    units = [dict(meta, **u) for u in tr.units.values()]
    atks = [dict(meta, **a) for a in tr.attacks]
    return b, units, atks


def run(out_dir="out", workers=None):
    jobs = []
    for D in DS:
        for P in PS:
            tag = f"{D}_{P}_x1.75"
            with open(Path(out_dir) / f"wolves_5v5_v6s1_{tag}_battles.csv", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    jobs.append((tag, f"rules_v06_{D}_{P}.yaml", int(r["seed"]), r["policy"], int(r["enemy_intel"])))
    workers = workers or max(1, os.cpu_count() or 2)
    B, U, A = [], [], []
    with ProcessPoolExecutor(workers) as ex:
        for b, u, a in ex.map(_one, jobs, chunksize=50):
            B.append(b)
            U += u
            A += a
    write_csv(Path(out_dir) / "v06_early_battles.csv", B)
    write_csv(Path(out_dir) / "v06_early_units.csv", U)
    write_csv(Path(out_dir) / "v06_early_attacks.csv", A)
    return B, U, A


if __name__ == "__main__":
    B, U, A = run()
    print(len(B), "battles", len(U), "unit rows", len(A), "attack rows")
