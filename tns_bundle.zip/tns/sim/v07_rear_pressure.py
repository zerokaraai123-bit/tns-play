"""Ver0.7 実験Bの補足: REAR EP Protection で、敵の狙いとREARへの被弾がどう変わったか。
python -m tns.sim.v07_rear_pressure > out/v07_rear_pressure.md   （同じシードで再実行して聞き取るだけ）"""
from __future__ import annotations

import csv
from collections import Counter
from concurrent.futures import ProcessPoolExecutor

from ..config_loader import load_battle_config
from ..model.enums import Side
from .runner import make_engine


def _one(job):
    D, P, pol, seed, intel = job
    cfg = load_battle_config(party="party_v05_C0", rules=f"rules_v07_{D}_{P}_A.yaml", ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    eng = make_engine(cfg, seed, pol, intel)
    c = Counter()

    def L(ev, e):
        if ev["t"] == "attack_declared":
            a, t = e.u(ev["unit"]), e.u(ev["target"])
            if a.side is Side.ENEMY:
                kind = "wolf" if a.d.id.startswith("wolf") else a.d.id
                c[f"att_{kind}_{t.rank.value}"] += 1
        elif ev["t"] == "damage":
            u, a = e.u(ev["unit"]), e.u(ev["attacker"])
            if u.side is Side.ALLY and u.rank.value == "REAR":
                c["rear_hits"] += 1
                c["rear_ep"] += ev.get("ep_spent") or 0
                c["rear_dmg"] += ev["dmg"]
                if a.d.id.startswith("wolf"):
                    c["rear_hits_wolf"] += 1
    eng.listeners.append(L)
    eng.run()
    return c


def main():
    print("| D×P | 方針 | 敵の攻撃: 狼(近接)→FRONT | 狼→REAR（開いた経路から） | リーダー→REAR | 投擲兵→REAR | 敵攻撃に占めるREAR狙い | REARが自分で受けた攻撃/戦 | うち狼から | REARの肉体ダメージ/戦 |")
    print("|---|---|---|---|---|---|---|---|---|---|")
    for D, P in (("D1", "P2"), ("D2", "P2")):
        with open(f"out/wolves_5v5_v6s1_{D}_{P}_x1.75_battles.csv", encoding="utf-8-sig") as f:
            seeds = [(int(r["seed"]), int(r["enemy_intel"])) for r in csv.DictReader(f)]
        for pol in ("situational", "rear_ep_protect"):
            tot = Counter()
            with ProcessPoolExecutor() as ex:
                for c in ex.map(_one, [(D, P, pol, s, i) for s, i in seeds], chunksize=25):
                    tot.update(c)
            n = len(seeds)
            att = sum(v for k, v in tot.items() if k.startswith("att_"))
            rear = sum(v for k, v in tot.items() if k.startswith("att_") and k.endswith("REAR"))
            print(f"| {D}×{P} | {'Current' if pol == 'situational' else 'Protect'} | {tot['att_wolf_FRONT'] / n:.2f} | {tot['att_wolf_REAR'] / n:.2f} | "
                  f"{tot['att_leader_REAR'] / n:.2f} | {tot['att_thrower_REAR'] / n:.2f} | {rear / att:.1%} | {tot['rear_hits'] / n:.2f} | "
                  f"{tot['rear_hits_wolf'] / n:.2f} | {tot['rear_dmg'] / n:.1f} |")


if __name__ == "__main__":
    main()
