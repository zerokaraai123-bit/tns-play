"""v06_trace_early の集計表。 python -m tns.sim.v06_trace_early_report > out/v06_early_tables.md"""
from __future__ import annotations

import csv
import statistics
from collections import Counter, defaultdict

DJ = {"D1": "D1", "D15": "D1.5", "D2": "D2", "D3": "D3"}
PS = ("P0", "P1", "P2", "P3")
IJ = {"0": "低", "1": "通常", "2": "高", "3": "戦術"}
UJ = {"adel": "アデル(EP50)", "vanguard": "前衛2(EP40)"}


def load(p):
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def pct(a, b):
    return f"{a / b:.1%}" if b else "-"


def ms(xs, fmt="{:.1f}"):
    xs = [x for x in xs if x is not None]
    if not xs:
        return "-"
    return f"{fmt.format(statistics.mean(xs))} / {fmt.format(statistics.median(xs))}"


def build():
    B = load("out/v06_early_battles.csv")
    U = load("out/v06_early_units.csv")
    A = load("out/v06_early_attacks.csv")
    L = []

    # ---------------- 1-3
    L.append("#### E1 最初の介入まで（戦闘単位。最初に介入した前衛について）  値は「平均 / 中央値」")
    L.append("| D×P | 戦闘数 | 介入が起きた戦闘 | 最初の介入までの敵行動数 | 最初の介入時の前衛EP | 同 最大EP比 | 同 HP比 | その前衛が介入前に自己防御した回数 | 介入前の自己防御で使ったEP | 最初の介入の対象がREAR |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    ukey = {(u["D"], u["P"], u["seed"], u["enemy_intel"], u["unit"]): u for u in U}

    def row(bs, label):
        iv = [b for b in bs if b["has_iv"] == "1"]
        us = [ukey[(b["D"], b["P"], b["seed"], b["enemy_intel"], b["fi_unit"])] for b in iv]
        return (f"| {label} | {len(bs)} | {pct(len(iv), len(bs))} | {ms([num(b['fi_enemy_turns']) for b in iv])} | "
                f"{ms([num(b['fi_ep']) for b in iv])} | {ms([num(b['fi_ep']) / num(b['fi_ep_max']) for b in iv], '{:.0%}')} | "
                f"{ms([num(b['fi_hp']) / num(b['fi_hp_max']) for b in iv], '{:.0%}')} | "
                f"{ms([num(u['selfdef_before']) for u in us])} | {ms([num(u['selfdef_ep_before']) for u in us])} | "
                f"{pct(sum(1 for b in iv if b['fi_target_rank'] == 'REAR'), len(iv))} |")

    byDP = defaultdict(list)
    for b in B:
        byDP[(b["D"], b["P"])].append(b)
    for D in DJ:
        for P in PS:
            L.append(row(byDP[(D, P)], f"{DJ[D]}×{P}"))
    L.append(row(B, "**全体**"))
    byI = defaultdict(list)
    for b in B:
        byI[b["enemy_intel"]].append(b)
    L.append("\n敵知能別（全D×P合算）")
    L.append("| 敵知能 | 戦闘数 | 介入が起きた戦闘 | 最初の介入までの敵行動数 | 最初の介入時の前衛EP | 同 最大EP比 | 同 HP比 | 介入前の自己防御回数 | 介入前の自己防御EP | 対象がREAR |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for i in "0123":
        L.append(row(byI[i], IJ[i]))

    # 前衛ごと
    L.append("\n#### E2 前衛ごと（全条件）: 自分の最初の介入までに、自分が狙われた回数・自己防御・EP")
    L.append("| 前衛 | 介入した戦闘 | 自分の最初の介入までの敵行動数 | それまでに自分が狙われた回数 | 自己防御回数 | うち完全防御 | 自己防御EP | 介入時EP | 介入時EP0の割合 | 戦闘全体のEP使途: 自己防御 / 介入の一撃 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for uid in ("adel", "vanguard"):
        us = [u for u in U if u["unit"] == uid]
        iv = [u for u in us if u["iv"] != "0"]
        sd = sum(num(u["ep_spent_selfdef_total"]) for u in us)
        ivs = sum(num(u["ep_spent_iv_total"]) for u in us)
        L.append(f"| {UJ[uid]} | {pct(len(iv), len(us))} | {ms([num(u['first_iv_enemy_turns']) for u in iv])} | "
                 f"{ms([num(u['targeted_before']) for u in iv])} | {ms([num(u['selfdef_before']) for u in iv])} | "
                 f"{ms([num(u['selfdef_full_before']) for u in iv])} | {ms([num(u['selfdef_ep_before']) for u in iv])} | "
                 f"{ms([num(u['first_iv_ep']) for u in iv])} | {pct(sum(1 for u in iv if num(u['first_iv_ep']) <= 0), len(iv))} | "
                 f"{pct(sd, sd + ivs)} / {pct(ivs, sd + ivs)} |")

    # ---------------- 4-6
    def early(as_, k=5):
        e = [a for a in as_ if int(a["attack_no"]) <= k]
        rear = [a for a in e if a["target_rank"] == "REAR"]
        reach = [a for a in rear if a["reach_ok"] == "1"]
        elig = [a for a in reach if num(a["front_eligible"]) and num(a["front_eligible"]) > 0]
        ivd = [a for a in elig if a["intervened"] == "1"]
        no = [a for a in elig if a["intervened"] != "1"]
        return e, rear, reach, elig, ivd, no

    L.append("\n#### E3 序盤（敵の攻撃1〜5回目）にREARが狙われたか・介入できたか・介入したか")
    L.append("| 区分 | 序盤の敵攻撃 | うちREAR狙い | REAR狙いのうち届いた | 介入可能（READYの前衛あり） | 実際に介入 | 介入可能なのに介入せず | REAR狙いの攻撃者 |")
    L.append("|---|---|---|---|---|---|---|---|")
    byD = defaultdict(list)
    byAI = defaultdict(list)
    for a in A:
        byD[a["D"]].append(a)
        byAI[a["enemy_intel"]].append(a)

    def erow(label, as_):
        e, rear, reach, elig, ivd, no = early(as_)
        who = Counter(a["attacker"] for a in rear)
        whos = "、".join(f"{k} {pct(v, len(rear))}" for k, v in who.most_common(3))
        return (f"| {label} | {len(e)} | {len(rear)}（{pct(len(rear), len(e))}） | {pct(len(reach), len(rear))} | "
                f"{len(elig)}（{pct(len(elig), len(rear))}） | {len(ivd)}（{pct(len(ivd), len(elig))}） | {len(no)}（{pct(len(no), len(elig))}） | {whos} |")

    for D in DJ:
        L.append(erow(DJ[D], byD[D]))
    for i in "0123":
        L.append(erow("知能" + IJ[i], byAI[i]))
    L.append(erow("**全体**", A))

    # 6 理由
    L.append("\n#### E4 介入可能なのに介入しなかった理由（序盤1〜5回目のREAR狙い）")
    _, rear, _, elig, ivd, no = early(A)
    L.append("| 理由（状況判断AIが出した損失の比較から分類） | 件数 | 割合 | そのときの対象REARのEP（中央値） | 対象が実際に防御した | 実際のHPダメージ（中央値） |")
    L.append("|---|---|---|---|---|---|")
    for cat, n in Counter(a["no_iv_cat"] for a in no).most_common():
        xs = [a for a in no if a["no_iv_cat"] == cat]
        L.append(f"| {cat or '不明'} | {n} | {pct(n, len(no))} | {statistics.median(num(a['target_ep']) for a in xs):.0f} | "
                 f"{pct(sum(1 for a in xs if a['target_defended'] == '1'), len(xs))} | "
                 f"{statistics.median(num(a['dmg']) or 0 for a in xs):.0f} |")
    if ivd:
        L.append(f"| （参考）実際に介入したとき | {len(ivd)} | - | {statistics.median(num(a['target_ep']) for a in ivd):.0f} | - | - |")
    # 届かなかった・介入不能
    noel = [a for a in rear if a["reach_ok"] == "1" and not (num(a["front_eligible"]) or 0)]
    if noel:
        L.append(f"\nREAR狙いで介入できなかった（READYの前衛がいない）{len(noel)}件の前衛の状態: " +
                 "、".join(f"{k} {v}" for k, v in Counter(a["front_states"] for a in noel).most_common(5)))

    # 全攻撃での介入時の対象EP
    L.append("\n#### E5 （参考）開始から10回目までの敵攻撃全体で、介入が起きた／起きなかったときの対象のEP")
    allel = [a for a in A if (num(a["front_eligible"]) or 0) > 0 and a["reach_ok"] == "1"]
    for rk in ("FRONT", "REAR"):
        x = [a for a in allel if a["target_rank"] == rk]
        y = [a for a in x if a["intervened"] == "1"]
        z = [a for a in x if a["intervened"] != "1"]
        L.append(f"- 対象{rk}: 介入可能{len(x)}件、介入{len(y)}件（{pct(len(y), len(x))}）。介入したときの対象EP中央値 "
                 f"{statistics.median(num(a['target_ep']) for a in y) if y else '-'}、しなかったとき {statistics.median(num(a['target_ep']) for a in z) if z else '-'}。"
                 f"介入しなかった理由の最多: {Counter(a['no_iv_cat'] for a in z).most_common(1)[0][0] if z else '-'}（{pct(Counter(a['no_iv_cat'] for a in z).most_common(1)[0][1], len(z)) if z else '-'}）")

    # ---------------- 7-9
    L.append("\n#### E6 敵の初撃がREARを狙ったケース")
    L.append("| D | 初撃がREAR | うち介入可能 | うち介入した | 介入しなかった理由の最多 | 介入直後の前衛EP（平均/中央値） | 介入直後EP0 | 離脱中に生身被弾 | HP75%以下＋EP残存 | HP50%以下＋EP残存 | HP25%以下＋EP残存 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    bD = defaultdict(list)
    for b in B:
        bD[b["D"]].append(b)

    def frow(label, bs):
        r = [b for b in bs if b["fa_target_rank"] == "REAR"]
        el = [b for b in r if b["fa_window"] == "1"]
        iv = [b for b in r if b["fa_intervened"] == "1"]
        no = Counter(b["fa_no_iv_cat"] for b in el if b["fa_intervened"] != "1")
        top = f"{no.most_common(1)[0][0]}（{pct(no.most_common(1)[0][1], sum(no.values()))}）" if no else "-"
        eps = [num(b["fe_post_iv_ep"]) for b in iv]
        g = lambda k: sum(1 for b in iv if b[k] == "1")
        dh = sum(1 for b in iv if (num(b["fe_disp_hits"]) or 0) > 0)
        return (f"| {label} | {len(r)}（{pct(len(r), len(bs))}） | {pct(len(el), len(r))} | {len(iv)}（{pct(len(iv), len(r))}） | {top} | "
                f"{ms(eps)} | {pct(sum(1 for e in eps if e is not None and e <= 0), len(iv))} | {pct(dh, len(iv))} | "
                f"{g('fe_w75')}（{pct(g('fe_w75'), len(iv))}） | {g('fe_w50')}（{pct(g('fe_w50'), len(iv))}） | {g('fe_w25')}（{pct(g('fe_w25'), len(iv))}） |")

    for D in DJ:
        L.append(frow(DJ[D], bD[D]))
    L.append(frow("**全体**", B))
    L.append("\n初撃の攻撃者と狙い（全体）: " + "、".join(f"{k} {pct(v, len(B))}" for k, v in
                                               Counter(f"{b['fa_attacker']}→{b['fa_target_rank']}" for b in B).most_common(6)))

    # ---------------- 代替: 最初の介入（対象REAR/FRONT）のその後  ※ v06_trace_episodes.csv と突き合わせ
    E = load("out/v06_trace_episodes.csv")
    idx = defaultdict(list)
    for e in E:
        idx[(e["D"], e["P"], e["enemy_intel"], e["seed"], e["unit"], e["round"])].append(e)
    pairs = []
    for b in B:
        if b["has_iv"] != "1":
            continue
        c = [e for e in idx[(b["D"], b["P"], b["enemy_intel"], b["seed"], b["fi_unit"], b["fi_round"])]
             if e["pre_ep"] == b["fi_ep"] and e["pre_hp"] == b["fi_hp"]]
        if c:
            pairs.append((b, c[0]))
    L.append(f"\n#### E7 （8・9の代替）戦闘で最初の介入のその後（対象別）  突き合わせ {len(pairs)}件")
    L.append("| D | 対象 | 件数 | 介入直前EP（平均/中央値） | 介入で使ったEP（中央値） | 介入直後EP（平均/中央値） | 介入直後EP0 | 離脱中に生身被弾 | HP75%以下＋EP残存 | HP50%以下＋EP残存 | HP25%以下＋EP残存 | 復帰後に防御を使用 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for D in list(DJ) + [None]:
        for rk in ("REAR", "FRONT"):
            rs = [(b, e) for b, e in pairs if b["fi_target_rank"] == rk and (D is None or b["D"] == D)]
            n = len(rs)
            if not n:
                continue
            f = lambda k: sum(1 for b, e in rs if e[k] == "1")
            L.append(f"| {DJ[D] if D else '**全体**'} | {rk} | {n} | {ms([num(e['pre_ep']) for b, e in rs])} | "
                     f"{statistics.median(num(e['iv_ep_used']) for b, e in rs):.0f} | {ms([num(e['post_iv_ep']) for b, e in rs])} | "
                     f"{pct(sum(1 for b, e in rs if num(e['post_iv_ep']) <= 0), n)} | {pct(sum(1 for b, e in rs if num(e['disp_hits']) > 0), n)} | "
                     f"{f('w75')}（{pct(f('w75'), n)}） | {f('w50')}（{pct(f('w50'), n)}） | {f('w25')}（{pct(f('w25'), n)}） | "
                     f"{pct(sum(1 for b, e in rs if e['outcome'] == 'USED'), n)} |")

    # ---------------- 介入の順番ごとのEP
    g = defaultdict(list)
    for e in E:
        g[(e["D"], e["P"], e["enemy_intel"], e["seed"], e["unit"])].append(e)
    byk = defaultdict(list)
    for es in g.values():
        es.sort(key=lambda e: (int(e["round"]), -num(e["pre_ep"])))
        for i, e in enumerate(es, 1):
            byk[min(i, 6)].append(e)
    L.append("\n#### E8 同じ前衛の何回目の介入か（全条件）: 介入直前EP・EP0の割合・その後")
    L.append("| 何回目 | 件数（全介入に占める割合） | 介入直前EP（平均/中央値） | 介入時EP0 | 介入の一撃後もEP残存 | HP75%以下＋EP残存 | HP50%以下＋EP残存 | B 復帰時EP0 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for k in sorted(byk):
        es = byk[k]
        n = len(es)
        L.append(f"| {'%d回目' % k if k < 6 else '6回目以降'} | {n}（{pct(n, len(E))}） | {ms([num(e['pre_ep']) for e in es])} | "
                 f"{pct(sum(1 for e in es if num(e['pre_ep']) <= 0), n)} | {pct(sum(1 for e in es if num(e['post_iv_ep']) > 0), n)} | "
                 f"{pct(sum(1 for e in es if e['w75'] == '1'), n)} | {pct(sum(1 for e in es if e['w50'] == '1'), n)} | "
                 f"{pct(sum(1 for e in es if e['outcome'] == 'B'), n)} |")
    return "\n".join(L)


if __name__ == "__main__":
    print(build())
