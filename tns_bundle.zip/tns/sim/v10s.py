"""Ver0.10.1 感度確認: 「戦闘不能者は攻撃対象外」という仮仕様の影響。
Ver0.10中心条件（q=0.585・f(0.5)=0.85）で、現行仮仕様 と「戦闘不能の味方も敵の攻撃対象になる」を同一シードで比較する。
python -m tns.sim.v10s"""
from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..model.enums import Side
from .csv_export import write_csv
from .v08 import summarize_records
from .v09 import seeds
from .v10 import V10Tracer, build

OUT = Path("out/v10s")
RULES = {"current": "q058_f85", "inctgt": "q058_f85_inctgt", "inctgt2": "q058_f85_inctgt2",
         "incap4": "q058_f85_incap4"}  # inctgt2 = 補足: 双方とも戦闘不能者を攻撃できる
POLS = ("v9", "v10", "never", "always")


class SensTracer(V10Tracer):
    def __init__(self, eng, ally):
        super().__init__(eng, ally)
        self.interveners = set()

    def __call__(self, ev, eng):
        t = ev["t"]
        c = self.c
        if t == "attack_declared":
            a, tg = eng.u(ev["unit"]), eng.u(ev["target"])
            if a.side is Side.ENEMY and tg.side is Side.ALLY and tg.incapacitated:
                c[f"att_on_incap_{tg.rank.value}"] += 1
                c[f"att_on_incap_i{a.intel_effective}"] += 1
                if not any(u.alive for u in eng.state.units.values() if u.side is Side.ALLY):
                    c["att_on_incap_forced"] += 1
            elif a.side is Side.ALLY and tg.side is Side.ENEMY and tg.incapacitated:
                c["ally_att_on_incap_enemy"] += 1
        elif t == "intervened":
            f, tg = eng.u(ev["unit"]), eng.u(ev["target"])
            if f.side is Side.ALLY:
                self.interveners.add(f.id)
                if tg.incapacitated:
                    c["iv_for_incap"] += 1
        elif t == "revive":
            c[f"revive_{eng.u(ev['unit']).rank.value}"] += 1
        elif t == "ko" and ev.get("after_incap"):
            u = eng.u(ev["unit"])
            if u.side is Side.ALLY:
                c[f"incap_to_dead_{u.rank.value}"] += 1
            return        # 戦闘不能→死亡は、初回の離脱（戦闘不能）として既に数えてあるので二重に数えない
        super().__call__(ev, eng)


def _one(job):
    rk, pol, seed, intel = job
    eng, ally = build(RULES[rk], pol, seed, intel)
    tr = SensTracer(eng, ally)
    eng.listeners.append(tr)
    eng.run()
    row = {"rule": rk, "policy": pol, "seed": seed, "enemy_intel": intel, "winner": eng.stats.winner}
    row.update(tr.c)
    row["finish_cand"] = eng.stats.c.get("v10_finish_cand", 0)
    row["seen_healer"] = int(bool(getattr(eng, "seen_healers", {}).get(Side.ALLY)))
    row.update(summarize_records(ally.records, tr))
    ivs = [r for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR"]
    row["ivrec_n"] = len(ivs)
    row["ivrec_protect"] = sum(1 for r in ivs if r["choice"] != "self")
    fr = [u for u in eng.state.units.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    row["n_interveners"] = len(tr.interveners)
    row["interveners_survived"] = sum(1 for u in fr if u.id in tr.interveners and u.alive)
    for u in eng.state.units.values():
        if u.side is Side.ALLY:
            rk2 = u.rank.value
            row[f"end_dead_{rk2}"] = row.get(f"end_dead_{rk2}", 0) + int(u.hp <= 0)
            row[f"end_incap_{rk2}"] = row.get(f"end_incap_{rk2}", 0) + int(u.incapacitated)
            row[f"end_out_{rk2}"] = row.get(f"end_out_{rk2}", 0) + int(not u.alive)
    return row


def run(rules=None, step=1, tag_suffix=""):
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")[::step]
    for rk in (rules or RULES):
        for pol in POLS:
            tag = f"{rk}_{pol}{tag_suffix}"
            if (OUT / f"{tag}_battles.csv").exists():
                print("skip", tag, flush=True)
                continue
            with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                B = list(ex.map(_one, [(rk, pol, s, i) for s, i in S], chunksize=20))
            keys = sorted({k for b in B for k in b})
            write_csv(OUT / f"{tag}_battles.csv", [{k: b.get(k, 0) for k in keys} for b in B])
            print("done", tag, flush=True)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "smoke":      # Ver0.10.2 動作確認: 4戦に1戦（250戦）
        run(rules=["incap4"], step=4, tag_suffix="_smoke")
    else:
        run(rules=["current", "inctgt", "inctgt2"])
