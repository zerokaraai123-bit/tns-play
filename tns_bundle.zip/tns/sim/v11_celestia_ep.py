"""セレスティアのEP: 戦闘終了時の残りと、攻撃できたのに使わなかった理由（手番ごと）。
python -m tns.sim.v11_celestia_ep [cond] [policy]   ※判断・ルールは一切変えない（記録だけ）
"""
from __future__ import annotations

import csv
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..model.enums import ActionKind, Side
from .v09 import seeds
from .v11 import build

OUT = Path("out/v11")


def classify(ctl, u):
    """_mage_value と同じ計算で候補を並べ、選ばれる行動と「使わなかった理由」を返す（判断には影響しない）。"""
    eng = ctl.engine
    spend = eng.spendable_ep(u)
    pi = ctl.protection(u)
    cands = []
    for v, aid, tid, cost in ctl.best_actions(u, spend):
        rest = ctl.regen_next(u, u.ep - cost)
        cands.append((v + ctl.v_rest(u, rest, pi), v, aid, cost, rest))
    cands.sort(key=lambda x: -x[0])
    best = cands[0]
    atk = [c for c in cands if c[2] in ("fire", "storm")]
    info = {"ep": u.ep, "choice": best[2], "pi": pi, "can_attack": bool(atk)}
    if not atk:
        info["cat"] = "攻撃不可（EP15未満）" if u.ep < 15 else "攻撃不可（届く敵なし）"
        return info
    if best[2] in ("fire", "storm"):
        info["cat"] = "攻撃した（" + ("炎嵐" if best[2] == "storm" else "攻撃魔法") + "）"
        return info
    if best[2] == "heal":
        info["cat"] = "治療にEPを使った"
        return info
    # 待機: 最良の攻撃との差を分解する
    a = max(atk, key=lambda c: c[0])
    r_w, r_a = best[4], a[4]
    def_w, def_a = ctl.v_def(u, r_w, pi), ctl.v_def(u, r_a, pi)
    heal = next((eng.actions[x] for x in u.d.action_ids if eng.actions[x].kind is ActionKind.HEAL), None)
    hv = ctl.proj_heal_value(u)[0] if heal else 0.0
    keep_heal_w = (heal is not None and heal.ep_cost <= r_w)
    rest_w = ctl.v_rest(u, r_w, pi)
    heal_branch = keep_heal_w and rest_w > def_w + 1e-9
    info.update(att_value=a[1], att_aid=a[2], opp_cost=rest_w - ctl.v_rest(u, r_a, pi), def_drop=def_w - def_a,
                heal_proj=hv, heal_branch=int(heal_branch))
    if heal_branch:
        info["cat"] = "待機：次の治療用に温存"
    else:
        info["cat"] = "待機：自衛用に温存"
    return info


class Probe(ValueAllyController):
    def _mage_value(self, u):
        if u.id == "celestia":
            info = classify(self, u)
            info["round"] = self.engine.state.round
            info["front_ok"] = int(self._front_alive_ok())
            info["foes"] = sum(1 for x in self.engine.state.side_units(Side.ENEMY))
            self.turns.append(info)
        d = super()._mage_value(u)
        if u.id == "celestia" and self.turns:
            assert d.action_id == self.turns[-1]["choice"] or (d.action_id == "wait" and self.turns[-1]["choice"] == "wait"), \
                (d.action_id, self.turns[-1]["choice"])
        return d


def _one(job):
    cond, pol, seed, intel = job
    import tns.sim.v11 as V
    orig = V.ValueAllyController
    V.ValueAllyController = Probe
    try:
        eng, ally = build(cond, pol, seed, intel)
    finally:
        V.ValueAllyController = orig
    ally.turns = []
    spent = Counter()
    state = {"out_ep": None, "out_kind": None}

    def lis(ev, e):
        t = ev["t"]
        if t in ("attack_declared", "area_attack", "heal") and ev.get("unit") == "celestia":
            act = ev.get("action") or ("heal" if t == "heal" else None)
            if t == "heal":
                spent["治療"] += ev.get("ep_cost", 0) or 0
            elif t == "area_attack":
                spent["炎嵐"] += e.actions[act].ep_cost
            elif act == "fire":
                spent["攻撃魔法"] += e.actions[act].ep_cost
        elif t == "damage" and ev.get("unit") == "celestia":
            spent["自衛（エーテル防御）"] += ev.get("ep_spent", 0) or 0
        elif t == "ko" and ev.get("unit") == "celestia" and state["out_ep"] is None:
            state["out_ep"] = e.u("celestia").ep
            state["out_kind"] = "戦闘不能" if ev.get("incap") else "死亡"
    eng.listeners.append(lis)
    eng.run()
    c = eng.u("celestia")
    win = eng.stats.winner == "ally"
    if state["out_ep"] is not None and not c.alive:
        end = f"倒れた（{state['out_kind']}）"
    elif state["out_ep"] is not None:
        end = "倒れたが治療で復帰し、最後まで残った"
    else:
        end = "最後まで戦えた"
    return dict(seed=seed, intel=intel, win=int(win), end_ep=c.ep, end=end, out_ep=state["out_ep"],
                spent=dict(spent), turns=ally.turns)


def run(cond="q058_f85_incap4", pol="v11"):
    S = seeds("q058_f85")
    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
        R = list(ex.map(_one, [(cond, pol, s, i) for s, i in S], chunksize=20))
    n = len(R)
    print(f"## セレスティアのEP（{cond}・{pol}・{n}戦。最大EP100、戦闘中の自然回復なし）\n")
    print(f"- 戦闘終了時の残りEP: 平均 **{sum(r['end_ep'] for r in R)/n:.1f}**")
    sp = Counter()
    for r in R:
        sp.update(r["spent"])
    print("- 1戦あたりのEPの使い道: " + "、".join(f"{k} {v/n:.1f}" for k, v in sp.most_common())
          + f"、残り {sum(r['end_ep'] for r in R)/n:.1f}")
    print("\n| 戦闘終了時の状態 | 戦数 | 勝ち | 残りEPの平均 | 残りEP合計に占める割合 |\n|---|---|---|---|---|")
    tot = sum(r["end_ep"] for r in R) or 1
    for k in sorted({r["end"] for r in R}):
        g = [r for r in R if r["end"] == k]
        print(f"| {k} | {len(g)} | {sum(r['win'] for r in g)} | {sum(r['end_ep'] for r in g)/len(g):.1f} | "
              f"{sum(r['end_ep'] for r in g)/tot*100:.0f}% |")
    T = [t for r in R for t in r["turns"]]
    print(f"\n### セレスティアの手番（全{len(T)}手番、1戦あたり{len(T)/n:.1f}）\n")
    print("| 分類 | 手番数 | 割合 | 1戦あたり | 平均EP |\n|---|---|---|---|---|")
    cats = Counter(t["cat"] for t in T)
    for k, v in cats.most_common():
        g = [t for t in T if t["cat"] == k]
        print(f"| {k} | {v} | {v/len(T)*100:.0f}% | {v/n:.2f} | {sum(t['ep'] for t in g)/v:.0f} |")
    A = [t for t in T if t["can_attack"]]
    W = [t for t in A if t["choice"] == "wait"]
    print(f"\n攻撃できた手番 {len(A)}（1戦 {len(A)/n:.2f}）のうち、待機 {len(W)}（{len(W)/max(1,len(A))*100:.0f}%）")
    if W:
        print("\n**待機した手番の中身（平均）**\n")
        print("| 分類 | 手番 | 平均EP | 撃てば得た価値 | 温存した価値（機会費用） | 前衛が健在 | 守られる見込みπ |\n|---|---|---|---|---|---|---|")
        for k in ("待機：自衛用に温存", "待機：次の治療用に温存"):
            g = [t for t in W if t["cat"] == k]
            if not g:
                continue
            m = lambda x: sum(t[x] for t in g) / len(g)
            print(f"| {k} | {len(g)} | {m('ep'):.0f} | {m('att_value'):.2f} | {m('opp_cost'):.2f} | {m('front_ok')*100:.0f}% | {m('pi'):.2f} |")
        print("\n**待機した手番のEP帯**\n")
        print("| EP帯 | 待機 | うち自衛用 | うち治療用 | 同じEP帯で攻撃した手番 |\n|---|---|---|---|---|")
        for lo, hi in ((15, 30), (30, 45), (45, 60), (60, 80), (80, 101)):
            g = [t for t in W if lo <= t["ep"] < hi]
            ga = [t for t in A if lo <= t["ep"] < hi and t["choice"] in ("fire", "storm")]
            print(f"| {lo}〜{hi - 1} | {len(g)} | {sum(t['cat'].endswith('自衛用に温存') for t in g)} | "
                  f"{sum(t['cat'].endswith('治療用に温存') for t in g)} | {len(ga)} |")
    with open(OUT / f"celestia_ep_turns_{cond}_{pol}.csv", "w", newline="", encoding="utf-8-sig") as fh:
        keys = sorted({k for t in T for k in t})
        w = csv.DictWriter(fh, keys + ["seed", "intel"])
        w.writeheader()
        for r in R:
            for t in r["turns"]:
                w.writerow({**t, "seed": r["seed"], "intel": r["intel"]})


if __name__ == "__main__":
    run(*sys.argv[1:])
