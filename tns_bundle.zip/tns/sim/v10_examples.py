"""Ver0.10 具体例。 python -m tns.sim.v10_examples > out/v10_examples.md
A: 穴の危険を承知で介入した / B: 目の前なら守る方が安いが、離脱後の危険で見送った / C: 同じ局面でVer0.9とVer0.10の判断が分かれた
"""
from __future__ import annotations

import csv
import random
from pathlib import Path

from .v10 import build

OUT = Path("out/v10")
NAME = {"adel": "アデル", "vanguard": "前衛2", "celestia": "セレスティア", "archer": "弓手", "toolsmith": "エーテル学者",
        "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "leader": "狼リーダー", "thrower": "投擲兵"}
COND = "q058_f85"


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def text(r, title):
    t, fr = NAME.get(r["target"], r["target"]), NAME.get(r["f"], r["f"])
    prot = r["choice"] != "self"
    hole_parts = [p for p in str(r["parts"]).split("; ") if p.startswith(("穴", "離脱中", "自衛不能"))]
    return "\n".join([
        f"### {title}（seed={r['seed']}・敵知能={r['enemy_intel']}・{r['round']}巡・{'Ver0.10' if r.get('hole_model') == 'v10' else 'Ver0.9'}のAI）",
        f"- 攻撃: {NAME.get(r['attacker'], r['attacker'])} → {t}（期待威力 {r['raw']}）",
        f"- {t}: HP {r['t_hp']}/{r['t_hpmax']}・EP {r['t_ep']}・自衛の必要EP {r['t_need']}"
        + (f"・次の手番の最善手 {r['t_next']}（自衛すると {r['t_next_after']}）" if r.get("t_next_after") and r["t_next_after"] != r["t_next"] else f"・次の手番の最善手 {r.get('t_next') or '-'}"),
        f"- {fr}: HP {r['f_hpabs']}/{r['f_hpmax']}・EP {r['f_ep']}・介入の必要EP {r['f_need']}",
        f"- {fr}が持ち場に戻るまでに動く敵: {int(f(r.get('n_enemy_actions')))}回"
        + (f"（うち穴を使える敵: {r['hole_users']}）" if r.get("hole_users") else "（穴を使える敵はいない）"),
        f"- 予測される追加被害: 後衛への追加攻撃 {f(r.get('pred_extra_rear_hits')):.2f}回（後衛のEP {f(r.get('pred_rear_ep')):.1f}・生身 {f(r.get('pred_rear_hp')):.1f}）、"
        f"{fr}への攻撃 {f(r.get('pred_front_hits')):.2f}回（生身 {f(r.get('pred_front_dmg')):.1f}）",
        f"- 介入しない場合の総期待損失: {f(r['L_self']):.2f}（{t}が自分で対応）",
        f"- 介入する場合の総期待損失: {f(r['L_iv']):.2f}（目の前の一撃だけなら {f(r.get('L_iv_now')):.2f}、離脱後の危険 " + ("、".join(hole_parts) or "0") + "）",
        f"- **最終判断: {'★ ' + fr + 'が介入' if prot else '☆ ' + t + 'が自分で対応'}**",
    ])


def lockstep_diffs(n_seeds=120):
    """同じシードを Ver0.9 と Ver0.10 で並べて再生し、判断記録が初めて食い違った局面（それまでは同一の戦闘）を集める。"""
    from .v09 import seeds
    out = []
    for s, i in seeds(COND)[:n_seeds]:
        recs = {}
        for p in ("v9", "v10"):
            eng, ally = build(COND, p, s, i)
            eng.run()
            recs[p] = [r for r in ally.records if r["kind"] == "iv"]
        for a, b in zip(recs["v9"], recs["v10"]):
            same_state = all(a[k] == b[k] for k in ("target", "attacker", "t_ep", "f_ep", "t_hp", "f_hpabs", "round"))
            if not same_state:
                break
            if a["choice"] != b["choice"] and a["trank"] == "REAR":
                out.append((dict(a, seed=s, enemy_intel=i), dict(b, seed=s, enemy_intel=i)))
                break
    return out


def main():
    p = OUT / f"{COND}_v10_ivdecisions.csv"
    R = [r for r in csv.DictReader(open(p, encoding="utf-8-sig")) if r["trank"] == "REAR"]
    rnd = random.Random(3)
    A = [r for r in R if r["choice"] != "self" and f(r.get("pred_extra_rear_hits")) >= 0.5 and "穴からの追加被弾" in r["parts"]]
    B = [r for r in R if r["choice"] == "self" and f(r.get("L_iv_now")) + 0.02 < f(r["L_self"])]
    L = [f"# Ver0.10 具体例（条件 q=0.585・f(0.5)=0.85。損失の単位は戦力点）\n"]
    L.append(f"## A｜穴の危険を承知で介入した例（{len(A)}件から）\n")
    for r in rnd.sample(A, min(3, len(A))):
        L.append(text(r, "A") + "\n")
    L.append(f"## B｜目の前の一撃だけなら守る方が安いが、持ち場を離れる危険で見送った例（{len(B)}件から）\n")
    for r in rnd.sample(B, min(3, len(B))):
        L.append(text(r, "B") + "\n")
    D = lockstep_diffs()
    L.append(f"## C｜同じ局面でVer0.9とVer0.10の判断が分かれた例（最初の120シードを両AIで再生し、それまで同一だった戦闘で初めて判断が分かれた {len(D)} 件から）\n")
    v9p = sum(1 for a, b in D if a["choice"] != "self")
    L.append(f"内訳: Ver0.9は介入→Ver0.10は見送り {v9p}件、Ver0.9は見送り→Ver0.10は介入 {len(D) - v9p}件\n")
    for a, b in D[:4]:
        L.append(text(a, "C-Ver0.9") + "\n")
        L.append(text(b, "C-Ver0.10") + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
