"""Ver0.9: 実効肉体強度モデル × 介入価値の分岐点探索。

土台は自由設計実験の M1（現行ルール＋炎嵐・治療＋価値AI v3）、D1.5×P2・Speed+Incap。肉体強度モデル以外は変更しない。
格子: q（肉体強度→防御効率の効き）× f(0.5)（負傷による発揮効率の追加低下）。比較用に現行P2も同じ土台で回す。
方針: 価値AI / Never Protect（一切介入しない）/ Always Protect（REAR狙いは可能なら常に介入）。各1,000戦・同一シード。

使い方: python -m tns.sim.v09
"""
from __future__ import annotations

import csv
import math
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController, eff_strength
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..model.enums import ActionKind, Side
from .csv_export import write_csv
from .v08 import V08Tracer, summarize_records

OUT = Path("out/v09")
GRID = ["q0_f100"] + [f"{q}_{f}" for q in ("q058", "q10", "q15", "q20") for f in ("f100", "f85", "f70", "f50")] + ["q058_fP2"]
POLICIES = {"value": None, "never": "never_iv", "always": "always_iv"}


EXTRA = ["q075_f85", "q075_f70", "D2_q058_f70", "D2_q10_f70", "D2_q15_f70", "D2_q20_f70"]   # 境界の確認と難易度の確認（追加）


def rules_of(cond):
    return "rules_v08_D15_base.yaml" if cond == "P2ref" else f"rules_v09_{cond}.yaml"


def build(cond, policy, seed, intel, log=False):
    cfg = load_battle_config(party="party_v08", rules=rules_of(cond), ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    ally = ValueAllyController(cfg.ally_policies, probe=POLICIES[policy])
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)},
                       seed=seed, enemy_intel=intel, log_enabled=log)
    return eng, ally


class V09Tracer(V08Tracer):
    """V08Tracer に、実効肉体強度・必要EPの差・温存EPとその使い道・介入後の被弾を足す。"""

    def __init__(self, eng):
        super().__init__(eng)
        self.saved_pool = Counter()

    def _first_attack(self, u):
        eng = self.eng
        return next((eng.actions[a] for a in u.d.action_ids if eng.actions[a].kind is ActionKind.ATTACK), None)

    def __call__(self, ev, eng):
        t = ev["t"]
        c = self.c
        if t == "attack_declared":
            a, tg = eng.u(ev["unit"]), eng.u(ev["target"])
            if a.side is Side.ENEMY and tg.rank.value == "REAR" and tg.side is Side.ALLY:
                act = eng.actions[ev["action"]]
                raw = eng.damage.expected(a, act)
                fronts = [f for f in eng.state.side_units(Side.ALLY) if f.rank.value == "FRONT"]
                c["rearatk_n"] += 1
                c["rearatk_S_rear"] += eff_strength(eng.defense, tg)
                c["rearatk_need_rear"] += eng.defense.required_ep(tg, raw)
                if fronts:
                    best = min(fronts, key=lambda f: eng.defense.required_ep(f, raw))
                    c["rearatk_withfront"] += 1
                    c["rearatk_S_front"] += eff_strength(eng.defense, best)
                    c["rearatk_need_front"] += eng.defense.required_ep(best, raw)
                    c["rearatk_need_rear_wf"] += eng.defense.required_ep(tg, raw)
            if a.side is Side.ALLY and a.id in self.saved_pool:
                cost = eng.actions[ev["action"]].ep_cost if ev["action"] == "fire" else 0
                self._convert(a.id, cost)
        elif t == "area_attack" and ev["unit"] in self.saved_pool:
            self._convert(ev["unit"], eng.actions[ev["action"]].ep_cost)
        elif t == "heal" and ev["unit"] in self.saved_pool:
            self._convert(ev["unit"], ev.get("ep_cost", 0) or 0)
        elif t == "intervened":
            f, tg = eng.u(ev["unit"]), eng.u(ev["target"])
            if f.side is Side.ALLY and tg.rank.value == "REAR":
                atk = eng.u(ev["attacker"])
                raw = eng.damage.expected(atk, self._first_attack(atk))
                need_r = math.ceil(eng.defense.required_ep(tg, raw) - 1e-9)
                saved = min(tg.ep, need_r) if eng.defense_allowed(tg) else 0
                c["iv_rear_saved_ep"] += saved
                c["iv_rear_front_need"] += math.ceil(eng.defense.required_ep(f, raw) - 1e-9)
                self.saved_pool[tg.id] += saved
        elif t == "damage":
            u = eng.u(ev["unit"])
            if u.side is Side.ALLY and u.rank.value == "FRONT" and u.displaced and u.id not in self.pending_iv \
                    and eng.u(ev["attacker"]).side is Side.ENEMY:
                c["front_disp_hits"] += 1
                c["front_disp_dmg"] += ev["dmg"]
        super().__call__(ev, eng)

    def _convert(self, uid, cost):
        take = min(self.saved_pool[uid], cost)
        if take > 0:
            self.saved_pool[uid] -= take
            self.c["saved_converted"] += take


def _one(job):
    cond, policy, seed, intel = job
    eng, ally = build(cond, policy, seed, intel)
    tr = V09Tracer(eng)
    eng.listeners.append(tr)
    eng.run()
    row = {"cond": cond, "policy": policy, "seed": seed, "enemy_intel": intel, "winner": eng.stats.winner,
           "rounds": eng.stats.rounds}
    row.update(tr.c)
    row.update(summarize_records(ally.records, tr))
    ivs = [r for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR"]
    row["ivrec_n"] = len(ivs)
    row["ivrec_protect"] = sum(1 for r in ivs if r["choice"] != "self")
    row["ev_protect_sum"] = sum(r["L_self"] - r["L_iv"] for r in ivs if r["choice"] != "self")
    row["ev_self_sum"] = sum(r["L_self"] - r["L_iv"] for r in ivs if r["choice"] == "self")
    ivrows = [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k != "text"}
              | {"cond": cond, "policy": policy, "seed": seed, "enemy_intel": intel} for r in ivs] if policy == "value" else []
    return row, ivrows


def seeds(cond=""):
    lv = "D2" if cond.startswith("D2_") else "D15"
    with open(f"out/wolves_5v5_v6s1_{lv}_P2_x1.75_battles.csv", encoding="utf-8-sig") as f:
        return [(int(r["seed"]), int(r["enemy_intel"])) for r in csv.DictReader(f)][:1000]


def run(workers=None):
    OUT.mkdir(parents=True, exist_ok=True)
    workers = workers or max(1, os.cpu_count() or 2)
    for cond in GRID + EXTRA:
        S = seeds(cond)
        for pol in POLICIES:
            tag = f"{cond}_{pol}"
            if (OUT / f"{tag}_battles.csv").exists():
                print("skip", tag, flush=True)
                continue
            B, IV = [], []
            with ProcessPoolExecutor(workers) as ex:
                for b, iv in ex.map(_one, [(cond, pol, s, i) for s, i in S], chunksize=20):
                    B.append(b)
                    IV += iv
            keys = sorted({k for b in B for k in b})
            write_csv(OUT / f"{tag}_battles.csv", [{k: b.get(k, 0) for k in keys} for b in B])
            if IV:
                write_csv(OUT / f"{tag}_ivdecisions.csv", IV)
            print("done", tag, flush=True)


if __name__ == "__main__":
    run()
