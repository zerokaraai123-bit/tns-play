"""Ver0.4 段階1/2 の比較表を Markdown で出力する。
python -m tns.sim.v04_report out s1 > tables.md
"""
from __future__ import annotations

import math
import sys
from collections import defaultdict
from pathlib import Path

from .v04_analysis import analyze, load

MODELS = ["v03", "A", "B", "C"]
MODEL_JA = {"v03": "v0.3防御(比較)", "A": "A弱", "B": "B中", "C": "C強"}
MULTS = [1, 2, 3, 5]
import os
if os.environ.get("V04_MULTS"):
    MULTS = [float(x) if "." in x else int(x) for x in os.environ["V04_MULTS"].split(",")]
INTELS = ["0", "1", "2", "3"]
INTEL_JA = {"0": "低", "1": "通常", "2": "高", "3": "戦術"}
POLS = ["situational", "always", "never"]


def collect(out_dir, prefix):
    data = {}
    for m in MODELS:
        for x in MULTS:
            p = Path(out_dir) / f"wolves_5v5_{prefix}_{m}_x{x}_battles.csv"
            if not p.exists():
                continue
            rows = load(p)
            g = defaultdict(list)
            for r in rows:
                g[(r["enemy_intel"], r["policy"])].append(r)
                g[("all", r["policy"])].append(r)
                g[(r["enemy_intel"], "all")].append(r)
                g[("all", "all")].append(r)
            data[(m, x)] = {k: analyze(v) for k, v in g.items()}
    return data


def fmt(v, kind="f"):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "-"
    if kind == "%":
        return f"{v:.0%}"
    if kind == "f1":
        return f"{v:.1f}"
    if kind == "f2":
        return f"{v:.2f}"
    return f"{v:.2f}"


def table_by_mult(data, key, kind, intel="all", pol="all", title=""):
    L = [f"\n#### {title}", "| 前衛HP | " + " | ".join(MODEL_JA[m] for m in MODELS) + " |",
         "|---|" + "---|" * len(MODELS)]
    for x in MULTS:
        cells = [fmt(data.get((m, x), {}).get((intel, pol), {}).get(key), kind) for m in MODELS]
        L.append(f"| ×{x} | " + " | ".join(cells) + " |")
    return "\n".join(L)


def table_intel_mult(data, key, kind, pol, title):
    L = [f"\n#### {title}", "| 知能 | 前衛HP | " + " | ".join(MODEL_JA[m] for m in MODELS) + " |",
         "|---|---|" + "---|" * len(MODELS)]
    for i in INTELS:
        for x in MULTS:
            cells = [fmt(data.get((m, x), {}).get((i, pol), {}).get(key), kind) for m in MODELS]
            L.append(f"| {INTEL_JA[i]} | ×{x} | " + " | ".join(cells) + " |")
    return "\n".join(L)


def ep_bucket_table(data, side, rank, x=1):
    L = [f"\n#### ⑤ HP残量帯ごとの「1ダメージを防ぎ切るのに必要なEP」と防御展開の割合（{side} {rank}、前衛HP×{x}、全条件平均）",
         "| HP残量帯 | " + " | ".join(MODEL_JA[m] for m in MODELS) + " |", "|---|" + "---|" * len(MODELS)]
    names = ["100〜75%", "75〜50%", "50〜25%", "25〜0%"]
    for b in range(4):
        cells = []
        for m in MODELS:
            a = data.get((m, x), {}).get(("all", "all"), {})
            tot = sum(a.get(f"def_count_{side}_{rank}_b{k}", 0) for k in range(4)) or 1
            cells.append(f"{fmt(a.get(f'need_per_dmg_{side}_{rank}_b{b}'), 'f2')}（{a.get(f'def_count_{side}_{rank}_b{b}', 0) / tot:.0%}）")
        L.append(f"| {names[b]} | " + " | ".join(cells) + " |")
    return "\n".join(L)


def build(out_dir, prefix):
    d = collect(out_dir, prefix)
    n_each = next(iter(next(iter(d.values())).values()))["n"] if d else 0
    S = [f"### 自動集計表（{prefix}）"]
    for pol in POLS:
        S.append(table_intel_mult(d, "win", "%", pol, f"勝率（味方方針 {pol}）"))
    S.append(table_by_mult(d, "draw", "%", title="引き分け率（30巡打ち切り、全知能・全方針）"))
    S.append(table_by_mult(d, "rounds", "f1", title="⑫ 戦闘巡数（全条件平均）"))
    for g, ja in (("ally_front", "味方FRONT"), ("ally_rear", "味方REAR"), ("enemy", "敵")):
        S.append(table_by_mult(d, f"{g}_first_hit_t", "f1", title=f"① 最初のHP直撃までの全体行動数（{ja}、直撃を受けた個体の平均）"))
        S.append(table_by_mult(d, f"{g}_death_given_hit", "%", title=f"② 一度HPへ直撃した後に死亡した割合（{ja}）"))
        S.append(table_by_mult(d, f"{g}_hits_to_death", "f1", title=f"② 最初の直撃から死亡までに本人が受けた攻撃回数（{ja}、死亡した個体）"))
        S.append(table_by_mult(d, f"{g}_hit_to_death", "f1", title=f"② 最初の直撃から死亡までの全体行動数（{ja}）"))
        S.append(table_by_mult(d, f"{g}_half_to_death", "f1", title=f"③ HP50%以下から死亡までの全体行動数（{ja}）"))
        S.append(table_by_mult(d, f"{g}_ep_out_t", "f1", title=f"④ EP枯渇までの全体行動数（{ja}、枯渇した個体）"))
        S.append(table_by_mult(d, f"{g}_ep_out_rate", "%", title=f"④ EP枯渇した割合（{ja}）"))
        S.append(table_by_mult(d, f"{g}_death_rate", "%", title=f"⑧ 死亡率（{ja}）"))
        S.append(table_by_mult(d, f"{g}_focus_ratio", "f2", title=f"⑦ 直撃後の被攻撃シェア ÷ 直撃前（{ja}。1より大きいほど直撃後に狙われる）"))
    S.append(ep_bucket_table(d, "ally", "front", 1))
    S.append(ep_bucket_table(d, "ally", "rear", 1))
    S.append(ep_bucket_table(d, "enemy", "front", 1))
    S.append(table_by_mult(d, "partial_pierce_ally", "f1", title="⑥ 部分防御でHPへ貫通した回数（味方、1戦平均）"))
    S.append(table_by_mult(d, "partial_pierce_enemy", "f1", title="⑥ 部分防御でHPへ貫通した回数（敵、1戦平均）"))
    S.append(table_by_mult(d, "iv_prevented_hp_hit_ally", "f1", pol="situational", title="⑨ 介入で後衛等へのHP直撃を防いだ回数（状況判断、1戦平均）"))
    S.append(table_by_mult(d, "iv_prevented_collapse_ally", "f2", pol="situational", title="⑨ 介入でHP50%以下の味方を守った回数（状況判断）"))
    S.append(table_by_mult(d, "iv_prevented_ko_ally", "f2", pol="situational", title="⑨ 介入で致命傷を防いだ回数（状況判断）"))
    for pol in ("situational", "always"):
        S.append(table_by_mult(d, "breach_hp_hit_ally", "f2", pol=pol, title=f"⑩ 介入でOPENした経路からの侵入でHPへ通った回数（{pol}）"))
        S.append(table_by_mult(d, "breach_first_hp_hit_ally", "f2", pol=pol, title=f"⑩ それが『最初のHP直撃』になった回数＝崩壊の起点（{pol}）"))
        S.append(table_by_mult(d, "breach_kos_ally", "f2", pol=pol, title=f"⑩ 穴からの侵入で撃破された数（{pol}）"))
    for k, ja in (("enemy_front_rate", "敵のFRONT狙い率"), ("enemy_wounded_rate", "敵が負傷済みの相手を狙った率"),
                  ("enemy_weakest_rate", "敵が最もHP割合の低い相手を狙った率"), ("enemy_streak", "敵の同一標的連続攻撃")):
        S.append(table_intel_mult(d, k, "%" if "rate" in k else "f2", "situational", f"⑪ {ja}（状況判断）"))
    S.append(table_by_mult(d, "ally_hit_first_rate", "%", title="B: 味方が先にHP直撃を受けた戦闘の割合"))
    S.append(table_by_mult(d, "win_if_ally_hit_first", "%", title="B: 味方が先に直撃を受けた戦闘での味方勝率"))
    S.append(table_by_mult(d, "win_if_enemy_hit_first", "%", title="B: 敵が先に直撃を受けた戦闘での味方勝率"))
    return f"（各セル: 知能×方針の1条件あたり {n_each} 戦。『全条件』は知能4×方針3を合算）\n" + "\n".join(S)


if __name__ == "__main__":
    print(build(sys.argv[1], sys.argv[2]))
