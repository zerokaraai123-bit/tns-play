"""3FRONT比較の集計。 python -m tns.sim.v11f_report > out/v11f/report.md"""
from __future__ import annotations

import json
import math
import random
from collections import Counter

from .v11f import OUT, FORMS, CASTS
from .v11_timeline import NAME

NAME = dict(NAME, vanguard3="前衛3")
FN = {"old": "旧2FRONT", "center": "新3FRONT（中央）", "L": "3FRONT・L配置", "R": "3FRONT・R配置"}


def load(form, n, p):
    path = OUT / f"{form}_cast{n}_{p}.jsonl"
    return {(r["seed"], r["intel"]): r for r in map(json.loads, open(path, encoding="utf-8"))} if path.exists() else None


def mean(x):
    x = list(x)
    return sum(x) / len(x) if x else float("nan")


def pair(A, B):
    d = [A[k]["win"] - B[k]["win"] for k in A]
    n = len(d); m = sum(d) / n; sd = math.sqrt(sum((x - m) ** 2 for x in d) / (n - 1))
    return "%+.1f（z=%.1f）" % (m * 100, m / (sd / math.sqrt(n)) if sd else 0)


def ev(r, k):
    return [e for kk, e in r["E"] if kk == k]


def S(R):
    N = len(R)
    s = {"win": mean(r["win"] for r in R.values()) * 100, "rounds": mean(r["rounds"] for r in R.values()),
         "N": mean(r["N"] for r in R.values())}
    nf = next(iter(R.values()))["nf"]
    nr = next(iter(R.values()))["nr"]
    s["dead_F"] = mean(r["dead_F"] for r in R.values()) / nf * 100
    s["incap_F"] = mean(r["incap_F"] for r in R.values()) / nf * 100
    s["dead_R"] = mean(r["dead_R"] for r in R.values()) / nr * 100
    s["incap_R"] = mean(r["incap_R"] for r in R.values()) / nr * 100
    s["cel_dead"] = mean(r["cel_dead"] for r in R.values()) * 100
    s["cel_incap"] = mean(r["cel_incap"] for r in R.values()) * 100
    ends = [e for r in R.values() for e in ev(r, "cast_end")]
    starts = [e for r in R.values() for e in ev(r, "cast_start")]
    s["starts"] = len(starts) / N
    s["storms"] = sum(len(ev(r, "storm")) for r in R.values()) / N
    s["cancel"] = sum(1 for e in ends if e["kind"] == "cast_cancel") / N
    s["cancel_incap"] = sum(1 for e in ends if e["kind"] == "cast_cancel" and e["reason"] == "戦闘不能") / N
    s["cancel_dead"] = sum(1 for e in ends if e["kind"] == "cast_cancel" and e["reason"] == "死亡") / N
    s["fail"] = sum(1 for e in ends if e["kind"] == "cast_fail") / N
    for lab, k, j in (("s1", "cast_start", 0), ("f1", "storm", 0), ("s2", "cast_start", 1), ("f2", "storm", 1)):
        x = [(ev(r, k)[j]["idx"], ev(r, k)[j]["idx"] / r["N"]) for r in R.values() if len(ev(r, k)) > j]
        s[lab] = (len(x) / N * 100, mean(a for a, _ in x), mean(b for _, b in x) * 100)
    # casting interventions
    T = [e for r in R.values() for e in ev(r, "target")]
    TC = [e for e in T if e["casting"]]
    s["tg_cast"] = len(TC) / N
    s["tg_cast_win"] = sum(e["window"] for e in TC) / N
    s["tg_cast_iv"] = sum(1 for e in TC if e["iv_by"]) / N
    s["ivrate"] = (sum(1 for e in TC if e["iv_by"]) / len(TC) * 100) if TC else float("nan")
    s["iv_fronts_mean"] = mean(e["n_iv_fronts"] for e in ends if e["tg"] > 0) if any(e["tg"] > 0 for e in ends) else 0
    s["iv2"] = sum(1 for e in ends if e["n_iv_fronts"] >= 2) / N
    s["iv3"] = sum(1 for e in ends if e["n_iv_fronts"] >= 3) / N
    s["iv_clean_done"] = sum(1 for e in ends if e["n_iv_fronts"] >= 1 and e["raw_hits"] == 0 and e["kind"] == "cast_complete") / N
    s["iv_casts"] = sum(1 for e in ends if e["n_iv_fronts"] >= 1) / N
    hold = Counter()
    for e in ends:
        for k, v in e["hold"].items():
            hold[int(k)] += v
    tot = sum(hold.values()) or 1
    s["hold"] = {k: hold[k] / tot * 100 for k in range(4)}
    C = Counter()
    for r in R.values():
        C.update(r["C"])
    for k in ("intr", "intr_cast", "intr_by_iv", "intr_cel", "intr_cel_cast", "phys_dmg", "phys_enemy_ep", "phys_dmg_early",
              "phys_enemy_ep_early", "mag_dmg", "mag_enemy_ep", "phys_dmg_adel", "phys_dmg_vanguard", "phys_dmg_vanguard3", "phys_dmg_archer",
              "phys_hits"):
        s[k] = C[k] / N
    s["melee_reach_cast"] = sum(e["melee_reach"] for e in ends) / N
    s["cast_raw1"] = sum(1 for e in ends if e["raw_hits"] == 1) / N
    s["cast_raw2"] = sum(1 for e in ends if e["raw_hits"] >= 2) / N
    s["cast_raw_any"] = sum(1 for e in ends if e["raw_hits"] >= 1) / N
    # EP
    sp = Counter()
    for r in R.values():
        for e in ev(r, "spend"):
            sp[e["cat"]] += e["ep"]
    for c in ("炎嵐", "攻撃魔法", "治療", "自衛"):
        s["ep_" + c] = sp[c] / N
    s["end_ep"] = mean(r["end_ep"] for r in R.values())
    def ep_at(r, p):
        lim, ep = p * r["N"], 100
        for k, e in r["E"]:
            if k == "sample":
                if e["idx"] <= lim:
                    ep = e["ep"]
                else:
                    break
        return ep if p < 1 else r["end_ep"]
    s["ept"] = [mean(ep_at(r, p) for r in R.values()) for p in (0, .2, .4, .6, .8, 1.0)]
    s["iv_rear"] = mean(r["iv_rear"] for r in R.values())
    s["cel_iv_all"] = sum(1 for e in T if e["iv_by"]) / N
    s["tg_all"] = len(T) / N
    return s


def main():
    D = {(f, n, p): load(f, n, p) for f in FORMS for n in CASTS for p in ("v11", "never")}
    D = {k: v for k, v in D.items() if v}
    X = {k: S(v) for k, v in D.items()}
    forms = [f for f in FORMS if (f, 0, "v11") in D]
    L = ["## 1. 詠唱 × 編成：基本の比較（同一シード各1,000戦）\n"]
    L.append("| 詠唱 | 編成 | 介入AI勝率 | Never勝率 | 介入AI−Never | 旧2FRONT比（介入AI） | 炎嵐発動/戦 | キャンセル/戦 | セレスティア 死亡/戦闘不能 | FRONT 死亡/戦闘不能（1人あたり） | 戦闘時間（巡） |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for n in CASTS:
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            a, b = X[f, n, "v11"], X[f, n, "never"]
            L.append(f"| {n} | {FN[f]} | {a['win']:.1f}% | {b['win']:.1f}% | {pair(D[f, n, 'v11'], D[f, n, 'never'])} | "
                     f"{'–' if f == 'old' else pair(D[f, n, 'v11'], D['old', n, 'v11'])} | {a['storms']:.2f} | {a['cancel']:.3f} | "
                     f"{a['cel_dead']:.0f}% / {a['cel_incap']:.0f}% | {a['dead_F']:.0f}% / {a['incap_F']:.0f}% | {a['rounds']:.1f} |")
    L.append("\n## 2. 前線（詠唱中に持ち場で経路を塞いでいた前衛の人数。詠唱中の行動ごとの割合）と前線突破（介入AI、1戦あたり）\n")
    L.append("| 詠唱 | 編成 | 3人 | 2人 | 1人 | 0人 | 前線突破（近接が後衛に到達） | うち詠唱中 | うち介入で開いた経路から | セレスティアへの到達 | うち詠唱中 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for n in CASTS:
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            a = X[f, n, "v11"]
            h = a["hold"]
            L.append(f"| {n} | {FN[f]} | " + " | ".join(f"{h[k]:.0f}%" if n else "–" for k in (3, 2, 1, 0)) +
                     f" | {a['intr']:.2f} | {a['intr_cast']:.2f} | {a['intr_by_iv']:.2f} | {a['intr_cel']:.2f} | {a['intr_cel_cast']:.2f} |")
    L.append("\n（Neverの前線突破/戦: " + "、".join(f"{FN[f]} 詠唱{n} {X[f, n, 'never']['intr']:.2f}" for f in forms for n in (4, 6) if (f, n, 'never') in X) + "）")
    L.append("\n## 3. 詠唱中の介入（介入AI、1戦あたり）\n")
    L.append("| 詠唱 | 編成 | 詠唱中に狙われた | 介入できた | 介入した | 介入率 | 1回の詠唱で介入した前衛の数（狙われた詠唱） | 2人以上が介入した詠唱 | 3人とも介入した詠唱 | 介入→無傷→発動成功 / 介入があった詠唱 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for n in (2, 4, 6):
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            a = X[f, n, "v11"]
            L.append(f"| {n} | {FN[f]} | {a['tg_cast']:.2f} | {a['tg_cast_win']:.2f} | {a['tg_cast_iv']:.2f} | {a['ivrate']:.0f}% | {a['iv_fronts_mean']:.2f} | "
                     f"{a['iv2']:.2f} | {a['iv3']:.2f} | {a['iv_clean_done']:.2f} / {a['iv_casts']:.2f} |")
    L.append("\n## 4. 詠唱中のセレスティア（介入AI / Never、1戦あたり）\n")
    L.append("| 詠唱 | 編成 | 方針 | 詠唱中に敵近接が到達 | 生身で被弾した詠唱 | 1回被弾 | 2回以上 | キャンセル（戦闘不能/死亡） |")
    L.append("|---|---|---|---|---|---|---|---|")
    for n in (4, 6):
        for f in forms:
            for p in ("v11", "never"):
                if (f, n, p) not in X:
                    continue
                a = X[f, n, p]
                L.append(f"| {n} | {FN[f]} | {'介入AI' if p == 'v11' else 'Never'} | {a['intr_cel_cast']:.2f} | {a['cast_raw_any']:.2f} | {a['cast_raw1']:.2f} | {a['cast_raw2']:.2f} | "
                         f"{a['cancel_incap']:.3f} / {a['cancel_dead']:.3f} |")
    L.append("\n## 5. 炎嵐のタイミング（介入AI。累積行動数 / 進行度）\n")
    L.append("| 詠唱 | 編成 | 詠唱開始/戦 | 発動/戦 | キャンセル/戦 | 1回目 開始 | 1回目 発動 | 2回目 開始 | 2回目 発動（発生率） |\n|---|---|---|---|---|---|---|---|---|")
    for n in CASTS:
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            a = X[f, n, "v11"]
            fmt = lambda t: f"{t[1]:.1f}（{t[2]:.0f}%）" if t[0] else "–"
            L.append(f"| {n} | {FN[f]} | {a['starts']:.2f} | {a['storms']:.2f} | {a['cancel']:.3f} | {fmt(a['s1'])} | {fmt(a['f1'])} | {fmt(a['s2'])} | {fmt(a['f2'])}（{a['f2'][0]:.0f}%） |")
    L.append("\n## 6. セレスティアのEP（介入AI）\n")
    L.append("| 詠唱 | 編成 | 0% | 20% | 40% | 60% | 80% | 100% | 炎嵐 | 攻撃魔法 | 治療 | 自衛 |\n|---|---|---|---|---|---|---|---|---|---|---|---|")
    for n in CASTS:
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            a = X[f, n, "v11"]
            L.append(f"| {n} | {FN[f]} | " + " | ".join(f"{v:.0f}" for v in a["ept"]) + " | " +
                     " | ".join(f"{a['ep_' + c]:.1f}" for c in ("炎嵐", "攻撃魔法", "治療", "自衛")) + " |")
    L.append("\n## 7. 味方の物理攻撃（弓手を外した影響を見るため。介入AI、1戦あたり）\n")
    L.append("| 詠唱 | 編成 | 物理で敵に与えた生身ダメ | うちアデル / 前衛2 / 前衛3 / 弓手 | 物理攻撃を敵がEPで防いだ量 | 序盤20行動の物理ダメ / 敵の防御EP | 炎嵐の生身ダメ / 炎嵐で敵が使ったEP |")
    L.append("|---|---|---|---|---|---|---|")
    for n in CASTS:
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            a = X[f, n, "v11"]
            L.append(f"| {n} | {FN[f]} | {a['phys_dmg']:.0f} | {a['phys_dmg_adel']:.0f} / {a['phys_dmg_vanguard']:.0f} / {a['phys_dmg_vanguard3']:.0f} / {a['phys_dmg_archer']:.0f} | "
                     f"{a['phys_enemy_ep']:.0f} | {a['phys_dmg_early']:.0f} / {a['phys_enemy_ep_early']:.0f} | {a['mag_dmg']:.0f} / {a['mag_enemy_ep']:.0f} |")
    L.append("\n## 8. 敵知能別の勝率（介入AI / Never）\n")
    L.append("| 詠唱 | 編成 | 低知能 | 通常 | 高知能 | 戦術級 |\n|---|---|---|---|---|---|")
    for n in CASTS:
        for f in forms:
            if (f, n, "v11") not in X:
                continue
            cells = []
            for i in range(4):
                w = lambda p: mean(r["win"] for r in D[f, n, p].values() if r["intel"] == i) * 100
                cells.append(f"{w('v11'):.0f} / {w('never'):.0f}")
            L.append(f"| {n} | {FN[f]} | " + " | ".join(cells) + " |")
    print("\n".join(L))
    examples(D)


def render(r, title):
    out = [f"### {title}｜seed={r['seed']}・敵知能={['低知能','通常','高知能','戦術級'][r['intel']]}・{'勝ち' if r['win'] else '負け'}・総行動{r['N']}", "```"]
    ep = 100
    cast_hold = None
    for k, e in r["E"]:
        if k == "sample" and e["casting"]:
            if cast_hold != e["hold"]:
                cast_hold = e["hold"]
                out.append(f"行動{e['idx']:3d}   （詠唱中・持ち場の前衛 {e['hold']}人）")
        elif k == "sample":
            cast_hold = None
        if k == "spend" and e["cat"] in ("攻撃魔法", "治療"):
            out.append(f"行動{e['idx']:3d} セレスティア {e['cat']}  EP{ep}→{ep - e['ep']}")
            ep -= e["ep"]
        elif k == "spend" and e["cat"] == "自衛":
            ep -= e["ep"]
        elif k == "cast_start":
            out.append(f"行動{e['idx']:3d} セレスティア 炎嵐の詠唱開始（HP{e['hp']}・EP{e['ep']}）")
        elif k == "storm":
            out.append(f"行動{e['idx']:3d} ★炎嵐発動  EP{ep}→{ep - 40}")
            ep -= 40
        elif k == "cast_end" and e["kind"] != "cast_complete":
            out.append(f"行動{e['idx']:3d} ✕詠唱{'キャンセル（' + str(e['reason']) + '）' if e['kind'] == 'cast_cancel' else '失敗'}")
        elif k == "target" and (e["casting"] or e["idx"] < 25):
            tag = "【詠唱中】" if e["casting"] else ""
            how = "近接・経路" + str(e["via"]) + "から突破" if e["via"] else ("近接" if e["melee"] else "遠隔")
            res = (f"→ {NAME[e['iv_by']]}が介入" if e["iv_by"] else
                   ("→ 介入できる前衛なし" if not e["window"] else "→ 前衛は見送り") + f"・生身{e['dmg']}（HP{e['hp']}→{e['hp_after']}）")
            out.append(f"行動{e['idx']:3d} {tag}{NAME.get(e['attacker'], e['attacker'])}がセレスティアを狙う（{how}・持ち場の前衛{e['hold']}人） {res}")
    out.append("```")
    return "\n".join(out)


def examples(D):
    rnd = random.Random(5)
    print("\n## 9. 代表的な戦闘ログ（介入AI。持ち場の前衛＝経路を塞いでいる前衛の人数）\n")
    C6, O6 = D.get(("center", 6, "v11")), D.get(("old", 6, "v11"))
    C4 = D.get(("center", 4, "v11"))
    if not C6 or not O6:
        return
    def ends(r):
        return ev(r, "cast_end")
    A = [r for r in C4.values() if any(e["n_iv_fronts"] == 1 and e["kind"] == "cast_complete" and e["raw_hits"] == 0 for e in ends(r))]
    B = [r for r in C6.values() if any(e["n_iv_fronts"] >= 2 and e["kind"] == "cast_complete" and e["raw_hits"] == 0 and e["melee_reach"] == 0 for e in ends(r))]
    Cc = [r for r in C6.values() if any(e["kind"] == "cast_cancel" for e in ends(r))]
    Dd = [k for k in C6 if any(e["kind"] == "cast_cancel" for e in ends(O6[k])) and not any(e["kind"] == "cast_cancel" for e in ends(C6[k]))
          and len(ev(C6[k], "storm")) > len(ev(O6[k], "storm"))]
    E0 = D.get(("center", 0, "v11")); O0 = D.get(("old", 0, "v11"))
    Ee = [k for k in O0 if O0[k]["win"] and not E0[k]["win"]] if E0 and O0 else []
    print(f"- 候補数: A {len(A)}／B {len(B)}／C {len(Cc)}／D {len(Dd)}／E {len(Ee)}\n")
    for lab, pool in (("A｜詠唱4・中央配置：前衛1人が介入→残り2人が前線維持→炎嵐成功", A),
                      ("B｜詠唱6・中央配置：2人以上が連続介入→それでも前線は持ちこたえ→炎嵐成功", B),
                      ("C｜詠唱6・中央配置：3FRONTでも突破され→被弾→キャンセル", Cc)):
        for r in rnd.sample(pool, min(1, len(pool))):
            print(render(r, lab) + "\n")
    for k in rnd.sample(Dd, min(1, len(Dd))):
        print(render(O6[k], "D｜同じシード・旧2FRONT 詠唱6（キャンセル）") + "\n")
        print(render(C6[k], "D｜同じシード・新3FRONT（中央）詠唱6（成功）") + "\n")
    for k in rnd.sample(Ee, min(1, len(Ee))):
        r0, r1 = O0[k], E0[k]
        print(f"### E｜詠唱0：旧2FRONTなら勝ち・新3FRONTで負け（seed={k[0]}・敵知能={['低知能','通常','高知能','戦術級'][k[1]]}）\n")
        print(f"- 旧: 総行動{r0['N']}・物理ダメ{r0['C'].get('phys_dmg',0)}（弓手{r0['C'].get('phys_dmg_archer',0)}）・敵がEPで防いだ{r0['C'].get('phys_enemy_ep',0)}")
        print(f"- 新: 総行動{r1['N']}・物理ダメ{r1['C'].get('phys_dmg',0)}（前衛3 {r1['C'].get('phys_dmg_vanguard3',0)}）・敵がEPで防いだ{r1['C'].get('phys_enemy_ep',0)}\n")


if __name__ == "__main__":
    main()
