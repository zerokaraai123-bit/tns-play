"""Ver0.13 介入AIの時間認識修正（PA-190）・速度方式の再比較。
- 旧介入AI = v11（Ver0.11の価値判断のまま）／時間認識修正版 = v13／基準 = Never
- 速度方式 A/B/C（Ver0.12 の TimelineEngine）。敵: 6体・投擲兵追加。seed 0〜999
- 介入1回ごとに「予測（旧の見積もり o_ / 時間認識版 n_）」と「実際」を記録する
python -m tns.sim.v13 smoke|s1|grid|v11log|calib|eq|sens
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..model.enums import Rank, Side
from . import v12
from .v12 import _one as _one12

OUT = Path("out/v13")
LOG = OUT / "progress.log"
PRED_KEYS = ("o_win", "o_nact", "o_fdmg", "o_rhits", "o_rhp", "n_win", "n_nact", "n_fdmg", "n_rhits", "n_rhp")


def _hook(eng, ally):
    """介入ごとの予測と実際、REARの被弾、介入しなかったことで失った味方 などを記録する。"""
    U = eng.state.units
    st = {"open": {}, "done": [], "win_pend": None, "intr": {}, "iv_now": None}
    C = {"rear_raw": 0, "rear_raw_hp": 0, "lost_no_iv": 0, "front_ko_disp": 0, "iv_front_raw": 0, "iv_front_hp": 0,
         "front_incap_ever": 0, "front_dead": 0}
    incap_seen = set()

    def close(f, t_now, reason):
        o = st["open"].pop(f, None)
        if o is None:
            return
        o["a_win"] = round(t_now - o["t0"], 4)
        o["end"] = reason
        st["done"].append(o)

    def lis(ev, e):
        t = ev["t"]
        if t == "turn_start":
            u = ev["unit"]
            if u in st["open"]:
                close(u, e.cur_time, "turn")
            elif U[u].side is Side.ENEMY:
                for o in st["open"].values():
                    o["a_nact"] += 1
            st["win_pend"] = None
            st["iv_now"] = None
        elif t == "intervention_window":
            tg = U[ev["target"]]
            if tg.side is Side.ALLY:
                st["win_pend"] = (ev["target"], ev["attacker"], e.action_index, False)
        elif t == "intervened":
            f = ev["unit"]
            if U[f].side is Side.ALLY:
                if st["win_pend"]:
                    w = st["win_pend"]
                    st["win_pend"] = (w[0], w[1], w[2], True)
                rec = next((r for r in reversed(ally.records) if r.get("kind") == "iv" and r.get("f") == f
                            and r.get("choice") == "move"), {})
                o = {k: rec.get(k) for k in PRED_KEYS}
                o.update(f=f, tg=ev["target"], trank=U[ev["target"]].rank.value, casting=int("celestia" in e.casting),
                         t0=e.cur_time, a_nact=0, a_fdmg=0, a_ihit=0, a_rhits=0, a_rhp=0, ko=0,
                         hp0=U[f].hp, pred_cost=rec.get("L_iv"), L_self=rec.get("L_self"))
                close(f, e.cur_time, "re")       # 念のため（再介入はルール上起きない）
                st["open"][f] = o
                st["iv_now"] = f
        elif t == "intrusion":
            cb = ev.get("caused_by")
            if cb in st["open"] and U[ev["target"]].side is Side.ALLY:
                st["open"][cb]["a_rhits"] += 1
                st["intr"][(ev["unit"], ev["target"])] = cb
        elif t == "damage":
            v, a, d = ev["unit"], ev["attacker"], ev.get("dmg", 0) or 0
            if U[a].side is not Side.ENEMY or U[v].side is not Side.ALLY:
                return
            if U[v].rank is Rank.REAR and d > 0:
                C["rear_raw"] += 1
                C["rear_raw_hp"] += d
            if v in st["open"]:
                o = st["open"][v]
                if st["iv_now"] == v:
                    o["a_ihit"] += d
                    if d > 0:
                        C["iv_front_raw"] += 1
                        C["iv_front_hp"] += d
                else:
                    o["a_fdmg"] += d
                    if d > 0:
                        C["iv_front_raw"] += 1
                        C["iv_front_hp"] += d
            cb = st["intr"].pop((a, v), None)
            if cb is not None:
                for o in [st["open"].get(cb)] + [x for x in st["done"][-3:] if x["f"] == cb]:
                    if o is not None:
                        o["a_rhp"] += d
                        break
        elif t == "ko":
            u = ev["unit"]
            x = U[u]
            if x.side is not Side.ALLY:
                return
            if x.rank is Rank.FRONT:
                if ev.get("incap"):
                    incap_seen.add(u)
                if u in st["open"]:
                    st["open"][u]["ko"] = 1
                    C["front_ko_disp"] += 1
                    close(u, e.cur_time, "ko")
            w = st["win_pend"]
            if x.rank is Rank.REAR and w and w[0] == u and not w[3] and w[2] == e.action_index:
                C["lost_no_iv"] += 1
    eng.listeners.append(lis)

    def fin():
        for f in list(st["open"]):
            close(f, eng.cur_time, "end")
        fronts = [u for u in U.values() if u.side is Side.ALLY and u.rank is Rank.FRONT]
        C["front_incap_ever"] = len(incap_seen | {u.id for u in fronts if u.incapacitated})
        C["front_dead"] = sum(1 for u in fronts if u.hp <= 0)
        dec = [r for r in ally.records if r.get("kind") == "iv" and r.get("trank") == "REAR"]
        C["iv_dec_rear"] = len(dec)
        C["iv_dec_rear_go"] = sum(1 for r in dec if r.get("choice") != "self")
        return {"C": C, "iv": [[o.get(k) for k in IVF] for o in st["done"]]}
    return fin


IVF = ("f", "tg", "trank", "casting", "end", "ko", "hp0", "a_win", "a_nact", "a_fdmg", "a_ihit", "a_rhits", "a_rhp",
       "pred_cost", "L_self") + PRED_KEYS


def _one(job):
    r = _one12(job, hook=_hook)
    ex = r["C"].pop("_extra")
    r["X"] = ex["C"]
    r["iv"] = ex["iv"]
    return r


def path_of(m, n, pol, intel, tag=""):
    return OUT / f"{m}{tag}_cast{n}_{pol}_i{intel}.jsonl"


def log(msg):
    OUT.mkdir(parents=True, exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(msg + "\n")
    print(msg, flush=True)


def run(methods, casts, pols, intels, tag="", nseed=1000, mods=None, seed0=0):
    import time
    OUT.mkdir(parents=True, exist_ok=True)
    for it in intels:
        for pol in pols:
            for m in methods:
                for n in casts:
                    path = path_of(m, n, pol, it, tag)
                    if path.exists():
                        continue
                    t0 = time.time()
                    jobs = [(m, n, pol, s, it, None, 0.0, None, None, mods) for s in range(seed0, seed0 + nseed)]
                    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                        R = list(ex.map(_one, jobs, chunksize=20))
                    tmp = path.with_suffix(".tmp")
                    with open(tmp, "w", encoding="utf-8") as fh:
                        for r in R:
                            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
                    tmp.rename(path)
                    log(f"done {path.name} win={sum(r['win'] for r in R) / len(R):.3f} n={len(R)} {time.time() - t0:.0f}s")


CASTS4 = (0, 2, 4, 6)
SENS = {"ally+10": {"ally": 1.1}, "ally-10": {"ally": 0.9}, "enemy+10": {"enemy": 1.1}, "enemy-10": {"enemy": 0.9},
        "adel+20": {"adel": 1.2}, "celestia+20": {"celestia": 1.2}}


def calib(methods, target=(0.55, 0.65), n=400):
    """二分探索（敵の power 倍率）。各点 n 戦（seed 0〜n−1）。結果は out/v13/power.json"""
    res = {}
    pj = OUT / "power.json"
    if pj.exists():
        res = json.loads(pj.read_text())
    for m in methods:
        if m in res:
            continue
        lo, hi = 0.4, 1.0
        best = None
        for _ in range(8):
            p = round((lo + hi) / 2, 3)
            run((m,), (0,), ("v13",), (1,), tag=f"_pw{p}", nseed=n, mods={"enemy_power": p})
            R = [json.loads(l) for l in open(path_of(m, 0, "v13", 1, f"_pw{p}"))]
            w = sum(r["win"] for r in R) / len(R)
            log(f"calib {m} power x{p} -> win {w:.3f}")
            if best is None or abs(w - 0.6) < abs(best[1] - 0.6):
                best = (p, w)
            if target[0] <= w <= target[1]:
                break
            if w < target[0]:
                hi = p
            else:
                lo = p
        res[m] = best[0]
        log(f"calib {m}: 採用 power x{best[0]} (win {best[1]:.3f})")
        pj.write_text(json.dumps(res))
    return res


if __name__ == "__main__":
    a = sys.argv[1] if len(sys.argv) > 1 else "smoke"
    M = ("A", "B", "C")
    if a == "smoke":
        run(M, (0,), ("v11", "v13"), (1,), tag="_smoke", nseed=40)
    elif a == "s1":              # 第1段階: 通常知能・詠唱0
        run(M, (0,), ("v13", "v11"), (1,))
    elif a == "grid":            # 時間認識修正版: 全知能 × 詠唱0/2/4/6
        run(M, (0, 2, 4, 6), ("v13",), (3, 1, 0, 2))
    elif a == "v11log":          # 旧介入AIの記録（勝率は Ver0.12 と同一 seed で一致することを確認済み。詳細記録だけのため一部の条件）
        run(M, (4,), ("v11",), (1,))
        run(M, (0, 4), ("v11",), (3,))
    elif a == "neverlog":        # Never の詳細記録（介入しなかったことで倒れたREAR など）
        run(M, (0, 4), ("never",), (1, 3))
    elif a == "calib":           # 第2段階: 敵の攻撃力（power）1つだけで、通常知能・詠唱0・修正版AIを55〜65%へ
        calib(M)
    elif a == "eq":              # 難易度を揃えた比較（方式ごとに calib の倍率を使う）
        P = json.loads((OUT / "power.json").read_text())
        for m in M:
            mods = {"enemy_power": P[m]}
            run((m,), CASTS4, ("v13",), (1, 3, 0, 2), tag=f"_eq", mods=mods)
        for m in M:
            mods = {"enemy_power": P[m]}
            run((m,), CASTS4, ("never",), (1, 3, 0, 2), tag=f"_eq", nseed=500, mods=mods)
            run((m,), (0, 4), ("v11",), (1, 3), tag=f"_eq", nseed=500, mods=mods)
    elif a == "sens":            # 速度の感度分析（本検証とは別。難易度を揃えた条件・通常知能・詠唱0・修正版AI）
        P = json.loads((OUT / "power.json").read_text())
        for m in M:
            for lab, sp in SENS.items():
                run((m,), (0,), ("v13",), (1,), tag=f"_eq_{lab}", mods={"enemy_power": P[m], "speed": sp})
