"""Ver0.13 集計。python -m tns.sim.v13_report"""
from __future__ import annotations

import json
import math
from collections import Counter
from functools import lru_cache

from . import v12
from .v13 import IVF, OUT
from .v13 import path_of as p13

INAME = {0: "低知能", 1: "通常", 2: "高知能", 3: "戦術級"}
PNAME = {"v11": "旧介入AI", "v13": "時間認識修正版", "never": "Never"}
CASTS = (0, 2, 4, 6)
FR = ("adel", "vanguard3", "vanguard")


def avg(xs):
    xs = [x for x in xs if x is not None and not (isinstance(x, float) and math.isnan(x))]
    return sum(xs) / len(xs) if xs else float("nan")


def pct(x, d=1):
    return "—" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{100 * x:.{d}f}"


def f2(x, d=2):
    return "—" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{x:.{d}f}"


def tbl(head, rows):
    s = "| " + " | ".join(head) + " |\n|" + "---|" * len(head) + "\n"
    for r in rows:
        s += "| " + " | ".join(str(x) for x in r) + " |\n"
    return s


@lru_cache(maxsize=None)
def L(m, n, pol, it, tag=""):
    """Ver0.13 のファイルがあればそれを、無ければ Ver0.12 の同条件（同じ seed・同じエンジン）を読む。"""
    p = p13(m, n, pol, it, tag)
    src = "v13"
    if not p.exists():
        if tag:
            return None
        p = v12.path_of(m, n, pol, it)
        src = "v12"
        if not p.exists():
            return None
    out = []
    with open(p, encoding="utf-8") as fh:
        for l in fh:
            r = json.loads(l)
            C = Counter(r["C"])
            q = {"win": r["win"], "seed": r["seed"], "C": C, "X": r.get("X"), "src": src, "time": r["time"],
                 "N": r["N"], "dead_A": r["dead_A"], "cel_dead": r["cel_dead"],
                 "seq": r["seq"], "lost": r.get("lost", {})}
            q["iv"] = [dict(zip(IVF, x)) for x in r.get("iv", [])]
            out.append(q)
    return out


def wr(Q):
    return sum(q["win"] for q in Q) / len(Q)


def pair(Q1, Q2):
    m1 = {q["seed"]: q["win"] for q in Q1}
    d = [m1[q["seed"]] - q["win"] for q in Q2 if q["seed"] in m1]
    n = len(d)
    mu = sum(d) / n
    var = sum((x - mu) ** 2 for x in d) / (n - 1) if n > 1 else 0
    se = math.sqrt(var / n) if var > 0 else 0
    return mu, (mu / se if se else 0.0)


def sec_win(methods=("A", "B", "C"), tag="", pols=("v11", "v13", "never"), intels=(0, 1, 2, 3)):
    rows = []
    for it in intels:
        for m in methods:
            row = [INAME[it], m]
            ok = False
            for n in CASTS:
                Qs = {p: L(m, n, p, it, tag) for p in pols}
                cell = []
                for p in pols:
                    cell.append(pct(wr(Qs[p])) if Qs[p] else "—")
                if Qs.get("v13") and Qs.get("v11"):
                    d, z = pair(Qs["v13"], Qs["v11"])
                    cell.append(f"差{100*d:+.1f}(z={z:.1f})")
                ok = ok or any(Qs.values())
                row.append(" / ".join(cell))
            if ok:
                rows.append(row)
    return tbl(["知能", "方式"] + [f"詠唱{n}: " + "/".join(PNAME[p] for p in pols) + "/修正版−旧" for n in CASTS], rows)


def sec_behavior(it, n, methods=("A", "B", "C"), pols=("v11", "v13", "never"), tag=""):
    rows = []
    for m in methods:
        for p in pols:
            Q = L(m, n, p, it, tag)
            if not Q:
                continue
            g = lambda k: f"{avg([q['C'][k] for q in Q]):.2f}"
            X = [q["X"] for q in Q if q["X"]]
            gx = lambda k: f"{avg([x[k] for x in X]):.2f}" if X else "—"
            rows.append([m, PNAME[p], pct(wr(Q)), g("iv"), f"{avg([q['C']['iv_to_celestia'] + q['C']['iv_to_toolsmith'] for q in Q]):.2f}",
                         gx("iv_front_raw"), gx("iv_front_hp"), gx("front_ko_disp"), gx("front_incap_ever"), gx("front_dead"),
                         g("breach"), gx("rear_raw"), gx("rear_raw_hp"), g("raw_cast"), g("cancel"), gx("lost_no_iv")])
    return tbl(["方式", "AI", "勝率%", "介入/戦", "うちREARへ", "介入後のFRONT生身被弾(回)", "同(HP)", "離脱中に倒れたFRONT",
                "FRONT戦闘不能(一度でも,人)", "FRONT死亡(人)", "前線突破", "REAR生身被弾(回)", "同(HP)", "セレ詠唱中の被弾",
                "炎嵐キャンセル", "介入しなかったことで倒れたREAR"], rows)


def acc_rows(Q, only_rear=False, closed="turn"):
    ivs = [o for q in Q for o in q["iv"] if (not only_rear or o["trank"] == "REAR") and o["o_win"] is not None]
    if closed:
        ivs_c = [o for o in ivs if o["end"] == closed]
    else:
        ivs_c = ivs
    return ivs, ivs_c


def mae(xs, ys):
    return avg([abs(x - y) for x, y in zip(xs, ys)])


def corr(xs, ys):
    n = len(xs)
    if n < 3:
        return float("nan")
    mx, my = sum(xs) / n, sum(ys) / n
    sx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    sy = math.sqrt(sum((y - my) ** 2 for y in ys))
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / (sx * sy) if sx > 0 and sy > 0 else float("nan")


def sec_accuracy(it, n, methods=("A", "B", "C"), pols=("v11", "v13"), tag=""):
    rows = []
    for m in methods:
        for p in pols:
            Q = L(m, n, p, it, tag)
            if not Q or Q[0]["src"] != "v13":
                continue
            ivs, ivc = acc_rows(Q)
            if not ivc:
                continue
            aw = [o["a_win"] for o in ivc]
            an = [o["a_nact"] for o in ivc]
            ad = [o["a_fdmg"] for o in ivs]
            ar = [o["a_rhits"] for o in ivs]
            row = [m, PNAME[p], len(ivs), len(ivc)]
            for tg in ("o_", "n_"):
                row += [f"{avg([o[tg+'win'] for o in ivc]):.3f}", f"{mae([o[tg+'win'] for o in ivc], aw):.3f}",
                        f"{avg([o[tg+'nact'] for o in ivc]):.2f}", f"{mae([o[tg+'nact'] for o in ivc], an):.2f}",
                        f"{avg([o[tg+'fdmg'] for o in ivs]):.1f}", f2(corr([o[tg+'fdmg'] for o in ivs], ad)),
                        f"{avg([o[tg+'rhits'] for o in ivs]):.3f}"]
            row += [f"{avg(aw):.3f}", f"{avg(an):.2f}", f"{avg(ad):.1f}", f"{avg(ar):.3f}",
                    pct(avg([o["ko"] for o in ivs]))]
            rows.append(row)
    h = ["方式", "AI", "介入数", "うち手番で復帰"]
    for lab in ("旧の見積もり", "時間認識版"):
        h += [f"{lab}: 離脱時間T", "誤差(平均絶対)", "敵の行動数", "誤差", "FRONT被弾HP", "実際との相関", "穴からのREAR被弾数"]
    h += ["実際: 離脱時間T", "敵の行動数", "FRONT被弾HP(離脱中)", "穴からのREAR被弾数", "離脱中に倒れた%"]
    return tbl(h, rows)


def sec_bucket(it, n, m, p="v13", tag=""):
    """予測された敵の行動数ごとに、実際の行動数・被弾を並べる（予測の当たり具合）"""
    Q = L(m, n, p, it, tag)
    if not Q or Q[0]["src"] != "v13":
        return ""
    ivs, ivc = acc_rows(Q)
    rows = []
    for tg, lab in (("o_", "旧の見積もり"), ("n_", "時間認識版")):
        B = {}
        for o in ivc:
            B.setdefault(min(o[tg + "nact"], 4), []).append(o)
        for k in sorted(B):
            L_ = B[k]
            rows.append([lab, f"{k}{'+' if k == 4 else ''}", len(L_), f"{avg([o['a_nact'] for o in L_]):.2f}",
                         f"{avg([o[tg + 'fdmg'] for o in L_]):.1f}", f"{avg([o['a_fdmg'] for o in L_]):.1f}"])
    return tbl(["見積もり", "予測した敵の行動数", "件数", "実際の敵の行動数", "予測したFRONT被弾HP", "実際のFRONT被弾HP"], rows)


def main():
    out = []
    w = out.append
    w("## 勝率（旧介入AI / 時間認識修正版 / Never）\n" + sec_win())
    for it in (1, 3, 0, 2):
        for n in (0, 4):
            s = sec_behavior(it, n)
            if s.count("\n") > 3:
                w(f"## 介入と被害（{INAME[it]}・詠唱{n}）\n" + s)
            s = sec_accuracy(it, n)
            if s.count("\n") > 3:
                w(f"## 危険予測の精度（{INAME[it]}・詠唱{n}）\n" + s)
    for m in ("A", "B", "C"):
        s = sec_bucket(1, 0, m)
        if s:
            w(f"## 予測した敵行動数ごとの実際（{m}・通常・詠唱0・修正版）\n" + s)
    txt = "\n".join(out)
    (OUT / "report_tables.md").write_text(txt, encoding="utf-8")
    print(txt)




# ================================================================ 第2段階（難易度を揃えた比較）
from .v12 import UNITS, ENEMY  # noqa: E402

SPEED = {"leader": 15, "wolf_a": 14, "wolf_b": 13, "wolf_c": 12, "toolsmith": 12, "celestia": 11, "adel": 10,
         "vanguard": 9, "vanguard3": 9, "thrower": 8, "thrower2": 8}
JP = {"leader": "リーダー", "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "thrower": "投擲兵", "thrower2": "投擲兵2",
      "celestia": "セレスティア", "toolsmith": "学者", "adel": "左FRONT", "vanguard3": "中央FRONT", "vanguard": "右FRONT"}
EQ = "_eq"


def sec_eq_win():
    rows = []
    for it in (0, 1, 2, 3):
        for m in ("A", "B", "C"):
            row = [INAME[it], m]
            for n in CASTS:
                Q1, Q0 = L(m, n, "v13", it, EQ), L(m, n, "never", it, EQ)
                if not Q1:
                    row.append("—")
                    continue
                c = pct(wr(Q1))
                if Q0:
                    d, z = pair(Q1, Q0)
                    c += f" / {pct(wr(Q0))} / {100*d:+.1f}(z={z:.1f})"
                row.append(c)
            rows.append(row)
    return tbl(["知能", "方式"] + [f"詠唱{n}: 修正版 / Never(500戦) / 差" for n in CASTS], rows)


def sec_eq_v11():
    rows = []
    for it in (1, 3):
        for m in ("A", "B", "C"):
            row = [INAME[it], m]
            for n in (0, 4):
                Q1, Q0 = L(m, n, "v13", it, EQ), L(m, n, "v11", it, EQ)
                if not (Q1 and Q0):
                    row.append("—")
                    continue
                d, z = pair(Q1, Q0)
                row.append(f"{pct(wr([q for q in Q1 if q['seed'] < 500]))} / {pct(wr(Q0))} / {100*d:+.1f}(z={z:.1f})")
            rows.append(row)
    return tbl(["知能", "方式", "詠唱0: 修正版 / 旧 / 差（共通500戦）", "詠唱4: 修正版 / 旧 / 差"], rows)


def unit_actions(Q, u):
    return avg([sum(1 for x in q["seq"] if UNITS[x] == u) for q in Q])


def sec_eq_freq(it=1, n=0):
    rows = []
    for u in ("leader", "wolf_a", "wolf_b", "wolf_c", "thrower", "thrower2", "celestia", "toolsmith", "adel", "vanguard3", "vanguard"):
        row = [JP[u], SPEED[u]]
        for m in ("A", "B", "C"):
            Q = L(m, n, "v13", it, EQ)
            a = unit_actions(Q, u)
            rate = avg([sum(1 for x in q["seq"] if UNITS[x] == u) / q["time"] for q in Q])
            row.append(f"{a:.1f} ({rate:.2f}/T)")
        rows.append(row)
    for lab, fn in (("リーダー÷投擲兵", lambda Q: unit_actions(Q, "leader") / unit_actions(Q, "thrower")),
                    ("味方の行動の割合", lambda Q: avg([sum(1 for x in q["seq"] if UNITS[x] not in ENEMY) / len(q["seq"]) for q in Q]))):
        rows.append([lab, ""] + [f"{fn(L(m, n, 'v13', it, EQ)):.2f}" for m in ("A", "B", "C")])
    return tbl(["ユニット", "速度"] + [f"{m}: 行動回数(1Tあたり)" for m in ("A", "B", "C")], rows)


def sec_eq_detail(it, casts=CASTS):
    rows = []
    for m in ("A", "B", "C"):
        for n in casts:
            Q = L(m, n, "v13", it, EQ)
            if not Q:
                continue
            g = lambda k: f"{avg([q['C'][k] for q in Q]):.2f}"
            X = [q["X"] for q in Q]
            gx = lambda k: f"{avg([x[k] for x in X]):.2f}"
            rt = []
            for f in FR:
                nn = sum(Counter(q.get("ret", {}))[f"{f}_n"] for q in Q) if False else None
            ivs = [o for q in Q for o in q["iv"] if o["end"] == "turn"]
            rows.append([m, n, pct(wr(Q)), g("iv"), f"{avg([o['a_win'] for o in ivs]):.3f}", f"{avg([o['a_nact'] for o in ivs]):.2f}",
                         gx("iv_front_hp"), gx("front_ko_disp"), g("breach"), gx("rear_raw"),
                         g("storm"), g("cancel"), g("tg_cast"), g("raw_cast"), pct(avg([q["cel_dead"] for q in Q])),
                         f"{avg([sum(v for k, v in q['lost'].items() if k not in ENEMY) for q in Q]):.2f}"])
    return tbl(["方式", "詠唱", "勝率%", "介入/戦", "離脱時間T(実際)", "その間の敵行動数", "介入後のFRONT生身HP", "離脱中に倒れたFRONT",
                "前線突破", "REAR生身被弾", "炎嵐/戦", "キャンセル", "詠唱中に狙われた", "詠唱中の生身被弾", "セレ死亡%",
                "HP低下で失った味方の行動数"], rows)


def sec_eq_contrib(it=1, n=0):
    rows = []
    for u in ("leader", "wolf_b", "thrower", "thrower2", "celestia", "adel", "vanguard3", "vanguard"):
        row = [JP[u], SPEED[u]]
        for m in ("A", "B", "C"):
            Q = L(m, n, "v13", it, EQ)
            tot_e = avg([sum(q["C"][f"dmg_by_{x}"] for x in ENEMY) for q in Q])
            tot_a = avg([sum(q["C"][f"dmg_by_{x}"] for x in ("celestia", "adel", "vanguard3", "vanguard")) for q in Q])
            d = avg([q["C"][f"dmg_by_{u}"] for q in Q])
            share = d / (tot_e if u in ENEMY else tot_a)
            row.append(f"{d:.0f}（{100*share:.0f}%）")
        rows.append(row)
    return tbl(["ユニット", "速度"] + [f"{m}: 与HPダメージ（陣営内の割合）" for m in ("A", "B", "C")], rows)


def sec_sens():
    from .v13 import SENS
    rows = []
    for m in ("A", "B", "C"):
        base = L(m, 0, "v13", 1, EQ)
        row = [m, pct(wr(base))]
        for lab in SENS:
            Q = L(m, 0, "v13", 1, f"{EQ}_{lab}")
            if not Q:
                row.append("—")
                continue
            d, z = pair(Q, base)
            row.append(f"{pct(wr(Q))}（{100*d:+.1f}, z={z:.1f}）")
        rows.append(row)
    return tbl(["方式", "基準（難易度を揃えた条件）"] + list(SENS), rows)


def sec_calib():
    import re
    rows = []
    for line in open(OUT / "progress.log", encoding="utf-8"):
        mm = re.match(r"calib (\w) power x([\d.]+) -> win ([\d.]+)", line)
        if mm:
            rows.append([mm.group(1), mm.group(2), pct(float(mm.group(3)))])
    return tbl(["方式", "敵の攻撃力の倍率", "勝率%（通常・詠唱0・修正版, 400戦）"], rows)


def main2():
    out = []
    w = out.append
    w("## 難易度調整（敵の攻撃力 power だけを全敵一律に倍率）\n" + sec_calib())
    w("## 難易度を揃えた比較: 勝率（修正版 / Never / 差）\n" + sec_eq_win())
    w("## 難易度を揃えた比較: 修正版と旧介入AI\n" + sec_eq_v11())
    w("## 行動頻度（通常・詠唱0）\n" + sec_eq_freq())
    w("## 行動頻度（戦術級・詠唱0）\n" + sec_eq_freq(3))
    for it in (1, 3, 0, 2):
        w(f"## 詳細（{INAME[it]}）\n" + sec_eq_detail(it))
    w("## 与ダメージの分担（通常・詠唱0）\n" + sec_eq_contrib())
    w("## 速度の感度分析（通常・詠唱0・修正版。基準との差は同seed）\n" + sec_sens())
    txt = "\n".join(out)
    (OUT / "report_eq.md").write_text(txt, encoding="utf-8")
    print(txt)


if __name__ == "__main__":
    import sys as _s
    if len(_s.argv) > 1 and _s.argv[1] == "eq":
        main2()
    else:
        main()


def _plt():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for f in font_manager.findSystemFonts():
        if "NotoSansCJK" in f.replace(" ", ""):
            font_manager.fontManager.addfont(f)
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "sans-serif"]
    return plt


def graphs():
    plt = _plt()
    col = {"A": "tab:red", "B": "tab:blue", "C": "tab:green"}
    fig, axes = plt.subplots(1, 4, figsize=(18, 4.6), sharey=True)
    for ax, it in zip(axes, (0, 1, 2, 3)):
        for m in ("A", "B", "C"):
            for p, ls, al in (("v13", "o-", 1.0), ("never", "s--", 0.45)):
                ys = [100 * wr(L(m, n, p, it, EQ)) if L(m, n, p, it, EQ) else float("nan") for n in CASTS]
                ax.plot(CASTS, ys, ls, color=col[m], alpha=al, label=f"{m}{'・修正版AI' if p == 'v13' else '・Never'}")
        ax.set_title(f"{INAME[it]}")
        ax.set_xticks(CASTS)
        ax.set_xlabel("炎嵐の詠唱")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("味方勝率 %")
    axes[0].legend(fontsize=7)
    fig.suptitle("難易度を揃えた比較（通常知能・詠唱0を55〜65%に合わせた敵の攻撃力: A×0.887 / B×0.954 / C×0.925）")
    fig.tight_layout()
    fig.savefig(OUT / "eq_winrate.png", dpi=110)
    from .v13 import SENS
    fig, ax = plt.subplots(figsize=(10, 4.4))
    labs = list(SENS)
    import numpy as np
    x = np.arange(len(labs))
    for i, m in enumerate(("A", "B", "C")):
        base = L(m, 0, "v13", 1, EQ)
        ys = [100 * (wr(L(m, 0, "v13", 1, f"{EQ}_{lab}")) - wr(base)) for lab in labs]
        ax.bar(x + (i - 1) * 0.27, ys, 0.27, color=col[m], label=m)
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(["味方全員 速度+10%", "味方全員 −10%", "敵全員 +10%", "敵全員 −10%", "アデルだけ +20%", "セレスティアだけ +20%"])
    ax.set_ylabel("勝率の変化（ポイント）")
    ax.set_title("速度の感度分析（難易度を揃えた条件・通常知能・詠唱0、各1,000戦）")
    ax.legend()
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig(OUT / "speed_sens.png", dpi=110)
