"""反実仮想の集計。 python -m tns.sim.v11_cf_report [cond] [policy]"""
import csv
import math
import sys

from .v11 import OUT

f = lambda x: float(x or 0)


def stat(rows, k):
    d = [f(r[f"iv_{k}"]) - f(r[f"self_{k}"]) for r in rows]
    n = len(d)
    if n < 2:
        return "–"
    m = sum(d) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in d) / (n - 1))
    return f"{m*100 if k == 'win' else m:+.{1 if k == 'win' else 2}f}（±{1.96*sd/math.sqrt(n)*(100 if k == 'win' else 1):.{1 if k == 'win' else 2}f}）"


def main(cond="q058_f85_incap4", pol="v11"):
    R = list(csv.DictReader(open(OUT / f"cf_{cond}_{pol}.csv", encoding="utf-8-sig")))
    groups = [("全局面", R),
              ("AIが介入を選んだ局面", [r for r in R if r["choice"] != "self"]),
              ("AIが見送った局面", [r for r in R if r["choice"] == "self"]),
              ("前衛EP0の局面", [r for r in R if int(f(r["f_ep"])) == 0]),
              ("前衛EP>0の局面", [r for r in R if int(f(r["f_ep"])) > 0]),
              ("AIの見込み差 L_self−L_iv ≥ 0.3（強く介入有利）", [r for r in R if f(r["L_self"]) - f(r["L_iv"]) >= 0.3]),
              ("見込み差 0〜0.3", [r for r in R if 0 <= f(r["L_self"]) - f(r["L_iv"]) < 0.3]),
              ("見込み差 −0.3〜0", [r for r in R if -0.3 <= f(r["L_self"]) - f(r["L_iv"]) < 0]),
              ("見込み差 < −0.3（強く見送り有利）", [r for r in R if f(r["L_self"]) - f(r["L_iv"]) < -0.3])]
    print(f"### 反実仮想（{cond}・{pol}。各局面で「介入」「見送り」を両方再生。差 = 介入 − 見送り、括弧は95%幅）\n")
    print("| 局面 | 件数 | 勝率の差（ポイント） | FRONT離脱の差（人） | REAR離脱の差（人） |\n|---|---|---|---|---|")
    for name, rows in groups:
        print(f"| {name} | {len(rows)} | {stat(rows, 'win')} | {stat(rows, 'out_F')} | {stat(rows, 'out_R')} |")


if __name__ == "__main__":
    main(*sys.argv[1:])
