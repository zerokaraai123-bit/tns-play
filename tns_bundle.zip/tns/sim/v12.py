"""Ver0.12 行動速度・時間管理 比較（PA-180〜183）。
編成: 3FRONT・2REAR（center）／介入担当範囲あり／敵: wolves_6t。
方式 A（指数1.0）/ B（0.5）/ C（0.75）× 炎嵐詠唱 0/2/4/6 × 介入AI(v11)/Never × 知能0〜3（各1,000戦, seed0〜999）
python -m tns.sim.v12 main|never|...
"""
from __future__ import annotations

import json
import math
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.timeline_engine import make_engine
from ..model.enums import Side
from .v11f import FORMS, POLS

POLS = dict(POLS)
POLS["v13"] = ("v13", None)          # Ver0.13: 介入AIの時間認識修正版（PA-190）
OUT = Path("out/v12")
ENC = "wolves_6t"
NSEED = 1000
METHODS = {"A": 1.0, "B": 0.5, "C": 0.75}
FRONTS = ("adel", "vanguard3", "vanguard")
ENEMY = ("leader", "wolf_a", "wolf_b", "wolf_c", "thrower", "thrower2", "wolf_d")


def rules_name(method, n):
    if method == "old":
        return "rules_v09_q058_f85_incap4_lane.yaml" if n == 0 else f"rules_v09_q058_f85_incap4_cast{n}_lane.yaml"
    return f"rules_v12_{method}_cast{n}.yaml"


def apply_mods(cfg, mods):
    """Ver0.13（検証用）: 難易度調整・速度の感度分析のための能力値の上書き（正式な能力値は変えない）。
    mods = {"enemy_power": 倍率, "speed": {ユニットID または "ally"/"enemy": 倍率}}"""
    import copy
    if not mods:
        return cfg
    cfg.encounter = copy.deepcopy(cfg.encounter)
    cfg.party = copy.deepcopy(cfg.party)
    ep = mods.get("enemy_power")
    for u in cfg.encounter["units"]:
        if ep:
            u["power"] = u["power"] * ep
    sp = mods.get("speed") or {}
    for side, units in (("enemy", cfg.encounter["units"]), ("ally", cfg.party["units"])):
        for u in units:
            f = sp.get(u["id"], sp.get(side))
            if f:
                u["speed"] = u["speed"] * f
    return cfg


def build(method, n, pol, seed, intel, exponent=None, offset=0.0, tie=None, enc=None, mods=None):
    cfg = load_battle_config(party=FORMS["center"], encounter=enc or ENC, rules=rules_name(method if method in METHODS or method == "old" else "C", n),
                             ai_weights="ai_weights_v04.yaml", ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    cfg = apply_mods(cfg, mods)
    if exponent is not None or offset or tie:
        cfg.rules = dict(cfg.rules)
        tl = dict(cfg.rules.get("timeline", {}))
        if exponent is not None:
            tl["exponent"] = exponent
        if offset:
            tl["init_offset"] = offset
        if tie:
            tl["tie"] = tie
        cfg.rules["timeline"] = tl
    hm, probe = POLS[pol]
    ally = ValueAllyController(cfg.ally_policies, probe=probe, hole_model=hm)
    eng = make_engine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)}, seed=seed, enemy_intel=intel)
    return eng, ally

UNITS = ("leader", "wolf_a", "wolf_b", "wolf_c", "thrower", "thrower2", "celestia", "toolsmith", "adel", "vanguard3", "vanguard", "wolf_d")
UIDX = {u: i for i, u in enumerate(UNITS)}


def _one(job, hook=None):
    method, n, pol, seed, intel = job[:5]
    exponent = job[5] if len(job) > 5 else None
    offset = job[6] if len(job) > 6 else 0.0
    tie = job[7] if len(job) > 7 else None
    enc = job[8] if len(job) > 8 else None
    mods = job[9] if len(job) > 9 else None
    eng, ally = build(method, n, pol, seed, intel, exponent, offset, tie, enc, mods)
    extra = hook(eng, ally) if hook else None
    U = eng.state.units
    cel = U["celestia"]
    C = Counter()
    seq, tms = [], []
    K = []
    st = {"iv_pend": None, "heal_pend": {}, "iv_t": {}, "ret": [], "cel_ep0": cel.ep}

    def lis(ev, e):
        t = ev["t"]
        if t == "turn_start":
            u = ev["unit"]
            seq.append(UIDX[u])
            tms.append(round(e.cur_time, 4))
            st["iv_pend"] = None
            if u in st["iv_t"]:                       # 介入した前衛の次の手番（＝持ち場へ戻る）
                st["ret"].append((u, e.cur_time - st["iv_t"].pop(u)))
        elif t == "attack_declared":
            a, tg = ev["unit"], ev["target"]
            if a in ENEMY and tg == "celestia":
                C["tg_cel"] += 1
                if "celestia" in e.casting:
                    C["tg_cast"] += 1
            if a == "celestia" and ev["action"] == "fire":
                C["fire"] += 1
                C["cel_ep_spent"] += e.actions["fire"].ep_cost
        elif t == "intervened":
            f, tg = ev["unit"], ev["target"]
            if f in FRONTS:
                C["iv"] += 1
                C[f"iv_{f}"] += 1
                C[f"iv_to_{tg}"] += 1
                C[f"iv_{f}_{tg}"] += 1
                if tg == "celestia" and "celestia" in e.casting:
                    C["iv_cast"] += 1
                st["iv_pend"] = f
                st["iv_t"][f] = e.cur_time
        elif t == "intrusion":
            if ev["target"] in ("celestia", "toolsmith"):
                C["breach"] += 1
        elif t == "damage":
            v, a, d = ev["unit"], ev["attacker"], ev.get("dmg", 0) or 0
            C[f"dmg_by_{a}"] += d
            C[f"epstrip_by_{a}"] += ev.get("ep_spent", 0) or 0
            if v in FRONTS and a in ENEMY:
                if st["iv_pend"] == v:
                    C["front_iv_hit"] += d
                elif U[v].displaced:
                    C["front_disp_hit"] += d
            if v == "celestia" and a in ENEMY:
                C["cel_ep_spent"] += ev.get("ep_spent", 0) or 0
                if d > 0:
                    C["raw_cel"] += 1
                    if "celestia" in e.casting:
                        C["raw_cast"] += 1
            if a in ENEMY and v in st["heal_pend"]:
                pre, amt = st["heal_pend"].pop(v)
                thr = U[v].d.hp_max * 0.15
                hp_before_dmg = ev["hp"] + d
                if hp_before_dmg - d > thr and hp_before_dmg - amt - d <= thr:
                    C["heal_save"] += 1
        elif t == "heal" and ev["unit"] == "celestia":
            C["heal"] += 1
            C["cel_ep_spent"] += ev.get("ep_cost", 0) or 0
            st["heal_pend"][ev["target"]] = (ev["hp"] - ev["amount"], ev["amount"])
        elif t == "area_attack" and ev["unit"] == "celestia":
            C["storm"] += 1
            C["cel_ep_spent"] += 40
            if C["storm"] == 1:
                C["storm1_t"] = round(e.cur_time, 4)
                C["storm1_idx"] = e.action_index
                C["storm1_ep"] = sum(x.ep for x in U.values() if x.side is Side.ENEMY and x.alive)
        elif t == "cast_start" and ev["unit"] == "celestia":
            C["cast_start"] += 1
        elif t == "cast_cancel" and ev["unit"] == "celestia":
            C["cancel"] += 1
        elif t == "cast_delay" and ev["unit"] == "celestia":
            C["cast_delay"] += 1
        elif t == "ko":
            K.append((e.action_index, UIDX[ev["unit"]], int(bool(ev.get("incap"))), round(e.cur_time, 4)))
        elif t == "revive":
            C[f"revive_{ev['unit']}"] += 1
    eng.listeners.append(lis)
    eng.run()
    if extra is not None:
        C["_extra"] = extra()
    al = [u for u in U.values() if u.side is Side.ALLY]
    ret = Counter()
    for f, dt in st["ret"]:
        ret[f"{f}_n"] += 1
        ret[f"{f}_t"] += dt
    return {"m": method, "n": n, "pol": pol, "seed": seed, "intel": intel, "x": exponent, "off": offset, "enc": enc or ENC,
            "win": int(eng.stats.winner == "ally"), "draw": int(eng.stats.winner == "draw"),
            "N": eng.action_index, "time": round(eng.cur_time, 4), "rounds": eng.stats.rounds,
            "seq": seq, "tm": tms, "K": K, "C": dict(C), "ret": dict(ret),
            "lost": {k: round(v, 3) for k, v in getattr(eng, "lost_actions", {}).items()},
            "dead_A": sum(1 for u in al if u.hp <= 0), "incap_A": sum(1 for u in al if u.incapacitated),
            "cel_dead": int(cel.hp <= 0), "cel_incap_end": int(cel.incapacitated),
            "end": {u.id: u.hp for u in al}}


def path_of(method, n, pol, intel, tag=""):
    return OUT / f"{method}{tag}_cast{n}_{pol}_i{intel}.jsonl"


def run(methods, casts, pols, intels, exponent=None, offset=0.0, tag="", nseed=NSEED, tie=None, enc=None):
    OUT.mkdir(parents=True, exist_ok=True)
    for it in intels:
        for pol in pols:
            for m in methods:
                for n in casts:
                    path = path_of(m, n, pol, it, tag)
                    if path.exists():
                        continue
                    jobs = [(m, n, pol, s, it, exponent, offset, tie, enc) for s in range(nseed)]
                    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                        R = list(ex.map(_one, jobs, chunksize=20))
                    tmp = path.with_suffix(".tmp")
                    with open(tmp, "w", encoding="utf-8") as fh:
                        for r in R:
                            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
                    tmp.rename(path)
                    print("done", path, round(sum(r["win"] for r in R) / len(R), 3), flush=True)


if __name__ == "__main__":
    a = sys.argv[1] if len(sys.argv) > 1 else "main"
    if a == "main":                      # 介入AI → Never、戦術級から
        for pol in ("v11", "never"):
            run(("A", "B", "C"), (0, 2, 4, 6), (pol,), (3, 1, 0, 2))
    elif a == "old":                     # 比較用: 旧方式（Ver0.11, 担当範囲あり）を同じ記録で（介入AIのみ）
        run(("old",), (0, 2, 4, 6), ("v11",), (3, 1, 0, 2))
    elif a == "x0":                      # 対照: 指数0（速度は同時刻の並び順だけ。新しい時間軸・払い戻しなし）
        run(("C",), (0, 2, 4, 6), ("v11",), (3, 1, 0, 2), exponent=0.0, tag="x0")
    elif a == "xs":                      # 追加検証: 指数の刻み（詠唱0と4のみ, 介入AI）
        for x in (0.25, 0.35, 0.65):
            run(("C",), (0, 4), ("v11",), (3, 1, 0, 2), exponent=x, tag=f"x{x}")
    elif a == "old5never":
        run(("old",), (0, 2, 4, 6), ("never",), (3, 1, 0, 2), tag="@wolves_5v5", nseed=250, enc="wolves_5v5")
    elif a == "x0never":
        run(("C",), (0, 2, 4, 6), ("never",), (3, 1, 0, 2), exponent=0.0, tag="x0")
    elif a.startswith("x"):              # 指数の追加検証: x0.65 など（方式Cの式で指数だけ変える）
        x = float(a[1:])
        run(("C",), (0, 2, 4, 6), ("v11",), (3, 1, 0, 2), exponent=x, tag=f"x{a[1:]}")
    elif a == "calib":                   # 難易度を揃えた比較のための下調べ（別集計・既存の敵構成のみ）
        for enc in ("wolves_5v5", "wolves_5w"):
            run(("A", "B", "C"), (4,), ("v11",), (3, 1, 0, 2), tag=f"@{enc}", nseed=250, enc=enc)
    elif a == "eq":                      # 補足: 易しい既存編成（5体 wolves_5v5）で同じ比較（別集計。主比較は上書きしない）
        for pol in ("v11", "never"):
            run(("A", "B", "C"), (0, 2, 4, 6), (pol,), (3, 1, 0, 2), tag="@wolves_5v5", nseed=250, enc="wolves_5v5")
        run(("old",), (0, 2, 4, 6), ("v11",), (3, 1, 0, 2), tag="@wolves_5v5", nseed=250, enc="wolves_5v5")
    elif a.startswith("rob"):            # 補足: 行動順への依存（戦術級, wolves_5v5, 500戦）
        enc = "wolves_5v5"
        for w in (0.05, 0.10):
            run(("A", "B", "C"), (0, 2, 4, 6), ("v11",), (3,), offset=w, tag=f"@{enc}off{w}", nseed=500, enc=enc)
        for rule in ("ally_first", "enemy_first"):
            run(("A", "B", "C"), (0, 2, 4, 6), ("v11",), (3,), tie=rule, tag=f"@{enc}tie{rule}", nseed=500, enc=enc)
    elif a.startswith("tie_"):            # 同時刻の並べ方（分析専用）: tie_ally_first / tie_enemy_first
        rule = a[4:]
        run(("A", "B", "C"), (0, 2, 4, 6), ("v11",), (3,), tag=f"tie{rule}", tie=rule)
    elif a.startswith("off"):            # 初動オフセット（分析専用）: off0.05 など
        w = float(a[3:])
        run(("A", "B", "C"), (0, 2, 4, 6), ("v11",), (3,), offset=w, tag=f"off{a[3:]}")
