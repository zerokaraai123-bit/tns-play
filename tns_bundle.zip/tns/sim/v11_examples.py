"""Ver0.11 具体例ログ。 python -m tns.sim.v11_examples > out/v11_examples.md
A: 自分の危険を承知で介入した / B: Ver0.10は介入、Ver0.11は見送り（同じ局面）/ C: EP0の前衛が介入しなかった / D: EP0の前衛がそれでも介入した
"""
from __future__ import annotations

import csv
import random

from .v09 import seeds
from .v10_examples import NAME
from .v11 import OUT, build

COND = "q058_f85_incap4"


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def text(r, title):
    t, fr = NAME.get(r["target"], r["target"]), NAME.get(r["f"], r["f"])
    prot = r["choice"] != "self"
    v11 = r.get("hole_model") == "v11"
    L = [f"### {title}（seed={r['seed']}・敵知能={r['enemy_intel']}・{r['round']}巡・{ {'v9': 'Ver0.9', 'v10': 'Ver0.10', 'v11': 'Ver0.11'}.get(r.get('hole_model'), '?') }のAI）",
         f"- 攻撃: {NAME.get(r['attacker'], r['attacker'])} → {t}（期待威力 {r['raw']}）",
         f"- {t}: HP {r['t_hp']}/{r['t_hpmax']}・EP {r['t_ep']}・自衛の必要EP {r['t_need']}",
         f"- {fr}: HP {r['f_hpabs']}/{r['f_hpmax']}・EP {r['f_ep']}・介入の必要EP {r['f_need']}",
         f"- {fr}が戻るまでに動く敵 {int(f(r.get('n_enemy_actions')))}回。予測: {fr}への攻撃 {f(r.get('pred_front_hits')):.2f}回"
         f"（生身 {f(r.get('pred_front_dmg')):.0f}）、後衛への追加攻撃 {f(r.get('pred_extra_rear_hits')):.2f}回"]
    if v11:
        L.append(f"- ①狙われやすさ（この戦闘の実績 {int(f(r.get('v11_obs_n')))}回から）: 等確率の {f(r.get('v11_disp_mult')):.2f}倍")
        L.append(f"- ②{fr}が前線に残る将来価値: {f(r.get('v11_V_now')):.2f}（攻撃 {f(r.get('v11_att')):.2f}・経路 {f(r.get('v11_block')):.2f}"
                 f"・狙いの引き受け {f(r.get('v11_absorb')):.2f}、2巡以内に倒れる確率 {f(r.get('v11_pout_now')):.0%}）"
                 f" → 介入後 {f(r.get('v11_V_after')):.2f}（倒れる確率 {f(r.get('v11_pout_after')):.0%}）")
    L += [f"- 介入しない場合の損失: {f(r['L_self']):.2f}（{t}が自分で対応）",
          f"- 介入する場合の損失: {f(r['L_iv']):.2f}（内訳 {r['parts']}）",
          f"- **判断: {'★ ' + fr + 'が介入' if prot else '☆ ' + t + 'が自分で対応'}**"]
    return "\n".join(L)


def lockstep(n_seeds=150):
    out = []
    for s, i in seeds("q058_f85")[:n_seeds]:
        recs = {}
        for p in ("v10", "v11"):
            eng, ally = build(COND, p, s, i)
            eng.run()
            recs[p] = [dict(r, seed=s, enemy_intel=i) for r in ally.records if r["kind"] == "iv"]
        for a, b in zip(recs["v10"], recs["v11"]):
            if not all(a[k] == b[k] for k in ("target", "attacker", "t_ep", "f_ep", "t_hp", "f_hpabs", "round")):
                break
            if a["choice"] != b["choice"] and a["trank"] == "REAR":
                out.append((a, b))
                break
    return out


def main():
    R = [r for r in csv.DictReader(open(OUT / f"{COND}_v11_ivdecisions.csv", encoding="utf-8-sig")) if r["trank"] == "REAR"]
    rnd = random.Random(5)
    risk = lambda r: sum(f(x.split("=")[1]) for x in str(r["parts"]).split("; ") if x.startswith(("離脱中の被弾", "前衛の将来価値")))
    A = [r for r in R if r["choice"] != "self" and risk(r) >= 0.15]
    C = [r for r in R if r["choice"] == "self" and int(f(r["f_ep"])) == 0]
    D = [r for r in R if r["choice"] != "self" and int(f(r["f_ep"])) == 0]
    L = ["# Ver0.11 具体例（条件 q=0.585・f(0.5)=0.85・戦闘不能暫定仕様。損失の単位は戦力点）\n"]
    L.append(f"## A｜自分が狙われる危険・将来価値の低下（合計0.15以上）を承知で介入した例（{len(A)}件から）\n")
    L += [text(r, "A") + "\n" for r in rnd.sample(A, min(3, len(A)))]
    D2 = lockstep()
    b = [(x, y) for x, y in D2 if x["choice"] != "self" and y["choice"] == "self"]
    L.append(f"## B｜同じ局面で Ver0.10 は介入、Ver0.11 は見送った例（最初の150シードを両AIで再生。"
             f"初めて判断が分かれた {len(D2)} 件のうち、この向き {len(b)} 件・逆向き {len(D2) - len(b)} 件）\n")
    for x, y in b[:3]:
        L.append(text(x, "B-Ver0.10") + "\n")
        L.append(text(y, "B-Ver0.11") + "\n")
    L.append(f"## C｜EP0の前衛が介入しなかった例（{len(C)}件から）\n")
    L += [text(r, "C") + "\n" for r in rnd.sample(C, min(3, len(C)))]
    L.append(f"## D｜EP0の前衛がそれでも介入した例（{len(D)}件から）\n")
    L += [text(r, "D") + "\n" for r in rnd.sample(D, min(3, len(D)))]
    print("\n".join(L))


if __name__ == "__main__":
    main()
