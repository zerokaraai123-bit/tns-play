"""Ver0.8 代表戦闘ログの抽出。同じシードで再実行し（完全再現）、条件に合う場面の前後を人が読める形で書き出す。
python -m tns.sim.v08_examples  → out/v08_examples.md
"""
from __future__ import annotations

from .v08 import build, seeds_for

NAMES = {}


def nm(eng, uid):
    return eng.u(uid).name if uid else "-"


def render(eng, ev):
    t = ev["t"]
    g = lambda k: ev.get(k)
    if t == "turn_start":
        u = eng.u(ev["unit"])
        return f"【{ev['round']}巡】{ev['snap']} の手番"
    if t == "attack_declared":
        why = "；".join(ev.get("reasons") or [])
        return f"  {nm(eng, g('unit'))} → {nm(eng, g('target'))}（{g('action')}）" + (f"  〔判断: {why}〕" if eng.u(g('unit')).side.value == "ally" and why else "")
    if t == "area_attack":
        return f"  {nm(eng, g('unit'))} が炎嵐  〔判断: {'；'.join(ev.get('reasons') or [])}〕"
    if t == "intervened":
        return f"  ★ {nm(eng, g('unit'))} が介入して受ける  〔理由: {'；'.join(ev.get('reasons') or [])}〕"
    if t == "aegis":
        return f"  ★ {nm(eng, g('unit'))} が遠隔障壁  〔理由: {'；'.join(ev.get('reasons') or [])}〕"
    if t == "no_intervention":
        return f"  ☆ 介入しない  〔理由: {'；'.join(ev.get('reasons') or [])}〕"
    if t == "cover":
        return f"  ◆ {nm(eng, g('unit'))} が {nm(eng, g('target'))} を庇う  〔理由: {'；'.join(ev.get('reasons') or [])}〕"
    if t == "covered":
        return f"  ◆ {nm(eng, g('unit'))} が庇って受ける"
    if t == "damage":
        u = eng.u(g("unit"))
        return (f"    → {u.name}: {g('dmg')}ダメージ（HP{g('hp')}/{u.d.hp_max}・EP{g('ep')}）"
                f" 防御:{g('mode')} {g('ep_spent')}EP" + (f"〔{g('defense_reason')}〕" if u.side.value == "ally" else ""))
    if t == "heal":
        return f"  {nm(eng, g('unit'))} が {nm(eng, g('target'))} を治療 +{g('amount')}  〔{'；'.join(ev.get('reasons') or [])}〕"
    if t == "wait" and eng.u(g("unit")).side.value == "ally":
        return f"  {nm(eng, g('unit'))} 待機  〔{'；'.join(ev.get('reasons') or [])}〕"
    if t == "ko":
        return f"  ✖ {nm(eng, g('unit'))} が{'戦闘不能' if g('incap') else '死亡'}"
    if t == "route_change":
        return f"  （経路{g('route')}が{g('status')}: {g('cause')}）"
    return None


def window(eng, idx, before=6, after=14):
    lines = []
    for ev in eng.events[max(0, idx - before): idx + after]:
        s = render(eng, ev)
        if s:
            lines.append(s)
    return "\n".join(lines)


def find_examples(model, level, n_seeds=300):
    found = {}
    for seed, intel in seeds_for(level, n_seeds):
        eng, ally = build(model, level, seed, intel, log=True)
        eng.run()
        ev = eng.events
        recs = getattr(ally, "records", [])

        def first(pred):
            for i, e in enumerate(ev):
                if pred(e):
                    return i
            return None

        def put(key, idx, note):
            if key not in found and idx is not None:
                found[key] = (seed, intel, note, window(eng, idx), eng.stats.winner)

        # 1. 前衛が守ることが合理的だった（REARの選択肢を守るため）
        put("iv_rational", first(lambda e: e["t"] in ("intervened", "aegis") and "落ちる" in " ".join(e.get("reasons") or [])
                                 and eng.u(e["target"]).rank.value == "REAR"), "REARが自衛すると次の手番の最善手が落ちる場面で、前衛が受けた")
        # 2. REAR自衛が合理的だった
        put("self_rational", first(lambda e: e["t"] == "no_intervention" and eng.u(e["target"]).rank.value == "REAR"
                                   and "痛み0.00" in " ".join(e.get("reasons") or [])), "REARのEPが十分で、自衛しても失う選択肢がない場面")
        # 3. 大魔法を撃った（守られている前提）
        put("storm_bold", first(lambda e: e["t"] == "area_attack" and "π=1.00" in " ".join(e.get("reasons") or [])),
            "前衛が構えていて守られる見込みπ=1の中で炎嵐を撃った")
        # 4. 大魔法を温存した
        put("storm_held", first(lambda e: e["t"] in ("attack_declared", "wait", "heal") and eng.u(e["unit"]).side.value == "ally"
                                and "温存へ切替" in " ".join(e.get("reasons") or [])), "守ってもらえる見込みが足りず、より温存する手を選んだ")
        # 5. 前衛喪失後にREARの行動が変わった
        ko = first(lambda e: e["t"] == "ko" and eng.u(e["unit"]).rank.value == "FRONT" and eng.u(e["unit"]).side.value == "ally")
        if ko is not None and "front_loss" not in found:
            after = next((i for i in range(ko, len(ev)) if ev[i]["t"] in ("attack_declared", "wait", "area_attack", "heal")
                          and ev[i].get("unit") == "celestia"), None)
            if after is not None and "π=0.00" in " ".join(ev[after].get("reasons") or []):
                found["front_loss"] = (seed, intel, "前衛が倒れた後、魔導士の判断（守られる見込みπ）が変わった",
                                       window(eng, ko, 4, 3) + "\n  …\n" + window(eng, after, 1, 6), eng.stats.winner)
        # 6. 介入が裏目に出た（介入した前衛が、離脱中に倒れた／開いた経路から後衛が殴られた）
        for i, e in enumerate(ev):
            if e["t"] == "intervened" and eng.u(e["unit"]).side.value == "ally" and "iv_backfire" not in found:
                c = e["unit"]
                for j in range(i + 1, min(len(ev), i + 40)):
                    x = ev[j]
                    if x["t"] == "stance" and x.get("unit") == c and x.get("new") == "READY":
                        break
                    if (x["t"] == "ko" and x["unit"] == c) or (x["t"] == "intrusion" and eng.u(x["target"]).side.value == "ally"):
                        found["iv_backfire"] = (seed, intel, "介入した前衛が持ち場に戻る前に、倒れた／開いた経路から後衛が攻撃された",
                                                window(eng, i, 2, j - i + 4), eng.stats.winner)
                        break
        # 7. 介入しなかったことが裏目に出た（自衛を任せたREARが、その後2巡以内に倒れた）
        for i, e in enumerate(ev):
            if e["t"] == "no_intervention" and eng.u(e["target"]).rank.value == "REAR" and "noiv_backfire" not in found \
                    and eng.u(e["target"]).side.value == "ally":
                tid, r0 = e["target"], e["round"]
                for j in range(i + 1, len(ev)):
                    x = ev[j]
                    if x["round"] > r0 + 2:
                        break
                    if x["t"] == "ko" and x["unit"] == tid:
                        found["noiv_backfire"] = (seed, intel, "前衛が守らずREARに自衛させた後、そのREARが2巡以内に倒れた",
                                                  window(eng, i, 2, 10) + "\n  …\n" + window(eng, j, 6, 2), eng.stats.winner)
                        break
        if model == "M4":
            put("cover", first(lambda e: e["t"] == "cover"), "前衛が自分の手番を使って後衛を庇った")
        if len(found) >= 9:
            break
    return found


TITLES = {"iv_rational": "FRONT介入が合理的だった例", "self_rational": "REAR自己防御が合理的だった例",
          "storm_bold": "大魔法の使用が合理的だった例（守られている前提）", "storm_held": "大魔法を温存した例",
          "front_loss": "FRONT喪失後にREARの行動が変化した例", "iv_backfire": "介入が裏目に出た例",
          "noiv_backfire": "介入しなかったことが裏目に出た例", "cover": "庇護の構え（M4）の例"}


def main():
    out = ["# Ver0.8 代表戦闘ログ（同じシードで再実行して抽出。判断理由はAIが実際に出力した文）\n",
           "読み方: 〔判断〕〔理由〕はAIのその場の計算。数値は「戦力点」（味方の損失＝重要度×失うHP割合＋倒れるなら1.2×重要度）。",
           "「痛み」＝そのEPを使うことで次の手番の最善の選択がどれだけ悪くなるか。π＝前衛に守ってもらえる見込み。\n"]
    for m in ("M1", "M4", "M5", "M2", "M3"):
        f = find_examples(m, "D15")
        out.append(f"\n## {m}（D1.5）\n")
        for key, title in TITLES.items():
            if key not in f:
                continue
            seed, intel, note, text, winner = f[key]
            out.append(f"### {title}\n- seed={seed}・敵知能={intel}・勝者={winner}\n- 何が起きたか: {note}\n```\n{text}\n```\n")
        missing = [TITLES[k] for k in TITLES if k not in f and (k != "cover" or m == "M4")]
        if missing:
            out.append("（最初の300戦で見つからなかった例: " + "、".join(missing) + "）\n")
    open("out/v08_examples.md", "w", encoding="utf-8").write("\n".join(out))


if __name__ == "__main__":
    main()
