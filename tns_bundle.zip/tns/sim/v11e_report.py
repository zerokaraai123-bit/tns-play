"""EP役割差検証の集計。 python -m tns.sim.v11e_report > out/v11e/report_tables.md"""
from __future__ import annotations

import csv
import math

from .v11e import EPS, OUT, QS

QN = {"q058": "現行（2.0倍）", "q075": "中（2.4倍）", "q10": "強（3.3倍）"}
f = lambda x: float(x or 0)
CATS = ["攻撃した（炎嵐）", "攻撃した（攻撃魔法）", "治療にEPを使った", "待機：次の治療用に温存", "待機：自衛用に温存",
        "攻撃不可（EP15未満）", "その他"]


def load(ep, q, p):
    path = OUT / f"ep{ep}_{q}_{p}.csv"
    if not path.exists():
        return None
    return {r["seed"] + "_" + r["enemy_intel"]: r for r in csv.DictReader(open(path, encoding="utf-8-sig"))}


def pair(A, B):
    d = [f(A[k]["win"]) - f(B[k]["win"]) for k in A]
    n = len(d); m = sum(d) / n; sd = math.sqrt(sum((x - m) ** 2 for x in d) / (n - 1))
    return "%+.1f（z=%.1f）" % (m * 100, m / (sd / math.sqrt(n)) if sd else 0)


def avg(B, k):
    return sum(f(b.get(k)) for b in B.values()) / len(B)


def main():
    D = {}
    for q in QS:
        for ep in EPS:
            for p in ("v11", "v11nh", "never"):
                x = load(ep, q, p)
                if x:
                    D[ep, q, p] = x
    A = D[100, "q058", "v11"]
    L = ["## 1. 勝率（同一シード1,000戦）\n",
         "| 最大EP | 防御効率差 | B（価値AI） | C（治療の未来温存なし） | Never | B−Never | C−B | B−A（基準） |",
         "|---|---|---|---|---|---|---|---|"]
    for q in QS:
        for ep in EPS:
            if (ep, q, "never") not in D:
                continue
            b, c, n = D[ep, q, "v11"], D[ep, q, "v11nh"], D[ep, q, "never"]
            L.append(f"| {ep} | {QN[q]} | {avg(b, 'win')*100:.1f}% | {avg(c, 'win')*100:.1f}% | {avg(n, 'win')*100:.1f}% | "
                     f"{pair(b, n)} | {pair(c, b)} | {'基準' if (ep, q) == (100, 'q058') else pair(b, A)} |")
    rows = [
        ("平均行動数 / 巡", lambda B: f"{avg(B,'actions'):.1f} / {avg(B,'rounds'):.1f}"),
        ("FRONT 死亡 / 戦闘不能", lambda B: f"{avg(B,'end_dead_FRONT')/2*100:.0f}% / {avg(B,'end_incap_FRONT')/2*100:.0f}%"),
        ("REAR 死亡 / 戦闘不能", lambda B: f"{avg(B,'end_dead_REAR')/3*100:.0f}% / {avg(B,'end_incap_REAR')/3*100:.0f}%"),
        ("セレスティア 死亡 / 戦闘不能", lambda B: f"{avg(B,'cel_dead')*100:.0f}% / {avg(B,'cel_incap')*100:.0f}%"),
        ("セレスティア 最大EP / 終了時EP", lambda B: f"{avg(B,'cel_ep_max'):.0f} / {avg(B,'cel_end_ep'):.1f}"),
        ("炎嵐 / 攻撃魔法 / 治療 / 待機（回）", lambda B: f"{avg(B,'cel_ep_storm')/40:.2f} / {avg(B,'cel_ep_fire')/15:.2f} / {avg(B,'cel_ep_heal')/18:.2f} / {avg(B,'cel_wait'):.2f}"),
        ("EP: 炎嵐 / 攻撃魔法 / 治療 / 自衛 / 残り", lambda B: " / ".join(f"{avg(B,k):.1f}" for k in ("cel_ep_storm", "cel_ep_fire", "cel_ep_heal", "cel_ep_selfdef", "cel_end_ep"))),
        ("自衛した被弾1回の平均EP / 1戦の最大", lambda B: f"{avg(B,'cel_ep_selfdef')/max(avg(B,'cel_def_hits'),1e-9):.1f} / {avg(B,'cel_def_max'):.1f}"),
        ("自衛1回で20EP以上使った回数", lambda B: f"{avg(B,'cel_def_ge20'):.2f}"),
        ("REARのための介入 / うちセレスティア", lambda B: f"{avg(B,'ivrec_protect'):.2f} / {avg(B,'iv_cel'):.2f}"),
        ("セレスティア介入1回: 自分なら必要EP / 実際に払えた分 / 前衛が使ったEP", lambda B: (
            f"{avg(B,'iv_cel_need')/avg(B,'iv_cel'):.1f} / {avg(B,'iv_cel_would')/avg(B,'iv_cel'):.1f} / {avg(B,'iv_cel_front_ep')/avg(B,'iv_cel'):.1f}" if avg(B, 'iv_cel') else "–")),
        ("節約EP（1回 / 1戦）※払えた分−前衛の消費", lambda B: (
            f"{(avg(B,'iv_cel_would')-avg(B,'iv_cel_front_ep'))/avg(B,'iv_cel'):+.1f} / {avg(B,'iv_cel_would')-avg(B,'iv_cel_front_ep'):+.1f}" if avg(B, 'iv_cel') else "–")),
        ("同上 ※必要EP−前衛の消費", lambda B: (
            f"{(avg(B,'iv_cel_need')-avg(B,'iv_cel_front_ep'))/avg(B,'iv_cel'):+.1f} / {avg(B,'iv_cel_need')-avg(B,'iv_cel_front_ep'):+.1f}" if avg(B, 'iv_cel') else "–")),
        ("節約EPの行き先（炎嵐/攻撃魔法/治療/後の自衛/倒れて未使用/終了時残り）", lambda B: (
            " / ".join(f"{avg(B,k)/avg(B,'saved_total')*100:.0f}%" for k in ("saved_to_storm", "saved_to_fire", "saved_to_heal", "saved_to_selfdef", "saved_to_fell", "saved_to_end")) if avg(B, 'saved_total') else "–")),
    ]
    for q in QS:
        for ep in EPS:
            if (ep, q, "never") not in D:
                continue
            L.append(f"\n## 最大EP {ep}・防御効率差 {QN[q]}\n")
            L.append("| | B（価値AI） | C（治療の未来温存なし） | Never |\n|---|---|---|---|")
            for name, fn in rows:
                L.append(f"| {name} | " + " | ".join(fn(D[ep, q, p]) for p in ("v11", "v11nh", "never")) + " |")
            L.append("\n手番分類（1戦あたり）\n")
            L.append("| 分類 | B | C | Never |\n|---|---|---|---|")
            for cat in CATS:
                L.append(f"| {cat} | " + " | ".join(f"{avg(D[ep, q, p], 'turn_' + cat):.2f}" for p in ("v11", "v11nh", "never")) + " |")
            b, n = D[ep, q, "v11"], D[ep, q, "never"]
            d = {k: avg(b, k) - avg(n, k) for k in ("cel_ep_storm", "cel_ep_fire", "cel_ep_heal", "cel_ep_selfdef", "cel_end_ep")}
            L.append("\n同じシードのNeverとの差（B − Never、セレスティアのEP／1戦）: " + "、".join(
                f"{nm} {d[k]:+.1f}" for nm, k in (("炎嵐", "cel_ep_storm"), ("攻撃魔法", "cel_ep_fire"), ("治療", "cel_ep_heal"),
                                                 ("自衛", "cel_ep_selfdef"), ("残り", "cel_end_ep"))))
    print("\n".join(L))


if __name__ == "__main__":
    main()
