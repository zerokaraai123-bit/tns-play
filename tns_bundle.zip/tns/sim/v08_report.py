"""Ver0.8 自由設計実験の集計。 python -m tns.sim.v08_report > out/v08_tables.md"""
from __future__ import annotations

import csv
import math
from pathlib import Path

from ..ai.ally.value_controller import PROBES

OUT = Path("out/v08")
MJ = {"M0": "M0 現行", "M1": "M1 機会費用AI", "M2": "M2 エーテル呼吸", "M3": "M3 二層エーテル",
      "M4": "M4 庇護の構え", "M5": "M5 遠隔障壁"}
LJ = {"D1": "D1（易）", "D15": "D1.5（難）", "D2": "D2（最難・追加）"}
PJ = {"always_iv": "常に守る（REAR狙いは必ず前衛が出る/M4は常に庇う）", "never_iv": "一切守らない（常にREAR自衛）",
      "always_storm": "撃てるなら常に炎嵐", "fixed_reserve": "魔導士は固定の温存ライン28（現行ルール）",
      "heal_only": "魔導士は治療だけ", "mage_only": "魔導士だけを守る"}
IJ = {"0": "低", "1": "通常", "2": "高", "3": "戦術"}


def load(tag):
    p = OUT / f"{tag}_battles.csv"
    if not p.exists():
        return None
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def n(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def avg(B, k):
    return sum(n(b.get(k)) for b in B) / len(B)


def pct(a, b=1.0):
    return f"{a / b:.1%}" if b else "-"


def win(B):
    return sum(1 for b in B if b["winner"] == "ally") / len(B)


def ci(p, N):
    return 1.96 * math.sqrt(max(p * (1 - p), 1e-9) / N)


def build():
    L = []
    data = {(lv, m): load(f"main_{lv}_{m}") for lv in LJ for m in MJ}
    data = {k: v for k, v in data.items() if v}
    L.append("## C｜シミュレーション結果（各1,000戦・同一シード・前衛HP×1.75・Speed+Incap・P2）")
    L.append("\n#### C1 勝率・死亡・戦闘不能（率は1人あたり）")
    L.append("| 難易度 | モデル | 味方勝率 | FRONT死亡 | FRONT戦闘不能 | REAR死亡 | REAR戦闘不能 | 戦闘の長さ(巡) |")
    L.append("|---|---|---|---|---|---|---|---|")
    for (lv, m), B in data.items():
        if not B:
            continue
        L.append(f"| {LJ[lv]} | {MJ[m]} | {pct(win(B))}±{ci(win(B), len(B)):.1%} | {pct(avg(B, 'dead_FRONT') / 2)} | {pct(avg(B, 'incap_FRONT') / 2)} | "
                 f"{pct(avg(B, 'dead_REAR') / 3)} | {pct(avg(B, 'incap_REAR') / 3)} | {avg(B, 'rounds'):.1f} |")

    L.append("\n#### C2 守り方と資源（1戦あたり）")
    L.append("| 難易度 | モデル | 介入（移動） | うちREARのため | 障壁 | 庇いの宣言 | 庇いで受けた攻撃 | FRONT自衛 回数/EP | FRONTが守りに使ったEP | REAR自衛 回数/EP | 生身を選んだ FRONT/REAR |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for (lv, m), B in data.items():
        if not B:
            continue
        prot = avg(B, "ep_front_iv") + avg(B, "ep_front_aegis") + avg(B, "ep_front_cover")
        L.append(f"| {LJ[lv]} | {MJ[m]} | {avg(B, 'iv_move'):.2f} | {avg(B, 'iv_move_rear'):.2f} | {avg(B, 'iv_aegis'):.2f} | {avg(B, 'cover_decl'):.2f} | "
                 f"{avg(B, 'cover_hit'):.2f} | {avg(B, 'selfdef_n_FRONT'):.1f}/{avg(B, 'selfdef_ep_FRONT'):.0f} | {prot:.1f} | "
                 f"{avg(B, 'selfdef_n_REAR'):.1f}/{avg(B, 'selfdef_ep_REAR'):.0f} | {avg(B, 'chose_body_FRONT'):.2f}/{avg(B, 'chose_body_REAR'):.2f} |")

    L.append("\n#### C3 魔法・治癒・与ダメージ（1戦あたり）")
    L.append("| 難易度 | モデル | 攻撃魔法 | 炎嵐 | 治療 | 治癒総量 | 魔法の与ダメ | 通常攻撃の与ダメ | チーム総与ダメ | 戦闘終了時の魔導士EP |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for (lv, m), B in data.items():
        if not B:
            continue
        L.append(f"| {LJ[lv]} | {MJ[m]} | {avg(B, 'fire'):.2f} | {avg(B, 'storm'):.2f} | {avg(B, 'heal'):.2f} | {avg(B, 'heal_amt'):.1f} | "
                 f"{avg(B, 'magic_dmg'):.1f} | {avg(B, 'phys_dmg'):.1f} | {avg(B, 'magic_dmg') + avg(B, 'phys_dmg'):.1f} | {avg(B, 'mage_ep_end'):.1f} |")

    L.append("\n#### C4 行動の変化（価値AIのモデルのみ。1戦あたり）")
    L.append("| 難易度 | モデル | REAR狙いへの判断: 自衛 / 前衛が守る | 守った理由: 選択肢の維持 / 前衛の方が安い / 生身の危険 | 介入で閾値を保てた | 守られている前提で大胆に投入 | 守りが足りず温存へ切替（前衛健在/前衛離脱後） | 同じ攻撃者→同じ標的で判断が割れた回数 | 敵のREAR狙い（うち開いた経路から） |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for (lv, m), B in data.items():
        if not B or m == "M0":
            continue
        L.append(f"| {LJ[lv]} | {MJ[m]} | {avg(B, 'ivdec_REAR_self'):.2f} / {avg(B, 'ivdec_REAR_move') + avg(B, 'ivdec_REAR_aegis'):.2f} | "
                 f"{avg(B, 'ivreason_選択肢の維持'):.2f} / {avg(B, 'ivreason_前衛の方が安い'):.2f} / {avg(B, 'ivreason_生身の危険'):.2f} | "
                 f"{avg(B, 'thr_kept'):.2f} | {avg(B, 'bold'):.2f} | {avg(B, 'cons_front_up'):.2f} / {avg(B, 'cons_front_down'):.2f} | "
                 f"{avg(B, 'same_attack_mixed'):.2f} | {avg(B, 'enemy_att_REAR'):.1f}（{avg(B, 'enemy_att_rear_open'):.1f}） |")
    L.append("\n（M0の介入判断は状況判断AI。REAR狙いに対して前衛が守ったのは C2 の「うちREARのため」）")

    L.append("\n#### C5 魔導士の手番: 前衛が健在か（生存かつEPあり）で、炎嵐を撃つ率が変わるか")
    L.append("| 難易度 | モデル | 前衛健在の手番 | そのうち炎嵐 | 前衛が全員EP0・離脱の手番 | そのうち炎嵐 |")
    L.append("|---|---|---|---|---|---|")
    for (lv, m), B in data.items():
        if not B or m == "M0":
            continue
        ok, ng = avg(B, "mage_turn_front_ok"), avg(B, "mage_turn_front_ng")
        L.append(f"| {LJ[lv]} | {MJ[m]} | {ok:.2f} | {pct(avg(B, 'storm_front_ok'), ok)} | {ng:.2f} | {pct(avg(B, 'storm_front_ng'), ng)} |")

    L.append("\n#### C6 敵知能別の味方勝率（D1.5）")
    L.append("| モデル | 低 | 通常 | 高 | 戦術 |")
    L.append("|---|---|---|---|---|")
    for m in MJ:
        B = data.get(("D15", m))
        if not B:
            continue
        L.append(f"| {MJ[m]} | " + " | ".join(pct(win([b for b in B if b["enemy_intel"] == i])) for i in "0123") + " |")

    # 永久最適解の探索
    L.append("\n## 永久最適解の探索（各500戦・同一シード＝本実験の1,000戦から1つおきに取った500戦で、敵知能4段階が各125戦。価値AIの一部を固定戦略に差し替え）")
    L.append("| 難易度 | モデル | 戦略 | 味方勝率 | 価値AIとの差 | FRONT離脱率 | REAR離脱率 | 炎嵐 | 治療 | 魔法与ダメ | 判定 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for lv in ("D15", "D2"):
        for m in ("M1", "M2", "M3", "M4", "M5"):
            base = data.get((lv, m))
            if not base or not load(f"probe_{lv}_{m}_{PROBES[0]}"):
                continue
            keys = {(b["seed"], b["enemy_intel"]) for b in load(f"probe_{lv}_{m}_{PROBES[0]}")}
            b5 = [b for b in base if (b["seed"], b["enemy_intel"]) in keys]
            w0 = win(b5)
            L.append(f"| {LJ[lv]} | {MJ[m]} | **価値AI（基準）** | {pct(w0)} | – | {pct((avg(b5, 'dead_FRONT') + avg(b5, 'incap_FRONT')) / 2)} | "
                     f"{pct((avg(b5, 'dead_REAR') + avg(b5, 'incap_REAR')) / 3)} | {avg(b5, 'storm'):.2f} | {avg(b5, 'heal'):.2f} | {avg(b5, 'magic_dmg'):.1f} | |")
            for p in PROBES:
                B = load(f"probe_{lv}_{m}_{p}")
                if not B:
                    continue
                w = win(B)
                diff = w - w0
                se = math.sqrt(w * (1 - w) / len(B) + w0 * (1 - w0) / len(b5))
                verdict = "上回る（永久最適解の候補）" if diff > 1.96 * max(se, 1e-9) else ("同等" if abs(diff) <= 1.96 * max(se, 0.005) else "劣る")
                L.append(f"| {LJ[lv]} | {MJ[m]} | {PJ[p]} | {pct(w)} | {diff:+.1%} | {pct((avg(B, 'dead_FRONT') + avg(B, 'incap_FRONT')) / 2)} | "
                         f"{pct((avg(B, 'dead_REAR') + avg(B, 'incap_REAR')) / 3)} | {avg(B, 'storm'):.2f} | {avg(B, 'heal'):.2f} | {avg(B, 'magic_dmg'):.1f} | {verdict} |")
    return "\n".join(L)


if __name__ == "__main__":
    print(build())
