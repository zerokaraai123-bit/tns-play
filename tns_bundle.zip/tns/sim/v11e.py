"""EP役割差検証（Ver0.11基準）: ①セレスティアの最大EP ②肉体強度→防御EP効率差（既存の式の q）③治療用の未来温存。
変更するのは「セレスティアの最大EP」「q（link_exponent）」「C条件でのセレスティアの行動選択から治療の未来温存を除く」だけ。
python -m tns.sim.v11e
"""
from __future__ import annotations

import math
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..model.enums import ActionKind, Side
from .csv_export import write_csv
from .v08 import summarize_records
from .v09 import seeds
from .v10s import SensTracer
from .v11_celestia_ep import classify

OUT = Path("out/v11e")
EPS = (100, 125, 150)
QS = {"q058": 0.584963, "q075": 0.75, "q10": 1.0}     # 現行 / 中程度 / 強く
POLICIES = {"v11": ("v11", False), "v11nh": ("v11", True), "never": ("v9", False)}


class EPRoleAlly(ValueAllyController):
    """Ver0.11 価値AIそのもの。no_heal_reserve=True のときだけ、セレスティア（魔導士）の行動選択で
    「残りEPの価値」から治療の未来価値を除く（＝将来の治療のためだけに撃てる魔法を撃たず待つ、をしない）。
    いま治療すべき相手がいる場合の治療の価値・自衛用EPの価値・介入や防御の判断（EPの痛み）は変えない。"""
    no_heal_reserve = False

    def _mage_value(self, u):
        if not self.no_heal_reserve:
            if u.id == "celestia":
                self._turn(u)
            return super()._mage_value(u)
        self.v_rest = lambda uu, r, pi=None: self.v_def(uu, r, pi)
        try:
            if u.id == "celestia":
                self._turn(u)
            return super()._mage_value(u)
        finally:
            del self.v_rest

    def _turn(self, u):
        info = classify(self, u)
        if info["cat"] == "攻撃不可（届く敵なし）":
            info["cat"] = "その他"
        self.turns.append(info)


def build(ep, qk, pol, seed, intel):
    rules = f"rules_v09_{qk}_f85_incap4.yaml"
    party = "party_v08" if ep == 100 else f"party_v08_cel{ep}"
    cfg = load_battle_config(party=party, rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    hm, nh = POLICIES[pol]
    ally = EPRoleAlly(cfg.ally_policies, probe=("never_iv" if pol == "never" else None), hole_model=hm)
    ally.no_heal_reserve = nh
    ally.turns = []
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)},
                       seed=seed, enemy_intel=intel)
    return eng, ally


class CelTracer:
    """セレスティアのEPの使い道・介入によるEP節約・節約EPの行き先（先入れ先出しの近似）。"""

    def __init__(self, eng):
        self.c = Counter()
        self.pending = {}           # 介入した前衛 -> {need, would}
        self.pool = 0.0             # 介入で節約されたセレスティアのEP（まだ行き先が決まっていない分）
        self.fell = False

    def _spend(self, kind, amt):
        self.c[f"cel_ep_{kind}"] += amt
        take = min(self.pool, amt)
        if take > 0:
            self.pool -= take
            self.c[f"saved_to_{kind}"] += take

    def __call__(self, ev, eng):
        t = ev["t"]
        c = self.c
        if t == "attack_declared" and ev["unit"] == "celestia" and ev["action"] == "fire":
            self._spend("fire", eng.actions["fire"].ep_cost)
        elif t == "area_attack" and ev["unit"] == "celestia":
            self._spend("storm", eng.actions[ev["action"]].ep_cost)
        elif t == "heal" and ev["unit"] == "celestia":
            self._spend("heal", ev.get("ep_cost", 0) or 0)
        elif t == "intervened":
            f, tg, atk = eng.u(ev["unit"]), eng.u(ev["target"]), eng.u(ev["attacker"])
            if f.side is Side.ALLY and tg.rank.value == "REAR":
                a = next((eng.actions[x] for x in atk.d.action_ids if eng.actions[x].kind is ActionKind.ATTACK), None)
                raw = eng.damage.expected(atk, a) if a else 0.0
                need = math.ceil(eng.defense.required_ep(tg, raw) - 1e-9)
                would = min(tg.ep, need) if eng.defense_allowed(tg) else 0
                who = "cel" if tg.id == "celestia" else "other"
                c[f"iv_{who}"] += 1
                c[f"iv_{who}_need"] += need
                c[f"iv_{who}_would"] += would
                self.pending[f.id] = {"who": who, "would": would}
        elif t == "damage":
            u = eng.u(ev["unit"])
            p = self.pending.pop(u.id, None)
            if p is not None:
                sp = ev.get("ep_spent", 0) or 0
                c[f"iv_{p['who']}_front_ep"] += sp
                c[f"iv_{p['who']}_front_dmg"] += ev.get("dmg", 0) or 0
                if p["who"] == "cel":
                    self.pool += p["would"]
                    c["saved_total"] += p["would"]
            elif u.id == "celestia" and eng.u(ev["attacker"]).side is Side.ENEMY:
                sp = ev.get("ep_spent", 0) or 0
                c["cel_hits"] += 1
                if sp > 0:
                    c["cel_def_hits"] += 1
                    c["cel_def_max"] = max(c["cel_def_max"], sp)
                    if sp >= 20:
                        c["cel_def_ge20"] += 1
                self._spend("selfdef", sp)
        elif t == "ko" and ev.get("unit") == "celestia" and not ev.get("after_incap"):
            if self.pool > 0:
                c["saved_to_fell"] += self.pool
                self.pool = 0.0


def _one(job):
    ep, qk, pol, seed, intel = job
    eng, ally = build(ep, qk, pol, seed, intel)
    tr = SensTracer(eng, ally)
    ct = CelTracer(eng)
    eng.listeners += [tr, ct]
    eng.run()
    cel = eng.u("celestia")
    row = {"ep": ep, "q": qk, "policy": pol, "seed": seed, "enemy_intel": intel,
           "win": int(eng.stats.winner == "ally"), "rounds": eng.stats.rounds, "actions": eng.action_index}
    row.update(tr.c)
    row.update(summarize_records(ally.records, tr))
    row.update(ct.c)
    row["saved_to_end"] = ct.pool
    for u in eng.state.units.values():
        if u.side is Side.ALLY:
            r = u.rank.value
            row[f"end_dead_{r}"] = row.get(f"end_dead_{r}", 0) + int(u.hp <= 0)
            row[f"end_incap_{r}"] = row.get(f"end_incap_{r}", 0) + int(u.incapacitated)
    row["cel_dead"] = int(cel.hp <= 0)
    row["cel_incap"] = int(cel.incapacitated)
    row["cel_end_ep"] = cel.ep
    row["cel_ep_max"] = cel.d.ep_max
    for k, v in Counter(t["cat"] for t in ally.turns).items():
        row["turn_" + k] = v
    row["turn_n"] = len(ally.turns)
    row["cel_wait"] = sum(1 for t in ally.turns if t["choice"] == "wait")
    ivs = [r for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR"]
    row["ivrec_protect"] = sum(1 for r in ivs if r["choice"] != "self")
    return row


def run():
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")
    jobs = [(ep, qk, pol) for qk in QS for ep in EPS for pol in POLICIES]
    if len(sys.argv) > 1 and sys.argv[1] == "smoke":
        S = S[::50]
    for ep, qk, pol in jobs:
        tag = f"ep{ep}_{qk}_{pol}" + ("_smoke" if len(S) < 1000 else "")
        if (OUT / f"{tag}.csv").exists():
            print("skip", tag, flush=True)
            continue
        with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
            B = list(ex.map(_one, [(ep, qk, pol, s, i) for s, i in S], chunksize=10))
        keys = sorted({k for b in B for k in b})
        write_csv(OUT / f"{tag}.csv", [{k: b.get(k, 0) for k in keys} for b in B])
        print("done", tag, flush=True)


if __name__ == "__main__":
    run()
