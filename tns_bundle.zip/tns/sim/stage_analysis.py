"""段階比較(A〜E)の主要指標を battles.csv から直接集計する。"""
import csv
from collections import defaultdict

def load(path):
    with open(path, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def agg(rows):
    g = defaultdict(list)
    for r in rows:
        g[(r["enemy_intel"], r["policy"])].append(r)
    out = {}
    for k, rs in g.items():
        n = len(rs); F = lambda c: sum(float(r[c] or 0) for r in rs)
        att = F("attacks_enemy")
        dmg = F("dmg_taken_ally_front") + F("dmg_taken_ally_rear")
        ld = [float(r["leader_down_round"]) for r in rs if r["leader_down_round"] != ""]
        fk = [float(r["first_ko_ally_attacks"]) for r in rs if r["first_ko_ally_attacks"] != ""]
        out[k] = {
            "win": F("win") / n, "draw": sum(r["winner"] == "draw" for r in rs) / n, "rounds": F("rounds") / n,
            "rear_dead": F("rear_dead_ally") / n, "front_dead": F("front_dead_ally") / n,
            "cel_dead": F("dead_celestia") / n,
            "adel_surv": F("survive_rounds_adel") / n, "van_surv": F("survive_rounds_vanguard") / n,
            "front_rate": F("attacks_enemy_on_front") / att if att else 0,
            "switch": F("target_switch_enemy") / att if att else 0,
            "streak": F("streak_sum_enemy") / max(F("streak_count_enemy"), 1),
            "dmg_per_att": dmg / att if att else 0, "dmg_front": F("dmg_taken_ally_front") / n, "dmg_rear": F("dmg_taken_ally_rear") / n,
            "first_ko_rate": len(fk) / n, "first_ko_att": sum(fk) / len(fk) if fk else float("nan"),
            "leader_round": sum(ld) / len(ld) if ld else float("nan"), "leader_rate": len(ld) / n,
            "iv": F("intervention_ally") / n, "open_iv": F("front_open_by_intervention_ally") / n,
            "intr": F("intrusion_ally") / n, "intr_hit": F("intrusion_hit_ally") / n, "intr_dmg": F("intrusion_damage_ally") / n,
            "prev": F("prevented_ally") / n, "breach": F("breach_damage_ally") / n,
            "keep": F("focus_keep") / n, "sw": F("focus_switch_better") / n, "hopeless": F("focus_release_hopeless") / n,
            "enemy_iv": F("intervention_enemy") / n,
        }
    return out
