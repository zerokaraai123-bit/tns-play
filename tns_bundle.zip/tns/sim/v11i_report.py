"""Ver0.11 初動タイミング頑健性テストの集計（out/v11i -> 表とグラフ）。python -m tns.sim.v11i_report"""
from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path

from .v11i import OUT, path_of

SPEED = {"leader": 15, "wolf_a": 14, "wolf_b": 13, "wolf_c": 12, "toolsmith": 12, "celestia": 11, "adel": 10,
         "vanguard": 9, "vanguard3": 9, "thrower": 8, "thrower2": 8}
JP = {"leader": "リーダー", "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "thrower": "投擲兵", "thrower2": "投擲兵2",
      "celestia": "セレスティア", "toolsmith": "学者", "adel": "左FRONT(アデル)", "vanguard3": "中央FRONT(前衛3)",
      "vanguard": "右FRONT(前衛2)", None: "（なし）"}
FOCUS = ["leader", "thrower", "thrower2", "celestia", "adel", "vanguard3", "vanguard"]
ENEMY = {"leader", "wolf_a", "wolf_b", "wolf_c", "thrower", "thrower2"}
FRONTS = ["adel", "vanguard3", "vanguard"]
INAME = {0: "低知能", 1: "通常知能", 2: "高知能", 3: "戦術級"}


def load_raw(off, n, pol, intel):
    p = path_of(off, n, pol, intel)
    if not p.exists():
        return None
    return [json.loads(l) for l in open(p, encoding="utf-8")]


def load(off, n, pol, intel):
    """軽量版（解析済みの要約だけをキャッシュ。生ログは保持しない）"""
    return P(off, n, pol, intel)


def pct(x, d=1):
    return f"{100 * x:.{d}f}"


def wr(R):
    return sum(r["win"] for r in R) / len(R)


def pair_z(R1, R2):
    """同じseedどうしの勝敗の差（R1−R2）と z 値"""
    m1 = {r["seed"]: r["win"] for r in R1}
    d = [m1[r["seed"]] - r["win"] for r in R2 if r["seed"] in m1]
    n = len(d)
    mu = sum(d) / n
    var = sum((x - mu) ** 2 for x in d) / (n - 1) if n > 1 else 0
    se = math.sqrt(var / n) if var > 0 else 0
    return mu, (mu / se if se else 0.0)


# ---------------------------------------------------------------- 1戦の解析
def parse(r):
    E = r["E"]
    T = [e for e in E if e[0] == "T"]
    tidx = {e[1]: e for e in T}
    out = {"win": r["win"], "seed": r["seed"]}
    # 行動順
    first, second, cnt = {}, {}, Counter()
    for e in T:
        u = e[2]
        cnt[u] += 1
        if cnt[u] == 1:
            first[u] = e[1]
        elif cnt[u] == 2:
            second[u] = e[1]
    out["first"], out["second"] = first, second
    out["q1"] = r["q1"]
    # 詠唱（セレスティアの最初の詠唱）
    cs = [e[1] for e in E if e[0] == "Cs" and e[2] == "celestia"]
    cc = [e[1] for e in E if e[0] == "Cc" and e[2] == "celestia"]
    cx = [e[1] for e in E if e[0] == "Cx" and e[2] == "celestia"]
    S = [e for e in E if e[0] == "S"]
    out["storms"], out["cancels"] = len(S), len(cx)
    out["cc1"] = cc[0] if cc else None
    if cc:
        c = cc[0]
        out["prev"] = tidx[c - 1][2] if (c - 1) in tidx else None
        out["next"] = tidx[c + 1][2] if (c + 1) in tidx else None
        s0 = max([x for x in cs if x <= c], default=None)
        out["cs1"] = s0
        out["acted_in_window"] = {u for e in T if s0 is not None and s0 < e[1] < c for u in [e[2]]}
        out["before_cc"] = {u: sum(1 for e in T if e[2] == u and e[1] < c) for u in ENEMY}
        out["storm_time"] = tidx[c][3]
    if S:
        s = S[0]
        out["storm_idx"], out["ep_at"] = s[1], s[2]
        nxt = [e for e in T if e[1] > s[1]]
        out["ep_after"] = nxt[0][6] if nxt else 0
    hp0 = T[0][7] if T else 0
    t21 = [e for e in T if e[1] >= 21]
    out["hpdmg20"] = hp0 - (t21[0][7] if t21 else (T[-1][7] if r["win"] == 0 else 0))
    if not t21 and r["win"]:
        out["hpdmg20"] = hp0
    ko = [e[1] for e in E if e[0] == "K" and e[2] in ENEMY]
    out["ko1"] = ko[0] if ko else None
    # 介入・危険
    C = Counter()
    for e in E:
        if e[0] == "I" and e[2] not in ENEMY:
            C["iv"] += 1
            C[f"iv_to_{e[3]}"] += 1
            C[f"iv_by_{e[2]}"] += 1
            if e[3] == "celestia" and e[5]:
                C["iv_cast"] += 1
        elif e[0] == "A" and e[2] in ENEMY and e[3] == "celestia":
            C["tg_cel"] += 1
            if e[4]:
                C["tg_cast"] += 1
        elif e[0] == "D" and e[2] == "celestia" and e[3] in ENEMY and e[4] > 0:
            C["raw_cel"] += 1
            if e[6]:
                C["raw_cast"] += 1
        elif e[0] == "K" and e[2] == "celestia":
            C["cel_ko"] += 1
            C["cel_incap_ev"] += e[3]
    out["C"] = C
    # 庇う → 無傷 → 完成 の連鎖（詠唱ごと）
    chains, casts = 0, 0
    ends = sorted([(x, "c") for x in cc] + [(x, "x") for x in cx])
    for s0 in cs:
        end = next(((x, k) for x, k in ends if x > s0), None)
        casts += 1
        if end is None or end[1] != "c":
            continue
        lo, hi = s0, end[0]
        ivs = sum(1 for e in E if e[0] == "I" and e[2] not in ENEMY and e[3] == "celestia" and lo < e[1] <= hi)
        raws = sum(1 for e in E if e[0] == "D" and e[2] == "celestia" and e[3] in ENEMY and e[4] > 0 and lo < e[1] <= hi)
        if ivs > 0 and raws == 0:
            chains += 1
    out["chains"], out["ncasts"] = chains, casts
    end = r["end"]["celestia"]
    out["cel_dead"], out["cel_incap_end"] = end["dead"], end["incap"]
    out["cel_incap_any"] = int(C["cel_incap_ev"] > 0 or end["incap"])
    out["N"] = r["N"]
    return out


@lru_cache(maxsize=None)
def P(off, n, pol, intel):
    p = path_of(off, n, pol, intel)
    if not p.exists():
        return None
    out = []
    with open(p, encoding="utf-8") as fh:
        for l in fh:
            out.append(parse(json.loads(l)))
    return out


def avg(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else float("nan")


# ---------------------------------------------------------------- 表
def tbl(head, rows):
    s = "| " + " | ".join(head) + " |\n|" + "---|" * len(head) + "\n"
    for r in rows:
        s += "| " + " | ".join(str(x) for x in r) + " |\n"
    return s


def sec_win(intel, offs):
    rows = []
    for n in range(9):
        row = [n]
        for o in offs:
            R = load(o, n, "v11", intel)
            row.append(pct(wr(R)) if R else "—")
        rows.append(row)
    return tbl(["詠唱"] + [f"{o}" for o in offs], rows)


def sec_sens(intel, a="B", b="C"):
    rows = []
    for n in range(9):
        R1, R2 = load(a, n, "v11", intel), load(b, n, "v11", intel)
        R0 = load("A", n, "v11", intel)
        if not (R1 and R0):
            continue
        d0, z0 = pair_z(R1, R0)
        if R2:
            d, z = pair_z(R1, R2)
            rows.append([n, pct(wr(R0)), pct(wr(R1)), pct(wr(R2)), f"{100*d0:+.1f} (z={z0:.1f})", f"{100*d:+.1f} (z={z:.1f})"])
        else:
            rows.append([n, pct(wr(R0)), pct(wr(R1)), "—", f"{100*d0:+.1f} (z={z0:.1f})", "—"])
    return tbl(["詠唱", "A", a, b, f"{a}−A", f"{a}−{b}"], rows)


def order_stats(off, n=0, intel=3):
    """最初の約20行動の順番（1巡目の並び＝q1, 2回目の行動番号）"""
    Q = P(off, n, "v11", intel)
    rows = []
    for u in FOCUS:
        r1 = [q["q1"].index(u) + 1 for q in Q if u in q["q1"]]
        dist = Counter(r1)
        top = ", ".join(f"{k}位:{100*v/len(r1):.0f}%" for k, v in sorted(dist.items()) if v / len(r1) >= 0.03)
        r2 = [q["second"].get(u) for q in Q]
        rows.append([JP[u], SPEED[u], f"{avg(r1):.2f}", top, f"{avg(r2):.1f}"])
    return tbl(["ユニット", "速度", "1回目の平均順位(1巡目)", "1回目の順位分布(3%以上)", "2回目の平均行動番号"], rows)


def inversion_stats(off, n=0, intel=3):
    Q = P(off, n, "v11", intel)
    res = {}
    for gap in (1, 2, 3, 4):
        tot = inv = 0
        battles = 0
        for q in Q:
            o = q["q1"]
            pos = {u: i for i, u in enumerate(o)}
            b = 0
            for x in o:
                for y in o:
                    if SPEED[x] - SPEED[y] == gap:
                        tot += 1
                        if pos[x] > pos[y]:
                            inv += 1
                            b = 1
            battles += b
        res[gap] = (inv / tot if tot else 0, battles / len(Q))
    lead = Counter(q["q1"][0] for q in Q)
    slow_top3 = sum(1 for q in Q if {"thrower", "thrower2"} & set(q["q1"][:3])) / len(Q)
    return res, lead, slow_top3


def completion_stats(off, n, intel=3):
    Q = P(off, n, "v11", intel)
    W = [q for q in Q if q.get("cc1")]
    prev = Counter(q["prev"] for q in W)
    nxt = Counter(q["next"] for q in W)
    return Q, W, prev, nxt


def fmt_counter(c, tot, k=5):
    return ", ".join(f"{JP.get(u, u)} {100*v/tot:.0f}%" for u, v in c.most_common(k))


def sec_completion(intel, offs, casts=range(1, 9)):
    rows = []
    for n in casts:
        for o in offs:
            if load(o, n, "v11", intel) is None:
                continue
            Q, W, prev, nxt = completion_stats(o, n, intel)
            if not W:
                continue
            ent = -sum((v / len(W)) * math.log2(v / len(W)) for v in nxt.values())
            rows.append([n, o, pct(len(W) / len(Q)), fmt_counter(prev, len(W), 3), fmt_counter(nxt, len(W), 3),
                         f"{ent:.2f}"])
    return tbl(["詠唱", "条件", "完成した戦闘%", "完成の直前に行動した者（＝完成のきっかけ）", "完成の直後に行動する者",
                "直後の散らばり(ビット)"], rows)


def sec_window(intel, offs, casts=range(1, 9)):
    """詠唱中（開始〜完成）に主要な敵が行動した割合"""
    rows = []
    for n in casts:
        for o in offs:
            if load(o, n, "v11", intel) is None:
                continue
            Q, W, _, _ = completion_stats(o, n, intel)
            if not W:
                continue
            row = [n, o]
            for u in ["leader", "wolf_a", "thrower", "thrower2"]:
                row.append(pct(sum(1 for q in W if u in q["acted_in_window"]) / len(W), 0))
            row.append(f"{avg([q['storm_time'] for q in W]):.3f}")
            rows.append(row)
    return tbl(["詠唱", "条件", "リーダー", "狼A", "投擲兵", "投擲兵2", "完成時刻(平均, 巡)"], rows)


def sec_win_by_leader(intel, offs, casts=range(1, 9)):
    """完成時点でリーダーが何回行動していたか → 勝率"""
    rows = []
    for n in casts:
        for o in offs:
            if load(o, n, "v11", intel) is None:
                continue
            Q, W, _, _ = completion_stats(o, n, intel)
            g = defaultdict(list)
            for q in W:
                g[q["before_cc"]["leader"]].append(q["win"])
            g2 = defaultdict(list)
            for q in W:
                g2[q["before_cc"]["thrower"] + q["before_cc"]["thrower2"]].append(q["win"])
            s1 = "; ".join(f"{k}回:{len(v)}戦 {pct(sum(v)/len(v),0)}%" for k, v in sorted(g.items()) if len(v) >= 10)
            s2 = "; ".join(f"{k}回:{len(v)}戦 {pct(sum(v)/len(v),0)}%" for k, v in sorted(g2.items()) if len(v) >= 10)
            rows.append([n, o, len(W), s1, s2])
    return tbl(["詠唱", "条件", "完成数", "完成時点のリーダー行動回数 → 件数・勝率", "完成時点の投擲兵(2体合計)行動回数 → 件数・勝率"], rows)


def sec_win_by_next(intel, off, n):
    Q, W, prev, nxt = completion_stats(off, n, intel)
    g = defaultdict(list)
    for q in W:
        g[q["next"]].append(q["win"])
    rows = [[JP.get(u, u), len(v), pct(sum(v) / len(v))] for u, v in sorted(g.items(), key=lambda kv: -len(kv[1])) if len(v) >= 10]
    return tbl(["完成直後に行動する者", "件数", "勝率%"], rows)


def sec_iv(intel, off, pol="v11"):
    rows = []
    for n in range(9):
        Q = P(off, n, pol, intel)
        if Q is None:
            continue
        m = lambda k: f"{avg([q['C'][k] for q in Q]):.2f}"
        tg = sum(q["C"]["tg_cast"] for q in Q)
        ok = sum(q["C"]["iv_cast"] for q in Q)
        rows.append([n, m("iv"), m("iv_to_celestia"), m("iv_to_toolsmith"), m("iv_by_adel"), m("iv_by_vanguard3"),
                     m("iv_by_vanguard"), m("tg_cast"), m("iv_cast"), f"{max(0, tg-ok)/len(Q):.2f}", m("raw_cast"),
                     f"{avg([q['cancels'] for q in Q]):.2f}"])
    return tbl(["詠唱", "介入合計", "→セレスティア", "→学者", "左FRONT", "中央FRONT", "右FRONT", "詠唱中に狙われた",
                "詠唱中の介入成功", "介入できず", "詠唱中の素通し被弾", "詠唱キャンセル"], rows)


def sec_chain(intel, off, pol="v11"):
    rows = []
    for n in range(1, 9):
        Q = P(off, n, pol, intel)
        if Q is None:
            continue
        ch = sum(q["chains"] for q in Q)
        nc = sum(q["ncasts"] for q in Q)
        rows.append([n, f"{ch/len(Q):.2f}", f"{nc/len(Q):.2f}", pct(ch / nc if nc else 0)])
    return tbl(["詠唱", "連鎖/戦", "詠唱開始/戦", "連鎖/詠唱 %"], rows)


def sec_danger(intel, off, pol="v11"):
    rows = []
    for n in range(9):
        Q = P(off, n, pol, intel)
        if Q is None:
            continue
        rows.append([n, pct(wr(Q)), f"{avg([q['storms'] for q in Q]):.2f}", f"{avg([q['cancels'] for q in Q]):.2f}",
                     f"{avg([q['C']['raw_cel'] for q in Q]):.2f}", pct(avg([q['cel_incap_any'] for q in Q])),
                     pct(avg([q['cel_dead'] for q in Q])), f"{avg([q['C']['tg_cast'] for q in Q]):.2f}"])
    return tbl(["詠唱", "勝率%", "炎嵐/戦", "キャンセル/戦", "セレスティア素通し被弾/戦", "セレスティア戦闘不能%(一度でも)",
                "セレスティア死亡%", "詠唱中に狙われた/戦"], rows)


def sec_ep(intel, off, pol="v11"):
    rows = []
    for n in range(9):
        Q = P(off, n, pol, intel)
        if Q is None:
            continue
        rows.append([n, f"{avg([q.get('storm_idx') for q in Q]):.1f}", f"{avg([q.get('ep_at') for q in Q]):.0f}",
                     f"{avg([q.get('ep_after') for q in Q]):.0f}", f"{avg([q['hpdmg20'] for q in Q]):.0f}",
                     f"{avg([q['ko1'] for q in Q]):.1f}"])
    return tbl(["詠唱", "最初の炎嵐(行動番号)", "炎嵐時の敵EP合計", "炎嵐直後の敵EP合計", "最初の20行動の敵HPダメージ",
                "最初の敵撃破(行動番号)"], rows)


def sec_never(intel=3, offs=("B", "A", "C")):
    rows = []
    for o in offs:
        for n in (0, 2, 4, 6):
            R1, R0 = load(o, n, "v11", intel), load(o, n, "never", intel)
            if not (R1 and R0):
                continue
            d, z = pair_z(R1, R0)
            Q1, Q0 = P(o, n, "v11", intel), P(o, n, "never", intel)
            f = lambda Q, k: f"{avg([q[k] for q in Q]):.2f}"
            rows.append([o, n, pct(wr(R1)), pct(wr(R0)), f"{100*d:+.1f} (z={z:.1f})", f"{f(Q1,'storms')} / {f(Q0,'storms')}",
                         f"{f(Q1,'cancels')} / {f(Q0,'cancels')}",
                         f"{avg([q['C']['raw_cel'] for q in Q1]):.2f} / {avg([q['C']['raw_cel'] for q in Q0]):.2f}",
                         f"{pct(avg([q['cel_incap_any'] for q in Q1]))} / {pct(avg([q['cel_incap_any'] for q in Q0]))}",
                         f"{pct(avg([q['cel_dead'] for q in Q1]))} / {pct(avg([q['cel_dead'] for q in Q0]))}"])
    return tbl(["条件", "詠唱", "介入AI勝率", "Never勝率", "差(同seed)", "炎嵐 介入/Never", "キャンセル", "素通し被弾",
                "セレ戦闘不能%", "セレ死亡%"], rows)


def sec_ai_side(intel=3, offs=("A", "A0", "B", "C"), n=0):
    """敵AIの行動の変化（1巡目の敵の攻撃先）"""
    rows = []
    for o in offs:
        R = load_raw(o, n, "v11", intel)
        if R is None:
            continue
        tg = Counter()
        lead = Counter()
        for r in R:
            for e in r["E"]:
                if e[0] == "T" and e[1] > 11:
                    break
                if e[0] == "A" and e[2] in ENEMY:
                    tg[e[3]] += 1
                    if e[2] == "leader":
                        lead[e[3]] += 1
        tot = sum(tg.values())
        rows.append([o, fmt_counter(tg, tot, 4), fmt_counter(lead, sum(lead.values()), 3)])
    return tbl(["条件", "1巡目(行動1〜11)の敵の攻撃先", "リーダーの初手の攻撃先"], rows)


def sec_46(intel=3, offs=("A", "A0", "B", "C")):
    rows = []
    for o in offs:
        for n in (4, 6):
            Q = P(o, n, "v11", intel)
            if Q is None:
                continue
            W = [q for q in Q if q.get("cc1")]
            ch = sum(q["chains"] for q in Q)
            nc = sum(q["ncasts"] for q in Q)
            rows.append([o, n, pct(wr(Q)), pct(len(W) / len(Q), 0), f"{avg([q['cancels'] for q in Q]):.2f}",
                         f"{avg([q['C']['tg_cast'] for q in Q]):.2f}", f"{avg([q['C']['iv_cast'] for q in Q]):.2f}",
                         f"{avg([q['C']['raw_cast'] for q in Q]):.2f}", pct(ch / nc if nc else 0, 0),
                         pct(sum(1 for q in W if 'leader' in q['acted_in_window']) / max(1, len(W)), 0),
                         f"{avg([q.get('storm_time') for q in W]):.2f}",
                         pct(avg([q['cel_incap_any'] for q in Q]), 0), pct(avg([q['cel_dead'] for q in Q]), 0),
                         f"{avg([q['ko1'] for q in Q]):.1f}"])
    return tbl(["条件", "詠唱", "勝率%", "最初の詠唱が完成%", "キャンセル/戦", "詠唱中に狙われた", "詠唱中の介入成功",
                "詠唱中の素通し被弾", "庇う→無傷→完成 %", "詠唱中にリーダーが行動%", "完成時刻(巡)", "セレ戦闘不能%",
                "セレ死亡%", "最初の敵撃破(行動番号)"], rows)


def graph(path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for f in font_manager.findSystemFonts():
        if "NotoSansCJK" in f.replace(" ", "") or "NotoSansCJK" in f:
            font_manager.fontManager.addfont(f)
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "Noto Sans CJK TC", "sans-serif"]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), sharey=True)
    sty = {"A": ("k", "o-", "A: オフセットなし"), "A0": ("gray", "x--", "A0: 速度の階段のみ(乱数なし)"),
           "B": ("tab:blue", "s-", "B: 小(幅0.02巡)"), "C": ("tab:red", "^-", "C: 中(幅0.04巡)")}
    for ax, it in zip(axes, (3, 1, 0)):
        for o, (c, m, lab) in sty.items():
            xs, ys = [], []
            for n in range(9):
                R = load(o, n, "v11", it)
                if R:
                    xs.append(n)
                    ys.append(100 * wr(R))
            if xs:
                ax.plot(xs, ys, m, color=c, label=lab)
        ax.set_title(f"{INAME[it]}（介入AI, 各1,000戦）")
        ax.set_xlabel("炎嵐の詠唱時間（行動数）")
        ax.set_xticks(range(9))
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("勝率 %")
    axes[0].legend(fontsize=8)
    fig.suptitle("3FRONT・2REAR／介入担当範囲あり／敵6体(投擲兵追加)：初回行動時刻オフセット別の勝率")
    fig.tight_layout()
    fig.savefig(path, dpi=110)


def main():
    out = []
    w = out.append
    w("## 勝率（戦術級, 介入AI, 各1,000戦）\n" + sec_win(3, ["A", "A0", "B", "C"]))
    w("## 感度（戦術級）\n" + sec_sens(3))
    for it in (1, 0):
        w(f"## 勝率（{INAME[it]}）\n" + sec_win(it, ["A", "A0", "B", "C"]))
        w(f"## 感度（{INAME[it]}）\n" + sec_sens(it))
    for o in ("A", "A0", "B", "C"):
        if load(o, 0, "v11", 3) is None:
            continue
        res, lead, top3 = inversion_stats(o)
        w(f"## 行動順（{o}, 戦術級, 詠唱0）\n" + order_stats(o) +
          "\n速度差ごとの逆転率（1巡目, ペア単位 / 1組でも逆転した戦闘の割合）: " +
          ", ".join(f"差{g}: {pct(a)}% / {pct(b)}%" for g, (a, b) in res.items()) +
          f"\n先頭: {fmt_counter(lead, sum(lead.values()), 4)}／投擲兵が1巡目の3番以内: {pct(top3)}%\n")
    w("## 完成位置（戦術級）\n" + sec_completion(3, ["A", "B", "C"]))
    w("## 詠唱中に敵が行動した割合（戦術級）\n" + sec_window(3, ["A", "B", "C"]))
    w("## 完成位置×勝率（戦術級）\n" + sec_win_by_leader(3, ["A", "B", "C"]))
    for o in ("A", "B", "C"):
        for n in (4, 5, 6):
            if load(o, n, "v11", 3):
                w(f"## 完成直後の行動者×勝率（{o}, 詠唱{n}）\n" + sec_win_by_next(3, o, n))
    for it in (3, 1, 0):
        for o in ("A", "B", "C"):
            if load(o, 0, "v11", it) is None:
                continue
            w(f"## 介入（{INAME[it]}, {o}）\n" + sec_iv(it, o))
            w(f"## 連鎖（{INAME[it]}, {o}）\n" + sec_chain(it, o))
            w(f"## 危険（{INAME[it]}, {o}）\n" + sec_danger(it, o))
            w(f"## EP剥がし（{INAME[it]}, {o}）\n" + sec_ep(it, o))
    w("## 介入AI vs Never（戦術級）\n" + sec_never())
    for it in (1, 0):
        w(f"## 介入AI vs Never（{INAME[it]}）\n" + sec_never(it, ("B",)))
    w("## 詠唱4と6の比較（戦術級）\n" + sec_46())
    w("## 詠唱4と6の比較（通常知能）\n" + sec_46(1, ("A", "B", "C")))
    w("## 敵AIの行動変化（戦術級, 詠唱0）\n" + sec_ai_side())
    txt = "\n".join(out)
    (OUT / "report_tables.md").write_text(txt, encoding="utf-8")
    graph(OUT / "winrate_by_cast.png")
    print(txt)


if __name__ == "__main__":
    main()
