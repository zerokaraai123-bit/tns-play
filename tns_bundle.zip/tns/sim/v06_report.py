"""Ver0.6 の結果表。 python -m tns.sim.v06_report > out/v06_tables.md"""
from __future__ import annotations

import math

from .v06_analysis import collect

DS = (("D1", "D1"), ("D15", "D1.5"), ("D2", "D2"), ("D3", "D3"))
PS = ("P0", "P1", "P2", "P3")


def f(v, kind="f1"):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "-"
    if kind == "%":
        return f"{v:.0%}"
    if kind == "f2":
        return f"{v:.2f}"
    if kind == "i":
        return f"{v:.0f}"
    return f"{v:.1f}"


def build():
    s1 = collect("out", "v6s1", by=())
    s2 = collect("out", "v6s2", by=("enemy_intel",))
    s3a = collect("out", "v6s3a", by=())
    s3b = collect("out", "v6s3b", by=())
    s3c = collect("out", "v6s3c", by=("policy",))

    def A(tag):
        if tag in s2:
            return s2[tag]["all"], s2[tag]["all"]["n"]
        return s1.get(tag, {}).get("all", {}), s1.get(tag, {}).get("all", {}).get("n", 0)

    S = []

    def grid(title, key, kind, x, note=""):
        L = [f"\n#### {title}（前衛HP×{x}）"]
        if note:
            L.append(note)
        L.append("| 生身ダメージ＼負傷補正 | " + " | ".join(PS) + " |")
        L.append("|---|" + "---|" * len(PS))
        for d, dj in DS:
            cells = []
            for p in PS:
                a, n = A(f"{d}_{p}_x{x}")
                cells.append(f(a.get(key), kind) + ("*" if n >= 4000 else ""))
            L.append(f"| {dj} | " + " | ".join(cells) + " |")
        return "\n".join(L)

    note = "（各セル1,000戦。*はStage2で4,000戦）"
    for x in ("1.5", "1.75"):
        S.append(grid("G1 ①味方勝率", "win", "%", x, note))
        S.append(grid("G2 ②FRONT死亡率", "ally_front_death_rate", "%", x))
        S.append(grid("G3 ③REAR死亡率", "ally_rear_death_rate", "%", x))
        S.append(grid("G4 ⑧救援猶予 REAR（初被弾から死亡までの味方の行動回数・中央値）", "rear_rw_side_med", "i", x))
        S.append(grid("G5 ⑧救援猶予0の割合 REAR（初被弾の次の味方行動を待たずに死亡）", "rear_rw0_rate", "%", x))
        S.append(grid("G6 ⑧救援猶予 FRONT（中央値）", "front_rw_side_med", "i", x))

    # 詳細表
    cols = [("条件", lambda t, a: t), ("n", lambda t, a: str(a["n"])),
            ("④初回直撃のHP減少 F/R", lambda t, a: f"{f(a['front_first_dmg'], '%')}/{f(a['rear_first_dmg'], '%')}"),
            ("⑤生身で耐えた回数(死亡者) F/R", lambda t, a: f"{f(a['front_body_hits_to_death'])}/{f(a['rear_body_hits_to_death'])}"),
            ("⑥EPで防いだ回数 F/R", lambda t, a: f"{f(a['front_full_blocks'])}/{f(a['rear_full_blocks'])}"),
            ("⑦初被弾→死亡 行動数 F中央値[10%-90%]", lambda t, a: f"{f(a['front_hit_to_death_med'], 'i')}[{f(a['front_hit_to_death_p10'], 'i')}-{f(a['front_hit_to_death_p90'], 'i')}]"),
            ("⑦同 R", lambda t, a: f"{f(a['rear_hit_to_death_med'], 'i')}[{f(a['rear_hit_to_death_p10'], 'i')}-{f(a['rear_hit_to_death_p90'], 'i')}]"),
            ("⑧RW 味方行動 F/R 平均", lambda t, a: f"{f(a['front_rw_side_mean'])}/{f(a['rear_rw_side_mean'])}"),
            ("⑧RW 本人の行動 F/R", lambda t, a: f"{f(a['front_rw_self_mean'])}/{f(a['rear_rw_self_mean'])}"),
            ("⑨⑩必要EP増加 HP50%未満/25%未満（F）", lambda t, a: f"×{f(a['front_ep_increase_under50'], 'f2')}/×{f(a['front_ep_increase_under25'], 'f2')}"),
            ("⑪直撃後に防御へ復帰 F/R", lambda t, a: f"{f(a['front_returned_rate'], '%')}/{f(a['rear_returned_rate'], '%')}"),
            ("⑫復帰後に防いだ回数 F", lambda t, a: f(a["front_full_after_returned"])),
            ("⑬直撃後に最後まで生存 F/R", lambda t, a: f"{f(a['front_hit_survived_rate'], '%')}/{f(a['rear_hit_survived_rate'], '%')}"),
            ("巡数", lambda t, a: f(a["rounds"]))]
    for x in ("1.5", "1.75"):
        L = [f"\n#### T1 16条件の詳細（前衛HP×{x}、F=FRONT・R=REAR）", "| " + " | ".join(c[0] for c in cols) + " |",
             "|" + "---|" * len(cols)]
        for d, dj in DS:
            for p in PS:
                t = f"{d}_{p}_x{x}"
                a, n = A(t)
                if a:
                    L.append("| " + " | ".join(c[1](f"{dj}×{p}", a) for c in cols) + " |")
        S.append("\n".join(L))

    # 分布
    L = ["\n#### T2 ⑭救援猶予の分布（初被弾から死亡までの味方の行動回数、死亡した個体。前衛HP×1.75・P2）",
         "| 条件 | 対象 | 0回 | 1〜2回 | 3〜5回 | 6〜9回 | 10回以上 |", "|---|---|---|---|---|---|---|"]
    for d, dj in DS:
        a, n = A(f"{d}_P2_x1.75")
        for g, gj in (("front", "FRONT"), ("rear", "REAR")):
            L.append(f"| {dj}×P2 | {gj} | " + " | ".join(f(a.get(f"{g}_rw_hist_{k}"), "%") for k in ("0", "1_2", "3_5", "6_9", "10p")) + " |")
    S.append("\n".join(L))

    # ⑨⑩
    L = ["\n#### T3 ⑨⑩ HPが減った後の「1ダメージを防ぐ必要EP」の増加率（HP75%以上を1とする。実戦での平均。前衛HP×1.75・D1）",
         "| 負傷補正 | FRONT HP50%未満 | FRONT HP25%未満 | REAR HP50%未満 | HP50%未満の帯で展開した防御の割合(FRONT) |", "|---|---|---|---|---|"]
    for p in PS:
        a, n = A(f"D1_{p}_x1.75")
        L.append(f"| {p} | ×{f(a.get('front_ep_increase_under50'), 'f2')} | ×{f(a.get('front_ep_increase_under25'), 'f2')} | "
                 f"×{f(a.get('rear_ep_increase_under50'), 'f2')} | {f(a.get('front_def_share_under50'), 'f2')}回/戦 |")
    S.append("\n".join(L))

    # 介入
    L = ["\n#### T4 介入後（持ち場離脱中・自己防御不可）に別の攻撃を受けた: 1戦あたりの被弾・ダメージ・死亡（FRONT、状況判断）",
         "| 条件 | 介入/戦 | 離脱中の被弾 | 離脱中のダメージ | 離脱中に死亡 |", "|---|---|---|---|---|"]
    for d, dj in DS:
        for p in ("P0", "P3"):
            a, n = A(f"{d}_{p}_x1.75")
            L.append(f"| {dj}×{p}（×1.75） | {f(a.get('interventions'))} | {f(a.get('front_disp_hits'), 'f2')} | {f(a.get('front_disp_dmg'))} | {f(a.get('front_disp_ko'), 'f2')} |")
    S.append("\n".join(L))
    L = ["\n#### T5 介入方針3種での比較（前衛HP×1.75・P2、各方針1,000戦）",
         "| 条件 | 方針 | 勝率 | 介入/戦 | 離脱中の被弾/戦 | 離脱中に死亡/戦 | FRONT死亡率 | REAR死亡率 |", "|---|---|---|---|---|---|---|---|"]
    for t in ("D1_P2_x1.75", "D2_P2_x1.75"):
        for pol in ("always", "never", "situational"):
            a = s3c.get(t, {}).get(("policy", pol), {})
            if a:
                L.append(f"| {t.split('_x')[0]} | {pol} | {f(a['win'], '%')} | {f(a['interventions'])} | {f(a['front_disp_hits'], 'f2')} | "
                         f"{f(a['front_disp_ko'], 'f2')} | {f(a['ally_front_death_rate'], '%')} | {f(a['ally_rear_death_rate'], '%')} |")
    S.append("\n".join(L))

    # 統制
    L = ["\n#### T6 統制: 負傷補正を「全員」に掛けた場合と「味方だけ」に掛けた場合（前衛HP×1.75）",
         "| 条件 | 全員に補正: 勝率 | 味方だけ: 勝率 | 全員: FRONT死亡 | 味方だけ: FRONT死亡 | 全員: REAR死亡 | 味方だけ: REAR死亡 |", "|---|---|---|---|---|---|---|"]
    for t in ("D1_P2", "D1_P3", "D15_P2", "D15_P3"):
        a, n = A(f"{t}_x1.75")
        b = s3a.get(f"{t}_x1.75_allyonly", {}).get("all", {})
        if b:
            L.append(f"| {t} | {f(a['win'], '%')} | {f(b['win'], '%')} | {f(a['ally_front_death_rate'], '%')} | {f(b['ally_front_death_rate'], '%')} | "
                     f"{f(a['ally_rear_death_rate'], '%')} | {f(b['ally_rear_death_rate'], '%')} |")
    S.append("\n".join(L))
    L = ["\n#### T7 補助地図（参考）: D2・D3 で戦闘が成立する前衛HPにしたとき、負傷補正 P0 と P3 の差（各1,000戦）",
         "| 前衛HP | 条件 | 勝率 | FRONT死亡 | REAR死亡 | RW中央値 F/R | 救援猶予0 R |", "|---|---|---|---|---|---|---|"]
    for x in ("2.5", "3"):
        for t in ("D2_P0", "D2_P3", "D3_P0", "D3_P3"):
            a = s3b.get(f"{t}_x{x}", {}).get("all", {})
            if a:
                L.append(f"| ×{x} | {t} | {f(a['win'], '%')} | {f(a['ally_front_death_rate'], '%')} | {f(a['ally_rear_death_rate'], '%')} | "
                         f"{f(a['front_rw_side_med'], 'i')}/{f(a['rear_rw_side_med'], 'i')} | {f(a['rear_rw0_rate'], '%')} |")
    S.append("\n".join(L))

    # 知能別（Stage2）
    L = ["\n#### T8 敵知能別の味方勝率（Stage2、各1,000戦）", "| 条件 | 低 | 通常 | 高 | 戦術 |", "|---|---|---|---|---|"]
    for t in s2:
        L.append(f"| {t} | " + " | ".join(f(s2[t][('enemy_intel', i)]['win'], '%') for i in "0123") + " |")
    S.append("\n".join(L))
    return "\n".join(S)


if __name__ == "__main__":
    print(build())
