"""原因分析の集計。 python -m tns.sim.v11h_report > out/v11h/report.md"""
from __future__ import annotations

import json
import math
from collections import Counter, defaultdict

from .v11h import OUT

AL = ["adel", "vanguard3", "vanguard", "celestia", "toolsmith"]
NM = {"adel": "アデル（左）", "vanguard3": "前衛3（中央）", "vanguard": "前衛2（右）", "celestia": "セレスティア", "toolsmith": "エーテル学者",
      "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "leader": "リーダー", "thrower": "投擲兵", "thrower2": "投擲兵2"}
LN = {"_lane": "担当範囲あり", "_nolane": "担当範囲なし"}


def load(suffix, n, pol="v11", it=3):
    p = OUT / f"{suffix}_cast{n}_{pol}_i{it}.jsonl"
    return {r["seed"]: r for r in map(json.loads, open(p, encoding="utf-8"))} if p.exists() else None


def mean(x):
    x = list(x)
    return sum(x) / len(x) if x else float("nan")


def battle_stats(r):
    """1戦の各種集計。"""
    E = r["E"]
    s = Counter()
    first_storm = None
    pend_iv = {}             # 攻撃者 -> 介入した前衛（直後のダメージを「介入で受けた」とする）
    last_attack = None
    storms = []
    enemy_ko = None
    ally_ko = {}
    iv_idx = []
    hold = Counter()
    nT = 0
    for k, e in enumerate(E):
        tag = e[0]
        if tag == "T":
            nT += 1
            for f, h in zip(("adel", "vanguard3", "vanguard"), e[5]):
                hold[f] += int(h)
            if e[2] == "celestia":
                s["cel_turns"] += 1
        elif tag == "A":
            _, i, a, tg, casting, act, via = e
            last_attack = (a, tg, casting, i)
            if a in NM and a not in AL:
                s[f"atk_{tg}"] += 1
                if tg == "celestia":
                    s["atk_cel_cast" if casting else "atk_cel_norm"] += 1
                if i >= 6 and i <= 25:
                    s[f"atk6_25_{tg}"] += 1
        elif tag == "I":
            _, i, f, tg, atk, casting = e
            if f in AL:
                s[f"iv_{f}"] += 1
                s[f"ivt_{tg}"] += 1
                s["iv"] += 1
                iv_idx.append(i)
                pend_iv[atk] = f
        elif tag == "D":
            _, i, u, a, dmg, ep = e
            if u in AL:
                via_iv = pend_iv.pop(a, None) == u
                s[f"hit_{u}"] += 1
                s[f"hpdmg_{u}"] += dmg
                s[f"ep_{u}"] += ep
                if ep > 0:
                    s[f"def_{u}"] += 1
                if dmg > 0:
                    s[f"raw_{u}"] += 1
                if via_iv:
                    s[f"ivhit_{u}"] += 1
            elif a in AL:
                s["enemy_hpdmg"] += dmg
                if first_storm is not None:
                    if i <= first_storm[0] + 10:
                        s["dmg10"] += dmg
                    if i <= first_storm[0] + 20:
                        s["dmg20"] += dmg
        elif tag == "S":
            _, i, ep, hp = e
            storms.append(i)
            if first_storm is None:
                nxt = next((x for x in E[k + 1:] if x[0] == "T"), None)
                first_storm = (i, ep, nxt[6] if nxt else ep, hp)
        elif tag == "K":
            _, i, u, incap, after = e
            if u not in AL and enemy_ko is None and not after:
                enemy_ko = i
            if u in AL and u not in ally_ko and not after:
                ally_ko[u] = i
        elif tag == "R":
            _, i, a, tg, cb = e
            if tg in AL:
                s["intr"] += 1
                if any(0 <= i - j <= 5 for j in iv_idx):
                    s["intr_after_iv5"] += 1
    s["first_iv"] = iv_idx[0] if iv_idx else None
    s["consec_iv"] = sum(1 for a, b in zip(iv_idx, iv_idx[1:]) if b - a <= 2)
    return s, first_storm, storms, enemy_ko, ally_ko, hold, nT


def summarize(R):
    N = len(R)
    agg = Counter()
    fs, ek, fiv, ako = [], [], [], defaultdict(list)
    holdf = Counter(); nT = 0
    mage = Counter()
    for r in R.values():
        s, f, storms, eko, ako_, hold, nt = battle_stats(r)
        for k, v in s.items():
            if v is not None and k != "first_iv":
                agg[k] += v
        if s["first_iv"] is not None:
            fiv.append(s["first_iv"])
        if f:
            fs.append(f)
        if eko is not None:
            ek.append(eko)
        for u, i in ako_.items():
            ako[u].append(i)
        holdf.update(hold); nT += nt
        mage.update(c for _, c in r["mage"])
        agg["storms"] += len(storms)
        for u in AL:
            agg[f"dead_{u}"] += r["end"][u]["dead"]
            agg[f"incap_{u}"] += r["end"][u]["incap"]
            agg[f"endhp_{u}"] += r["end"][u]["hp"] / r["end"][u]["max"]
        agg["end_ep_cel"] += r["end"]["celestia"]["ep"]
    out = {k: v / N for k, v in agg.items()}
    out["win"] = mean(r["win"] for r in R.values()) * 100
    out["N"] = mean(r["N"] for r in R.values())
    out["first_storm_idx"] = mean(f[0] for f in fs)
    out["storm_ep_before"] = mean(f[1] for f in fs)
    out["storm_ep_after"] = mean(f[2] for f in fs)
    out["first_enemy_ko"] = mean(ek) if ek else float("nan")
    out["first_enemy_ko_rate"] = len(ek) / N * 100
    out["first_iv"] = mean(fiv) if fiv else float("nan")
    out["ally_ko"] = {u: (mean(v), len(v) / N * 100) for u, v in ako.items()}
    out["hold"] = {f: holdf[f] / max(nT, 1) * 100 for f in ("adel", "vanguard3", "vanguard")}
    out["mage"] = {k: v / N for k, v in mage.items()}
    return out


def main():
    L = []
    # 0. 離散化スイープ
    L.append("## A. 詠唱時間スイープ（戦術級250戦・介入AI）— 詠唱6だけが特異点かを点検\n")
    L.append("| 担当範囲 | " + " | ".join(f"詠唱{n}" for n in range(9)) + " |\n|---|" + "---|" * 9)
    for suf in ("_nolane", "_lane"):
        cells = []
        for n in range(9):
            R = load(suf, n)
            cells.append(f"{mean(r['win'] for r in R.values())*100:.0f}%" if R else "–")
        L.append(f"| {LN[suf]} | " + " | ".join(cells) + " |")
    # 1. 戦術級 詠唱0 vs 6 詳細
    for suf in ("_nolane", "_lane"):
        A, B = load(suf, 0), load(suf, 6)
        if not A or not B:
            continue
        a, b = summarize(A), summarize(B)
        L.append(f"\n## B. 戦術級・詠唱0 vs 詠唱6（{LN[suf]}・介入AI・250戦）\n")
        L.append(f"- 勝率 {a['win']:.0f}% → {b['win']:.0f}%、総行動 {a['N']:.0f} → {b['N']:.0f}")
        W = [k for k in A if not A[k]["win"] and B[k]["win"]]
        Lz = [k for k in A if A[k]["win"] and not B[k]["win"]]
        L.append(f"- 同一シードの勝敗反転: 詠唱0敗北→詠唱6勝利 **{len(W)}戦**、詠唱0勝利→詠唱6敗北 **{len(Lz)}戦**（変わらず: {len(A) - len(W) - len(Lz)}戦）\n")
        L.append("**敵の攻撃対象（1戦あたり）**\n")
        L.append("| 対象 | 詠唱0 | 詠唱6 |\n|---|---|---|")
        for u in AL:
            L.append(f"| {NM[u]} | {a.get('atk_' + u, 0):.1f} | {b.get('atk_' + u, 0):.1f} |")
        L.append(f"| うちセレスティア（通常時 / 詠唱中） | {a.get('atk_cel_norm',0):.1f} / {a.get('atk_cel_cast',0):.1f} | {b.get('atk_cel_norm',0):.1f} / {b.get('atk_cel_cast',0):.1f} |")
        L.append(f"| 行動6〜25の間にセレスティアを狙った回数 | {a.get('atk6_25_celestia',0):.2f} | {b.get('atk6_25_celestia',0):.2f} |")
        L.append("\n**味方の被害分布（1戦あたり）**\n")
        L.append("| 味方 | 受けた攻撃 0→6 | エーテル防御 | 介入で受けた | HP直接被弾 | HPダメ | EP消費 | 戦闘不能率 | 死亡率 |\n|---|---|---|---|---|---|---|---|---|")
        for u in AL:
            g = lambda x, k: x.get(k, 0)
            L.append(f"| {NM[u]} | {g(a,'hit_'+u):.1f}→{g(b,'hit_'+u):.1f} | {g(a,'def_'+u):.1f}→{g(b,'def_'+u):.1f} | {g(a,'ivhit_'+u):.1f}→{g(b,'ivhit_'+u):.1f} | "
                     f"{g(a,'raw_'+u):.1f}→{g(b,'raw_'+u):.1f} | {g(a,'hpdmg_'+u):.0f}→{g(b,'hpdmg_'+u):.0f} | {g(a,'ep_'+u):.0f}→{g(b,'ep_'+u):.0f} | "
                     f"{g(a,'incap_'+u)*100:.0f}%→{g(b,'incap_'+u)*100:.0f}% | {g(a,'dead_'+u)*100:.0f}%→{g(b,'dead_'+u)*100:.0f}% |")
        L.append("\n**前衛の状態**\n")
        L.append("| 前衛 | 持ち場にいた手番の割合 0→6 | 介入回数 | 終了時HP | 戦闘不能 | 死亡 |\n|---|---|---|---|---|---|")
        for f in ("adel", "vanguard3", "vanguard"):
            L.append(f"| {NM[f]} | {a['hold'][f]:.0f}%→{b['hold'][f]:.0f}% | {a.get('iv_'+f,0):.2f}→{b.get('iv_'+f,0):.2f} | {a.get('endhp_'+f,0)*100:.0f}%→{b.get('endhp_'+f,0)*100:.0f}% | "
                     f"{a.get('incap_'+f,0)*100:.0f}%→{b.get('incap_'+f,0)*100:.0f}% | {a.get('dead_'+f,0)*100:.0f}%→{b.get('dead_'+f,0)*100:.0f}% |")
        L.append(f"\n**介入**: 総数 {a.get('iv',0):.2f}→{b.get('iv',0):.2f}、セレスティアへ {a.get('ivt_celestia',0):.2f}→{b.get('ivt_celestia',0):.2f}、"
                 f"学者へ {a.get('ivt_toolsmith',0):.2f}→{b.get('ivt_toolsmith',0):.2f}、前衛へ {sum(a.get('ivt_'+f,0) for f in ('adel','vanguard3','vanguard')):.2f}→{sum(b.get('ivt_'+f,0) for f in ('adel','vanguard3','vanguard')):.2f}、"
                 f"最初の介入（行動） {a['first_iv']:.1f}→{b['first_iv']:.1f}、連続介入（2行動以内） {a.get('consec_iv',0):.2f}→{b.get('consec_iv',0):.2f}、"
                 f"前線突破 {a.get('intr',0):.2f}→{b.get('intr',0):.2f}（介入後5行動以内 {a.get('intr_after_iv5',0):.2f}→{b.get('intr_after_iv5',0):.2f}）")
        L.append(f"\n**炎嵐とEP剥がし**: 最初の炎嵐の行動 {a['first_storm_idx']:.1f}→{b['first_storm_idx']:.1f}、"
                 f"発動時の敵EP合計 {a['storm_ep_before']:.0f}→{b['storm_ep_before']:.0f}、発動直後 {a['storm_ep_after']:.0f}→{b['storm_ep_after']:.0f}、"
                 f"その後10行動の敵HPダメ {a.get('dmg10',0):.0f}→{b.get('dmg10',0):.0f}、20行動 {a.get('dmg20',0):.0f}→{b.get('dmg20',0):.0f}、"
                 f"最初の敵撃破（行動） {a['first_enemy_ko']:.1f}→{b['first_enemy_ko']:.1f}（発生率 {a['first_enemy_ko_rate']:.0f}%→{b['first_enemy_ko_rate']:.0f}%）、炎嵐/戦 {a.get('storms',0):.2f}→{b.get('storms',0):.2f}")
        L.append(f"\n**セレスティアの行動（1戦あたり）**: " + "、".join(f"{k} {a['mage'].get(k,0):.2f}→{b['mage'].get(k,0):.2f}" for k in ("storm", "fire", "heal", "wait"))
                 + f"、手番 {a.get('cel_turns',0):.1f}→{b.get('cel_turns',0):.1f}、終了時EP {a.get('end_ep_cel',0):.1f}→{b.get('end_ep_cel',0):.1f}")
        L.append("\n**味方が最初に倒れた行動（平均・発生率）**: " + "、".join(
            f"{NM[u]} {a['ally_ko'].get(u,(float('nan'),0))[0]:.0f}({a['ally_ko'].get(u,(0,0))[1]:.0f}%)→{b['ally_ko'].get(u,(float('nan'),0))[0]:.0f}({b['ally_ko'].get(u,(0,0))[1]:.0f}%)" for u in AL))
        # flips detail
        if W:
            fa = summarize({k: A[k] for k in W}); fb = summarize({k: B[k] for k in W})
            L.append(f"\n**反転した{len(W)}戦（詠唱0敗北→詠唱6勝利）だけの比較**: セレスティアへの攻撃 {fa.get('atk_celestia',0):.1f}→{fb.get('atk_celestia',0):.1f}、"
                     f"前衛への攻撃 {sum(fa.get('atk_'+f,0) for f in ('adel','vanguard3','vanguard')):.1f}→{sum(fb.get('atk_'+f,0) for f in ('adel','vanguard3','vanguard')):.1f}、"
                     f"学者への攻撃 {fa.get('atk_toolsmith',0):.1f}→{fb.get('atk_toolsmith',0):.1f}、介入 {fa.get('iv',0):.1f}→{fb.get('iv',0):.1f}、"
                     f"前衛の生身HPダメ合計 {sum(fa.get('hpdmg_'+f,0) for f in ('adel','vanguard3','vanguard')):.0f}→{sum(fb.get('hpdmg_'+f,0) for f in ('adel','vanguard3','vanguard')):.0f}、"
                     f"後衛の生身HPダメ {fa.get('hpdmg_celestia',0)+fa.get('hpdmg_toolsmith',0):.0f}→{fb.get('hpdmg_celestia',0)+fb.get('hpdmg_toolsmith',0):.0f}、"
                     f"敵へのHPダメ {fa.get('enemy_hpdmg',0):.0f}→{fb.get('enemy_hpdmg',0):.0f}")
    print("\n".join(L))


if __name__ == "__main__":
    main()
