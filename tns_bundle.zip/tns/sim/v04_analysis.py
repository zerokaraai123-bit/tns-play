"""Ver0.4 解析: battles.csv から測定項目①〜⑫と「先に崩れた側が負けるか」を集計する。

使い方: python -m tns.sim.v04_analysis out/wolves_5v5_s1_C_x2_battles.csv ...
"""
from __future__ import annotations

import csv
import math
import statistics
import sys
from collections import defaultdict

ALLY = {"adel": "FRONT", "vanguard": "FRONT", "celestia": "REAR", "toolsmith": "REAR", "archer": "REAR"}
ENEMY = {"wolf_a": "FRONT", "wolf_b": "FRONT", "wolf_c": "FRONT", "leader": "REAR", "thrower": "REAR"}
GROUPS = {"ally_front": [k for k, v in ALLY.items() if v == "FRONT"],
          "ally_rear": [k for k, v in ALLY.items() if v == "REAR"],
          "enemy": list(ENEMY)}


def _f(x):
    return None if x in ("", None) else float(x)


def load(path):
    with open(path, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def _mean(xs):
    return sum(xs) / len(xs) if xs else math.nan


def _med(xs):
    return statistics.median(xs) if xs else math.nan


def analyze(rows) -> dict:
    """1条件ぶんの行をまとめる。"""
    n = len(rows)
    F = lambda k: sum(_f(r.get(k)) or 0 for r in rows)
    out = {"n": n,
           "win": F("win") / n, "draw": sum(r["winner"] == "draw" for r in rows) / n,
           "rounds": F("rounds") / n, "actions": F("actions") / n}
    for g, ids in GROUPS.items():
        hits_after_list = []
        hit_t, hit_rate, d_after_hit, half_to_death, ep_out_t, ep_out_rate, deaths = [], 0, [], [], [], 0, 0
        died_given_hit, hit_count = 0, 0
        att_b = opp_b = att_a = opp_a = 0
        for r in rows:
            for u in ids:
                fh, de, ha, eo = (_f(r.get(f"t_{k}_{u}")) for k in ("first_hp", "death", "half", "ep_out"))
                if fh is not None:
                    hit_t.append(fh)
                    hit_count += 1
                    if de is not None:
                        died_given_hit += 1
                        d_after_hit.append(de - fh)
                        hits_after_list.append((_f(r.get(f"t_hits_after_{u}")) or 0) + 1)   # 直撃を含む被弾回数
                if de is not None:
                    deaths += 1
                    if ha is not None:
                        half_to_death.append(de - ha)
                if eo is not None:
                    ep_out_t.append(eo)
                    ep_out_rate += 1
                att_b += _f(r.get(f"t_att_before_{u}")) or 0
                opp_b += _f(r.get(f"t_opp_before_{u}")) or 0
                att_a += _f(r.get(f"t_att_after_{u}")) or 0
                opp_a += _f(r.get(f"t_opp_after_{u}")) or 0
        units = n * len(ids)
        sb = att_b / opp_b if opp_b else math.nan
        sa = att_a / opp_a if opp_a else math.nan
        out.update({
            f"{g}_hit_rate": hit_count / units,                       # ① HP直撃を受けた割合
            f"{g}_first_hit_t": _mean(hit_t),                         # ① 最初のHP直撃までの行動数（戦闘開始からの全体行動数）
            f"{g}_death_given_hit": died_given_hit / hit_count if hit_count else math.nan,   # 直撃後に死亡した割合
            f"{g}_hit_to_death": _mean(d_after_hit),                  # ② 最初の直撃→死亡（全体行動数）
            f"{g}_hit_to_death_med": _med(d_after_hit),
            f"{g}_hits_to_death": _mean(hits_after_list),             # ② 最初の直撃→死亡（本人が受けた攻撃回数）
            f"{g}_half_to_death": _mean(half_to_death),               # ③ HP50%以下→死亡
            f"{g}_ep_out_rate": ep_out_rate / units,                  # ④ EP枯渇した割合
            f"{g}_ep_out_t": _mean(ep_out_t),                         # ④ EP枯渇までの行動数
            f"{g}_death_rate": deaths / units,                        # ⑧ 死亡率
            f"{g}_share_before": sb, f"{g}_share_after": sa,          # ⑦ 被攻撃シェア 直撃前/後
            f"{g}_focus_ratio": sa / sb if sb and sb == sb and sa == sa else math.nan,
        })
    # ⑤ HP残量帯ごとの「1ダメージを防ぐのに使ったEP」
    for side in ("ally", "enemy"):
        for rank in ("front", "rear"):
            for b in range(4):
                ep, raw, cnt = F(f"def_ep_{side}_{rank}_b{b}"), F(f"def_raw_{side}_{rank}_b{b}"), F(f"def_n_{side}_{rank}_b{b}")
                out[f"ep_per_dmg_{side}_{rank}_b{b}"] = ep / raw if raw else math.nan          # 実際に払ったEP/ダメージ
                need = F(f"def_need_{side}_{rank}_b{b}")
                out[f"need_per_dmg_{side}_{rank}_b{b}"] = need / raw if raw else math.nan      # 防ぎ切るのに必要だったEP/ダメージ
                out[f"ep_per_hit_{side}_{rank}_b{b}"] = ep / cnt if cnt else math.nan
                out[f"def_count_{side}_{rank}_b{b}"] = cnt / n
    for k in ("partial_pierce_ally", "partial_pierce_enemy", "full_block_ally", "full_block_enemy",  # ⑥
              "unshielded_hit_ally", "hp_hit_ally", "hp_hit_enemy",
              "intervention_ally", "iv_prevented_hp_hit_ally", "iv_prevented_collapse_ally", "iv_prevented_ko_ally",  # ⑨
              "front_open_by_intervention_ally", "intrusion_ally", "breach_hp_hit_ally", "breach_first_hp_hit_ally",
              "breach_kos_ally", "breach_damage_ally", "prevented_ally",                                   # ⑩
              "intervention_enemy", "intrusion_enemy"):
        out[k] = F(k) / n
    att = F("attacks_enemy")
    out["enemy_front_rate"] = F("attacks_enemy_on_front") / att if att else math.nan        # ⑪
    out["enemy_wounded_rate"] = F("attacks_enemy_on_wounded") / att if att else math.nan
    out["enemy_weakest_rate"] = F("attacks_enemy_on_weakest") / att if att else math.nan
    out["enemy_switch_rate"] = F("target_switch_enemy") / att if att else math.nan
    out["enemy_streak"] = F("streak_sum_enemy") / F("streak_count_enemy") if F("streak_count_enemy") else math.nan
    # B: 先にHPへ通された側が負けるか
    first = {"ally": 0, "enemy": 0}
    win_when = {"ally": 0, "enemy": 0}
    for r in rows:
        a = [x for x in (_f(r.get(f"t_first_hp_{u}")) for u in ALLY) if x is not None]
        e = [x for x in (_f(r.get(f"t_first_hp_{u}")) for u in ENEMY) if x is not None]
        if not a and not e:
            continue
        who = "ally" if (a and (not e or min(a) < min(e))) else "enemy"
        first[who] += 1
        win_when[who] += int(r["win"])
    out["ally_hit_first_rate"] = first["ally"] / n
    out["win_if_ally_hit_first"] = win_when["ally"] / first["ally"] if first["ally"] else math.nan
    out["win_if_enemy_hit_first"] = win_when["enemy"] / first["enemy"] if first["enemy"] else math.nan
    return out


def analyze_file(path) -> dict:
    g = defaultdict(list)
    for r in load(path):
        g[(r["enemy_intel"], r["policy"])].append(r)
    return {k: analyze(v) for k, v in g.items()}


if __name__ == "__main__":
    for p in sys.argv[1:]:
        res = analyze_file(p)
        for k, v in sorted(res.items()):
            print(p, k, {kk: round(vv, 3) if isinstance(vv, float) else vv for kk, vv in v.items()
                         if kk in ("win", "rounds", "ally_front_death_given_hit", "ally_rear_death_given_hit",
                                   "ally_rear_hit_to_death", "enemy_death_given_hit")})
