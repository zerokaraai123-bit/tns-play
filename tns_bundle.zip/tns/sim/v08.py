"""Ver0.8 自由設計実験の実行と記録。

モデル:
  M0 現行（現在のルール＋状況判断AI＋既存の魔導士AI）… 比較の基準
  M1 機会費用AI（ルールは M0 と同じ。AIだけ価値判断）
  M2 エーテル呼吸（毎手番 最大EPの10%回復）＋価値AI
  M3 二層エーテル（外殻＝防御専用・回復／内在＝魔法にも使える・回復なし）＋価値AI
  M4 庇護の構え（前衛が手番を使って味方REARを庇う。持ち場は離れない）＋価値AI
  M5 遠隔障壁（前衛が持ち場から障壁。必要EP×1.5）＋価値AI
固定戦略（永久最適解の探索）: 価値AIの一部を固定ルールに差し替えて同じ条件で戦わせる。

使い方: python -m tns.sim.v08 [main|probe|all]
"""
from __future__ import annotations

import csv
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.ally_controller import AllyAutoController
from ..ai.ally.value_controller import PROBES, ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..model.enums import Side
from .csv_export import write_csv

OUT = Path("out/v08")
MODELS = {"M0": "base", "M1": "base", "M2": "M2", "M3": "M3", "M4": "M4", "M5": "M5"}
LEVELS = {"D1": "D1", "D15": "D15"}
EXTRA_LEVEL = "D2"      # M2 が D1.5 で天井に近かったため追加した厳しい条件


def build(model, level, seed, intel, probe=None, log=False):
    cfg = load_battle_config(party="party_v08", rules=f"rules_v08_{level}_{MODELS[model]}.yaml",
                             ai_weights="ai_weights_v04.yaml", ally_policies="ally_policies_v05_none.yaml",
                             front_hp_mult=1.75)
    ally = AllyAutoController(cfg.ally_policies, "situational") if model == "M0" else \
        ValueAllyController(cfg.ally_policies, probe=probe)
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)},
                       seed=seed, enemy_intel=intel, log_enabled=log)
    eng.stats.ally_policy = getattr(ally, "policy_name", ally.name)
    return eng, ally


class V08Tracer:
    def __init__(self, eng):
        self.eng = eng
        self.c = Counter()
        self.pending_iv = set()
        self.out = {}
        self.first_front_out = None

    def __call__(self, ev, eng):
        t = ev["t"]
        c = self.c
        if t == "intervened":
            if eng.u(ev["unit"]).side is Side.ALLY:
                self.pending_iv.add(ev["unit"])
                c["iv_move"] += 1
                c["iv_move_rear" if eng.u(ev["target"]).rank.value == "REAR" else "iv_move_front"] += 1
        elif t == "aegis":
            if eng.u(ev["unit"]).side is Side.ALLY:
                c["iv_aegis"] += 1
                c["iv_aegis_rear" if eng.u(ev["target"]).rank.value == "REAR" else "iv_aegis_front"] += 1
        elif t == "cover":
            if eng.u(ev["unit"]).side is Side.ALLY:
                c["cover_decl"] += 1
        elif t == "covered":
            if eng.u(ev["unit"]).side is Side.ALLY:
                c["cover_hit"] += 1
        elif t == "attack_declared":
            a, tg = eng.u(ev["unit"]), eng.u(ev["target"])
            if a.side is Side.ENEMY:
                c[f"enemy_att_{tg.rank.value}"] += 1
                if ev.get("via_route"):
                    c["enemy_att_rear_open"] += 1
            elif ev["action"] == "fire":
                c["fire"] += 1
        elif t == "area_attack":
            if eng.u(ev["unit"]).side is Side.ALLY:
                c["storm"] += 1
        elif t == "heal":
            if eng.u(ev["unit"]).side is Side.ALLY:
                c["heal"] += 1
                c["heal_amt"] += ev["amount"]
        elif t == "damage":
            u, a = eng.u(ev["unit"]), eng.u(ev["attacker"])
            if a.side is Side.ALLY:
                if ev["action"] in ("fire", "storm"):
                    c["magic_dmg"] += ev["dmg"]
                else:
                    c["phys_dmg"] += ev["dmg"]
                return
            rk = u.rank.value
            spent = ev.get("ep_spent", 0) or 0
            if ev.get("aegis_by"):
                c["ep_front_aegis"] += spent
                return
            if u.id in self.pending_iv:
                self.pending_iv.discard(u.id)
                c["ep_front_iv"] += spent if ev["defense"] else 0
            elif ev.get("covered"):
                c["ep_front_cover"] += spent if ev["defense"] else 0
            elif ev["defense"]:
                c[f"selfdef_n_{rk}"] += 1
                c[f"selfdef_ep_{rk}"] += spent
            if ev["dmg"] > 0:
                c[f"body_hits_{rk}"] += 1
                c[f"body_dmg_{rk}"] += ev["dmg"]
                if not ev["defense"] and "生身で受ける" in (ev.get("defense_reason") or ""):
                    c[f"chose_body_{rk}"] += 1
        elif t == "ko":
            u = eng.u(ev["unit"])
            if u.side is Side.ALLY:
                kind = "incap" if ev.get("incap") else "dead"
                c[f"{kind}_{u.rank.value}"] += 1
                if u.rank.value == "FRONT" and self.first_front_out is None:
                    self.first_front_out = eng.action_index


def summarize_records(recs, tracer):
    c = Counter()
    groups = {}
    for r in recs:
        k = r["kind"]
        if k == "iv":
            ch = r["choice"]
            c[f"ivdec_{r['trank']}_{ch}"] += 1
            c[f"ivreason_{r['reason']}"] += 1
            if ch in ("move", "aegis") and r.get("threshold"):
                c["thr_kept"] += 1
            if r["trank"] == "REAR":
                g = (r["attacker"], r["target"])
                groups.setdefault(g, Counter())[ch if ch == "self" else "protect"] += 1
        elif k == "mage":
            c[f"mage_{r['choice']}"] += 1
            if r.get("bold"):
                c["bold"] += 1
                c[f"bold_{r['choice']}"] += 1
            if r.get("cons"):
                c["cons"] += 1
                c["cons_front_down" if not r.get("front_ok") else "cons_front_up"] += 1
            c["mage_turn_front_ok" if r.get("front_ok") else "mage_turn_front_ng"] += 1
            if r["choice"] in ("storm",):
                c["storm_front_ok" if r.get("front_ok") else "storm_front_ng"] += 1
        elif k == "cover":
            c[f"cover_{r['choice']}"] += 1
        elif k == "skip_def":
            c[f"skipdef_{r.get('frank', '')}"] += 1
    # 同じ（攻撃者, 標的）の組で、判断が割れた回数
    mixed = sum(min(g["self"], g["protect"]) for g in groups.values())
    c["same_attack_mixed"] = mixed
    c["same_attack_groups_mixed"] = sum(1 for g in groups.values() if g["self"] and g["protect"])
    return c


def _one(job):
    tag, model, level, probe, seed, intel = job
    eng, ally = build(model, level, seed, intel, probe)
    tr = V08Tracer(eng)
    eng.listeners.append(tr)
    eng.run()
    row = {"tag": tag, "model": model, "level": level, "probe": probe or "", "seed": seed, "enemy_intel": intel,
           "winner": eng.stats.winner, "rounds": eng.stats.rounds, "actions": eng.action_index,
           "first_front_out": tr.first_front_out if tr.first_front_out is not None else ""}
    row.update(tr.c)
    ivrows = []
    if isinstance(ally, ValueAllyController):
        row.update(summarize_records(ally.records, tr))
        for r in ally.records:
            if r["kind"] == "iv":
                ivrows.append({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k != "text"}
                              | {"tag": tag, "seed": seed, "enemy_intel": intel})
    end = {u.id: (u.hp, u.ep) for u in eng.state.units.values()}
    row["mage_ep_end"] = end["celestia"][1]
    return row, ivrows


def seeds_for(level, n):
    lv = {"D1": "D1", "D15": "D15", "D2": "D2"}[level]
    with open(f"out/wolves_5v5_v6s1_{lv}_P2_x1.75_battles.csv", encoding="utf-8-sig") as f:
        rows = [(int(r["seed"]), int(r["enemy_intel"])) for r in csv.DictReader(f)]
    if n >= len(rows):
        return rows
    return rows[::2][:n]      # 敵知能4段階が均等になるように1つおきに取る（先頭から取ると低・通常知能だけになる）


def conditions(which):
    C = []
    if which in ("main", "all"):
        for level in LEVELS:
            for m in MODELS:
                C.append((f"main_{level}_{m}", m, level, None, 1000))
    if which in ("probe", "all"):
        for m in ("M1", "M2", "M3", "M4", "M5"):
            for p in PROBES:
                C.append((f"probe_D15_{m}_{p}", m, "D15", p, 500))
    if which in ("extra", "all"):
        for m in ("M0", "M1", "M2", "M5"):
            C.append((f"main_D2_{m}", m, "D2", None, 1000))
        for m in ("M2",):
            for p in PROBES:
                C.append((f"probe_D2_{m}_{p}", m, "D2", p, 500))
    return C


def run(which="all", workers=None):
    OUT.mkdir(parents=True, exist_ok=True)
    workers = workers or max(1, os.cpu_count() or 2)
    for tag, m, level, probe, n in conditions(which):
        if (OUT / f"{tag}_battles.csv").exists():
            print("skip", tag, flush=True)
            continue
        jobs = [(tag, m, level, probe, s, i) for s, i in seeds_for(level, n)]
        B, IV = [], []
        with ProcessPoolExecutor(workers) as ex:
            for b, iv in ex.map(_one, jobs, chunksize=20):
                B.append(b)
                IV += iv
        keys = sorted({k for b in B for k in b})
        B = [{k: b.get(k, 0) for k in keys} for b in B]
        if IV:
            write_csv(OUT / f"{tag}_ivdecisions.csv", IV)
        write_csv(OUT / f"{tag}_battles.csv", B)
        print("done", tag, len(B), flush=True)


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "all")
