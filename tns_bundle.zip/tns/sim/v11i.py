"""Ver0.11 初動タイミング頑健性テスト（PA-170。分析専用オフセット＋ログのみ。ルール・AIは変更なし）。
編成: 3FRONT・2REAR（center）／介入担当範囲あり（_lane）／敵: wolves_6t
オフセット条件（初回時刻 = 1.0 + step×(最高速度−速度) + 一様乱数[0,width)）:
  A  : なし（従来）
  A0 : 速度の階段だけ（step=0.01, width=0）＝乱数なしの対照
  B  : 小（step=0.01, width=0.02）……速度差1の相手とだけ時々入れ替わる（差2以上は入れ替わらない）
  C  : 中（step=0.01, width=0.04）……速度差3までの相手と入れ替わりうる（差4以上は入れ替わらない）
seed: 0〜999 を、指定した知能で全部使う（各条件1,000戦）
python -m tns.sim.v11i main|lowmid|never
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..formation.route import blocker_is_holding
from ..model.enums import Side
from .v11f import FORMS, POLS

OUT = Path("out/v11i")
ENC = "wolves_6t"
SUFFIX = "_lane"
OFFS = {"A": None, "A0": {"step": 0.01, "width": 0.0}, "B": {"step": 0.01, "width": 0.02},
        "C": {"step": 0.01, "width": 0.04}}
NSEED = 1000


def build(n, pol, seed, intel, off):
    rules = (f"rules_v09_q058_f85_incap4{SUFFIX}.yaml" if n == 0 else f"rules_v09_q058_f85_incap4_cast{n}{SUFFIX}.yaml")
    cfg = load_battle_config(party=FORMS["center"], encounter=ENC, rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    if OFFS[off]:
        cfg.rules = dict(cfg.rules)
        cfg.rules["analysis"] = {"initial_offset": dict(OFFS[off])}
    hm, probe = POLS[pol]
    ally = ValueAllyController(cfg.ally_policies, probe=probe, hole_model=hm)
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)}, seed=seed, enemy_intel=intel)
    return eng, ally


def _one(job):
    n, pol, seed, intel, off = job
    eng, ally = build(n, pol, seed, intel, off)
    U = eng.state.units
    fronts = [u for u in U.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    enemies = [u for u in U.values() if u.side is Side.ENEMY]
    E = []
    q1 = []

    def lis(ev, e):
        t = ev["t"]
        i = e.action_index
        if t == "round_start" and e.state.round == 1:
            q1.extend(ev["queue"])
        elif t == "turn_start":
            E.append(("T", i, ev["unit"], round(e.cur_time, 3), int("celestia" in e.casting),
                      "".join(str(int(blocker_is_holding(f))) for f in fronts),
                      sum(x.ep for x in enemies if x.hp > 0), sum(x.hp for x in enemies if x.hp > 0)))
        elif t == "attack_declared":
            E.append(("A", i, ev["unit"], ev["target"], int("celestia" in e.casting), ev["action"], ev.get("via_route")))
        elif t == "intervened":
            E.append(("I", i, ev["unit"], ev["target"], ev["attacker"], int("celestia" in e.casting)))
        elif t == "damage":
            E.append(("D", i, ev["unit"], ev["attacker"], ev.get("dmg", 0) or 0, ev.get("ep_spent", 0) or 0,
                      int("celestia" in e.casting)))
        elif t == "area_attack" and ev["unit"] == "celestia":
            E.append(("S", i, sum(x.ep for x in enemies if x.hp > 0), sum(x.hp for x in enemies if x.hp > 0)))
        elif t in ("cast_start", "cast_complete", "cast_cancel", "cast_fail"):
            E.append(({"cast_start": "Cs", "cast_complete": "Cc", "cast_cancel": "Cx", "cast_fail": "Cf"}[t], i, ev["unit"]))
        elif t == "ko":
            E.append(("K", i, ev["unit"], int(bool(ev.get("incap"))), int(bool(ev.get("after_incap")))))
        elif t == "revive":
            E.append(("V", i, ev["unit"]))
    eng.listeners.append(lis)
    eng.run()
    end = {u.id: {"hp": u.hp, "dead": int(u.hp <= 0), "incap": int(u.incapacitated)}
           for u in U.values() if u.side is Side.ALLY}
    return {"n": n, "pol": pol, "seed": seed, "intel": intel, "off": off, "win": int(eng.stats.winner == "ally"),
            "N": eng.action_index, "rounds": eng.stats.rounds, "q1": q1,
            "o": {k: round(v, 4) for k, v in eng.init_offset.items()}, "E": E, "end": end}


def path_of(off, n, pol, intel):
    return OUT / f"{off}_cast{n}_{pol}_i{intel}.jsonl"


def run(offs, casts, pols, intels):
    OUT.mkdir(parents=True, exist_ok=True)
    for it in intels:
        for off in offs:
            for pol in pols:
                for n in casts:
                    path = path_of(off, n, pol, it)
                    if path.exists():
                        continue
                    jobs = [(n, pol, s, it, off) for s in range(NSEED)]
                    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                        R = list(ex.map(_one, jobs, chunksize=20))
                    tmp = path.with_suffix(".tmp")
                    with open(tmp, "w", encoding="utf-8") as fh:
                        for r in R:
                            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
                    tmp.rename(path)
                    print("done", path, round(sum(r["win"] for r in R) / len(R), 3), flush=True)


if __name__ == "__main__":
    a = sys.argv[1] if len(sys.argv) > 1 else "main"
    C9 = tuple(range(9))
    if a == "main":
        run(("A", "B", "C", "A0"), C9, ("v11",), (3,))
    elif a == "lowmid":
        run(("A", "B"), C9, ("v11",), (0, 1))
        run(("C",), C9, ("v11",), (0, 1))
    elif a == "a0lowmid":
        run(("A0",), C9, ("v11",), (1, 0))
    elif a == "never01":
        run(("B",), (0, 2, 4, 6), ("never",), (1, 0))
    elif a == "never":
        run(("B", "A", "C"), (0, 2, 4, 6), ("never",), (3,))
