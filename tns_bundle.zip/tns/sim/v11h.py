"""詠唱6・戦術級逆転の原因分析用ログ（PA-161。記録のみ、ロジック変更なし）。
python -m tns.sim.v11h  -> out/v11h/{suffix}_cast{n}_{pol}_i{intel}.jsonl
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..formation.route import blocker_is_holding
from ..model.enums import Side
from .v09 import seeds
from .v11f import build

OUT = Path("out/v11h")
ENC = "wolves_6t"


def _one(job):
    n, pol, seed, intel, suffix = job
    eng, ally = build("center", n, pol, seed, intel, ENC, suffix)
    U = eng.state.units
    fronts = [u for u in U.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    enemies = [u for u in U.values() if u.side is Side.ENEMY]
    E = []          # 時系列（簡約）
    st = {"pend": None}

    def lis(ev, e):
        t = ev["t"]
        i = e.action_index
        if t == "turn_start":
            E.append(("T", i, ev["unit"], round(e.cur_time, 3), int("celestia" in e.casting),
                      "".join(str(int(blocker_is_holding(f))) for f in fronts),
                      sum(x.ep for x in enemies if x.hp > 0), sum(x.hp for x in enemies if x.hp > 0)))
        elif t == "attack_declared":
            a = e.u(ev["unit"])
            E.append(("A", i, a.id, ev["target"], int("celestia" in e.casting), ev["action"], ev.get("via_route")))
        elif t == "intervened":
            E.append(("I", i, ev["unit"], ev["target"], ev["attacker"], int("celestia" in e.casting)))
        elif t == "damage":
            E.append(("D", i, ev["unit"], ev["attacker"], ev.get("dmg", 0) or 0, ev.get("ep_spent", 0) or 0))
        elif t == "area_attack" and ev["unit"] == "celestia":
            E.append(("S", i, sum(x.ep for x in enemies if x.hp > 0), sum(x.hp for x in enemies if x.hp > 0)))
        elif t in ("cast_start", "cast_complete", "cast_cancel"):
            E.append(("C" + t[5], i, ev["unit"]))
        elif t == "ko":
            E.append(("K", i, ev["unit"], int(bool(ev.get("incap"))), int(bool(ev.get("after_incap")))))
        elif t == "intrusion":
            E.append(("R", i, ev["unit"], ev["target"], ev.get("caused_by")))
        elif t == "revive":
            E.append(("V", i, ev["unit"]))
    eng.listeners.append(lis)
    eng.run()
    mage = [(r["round"], r["choice"]) for r in ally.records if r["kind"] == "mage" and r["unit"] == "celestia"]
    end = {u.id: {"hp": u.hp, "max": u.d.hp_max, "ep": u.ep, "alive": int(u.alive), "dead": int(u.hp <= 0),
                  "incap": int(u.incapacitated)} for u in U.values() if u.side is Side.ALLY}
    return {"n": n, "pol": pol, "seed": seed, "intel": intel, "suffix": suffix, "win": int(eng.stats.winner == "ally"),
            "N": eng.action_index, "rounds": eng.stats.rounds, "E": E, "mage": mage, "end": end}


def run(casts=(0, 2, 4, 6), pols=("v11",), intels=(3,), suffixes=("_lane", "")):
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")
    for suffix in suffixes:
        for n in casts:
            for pol in pols:
                for it in intels:
                    path = OUT / f"{suffix or '_nolane'}_cast{n}_{pol}_i{it}.jsonl"
                    if path.exists():
                        continue
                    jobs = [(n, pol, s, i, suffix) for s, i in S if i == it]
                    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                        R = list(ex.map(_one, jobs, chunksize=10))
                    with open(path, "w", encoding="utf-8") as fh:
                        for r in R:
                            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
                    print("done", path, round(sum(r["win"] for r in R) / len(R), 3), flush=True)


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "sweep":     # 離散化点検: 詠唱1〜8（戦術級のみ）
        run(casts=tuple(range(0, 9)), pols=("v11",), intels=(3,), suffixes=("_lane", ""))
    else:
        run(casts=(0, 2, 4, 6), pols=("v11", "never"), intels=(0, 1, 2, 3), suffixes=("_lane", ""))
