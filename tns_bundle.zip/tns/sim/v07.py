"""Ver0.7 実験の実行と記録。

実験A｜HPシステム検証: Baseline / Speed only / Incapacitation only / Speed + Incapacitation
実験B｜EP配分・介入検証: Current AI（状況判断） vs REAR EP Protection（比較実験用の介入方針, PA-64）

Ver0.6主実験（前衛HP×1.75）と同じシード・同じ敵知能で再実行し、エンジンのイベントを聞き取って記録する。
条件ごとにCSVを保存し、既に出力がある条件は飛ばす（途中で止まっても続きから再開できる）。

使い方: python -m tns.sim.v07 [A|B|all]
"""
from __future__ import annotations

import csv
import math
import os
import sys
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..config_loader import load_battle_config
from ..model.enums import Side
from .csv_export import write_csv
from .runner import make_engine

OUT = Path("out/v07")
FIRE_COST = 15
FIRE_RESERVE = 28            # ally_policies.yaml base.mage.fire_ep_reserve（読むだけ）
FIRE_THRESHOLD = FIRE_COST + FIRE_RESERVE   # とどめ以外で攻撃魔法を撃てるEP
HEAL_COST = 18


def _band_list():
    return (0.4, 0.3, 0.2)


class V07Tracer:
    def __init__(self, eng):
        self.eng = eng
        self.U = {}
        for u in eng.state.units.values():
            self.U[u.id] = {
                "unit": u.id, "side": u.side.value, "rank": u.rank.value, "role": u.d.role,
                "hp_max": u.d.hp_max, "ep_max": u.d.ep_max, "speed": u.d.speed,
                "out": "", "out_time": "", "out_turns_after_hit": "", "out_side_turns_after_hit": "",
                "reached_le15": 0, "skipped15": 0, "min_hp_ratio": 1.0,
                "first_hit_time": "", "first_hit_own_turns": "", "first_hit_side_turns": "",
                "turns": 0, "turns_lt60": 0, "turns_lt40": 0, "turns_lt20": 0,
                "delays": 0, "delay_sum": 0.0, "overtaken": 0, "overtaken_by_n": 0,
                "body_hits": 0, "body_dmg": 0,
                # EP
                "ep_self_def": 0, "ep_iv_def": 0, "ep_magic": 0, "ep0_time": "", "ep0_enemy_turns": "",
                "n_self_def": 0, "n_iv_def": 0, "iv": 0, "disp_hits": 0,
                "fire": 0, "fire_dmg": 0, "fire_kill_cast": 0, "heal": 0, "heal_amt": 0,
                "phys_dmg": 0, "ep_end": "",
                # REAR EP温存（相手に介入してもらった）
                "protected": 0, "saved_ep_est": 0, "thr_kept_fire": 0, "thr_kept_kill": 0, "thr_kept_heal": 0,
                "fire_enabled_est": 0, "held_back": 0, "held_back_front_ok": 0, "held_back_front_ng": 0,
                "mage_turns_front_ok": 0, "mage_turns_front_ng": 0, "fire_front_ok": 0, "fire_front_ng": 0,
                "hit_unshielded_after_lowep": 0, "lowep_after_cast": 0,
            }
            for b in _band_list():
                k = int(b * 100)
                self.U[u.id].update({f"b{k}_enter": 0, f"b{k}_turns_after": "", f"b{k}_hits_after": "",
                                     f"b{k}_time_to_out": "", f"b{k}_out": ""})
        self.enemy_turns = 0
        self.side_turns = {"ally": 0, "enemy": 0}
        self.iv_pending = {}                 # interceptor -> True（次の damage が介入の一撃）
        self.pending_delay = {}              # uid -> (nominal, actual, speed, side)
        self.first_iv_time = ""
        self.first_iv_enemy_turns = ""
        self.n_iv = 0
        self.n_iv_rear = 0
        self.rear_ep_samples = []
        self.cur_actor = None
        self.band_state = {}                 # (uid,b) -> {"turns":..,"hits":..,"t":..}
        self.saved = defaultdict(float)
        self.last_cast_lowep = {}

    # -------------------------------------------------------------
    def _front_ok(self):
        """介入できる（READYかつEP>0の）前衛がいるか。"""
        for u in self.eng.state.units.values():
            if u.side is Side.ALLY and u.rank.value == "FRONT" and u.alive and u.can_intervene and u.ep > 0:
                return True
        return False

    def _check_ep0(self, u):
        r = self.U[u.id]
        if r["ep0_time"] == "" and u.ep <= 0:
            r["ep0_time"] = round(self.eng.cur_time, 3)
            r["ep0_enemy_turns"] = self.enemy_turns

    def __call__(self, ev, eng):
        t = ev["t"]
        if t == "turn_start":
            u = eng.u(ev["unit"])
            r = self.U[u.id]
            self.cur_actor = u.id
            self.side_turns[u.side.value] += 1
            if u.side is Side.ENEMY:
                self.enemy_turns += 1
                for x in eng.state.units.values():
                    if x.side is Side.ALLY and x.rank.value == "REAR" and x.alive:
                        self.rear_ep_samples.append(x.ep)
            r["turns"] += 1
            hr = u.hp / u.d.hp_max
            if hr < 0.6:
                r["turns_lt60"] += 1
            if hr < 0.4:
                r["turns_lt40"] += 1
            if hr < 0.2:
                r["turns_lt20"] += 1
            for (uid, b), s in self.band_state.items():
                if uid == u.id and s["open"]:
                    s["turns"] += 1
            # 行動遅延で相手陣営に追い越されたか
            tnow = eng.cur_time
            self.pending_delay.pop(u.id, None)
            for uid, pdl in self.pending_delay.items():
                nominal, actual, spd, side = pdl["nominal"], pdl["actual"], pdl["speed"], pdl["side"]
                if side == u.side.value:
                    continue
                ahead = (nominal < tnow < actual) or (abs(tnow - nominal) < 1e-9 and u.d.speed < spd)
                if ahead:
                    pdl["n"] += 1
                    if not pdl["flag"]:
                        pdl["flag"] = True
                        self.U[uid]["overtaken"] += 1
                    self.U[uid]["overtaken_by_n"] += 1
            # 魔導士の手番（Ver0.7 実験B: 前衛の状態別）
            if u.d.role == "mage":
                ok = self._front_ok()
                r["mage_turns_front_ok" if ok else "mage_turns_front_ng"] += 1
                self._mage_front_ok = ok
            return
        if t == "schedule":
            u = eng.u(ev["unit"])
            if ev["mult"] < 1.0:
                r = self.U[u.id]
                r["delays"] += 1
                r["delay_sum"] += ev["next"] - ev["time"] - 1.0
                self.pending_delay[u.id] = {"nominal": ev["time"] + 1.0, "actual": ev["next"], "speed": u.d.speed,
                                            "side": u.side.value, "n": 0, "flag": False}
            return
        if t == "wait":
            u = eng.u(ev["unit"])
            if u.d.role == "mage":
                txt = " ".join(ev.get("reasons") or [])
                if "温存" in txt and u.ep >= FIRE_COST:
                    r = self.U[u.id]
                    r["held_back"] += 1
                    r["held_back_front_ok" if getattr(self, "_mage_front_ok", False) else "held_back_front_ng"] += 1
            return
        if t == "attack_declared":
            u = eng.u(ev["unit"])
            if ev["action"] == "fire":
                r = self.U[u.id]
                r["fire"] += 1
                r["ep_magic"] += FIRE_COST
                kill = any("とどめ" in x for x in (ev.get("reasons") or []))
                if kill:
                    r["fire_kill_cast"] += 1
                before = u.ep + FIRE_COST
                thr = FIRE_COST if kill else FIRE_THRESHOLD
                if before >= thr and before - self.saved[u.id] < thr:
                    r["fire_enabled_est"] += 1        # 介入で温存したEPがなければ撃てなかった（推定）
                if getattr(self, "_mage_front_ok", False):
                    r["fire_front_ok"] += 1
                else:
                    r["fire_front_ng"] += 1
                if u.ep < eng._hit_cost(u):
                    r["lowep_after_cast"] += 1
                    self.last_cast_lowep[u.id] = True
                self._check_ep0(u)
            return
        if t == "heal":
            u = eng.u(ev["unit"])
            r = self.U[u.id]
            r["heal"] += 1
            r["heal_amt"] += ev["amount"]
            r["ep_magic"] += ev.get("ep_cost", 0) or 0
            self._check_ep0(u)
            return
        if t == "intervened":
            c = eng.u(ev["unit"])
            if c.side is not Side.ALLY:
                return
            tgt = eng.u(ev["target"])
            self.iv_pending[c.id] = True
            self.n_iv += 1
            self.U[c.id]["iv"] += 1
            if self.first_iv_time == "":
                self.first_iv_time = round(eng.cur_time, 3)
                self.first_iv_enemy_turns = self.enemy_turns
            if tgt.rank.value == "REAR":
                self.n_iv_rear += 1
                tr = self.U[tgt.id]
                tr["protected"] += 1
                atk = eng.u(ev["attacker"])
                a = eng.actions[[x for x in atk.d.action_ids if eng.actions[x].kind.value == "attack"][0]]
                exp = eng.damage.expected(atk, a)
                would = eng.defense_allowed(tgt) and eng.controllers[tgt.side].decide_defense(tgt, atk, a, exp)[0]
                if would:
                    need = math.ceil(eng.defense.required_ep(tgt, exp) - 1e-9)
                    save = min(tgt.ep, need)
                    tr["saved_ep_est"] += save
                    self.saved[tgt.id] += save
                    e0 = tgt.ep
                    for thr, k in ((FIRE_THRESHOLD, "thr_kept_fire"), (FIRE_COST, "thr_kept_kill"), (HEAL_COST, "thr_kept_heal")):
                        if k == "thr_kept_heal" and "heal" not in tgt.d.action_ids:
                            continue
                        if k != "thr_kept_heal" and "fire" not in tgt.d.action_ids:
                            continue
                        if e0 >= thr and e0 - save < thr:
                            tr[k] += 1
            return
        if t == "damage":
            u = eng.u(ev["unit"])
            r = self.U[u.id]
            atk = eng.u(ev["attacker"])
            dmg, hp_after, spent = ev["dmg"], ev["hp"], ev.get("ep_spent", 0) or 0
            hp_before = hp_after + dmg
            # 与ダメージ
            ra = self.U[atk.id]
            if ev["action"] == "fire":
                ra["fire_dmg"] += dmg
            else:
                ra["phys_dmg"] += dmg
            # EP の使途
            is_iv = self.iv_pending.pop(u.id, False)
            if ev["defense"]:
                if is_iv:
                    r["ep_iv_def"] += spent
                    r["n_iv_def"] += 1
                else:
                    r["ep_self_def"] += spent
                    r["n_self_def"] += 1
            elif u.displaced and not is_iv and u.side is Side.ALLY:
                r["disp_hits"] += 1
            self._check_ep0(u)
            if dmg > 0 and self.last_cast_lowep.get(u.id) and (ev.get("mode") in ("partial", "none")):
                r["hit_unshielded_after_lowep"] += 1
                self.last_cast_lowep[u.id] = False
            if dmg <= 0:
                return
            # 肉体ダメージ
            r["body_hits"] += 1
            r["body_dmg"] += dmg
            hr = hp_after / u.d.hp_max
            r["min_hp_ratio"] = min(r["min_hp_ratio"], round(hr, 4))
            if r["first_hit_time"] == "":
                r["first_hit_time"] = round(eng.cur_time, 3)
                r["first_hit_own_turns"] = r["turns"]
                r["first_hit_side_turns"] = self.side_turns[u.side.value]
            if 0 < hr <= 0.15:
                r["reached_le15"] = 1
            if hp_after <= 0 and hp_before / u.d.hp_max > 0.15:
                r["skipped15"] = 1
            for (uid, b), s in self.band_state.items():
                if uid == u.id and s["open"]:
                    s["hits"] += 1
            for b in _band_list():
                k = int(b * 100)
                if hr <= b and not r[f"b{k}_enter"] and hp_after > 0 and u.alive:
                    r[f"b{k}_enter"] = 1
                    self.band_state[(u.id, b)] = {"open": True, "turns": 0, "hits": 0, "t": eng.cur_time}
            return
        if t == "ko":
            u = eng.u(ev["unit"])
            self._out(u, "incap" if ev.get("incap") else "dead")
            return
        if t == "battle_end":
            for u in eng.state.units.values():
                r = self.U[u.id]
                r["ep_end"] = u.ep
                if r["out"] == "":
                    self._out(u, "survived")
            return

    def _out(self, u, how):
        r = self.U[u.id]
        eng = self.eng
        r["out"] = how
        r["out_time"] = round(eng.cur_time, 3)
        if r["first_hit_time"] != "":
            r["out_turns_after_hit"] = r["turns"] - r["first_hit_own_turns"]
            r["out_side_turns_after_hit"] = self.side_turns[u.side.value] - r["first_hit_side_turns"]
        for b in _band_list():
            s = self.band_state.get((u.id, b))
            if s and s["open"]:
                k = int(b * 100)
                s["open"] = False
                r[f"b{k}_turns_after"] = s["turns"]
                r[f"b{k}_hits_after"] = s["hits"]
                r[f"b{k}_time_to_out"] = round(eng.cur_time - s["t"], 3)
                r[f"b{k}_out"] = how


def _one(job):
    exp, cond, party, rules, policy, D, P, V, seed, intel = job
    cfg = load_battle_config(party=party, rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    eng = make_engine(cfg, seed, policy, intel)
    tr = V07Tracer(eng)
    eng.listeners.append(tr)
    eng.run()
    meta = {"exp": exp, "cond": cond, "party": party, "D": D, "P": P, "V": V, "policy": policy,
            "seed": seed, "enemy_intel": intel}
    rear_ep = tr.rear_ep_samples
    b = dict(meta, winner=eng.stats.winner, rounds=eng.stats.rounds, end_time=round(eng.cur_time, 3),
             actions=eng.action_index, n_iv=tr.n_iv, n_iv_rear=tr.n_iv_rear,
             first_iv_time=tr.first_iv_time, first_iv_enemy_turns=tr.first_iv_enemy_turns,
             enemy_turns=tr.enemy_turns, rear_ep_mean=round(sum(rear_ep) / len(rear_ep), 2) if rear_ep else "")
    units = [dict(meta, **{k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()}) for r in tr.U.values()]
    return b, units


def seeds_for(D, P):
    with open(f"out/wolves_5v5_v6s1_{D}_{P}_x1.75_battles.csv", encoding="utf-8-sig") as f:
        return [(int(r["seed"]), int(r["enemy_intel"])) for r in csv.DictReader(f)]


def conditions(which):
    C = []
    if which in ("A", "all"):
        for D in ("D1", "D2", "D3"):
            for P in ("P0", "P2"):
                for V in ("A", "S", "I", "SI"):
                    C.append(("A", f"{D}_{P}_{V}", "party_v05_C0", f"rules_v07_{D}_{P}_{V}.yaml", "situational", D, P, V))
        for D in ("D1", "D2"):
            C.append(("A", f"{D}_P2_SIa", "party_v05_C0", f"rules_v07_{D}_P2_SIa.yaml", "situational", D, "P2", "SIa"))
    if which in ("B", "all"):
        for D, P in (("D1", "P0"), ("D1", "P2"), ("D2", "P0"), ("D2", "P2"), ("D3", "P2")):
            for V in ("A", "SI"):
                C.append(("B", f"{D}_{P}_{V}_protect", "party_v05_C0", f"rules_v07_{D}_{P}_{V}.yaml", "rear_ep_protect", D, P, V))
        for D, P in (("D1", "P2"), ("D2", "P2")):        # 補助: 既存の治療魔法（Ver0.5仕様）を持つ編成
            for pol in ("situational", "rear_ep_protect"):
                C.append(("Bh", f"{D}_{P}_A_heal_{pol}", "party_v05_C1", f"rules_v07_{D}_{P}_A.yaml", pol, D, P, "A"))
    return C


def run(which="all", workers=None):
    OUT.mkdir(parents=True, exist_ok=True)
    workers = workers or max(1, os.cpu_count() or 2)
    for exp, cond, party, rules, pol, D, P, V in conditions(which):
        tag = f"{exp}_{cond}"
        if (OUT / f"{tag}_units.csv").exists():
            print("skip", tag, flush=True)
            continue
        jobs = [(exp, cond, party, rules, pol, D, P, V, s, i) for s, i in seeds_for(D, P)]
        B, U = [], []
        with ProcessPoolExecutor(workers) as ex:
            for b, u in ex.map(_one, jobs, chunksize=25):
                B.append(b)
                U += u
        write_csv(OUT / f"{tag}_battles.csv", B)
        write_csv(OUT / f"{tag}_units.csv", U)
        print("done", tag, len(B), flush=True)


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "all")
