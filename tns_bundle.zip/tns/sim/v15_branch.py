"""Ver0.15（PA-212 ③）: 判断の効き（分岐分析）。

戦闘の途中の味方の判断（行動・介入）を、別の選択肢に差し替えて最後まで計算し直し、勝率がどう変わるかを測る。
  1. 基準の戦闘を流し、味方の判断ごとに「選べた選択肢」を記録する
  2. 判断点を選び、選択肢ごとに K 回、最後まで計算する。分岐した時点で乱数を K 通りに振り直す（共通乱数）
     → P(勝ち | その判断) を見積もる。分岐より前は記録どおりの判断で再現する（決定的）
  3. 効き = 最善の選択肢と最悪の選択肢の勝率の差。AIの後悔 = 最善 − AIが選んだもの
  4. 目先の得（val_attack が最大の攻撃）を選ぶと、最善より大きく勝率が下がる判断点を「毒まんじゅう」として数える
未来の情報を味方AIに渡しているわけではない（測定のための外側の計算）。
python -m tns.sim.v15_branch <out.jsonl> <seed0> <nbattles> [points_per_battle] [K] [intel] [power]
"""
from __future__ import annotations

import json
import os
import sys
import zlib
from concurrent.futures import ProcessPoolExecutor

from ..ai.ally.v15_controller import V15AllyController
from ..control.controller import Decision
from ..intervention.records import InterventionChoice
from ..model.enums import ActionKind, Rank
from .v15 import build, load_battle_config, PARTY, ENC, RULES, apply_mods


NOWAIT = os.environ.get("V15_BRANCH_NOWAIT") == "1"
MAXALT = int(os.environ.get("V15_BRANCH_MAXALT", "8"))


class BranchAlly(V15AllyController):
    def __init__(self, pol, force=None, reseed=None, record=False):
        super().__init__(pol)
        self.k = 0
        self.force = force or {}
        self.reseed = reseed
        self.record = record
        self.log = []

    def _maybe_reseed(self, k):
        if self.reseed is not None and k == self.reseed[0]:
            for name, r in self.engine.rng._streams.items():
                r.seed(self.reseed[1] * 1_000_003 + zlib.crc32(name.encode()))

    # ---------------------------------------------------------------- 行動
    def decide_action(self, actor):
        k = self.k
        self.k += 1
        if k in self.force:
            dec = self.force[k]
        else:
            dec = super().decide_action(actor)
        if self.record:
            self.log.append(dict(k=k, kind="action", unit=actor.id, t=round(self.engine.cur_time, 3),
                                 dec=(dec.action_id, dec.target_id), alts=self.action_alts(actor, dec)))
        self._maybe_reseed(k)
        return dec

    def decide_intervention(self, window):
        k = self.k
        self.k += 1
        if k in self.force:
            ch = self.force[k]
        else:
            ch = super().decide_intervention(window)
        if self.record:
            alts = [("iv", c.id) for c in window.eligible if c.rank is Rank.FRONT] + [("iv", None)]
            self.log.append(dict(k=k, kind="intervention", unit=window.target.id, t=round(self.engine.cur_time, 3),
                                 dec=("iv", ch.interceptor_id), alts=alts, attacker=window.attacker.id))
        self._maybe_reseed(k)
        return ch

    # ---------------------------------------------------------------- 選択肢
    def action_alts(self, actor, dec):
        eng = self.engine
        out = []
        greedy = None
        for a in eng.available_actions(actor):
            if a.kind is ActionKind.WAIT:
                continue
            if a.kind is ActionKind.ATTACK and a.area == "all":
                out.append((a.id, None, 0.0))
                continue
            tg = [t for t in eng.valid_targets(actor, a) if t.alive]
            if not tg:
                continue
            if a.kind is ActionKind.ATTACK:
                sc = sorted(((self.val_attack(actor, a, t), t.id) for t in tg), reverse=True)[:2]
                for v, tid in sc:
                    out.append((a.id, tid, v))
            elif a.kind is ActionKind.HEAL:
                t = max(tg, key=lambda t: self.val_heal(actor, a, t))
                out.append((a.id, t.id, 0.0))
            elif a.special == "observe":
                for t in tg:
                    out.append((a.id, t.id, 0.0))
            elif a.kind is ActionKind.EP_SUPPLY:
                t = max(tg, key=lambda t: t.d.ep_max - t.ep)
                out.append((a.id, t.id, 0.0))
            else:
                out.append((a.id, tg[0].id, 0.0))
        out.append(("wait", None, 0.0))
        seen, res = set(), []
        for aid, tid, v in out:
            if (aid, tid) in seen:
                continue
            seen.add((aid, tid))
            res.append((aid, tid, round(v, 4)))
        if (dec.action_id, dec.target_id) not in seen:
            res.append((dec.action_id, dec.target_id, 0.0))
        return res[:8]


def _make(seed, intel, power, force=None, reseed=None, record=False):
    cfg = load_battle_config(party=PARTY, encounter=ENC, rules=RULES, ai_weights="ai_weights_v15.yaml",
                             ally_policies="ally_policies_v15.yaml", front_hp_mult=1.75)
    cfg = apply_mods(cfg, {"stat": {"enemy": {"power": power, "magic": power}}})
    ally = BranchAlly(cfg.ally_policies, force=force, reseed=reseed, record=record)
    eng, _ = build(seed, intel, mods={"stat": {"enemy": {"power": power, "magic": power}}}, ally_ctl=ally)
    return eng, ally


def _to_choice(kind, item):
    if kind == "intervention":
        return InterventionChoice(item[1], reasons=["分岐分析"])
    return Decision(item[0], item[1], reasons=["分岐分析"])


def analyze_battle(args):
    seed, P, K, intel, power = args
    eng, ally = _make(seed, intel, power, record=True)
    eng.run()
    base_win = 1 if eng.state.winner == "ally" else 0
    log = ally.log
    cands = [d for d in log if len(d["alts"]) >= 2 and
             (not NOWAIT or d["kind"] != "action" or len([x for x in d["alts"] if x[0] != "wait"]) >= 2)]
    if not cands:
        return []
    # 判断点: 戦闘の前半〜中盤から均等に P 個
    fr = os.environ.get("V15_BRANCH_FRACS")
    if fr:
        idx = sorted({min(len(cands) - 1, int(float(x) * len(cands))) for x in fr.split(",")})
    else:
        idx = sorted({int(i * (len(cands) - 1) / max(P - 1, 1)) for i in range(P)}) if P > 1 else [0]
    out = []
    hist = {d["k"]: d for d in log}
    for i in idx:
        d = cands[i]
        k = d["k"]
        force_prefix = {}
        for j in range(k):
            h = hist[j]
            force_prefix[j] = _to_choice(h["kind"], h["dec"])
        res = []
        alts = d["alts"]
        if NOWAIT and d["kind"] == "action":
            alts = [x for x in alts if x[0] != "wait" or (x[0], x[1]) == tuple(d["dec"])]
            if len(alts) < 2:
                continue
            ai_alt = [x for x in alts if (x[0], x[1]) == tuple(d["dec"])]
            others = [x for x in alts if (x[0], x[1]) != tuple(d["dec"])]
            alts = ai_alt + others[:MAXALT - len(ai_alt)]
        for alt in alts:
            item = alt[:2] if d["kind"] == "action" else alt
            wins = 0
            for r in range(K):
                f = dict(force_prefix)
                f[k] = _to_choice(d["kind"], item)
                e2, a2 = _make(seed, intel, power, force=f, reseed=(k, seed * 7919 + k * 131 + r))
                e2.run()
                wins += 1 if e2.state.winner == "ally" else 0
            res.append(dict(alt=list(item), v=alt[2] if d["kind"] == "action" else None, p=wins / K))
        ai_item = list(d["dec"])
        out.append(dict(seed=seed, k=k, kind=d["kind"], unit=d["unit"], t=d["t"], ai=ai_item, base_win=base_win,
                        res=res, n_dec=len(log)))
    return out


def main():
    out = sys.argv[1]
    s0, nb = int(sys.argv[2]), int(sys.argv[3])
    P = int(sys.argv[4]) if len(sys.argv) > 4 else 3
    K = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    intel = int(sys.argv[6]) if len(sys.argv) > 6 else 1
    power = float(sys.argv[7]) if len(sys.argv) > 7 else 1.0
    jobs = [(s, P, K, intel, power) for s in range(s0, s0 + nb)]
    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
        for rs in ex.map(analyze_battle, jobs):
            with open(out, "a") as f:
                for r in rs:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
            print("battle done", rs[0]["seed"] if rs else "-", flush=True)


if __name__ == "__main__":
    main()
