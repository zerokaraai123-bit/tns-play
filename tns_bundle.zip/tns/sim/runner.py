from __future__ import annotations

from typing import Optional

from ..ai.ally.ally_controller import AllyAutoController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..engine.battle_engine import BattleEngine
from ..model.enums import Side


def make_engine(cfg, seed: int, ally_policy: str = "situational", enemy_intel: Optional[int] = None,
                log: bool = False, ally_controller=None) -> BattleEngine:
    ally = ally_controller or AllyAutoController(cfg.ally_policies, ally_policy)
    enemy = EnemyAIController(cfg.ai_weights)
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: enemy}, seed=seed,
                       enemy_intel=enemy_intel, log_enabled=log)
    eng.stats.ally_policy = getattr(ally, "policy_name", ally.name)
    return eng


def run_battle(cfg, seed, ally_policy="situational", enemy_intel=None, log=False):
    eng = make_engine(cfg, seed, ally_policy, enemy_intel, log)
    eng.run()
    return eng
