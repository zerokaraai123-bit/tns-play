"""Ver0.5 の結果表（Markdown）。 python -m tns.sim.v05_report > out/v05_tables.md"""
from __future__ import annotations

import math

from .metrics import wilson
from .v05_analysis import collect

INTEL_JA = {"0": "低", "1": "通常", "2": "高", "3": "戦術"}
COND_JA = {"C0": "条件0 なし", "C1": "条件1 治療のみ", "C2": "条件2 補給のみ", "C3": "条件3 治療→補給",
           "C4": "条件4 補給→治療", "C34n": "参考 両方・順番指定なし"}


def f(v, kind="f2"):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "-"
    if kind == "%":
        return f"{v:.0%}"
    if kind == "%1":
        return f"{v:.1%}"
    if kind == "f1":
        return f"{v:.1f}"
    return f"{v:.2f}"


def table(rows, cols, title, note=""):
    L = [f"\n#### {title}"]
    if note:
        L.append(note)
    L.append("| " + " | ".join(c[0] for c in cols) + " |")
    L.append("|" + "---|" * len(cols))
    for r in rows:
        L.append("| " + " | ".join(c[1](r) for c in cols) + " |")
    return "\n".join(L)


def build():
    s1, s2, s2b = collect("out", "v5s1"), collect("out", "v5s2"), collect("out", "v5s2b", by=("enemy_intel", "policy"))
    S = []

    def A(d, tag, grp="all"):
        return d.get(tag, {}).get(grp, {})

    def cond_rows(d, tags):
        return [(t, A(d, t)) for t in tags if t in d]

    def name(tag):
        c = tag.split("_")[0]
        rest = tag[len(c) + 1:]
        return f"{COND_JA.get(c, c)}（{rest}）"

    base_cols = [("条件", lambda r: name(r[0])), ("n", lambda r: str(r[1]["n"])),
                 ("勝率", lambda r: f(r[1]["win"], "%")),
                 ("FRONT死亡率", lambda r: f(r[1]["ally_front_death_rate"], "%")),
                 ("REAR死亡率", lambda r: f(r[1]["ally_rear_death_rate"], "%")),
                 ("FRONT EP枯渇率", lambda r: f(r[1]["ally_front_ep_out_rate"], "%")),
                 ("巡数", lambda r: f(r[1]["rounds"], "f1")),
                 ("治療/戦", lambda r: f(r[1]["heals"])), ("補給/戦", lambda r: f(r[1]["supplies"]))]
    for x in ("1.5", "1.75"):
        tags = [f"C0_x{x}"] + [f"{c}_{lv}_x{x}" for lv in ("S", "M") for c in ("C1", "C2", "C3", "C4")] + [f"C34n_M_x{x}"]
        S.append(table(cond_rows(s1, tags), base_cols, f"T1 5条件の比較（前衛HP×{x}、状況判断、知能4段階の合計。Stage1）"))
    tags2 = ["C0_x1"] + [f"{c}_{lv}_x1" for lv in ("S", "M") for c in ("C1", "C2", "C3", "C4", "C34n")]
    S.append(table(cond_rows(s2, tags2), base_cols, "T2 前衛HP×1（Ver0.4でほぼ全敗だった倍率）での5条件（Stage2、1条件4000戦）"))
    tags_b = [f"{c}_M_x{x}" for x in ("1", "2") for c in ("C0", "C3", "C4")]
    S.append(table(cond_rows(s1, tags_b), base_cols, "T3 参考: 前衛HP×1・×2（Stage1、1条件1200戦）"))

    # 順番比較
    oc = [("条件", lambda r: name(r[0])), ("n", lambda r: str(r[1]["n"])),
          ("勝率(95%CI)", lambda r: f"{r[1]['win']:.1%} [{wilson(round(r[1]['win'] * r[1]['n']), r[1]['n'])[0]:.3f}-{wilson(round(r[1]['win'] * r[1]['n']), r[1]['n'])[1]:.3f}]"),
          ("FRONT死亡", lambda r: f(r[1]["ally_front_death_rate"], "%1")), ("REAR死亡", lambda r: f(r[1]["ally_rear_death_rate"], "%1")),
          ("治療/戦", lambda r: f(r[1]["heals"])), ("補給/戦", lambda r: f(r[1]["supplies"])),
          ("治療量/戦", lambda r: f(r[1]["heal_amt"], "f1")), ("補給EP/戦", lambda r: f(r[1]["sup_ep"], "f1")),
          ("順番待ちで見送った治療/補給", lambda r: f"{r[1]['gate_skip_heal']:.2f} / {r[1]['gate_skip_supply']:.2f}"),
          ("戦線復旧率", lambda r: f(r[1]["recover_rate"], "%")),
          ("補給EP1あたり防いだダメージ", lambda r: f(r[1]["sup_block_per_ep"])),
          ("崩壊後の生存行動数(合計/戦)", lambda r: f(r[1]["post_collapse_total"], "f1"))]
    rows = cond_rows(s2, ["C3_S_x1", "C4_S_x1", "C34n_S_x1", "C3_M_x1", "C4_M_x1", "C34n_M_x1"]) + \
        cond_rows(s1, [f"{c}_{lv}_x{x}" for x in ("1.5", "1.75") for lv in ("S", "M") for c in ("C3", "C4")])
    S.append(table(rows, oc, "T4 条件3（治療→補給）と条件4（補給→治療）の比較"))

    # 知能別 順番比較 ×1
    L = ["\n#### T5 条件3 vs 条件4 を敵知能別に（前衛HP×1、Stage2、各1000戦）",
         "| 量 | 知能 | 勝率 3 / 4 | FRONT死亡 3 / 4 | REAR死亡 3 / 4 | 治療/戦 3 / 4 | 補給/戦 3 / 4 |", "|---|---|---|---|---|---|---|"]
    for lv in ("S", "M"):
        for i in "0123":
            a, b = A(s2, f"C3_{lv}_x1", ("enemy_intel", i)), A(s2, f"C4_{lv}_x1", ("enemy_intel", i))
            if a and b:
                L.append(f"| {lv} | {INTEL_JA[i]} | {f(a['win'], '%1')} / {f(b['win'], '%1')} | {f(a['ally_front_death_rate'], '%1')} / {f(b['ally_front_death_rate'], '%1')} | "
                         f"{f(a['ally_rear_death_rate'], '%1')} / {f(b['ally_rear_death_rate'], '%1')} | {f(a['heals'])} / {f(b['heals'])} | {f(a['supplies'])} / {f(b['supplies'])} |")
    S.append("\n".join(L))

    # 補給EPの価値（HP帯別）
    L = ["\n#### T6 ⑪⑭ 補給したEPが実際に防いだダメージ（補給を受けた時点のHP帯別、EP1あたり。カッコ内は帯ごとの補給の割合）",
         "| 条件 | HP 75%以上 | 50〜75% | 25〜50% | 25%未満 | 使われずに残ったEP |", "|---|---|---|---|---|---|"]
    for d, t in ((s1, "C2_M_x1.5"), (s1, "C3_M_x1.5"), (s1, "C4_M_x1.5"), (s1, "C3_M_x1.5_p0"), (s1, "C4_M_x1.5_p0"),
                 (s2, "C2_M_x1"), (s2, "C3_M_x1"), (s2, "C4_M_x1"), (s2, "C2_S_x1")):
        a = A(d, t)
        if not a:
            continue
        cells = [f"{f(a[f'sup_block_per_ep_b{b}'])}（{f(a[f'sup_share_b{b}'], '%')}）" for b in range(4)]
        L.append(f"| {name(t)} | " + " | ".join(cells) + f" | {f(a['sup_waste'], '%')} |")
    S.append("\n".join(L))

    # 戦線復旧
    rc = [("条件", lambda r: name(r[0])),
          ("崩壊/戦 FRONT・REAR", lambda r: f"{f(r[1]['ally_front_collapses'])}・{f(r[1]['ally_rear_collapses'])}"),
          ("⑫復旧率 FRONT・REAR", lambda r: f"{f(r[1]['ally_front_recover_rate'], '%')}・{f(r[1]['ally_rear_recover_rate'], '%')}"),
          ("復旧の決め手が治療", lambda r: f(r[1]["ally_front_recover_by_heal"], "%")),
          ("⑬復旧後の持続(行動数) FRONT", lambda r: f(r[1]["ally_front_rec_duration"], "f1")),
          ("復旧後の結末 再崩壊/死亡", lambda r: f"{f(r[1]['ally_front_rec_recollapse'], '%')}/{f(r[1]['ally_front_rec_death'], '%')}"),
          ("崩壊したFRONTが最後まで生存", lambda r: f(r[1]["ally_front_collapsed_survived"], "%")),
          ("⑩治療による必要EPの改善", lambda r: f(r[1]["heal_cpd_gain"], "%"))]
    S.append(table(cond_rows(s2, ["C0_x1", "C1_M_x1", "C2_M_x1", "C3_M_x1", "C4_M_x1", "C1_S_x1", "C2_S_x1", "C3_S_x1", "C4_S_x1"]) +
                   cond_rows(s1, ["C0_x1.5", "C1_M_x1.5", "C2_M_x1.5", "C3_M_x1.5", "C4_M_x1.5"]), rc,
                   "T7 戦線崩壊と戦線復旧（PA-41の定義）"))

    # ⑮
    L = ["\n#### T8 ⑮ 1行動あたり救えた戦闘時間（条件0との差。崩壊した味方が生き延びた全体行動数の合計 ÷ 治療・補給の行動数）",
         "| 条件 | 崩壊後の生存行動数(合計/戦) | 条件0との差 | 治療＋補給の行動/戦 | 1行動あたり |", "|---|---|---|---|---|"]
    for d, base, tags in ((s2, "C0_x1", ["C1_S_x1", "C1_M_x1", "C2_S_x1", "C2_M_x1", "C3_S_x1", "C4_S_x1", "C3_M_x1", "C4_M_x1"]),
                          (s1, "C0_x1.5", ["C1_S_x1.5", "C1_M_x1.5", "C2_S_x1.5", "C2_M_x1.5", "C3_M_x1.5", "C4_M_x1.5"])):
        b = A(d, base)
        for t in tags:
            a = A(d, t)
            if not a or not b:
                continue
            acts = a["heals"] + a["supplies"]
            diff = a["post_collapse_total"] - b["post_collapse_total"]
            L.append(f"| {name(t)} | {f(a['post_collapse_total'], 'f1')} | {diff:+.1f} | {f(acts)} | {f(diff / acts if acts else math.nan)} |")
    S.append("\n".join(L))
    S.append("※崩壊が早く起きるほど「崩壊後の生存時間」は長くなりうるため、条件間の比較は参考値。統制実験Cの方が厳密。")

    # 対照群
    ctl = [(t, A(s1, t)) for t in ["C0_x1.5", "C0_M_x1.5_p0", "C0_M_x1.5_firefree", "C3_M_x1.5", "C3_M_x1.5_p0", "C3_M_x1.5_p585",
                                    "C3_M_x1.5_firefree", "C4_M_x1.5", "C4_M_x1.5_p0", "C4_M_x1.5_p585", "C4_M_x1.5_firefree"] if t in s1]
    S.append(table(ctl, base_cols + [("FRONT最初のHP直撃(行動)", lambda r: f(r[1]["ally_front_first_hit_t"], "f1"))],
                   "T9 対照群（前衛HP×1.5・M）: p0=負傷による悪化なし / p585=中程度 / firefree=攻撃魔法のEP消費0"))

    # 介入方針
    L = ["\n#### T10 介入方針3種での確認（×1.5・M、各方針1200戦、Stage2b）", "| 条件 | 常に介入 | 一切介入しない | 状況判断 |", "|---|---|---|---|"]
    for t in ("C0_x1.5", "C3_M_x1.5", "C4_M_x1.5"):
        cells = [f(A(s2b, t, ("policy", p)).get("win"), "%") for p in ("always", "never", "situational")]
        L.append(f"| {name(t)} | " + " | ".join(cells) + " |")
    S.append("\n".join(L))

    # 敵AI
    ec = [("知能", lambda r: INTEL_JA[r[0]]), ("味方勝率", lambda r: f(r[1]["win"], "%")),
          ("標的変更率", lambda r: f(r[1]["enemy_switch_rate"], "%")),
          ("倒し切る前の変更率", lambda r: f(r[1]["enemy_abandon_rate"], "%")),
          ("瀕死への攻撃率", lambda r: f(r[1]["enemy_dying_rate"], "%")),
          ("FRONT/REAR", lambda r: f"{f(r[1]['enemy_front_rate'], '%')}/{f(r[1]['enemy_rear_rate'], '%')}"),
          ("OPEN経路利用/戦", lambda r: f(r[1]["enemy_open_route"], "f1")),
          ("誘発した味方介入/戦", lambda r: f(r[1]["enemy_induced_iv"], "f1")),
          ("集中攻撃の維持/途中解除", lambda r: f"{f(r[1]['enemy_focus_keep'], 'f1')}/{f(r[1]['enemy_focus_release'], 'f1')}"),
          ("囮計画/成功率", lambda r: f"{f(r[1]['enemy_plans'], 'f1')}/{f(r[1]['enemy_plan_success'], '%')}"),
          ("敵が味方をかばった/戦", lambda r: f(r[1]["enemy_self_iv"], "f1")),
          ("リーダー撃破率・巡", lambda r: f"{f(r[1]['leader_down_rate'], '%')}・{f(r[1]['leader_down_round'], 'f1')}"),
          ("敵の撃破数/戦", lambda r: f(r[1]["enemy_kills"])),
          ("初撃破までの敵攻撃", lambda r: f(r[1]["enemy_attacks_to_first_kill"], "f1"))]
    for d, t in ((s2, "C0_x1"), (s1, "C0_x1.5")):
        rows = [(i, A(d, t, ("enemy_intel", i))) for i in "0123"]
        S.append(table(rows, ec, f"T11 敵AIログ（{name(t)}、状況判断）"))
    return "\n".join(S)


if __name__ == "__main__":
    print(build())
