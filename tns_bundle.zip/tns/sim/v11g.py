"""Ver0.11 3FRONT基本陣形（中央両対応）・敵戦力キャリブレーション・詠唱比較（PA-150）。
python -m tns.sim.v11g cal wolves_6 wolves_7 ...   # 詠唱4・Ver0.11介入AIで勝率を見る
python -m tns.sim.v11g main wolves_X               # 決めた敵で 詠唱0/2/4/6 × 介入AI/Never
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from .v09 import seeds
from .v11f import _one

OUT = Path("out/v11g")


def runset(tag, jobs):
    path = OUT / f"{tag}.jsonl"
    if path.exists():
        R = [json.loads(l) for l in open(path, encoding="utf-8")]
        print("skip", tag, round(sum(r["win"] for r in R) / len(R), 3), flush=True)
        return
    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
        R = list(ex.map(_one, jobs, chunksize=20))
    with open(path, "w", encoding="utf-8") as fh:
        for r in R:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("done", tag, round(sum(r["win"] for r in R) / len(R), 3), flush=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")
    mode, encs = sys.argv[1], sys.argv[2:]
    if mode == "cal":
        for enc in encs:
            runset(f"cal_{enc}_cast4_v11", [("center", 4, "v11", s, i, enc) for s, i in S])
    else:
        enc = encs[0]
        suffix = encs[1] if len(encs) > 1 else ""
        for n in (0, 2, 4, 6):
            for pol in ("v11", "never"):
                runset(f"{enc}{suffix}_cast{n}_{pol}", [("center", n, pol, s, i, enc, suffix) for s, i in S])


if __name__ == "__main__":
    main()
