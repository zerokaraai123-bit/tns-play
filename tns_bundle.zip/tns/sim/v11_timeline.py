"""Ver0.11 時間軸診断（ログ・集計のみ。ルール・AIは一切変更しない）。
中心条件 q058_f85_incap4・Ver0.11価値AI（治療用の未来温存あり）・同一シード1,000戦。
時間軸 = 戦闘全体の累積行動数（味方・敵すべての手番。engine.action_index）。進行度 = その時点の行動数 ÷ その戦闘の総行動数。
python -m tns.sim.v11_timeline [policy]
"""
from __future__ import annotations

import json
import math
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..model.enums import ActionKind, Side
from .v09 import seeds
from .v11 import build

OUT = Path("out/v11t")
COND = "q058_f85_incap4"
NAME = {"adel": "アデル", "vanguard": "前衛2", "celestia": "セレスティア", "archer": "弓手", "toolsmith": "エーテル学者",
        "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "leader": "狼リーダー", "thrower": "投擲兵"}


def _one(job):
    pol, seed, intel = job
    eng, ally = build(COND, pol, seed, intel)
    cel = eng.u("celestia")
    fronts = [u for u in eng.state.units.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    ev_out = []          # (idx, enemy_actions, kind, data)
    st = {"enemy_actions": 0, "pending": None}

    def front_state(f):
        if f.hp <= 0:
            s = "死亡"
        elif f.incapacitated:
            s = "戦闘不能"
        elif not f.can_intervene:
            s = "持ち場を離れている"
        else:
            s = "介入可能"
        return {"id": f.id, "hp": f.hp, "hpmax": f.d.hp_max, "ep": f.ep, "state": s}

    def close_pending():
        p = st["pending"]
        if p is not None:
            ev_out.append((p["idx"], p["eacts"], "target", p))
            st["pending"] = None

    def lis(ev, e):
        t = ev["t"]
        idx = e.action_index
        if t == "turn_start":
            close_pending()
            u = e.u(ev["unit"])
            if u.side is Side.ENEMY:
                st["enemy_actions"] += 1
            ev_out.append((idx, st["enemy_actions"], "sample", {"ep": cel.ep, "hp": cel.hp, "actor": u.id}))
        elif t == "attack_declared":
            a, tg = e.u(ev["unit"]), e.u(ev["target"])
            if a.side is Side.ENEMY and tg.id == "celestia":
                close_pending()
                act = e.actions[ev["action"]]
                raw = e.damage.expected(a, act)
                st["pending"] = {"idx": idx, "eacts": st["enemy_actions"], "attacker": a.id, "intel": a.intel_effective,
                                 "cel_ep": cel.ep, "cel_hp": cel.hp, "cel_incap": int(cel.incapacitated),
                                 "need": math.ceil(e.defense.required_ep(cel, raw) - 1e-9), "raw": round(raw, 1),
                                 "reach_ok": int(ev["reach_ok"]), "fronts": [front_state(f) for f in fronts],
                                 "window": 0, "eligible": [], "iv_by": None, "ai_reason": None,
                                 "cel_spent": 0, "cel_dmg": 0, "front_spent": 0, "front_dmg": 0}
            elif a.id == "celestia" and ev["action"] == "fire":
                ev_out.append((idx, st["enemy_actions"], "spend", {"cat": "攻撃魔法", "ep": e.actions["fire"].ep_cost}))
        elif t == "area_attack" and ev["unit"] == "celestia":
            ev_out.append((idx, st["enemy_actions"], "spend", {"cat": "炎嵐", "ep": e.actions[ev["action"]].ep_cost}))
        elif t == "heal" and ev["unit"] == "celestia":
            ev_out.append((idx, st["enemy_actions"], "spend", {"cat": "治療", "ep": ev.get("ep_cost", 0) or 0}))
        elif t == "intervention_window" and ev["target"] == "celestia" and st["pending"] is not None:
            st["pending"]["window"] = 1
            st["pending"]["eligible"] = list(ev["eligible"])
        elif t == "intervened" and ev["target"] == "celestia" and st["pending"] is not None:
            st["pending"]["iv_by"] = ev["unit"]
        elif t == "no_intervention" and ev["target"] == "celestia" and st["pending"] is not None:
            rec = next((r for r in reversed(ally.records) if r["kind"] == "iv" and r["target"] == "celestia"), {})
            st["pending"]["ai_reason"] = rec.get("reason")
            st["pending"]["L_self"] = rec.get("L_self")
            st["pending"]["L_iv"] = rec.get("L_iv")
        elif t == "damage":
            u = e.u(ev["unit"])
            p = st["pending"]
            if u.id == "celestia" and e.u(ev["attacker"]).side is Side.ENEMY:
                sp = ev.get("ep_spent", 0) or 0
                if sp:
                    ev_out.append((idx, st["enemy_actions"], "spend", {"cat": "自衛", "ep": sp}))
                if p is not None:
                    p["cel_spent"] += sp
                    p["cel_dmg"] += ev.get("dmg", 0) or 0
            elif p is not None and p["iv_by"] == u.id:
                p["front_spent"] += ev.get("ep_spent", 0) or 0
                p["front_dmg"] += ev.get("dmg", 0) or 0
        elif t == "ko" and ev.get("unit") == "celestia":
            ev_out.append((idx, st["enemy_actions"], "cel_ko", {"incap": int(bool(ev.get("incap"))), "ep": cel.ep}))
        elif t == "revive" and ev.get("unit") == "celestia":
            ev_out.append((idx, st["enemy_actions"], "cel_revive", {}))
    eng.listeners.append(lis)
    eng.run()
    close_pending()
    turns = [{"round": r["round"], "choice": r["choice"], "ep": r["ep"]} for r in ally.records
             if r["kind"] == "mage" and r["unit"] == "celestia"]
    return {"seed": seed, "intel": intel, "win": int(eng.stats.winner == "ally"), "N": eng.action_index,
            "E": st["enemy_actions"], "end_ep": cel.ep, "cel_alive": int(cel.alive), "events": ev_out}


def run(pol="v11"):
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")
    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
        R = list(ex.map(_one, [(pol, s, i) for s, i in S], chunksize=20))
    with open(OUT / f"timeline_{pol}.jsonl", "w", encoding="utf-8") as fh:
        for r in R:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("done", len(R))


if __name__ == "__main__":
    run(*sys.argv[1:])
