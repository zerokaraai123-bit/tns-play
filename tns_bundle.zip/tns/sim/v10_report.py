"""Ver0.10 集計。 python -m tns.sim.v10_report > out/v10_tables.md"""
from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path

from .v09_report import avg, label, n, paired, win
from .v10 import CONDS

OUT = Path("out/v10")
PJ = {"v9": "Ver0.9価値AI", "v10": "Ver0.10価値AI", "never": "Never", "always": "Always"}


def load(tag):
    p = OUT / f"{tag}_battles.csv"
    if not p.exists():
        return None
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def cl(cond):
    q, f50, eff, fl = label(cond)
    return f"q={q:.3g}（{eff:.1f}倍）・f(0.5)={fl}"


def build():
    L = ["## Ver0.10 介入後の「穴」の見積もりだけを変えた価値AI（D1.5×P2・M1土台・各1,000戦・同一シード・敵知能均等）"]
    D = {c: {p: load(f"{c}_{p}") for p in PJ} for c in CONDS}
    D = {c: d for c, d in D.items() if all(d.values())}

    L.append("\n#### W1 勝率（±は同一シード対応比較の95%）")
    L.append("| 条件 | Ver0.9 | Ver0.10 | Never | Always | v10−Never | v10−v9 | v10−Always | v9−Never |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for c, d in D.items():
        pv = lambda a, b: "{:+.1%}±{:.1%}".format(paired(d[a], d[b])[0], 1.96 * paired(d[a], d[b])[1])
        L.append(f"| {cl(c)} | {win(d['v9']):.1%} | {win(d['v10']):.1%} | {win(d['never']):.1%} | {win(d['always']):.1%} | "
                 f"{pv('v10', 'never')} | {pv('v10', 'v9')} | {pv('v10', 'always')} | {pv('v9', 'never')} |")

    L.append("\n#### W2 死亡・戦闘不能（1人あたり。FRONT／REAR）")
    L.append("| 条件 | Ver0.9 | Ver0.10 | Never | Always |")
    L.append("|---|---|---|---|---|")
    for c, d in D.items():
        cell = lambda B: (f"死{avg(B, 'dead_FRONT') / 2:.0%}・不能{avg(B, 'incap_FRONT') / 2:.0%}／"
                          f"死{avg(B, 'dead_REAR') / 3:.0%}・不能{avg(B, 'incap_REAR') / 3:.0%}")
        L.append(f"| {cl(c)} | " + " | ".join(cell(d[p]) for p in PJ) + " |")

    L.append("\n#### W3 介入の量と損得（1戦あたり）")
    L.append("| 条件 | 方針 | REARのための介入 | 介入できたがしなかった | 介入で節約したREARのEP | 介入で防いだREARの生身ダメ | 開いた経路からREARへの攻撃 | 介入した前衛の離脱中被弾（回/ダメ） | 介入が原因の侵入でREARが失ったHP/EP | 介入でFRONTが使ったEP | 介入の一撃でFRONTが受けたダメ | 防いだ損失（EP+HP） | 新たに生じた損失（EP+HP） |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for c, d in D.items():
        for p in ("v9", "v10", "always", "never"):
            B = d[p]
            prevented = avg(B, "iv_rear_saved_ep") + avg(B, "iv_prevented_hp")
            new = (avg(B, "ep_front_iv") + avg(B, "iv_front_hit_dmg") + avg(B, "sum_real_front_dmg")
                   + avg(B, "sum_real_intr_hp") + avg(B, "sum_real_intr_ep"))
            L.append(f"| {cl(c)} | {PJ[p]} | {avg(B, 'iv_move_rear'):.2f} | {avg(B, 'ivrec_n') - avg(B, 'ivrec_protect'):.2f} | "
                     f"{avg(B, 'iv_rear_saved_ep'):.1f} | {avg(B, 'iv_prevented_hp'):.1f} | {avg(B, 'enemy_att_rear_open'):.2f} | "
                     f"{avg(B, 'sum_real_front_hits'):.2f}/{avg(B, 'sum_real_front_dmg'):.0f} | {avg(B, 'sum_real_intr_hp'):.1f}/{avg(B, 'sum_real_intr_ep'):.1f} | "
                     f"{avg(B, 'ep_front_iv'):.1f} | {avg(B, 'iv_front_hit_dmg'):.1f} | {prevented:.1f} | {new:.1f} |")

    L.append("\n#### W4 予測精度（介入1件あたり。予測＝介入を決めた時点でのVer0.10式の見積もり、実績＝その前衛が持ち場に戻るまでに実際に起きたこと）")
    L.append("（同じ見積もり式を、Ver0.9のAIの介入にも記録用として当てている。Ver0.9のAI自身が判断に使った「穴」はこれとは別の式）")
    L.append("| 条件 | 方針 | 介入数 | 穴からの追加攻撃 予測/実績 | それによるREARのHP損失 予測/実績 | REARのEP損失 予測/実績 | 介入した前衛への攻撃 予測/実績 | 前衛の生身ダメ 予測/実績 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for c, d in D.items():
        for p in ("v9", "v10", "always"):
            B = d[p]
            w = max(sum(n(b["win_n"]) for b in B), 1)
            s = lambda k: sum(n(b.get(k)) for b in B) / w
            L.append(f"| {cl(c)} | {PJ[p]} | {w:.0f} | {s('sum_pred_extra_rear_hits'):.2f} / {s('sum_real_intr'):.2f} | "
                     f"{s('sum_pred_rear_hp'):.1f} / {s('sum_real_intr_hp'):.1f} | {s('sum_pred_rear_ep'):.1f} / {s('sum_real_intr_ep'):.1f} | "
                     f"{s('sum_pred_front_hits'):.2f} / {s('sum_real_front_hits'):.2f} | {s('sum_pred_front_dmg'):.1f} / {s('sum_real_front_dmg'):.1f} |")

    L.append("\n#### W5 判断の理由（REARが狙われ、介入できる前衛がいた場面）")
    L.append("| 条件 | 方針 | 判断数/戦 | 介入: 選択肢の維持 | 介入: 前衛の方が安い | 介入: 生身の危険 | うち穴の危険（予測追加攻撃0.5回以上）を承知で介入 | 非介入: 目の前なら守る方が安いが離脱後の危険で見送り | 非介入: 前衛のEPが足りない | 非介入: 自衛の方が安い |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for c, d in D.items():
        for p in ("v9", "v10"):
            fp = OUT / f"{c}_{p}_ivdecisions.csv"
            if not fp.exists():
                continue
            R = list(csv.DictReader(open(fp, encoding="utf-8-sig")))
            nb = len(d[p])
            pro = [r for r in R if r["choice"] != "self"]
            slf = [r for r in R if r["choice"] == "self"]
            cr = Counter(r["reason"] for r in pro)
            risky = sum(1 for r in pro if n(r.get("pred_extra_rear_hits")) >= 0.5)
            hole_skip = sum(1 for r in slf if n(r.get("L_iv_now")) + 0.02 < n(r["L_self"]))
            ep_short = sum(1 for r in slf if not (n(r.get("L_iv_now")) + 0.02 < n(r["L_self"])) and n(r["f_ep"]) < n(r["f_need"]))
            L.append(f"| {cl(c)} | {PJ[p]} | {len(R) / nb:.2f} | {cr['選択肢の維持'] / nb:.2f} | {cr['前衛の方が安い'] / nb:.2f} | {cr['生身の危険'] / nb:.2f} | "
                     f"{risky / nb:.2f} | {hole_skip / nb:.2f} | {ep_short / nb:.2f} | {(len(slf) - hole_skip - ep_short) / nb:.2f} |")
    return "\n".join(L)


if __name__ == "__main__":
    print(build())
