"""自動戦闘と方針比較実験。

同じシード群で always / never / situational を戦わせ（乱数は用途別系列）、
「状況判断AIが、常に介入／一切介入より良い結果を出せるか」を判定する（PA-20）。
"""
from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..config_loader import load_battle_config
from .csv_export import write_csv
from .highlights import HighlightStore, tags_for
from .metrics import battle_row, summarize, wilson
from .runner import run_battle

POLICIES = ["always", "never", "situational"]


def _one(args):
    party, encounter, seed, policy, intel, rules, ai_weights, fhm, apol = args
    cfg = load_battle_config(party=party, encounter=encounter, rules=rules, ai_weights=ai_weights, front_hp_mult=fhm,
                             ally_policies=apol)
    eng = run_battle(cfg, seed, policy, intel)
    st = eng.stats
    row = battle_row(st, encounter, [(u.id, u.side.value, u.rank.value) for u in eng.state.units.values()])
    ivs = [dict(r.row(), encounter=encounter, seed=seed, enemy_intel="" if intel is None else intel,
                ally_policy=policy) for r in st.interventions]
    tags = tags_for(st, cfg.highlights)
    summary = (f"{ {'ally': '勝利', 'enemy': '敗北', 'draw': '引分'}[st.winner] } {st.rounds}巡 "
               f"味方HP{st.final['ally_hp_ratio']:.0%} 介入{st.c.get('intervention_ally', 0)} "
               f"侵入された{st.c.get('intrusion_ally', 0)} 侵入した{st.c.get('intrusion_enemy', 0)} "
               f"計画{len(st.plans)}(成功{sum(p['success'] for p in st.plans)})")
    entry = {"party": party, "encounter": encounter, "rules": rules, "ai_weights": ai_weights, "front_hp_mult": fhm, "ally_policies": apol, "seed": seed, "policy": policy,
             "enemy_intel": intel, "config_hash": cfg.hash, "summary": summary}
    return row, ivs, tags, entry


def run_experiment(party="party_default", encounter="wolves_5v5", n=1000, intels=(None,), policies=POLICIES,
                   seed0=0, out_dir="out", workers=None, tag="", rules="rules.yaml", ai_weights="ai_weights.yaml", front_hp_mult=1.0,
                   ally_policies="ally_policies.yaml"):
    cfg = load_battle_config(party=party, encounter=encounter, rules=rules, ai_weights=ai_weights,
                             front_hp_mult=front_hp_mult, ally_policies=ally_policies)
    jobs = [(party, encounter, seed0 + s, pol, intel, rules, ai_weights, front_hp_mult, ally_policies) for intel in intels for pol in policies for s in range(n)]
    workers = workers or max(1, (os.cpu_count() or 2))
    if workers > 1:
        with ProcessPoolExecutor(workers) as ex:
            results = list(ex.map(_one, jobs, chunksize=max(1, len(jobs) // (workers * 8))))
    else:
        results = [_one(j) for j in jobs]

    rows, iv_rows = [], []
    store = HighlightStore(cfg.highlights.get("max_per_tag", 20))
    by_key = {}
    for (row, ivs, tags, entry) in results:
        rows.append(row)
        iv_rows += ivs
        by_key[(entry["enemy_intel"], entry["seed"], entry["policy"])] = (row, tags, entry)

    # policy_split: 同じシードで方針により勝敗が分かれた
    splits = {}
    for intel in intels:
        for s in range(seed0, seed0 + n):
            res = {p: by_key[(intel, s, p)][0]["win"] for p in policies if (intel, s, p) in by_key}
            if "situational" in res:
                for other in ("always", "never"):
                    if other in res and res[other] != res["situational"]:
                        k = (intel, other)
                        sw = splits.setdefault(k, [0, 0])
                        sw[0 if res["situational"] else 1] += 1
            if len(set(res.values())) > 1:
                for p in policies:
                    row, tags, entry = by_key[(intel, s, p)]
                    if "policy_split" not in tags:
                        tags.append("policy_split")
                    entry["split"] = {q: ("勝" if res[q] else "負") for q in res}
    for (intel, s, p), (row, tags, entry) in sorted(by_key.items(), key=lambda kv: (str(kv[0][0]), kv[0][1], kv[0][2])):
        if tags:
            store.add(tags, entry)

    out = Path(out_dir)
    pre = f"{encounter}{('_' + tag) if tag else ''}"
    summary = summarize(rows)
    write_csv(out / f"{pre}_battles.csv", rows)
    write_csv(out / f"{pre}_interventions.csv", iv_rows)
    write_csv(out / f"{pre}_summary.csv", summary)
    store.save(out / f"{pre}_highlights.jsonl")
    report = comparison_report(summary, splits, encounter, n)
    (out / f"{pre}_report.txt").write_text(report, encoding="utf-8")
    return report, out / f"{pre}_highlights.jsonl"


def _fmt_intel(i):
    from ..model.enums import INTEL_NAMES
    return "設定値" if i in (None, "") else f"{i}:{INTEL_NAMES[int(i)]}"


def comparison_report(summary, splits, encounter, n) -> str:
    L = [f"# 方針比較レポート  encounter={encounter}  各条件 n={n}", ""]
    by_intel = {}
    for s in summary:
        by_intel.setdefault(s["enemy_intel"], {})[s["policy"]] = s
    for intel, d in by_intel.items():
        L.append(f"## 敵知能 {_fmt_intel(intel)}")
        L.append(f"{'方針':<12}{'勝率':>7} {'95%CI':>13} {'巡数':>6} {'HP残':>6} {'EP残':>6} {'介入':>6} "
                 f"{'防いだ':>7} {'自損':>6} {'穴被害':>7} {'net/介入':>8} {'侵入被':>6} {'侵入与':>6} {'計画':>5}")
        for p in POLICIES:
            if p not in d:
                continue
            s = d[p]
            L.append(f"{p:<12}{s['win_rate']:>7.1%} [{s['win_ci_low']:.2f}-{s['win_ci_high']:.2f}] "
                     f"{s['avg_rounds']:>6.1f} {s['avg_ally_hp_ratio']:>6.2f} {s['avg_ally_ep_ratio']:>6.2f} "
                     f"{s['avg_intervention_ally']:>6.1f} {s['avg_prevented_ally']:>7.1f} "
                     f"{s['avg_interceptor_taken_ally']:>6.1f} {s['avg_breach_damage_ally']:>7.1f} "
                     f"{str(s['net_per_intervention_ally']):>8} {s['avg_intrusion_ally']:>6.2f} "
                     f"{s['avg_intrusion_enemy']:>6.2f} {s['avg_plans']:>5.2f}")
        if all(p in d for p in POLICIES):
            sit, al, nv = d["situational"], d["always"], d["never"]
            better = (sit["win_rate"] > al["win_rate"] and sit["win_rate"] > nv["win_rate"]
                      and sit["avg_ally_hp_ratio"] > al["avg_ally_hp_ratio"]
                      and sit["avg_ally_hp_ratio"] > nv["avg_ally_hp_ratio"])
            L.append(f"→ 判定(PA-20: 勝率とHP残の両方で両方針を上回る): {'◎ 状況判断が優位' if better else '✕ 優位とは言えない'}")
            for other in ("always", "never"):
                sw = splits.get((None if intel == "" else intel, other))
                if sw:
                    tot = sw[0] + sw[1]
                    lo, hi = wilson(sw[0], tot)
                    L.append(f"   勝敗が分かれたシード vs {other}: {tot}件中 状況判断の勝ち {sw[0]} / 負け {sw[1]}"
                             f"（勝ち側比率 {sw[0] / tot:.0%}, 95%CI {lo:.2f}-{hi:.2f}）")
        L.append("   [敵の標的] 方針別: FRONT率/REAR率 | 標的変更率 | 同一標的連続(個体平均/最大, 群れ平均) | 味方初撃破:発生率・要した敵攻撃数・巡 | 前衛死/後衛死(人) | 侵入命中・ダメ | 維持/乗換/放棄(不利)")
        for p in POLICIES:
            if p not in d:
                continue
            s = d[p]
            L.append(f"   {p:<12}{s['enemy_front_attack_rate']}/{s['enemy_rear_attack_rate']} | {s['enemy_switch_rate']} | "
                     f"{s['enemy_avg_streak']}/{s['enemy_avg_max_streak']}, {s['enemy_team_avg_streak']} | "
                     f"{s['first_ko_ally_rate']:.0%}・{s['first_ko_ally_avg_attacks']}・{s['first_ko_ally_avg_round']} | "
                     f"{s['avg_front_dead_ally']}/{s['avg_rear_dead_ally']} | {s['avg_intrusion_hit_ally']}・{s['avg_intrusion_damage_ally']} | "
                     f"{s['avg_focus_keep']}/{s['avg_focus_switch_better']}/{s['avg_focus_release_hopeless']}")
        pre = d.get("situational") or next(iter(d.values()))
        if pre.get("ai_post_decisions"):
            L.append(f"   リーダー撃破前→後（{pre['policy']}）: 後衛狙い {pre['ai_pre_target_rear_rate']}→{pre['ai_post_target_rear_rate']} / "
                     f"OPEN経路突き(全体) {pre['ai_pre_open_route_rate']}→{pre['ai_post_open_route_rate']} / "
                     f"うち介入の穴 {pre['ai_pre_hole_exploit_rate']}→{pre['ai_post_hole_exploit_rate']} / "
                     f"囮計画 {pre['ai_pre_bait_rate']}→{pre['ai_post_bait_rate']} / "
                     f"敵の介入率 {pre['ai_pre_intervene_rate']}→{pre['ai_post_intervene_rate']}")
        L.append("")
    L.append("列: 防いだ=介入で防いだダメージ(PA-19) / 自損=介入者の被ダメ / 穴被害=その介入で開いた穴から後衛が受けたダメージ")
    L.append("    侵入被=味方後衛がOPEN経路から侵入された回数 / 侵入与=味方が敵の穴から敵後衛へ侵入した回数 / 計画=敵の囮計画数（1戦闘平均）")
    return "\n".join(L)
