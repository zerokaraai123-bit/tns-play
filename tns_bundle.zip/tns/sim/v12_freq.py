"""Ver0.12 第2段階: 敵のいない環境での純粋な行動頻度（TimelineEngine の interval をそのまま使う）。
python -m tns.sim.v12_freq -> out/v12/freq.md, out/v12/freq.png"""
from __future__ import annotations

from types import SimpleNamespace

from .v12 import METHODS, OUT, build

SPEEDS = (6, 8, 9, 10, 12, 13, 15)
HPS = (1.0, 0.5, 0.3, 0.15)
HORIZON = 10.0          # 10T（基準速度10・満タンで10回行動する長さ）


def engines():
    return {m: build(m, 0, "v11", 0, 3)[0] for m in METHODS}


def fake(eng, speed, hp_ratio):
    side = eng.u("adel").side
    d = SimpleNamespace(speed=speed, hp_max=100)
    return SimpleNamespace(id=f"s{speed}", d=d, hp=hp_ratio * 100, side=side)


def count_actions(eng, u, horizon=HORIZON):
    """敵のいない時間軸で、時刻0から待ち始めて horizon までに何回行動するか（同じ予約式をそのまま回す）"""
    t, k = 0.0, 0
    while True:
        t += eng.interval(u)
        if t > horizon + 1e-9:
            return k
        k += 1


def main():
    E = engines()
    rows = []
    lines = ["## 行動間隔（T）と10Tあたりの行動回数（HP満タン）",
             "| 速度 | A 間隔 | A 回数/10T | B 間隔 | B 回数/10T | C 間隔 | C 回数/10T |", "|---|---|---|---|---|---|---|"]
    for s in SPEEDS:
        r = [s]
        for m, eng in E.items():
            u = fake(eng, s, 1.0)
            iv = eng.interval(u)
            r += [f"{iv:.3f}", f"{10/iv:.2f}（実数{count_actions(eng, u)}）"]
            rows.append((m, s, 1.0, iv))
        lines.append("| " + " | ".join(str(x) for x in r) + " |")
    lines += ["", "## 速度15と速度9の行動頻度比（理論値 = (15/9)^指数）"]
    for m, eng in E.items():
        a, b = eng.interval(fake(eng, 9, 1)), eng.interval(fake(eng, 15, 1))
        lines.append(f"- {m}（指数{METHODS[m]}）: {a/b:.3f}倍。100T（基準速度で100行動）の間に 速度15={100/b:.1f}回、速度9={100/a:.1f}回、差{100/b-100/a:.1f}回")
    lines += ["", "## HP別の 10Tあたりの行動回数（HP速度倍率は既存曲線: 100%→1.00, 50%→0.95, 30%→0.80, 15%→0.55）",
              "| 速度 | 方式 | HP100% | HP50% | HP30% | HP15% |", "|---|---|---|---|---|---|"]
    for s in SPEEDS:
        for m, eng in E.items():
            vals = [10 / eng.interval(fake(eng, s, h)) for h in HPS]
            lines.append(f"| {s} | {m} | " + " | ".join(f"{v:.2f}" for v in vals) + " |")
    # 戦場全体の行動密度（味方5＋敵6, 満タン）
    lines += ["", "## この戦闘（味方5＋敵6, HP満タン）の 1Tあたりの総行動数"]
    for m, eng in E.items():
        tot = sum(1 / eng.interval(u) for u in eng.state.units.values())
        lines.append(f"- {m}: {tot:.2f} 行動/T（旧方式は全員1回/T = 11.00）")
    txt = "\n".join(lines)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "freq.md").write_text(txt, encoding="utf-8")
    print(txt)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for f in font_manager.findSystemFonts():
        if "NotoSansCJK" in f.replace(" ", ""):
            font_manager.fontManager.addfont(f)
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "sans-serif"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4))
    sty = {"A": ("tab:red", "o-", "A 比例型 (指数1.0)"), "B": ("tab:blue", "s-", "B 緩和型 (指数0.5)"),
           "C": ("tab:green", "^-", "C 中間型 (指数0.75)")}
    xs = list(range(6, 16))
    for m, eng in E.items():
        c, mk, lab = sty[m]
        axes[0].plot(xs, [10 / eng.interval(fake(eng, s, 1)) for s in xs], mk, color=c, label=lab)
        axes[1].plot([100, 50, 30, 15], [10 / eng.interval(fake(eng, 9, h)) for h in (1, .5, .3, .15)], mk, color=c, label=f"{lab}・速度9")
        axes[1].plot([100, 50, 30, 15], [10 / eng.interval(fake(eng, 15, h)) for h in (1, .5, .3, .15)], mk, color=c, alpha=0.45,
                     label=f"{lab}・速度15")
    axes[0].axhline(10, color="gray", lw=0.8, ls="--")
    axes[0].set_xlabel("速度")
    axes[0].set_ylabel("10Tあたりの行動回数（HP満タン）")
    axes[0].set_title("速度と行動回数（基準速度10で10回）")
    axes[0].legend(fontsize=8)
    axes[0].grid(alpha=0.3)
    axes[1].set_xlabel("HP %")
    axes[1].invert_xaxis()
    axes[1].set_ylabel("10Tあたりの行動回数")
    axes[1].set_title("HP低下による行動回数（速度9と15）")
    axes[1].legend(fontsize=7)
    axes[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT / "freq.png", dpi=110)


if __name__ == "__main__":
    main()
