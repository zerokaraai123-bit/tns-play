"""時間軸診断の集計。 python -m tns.sim.v11_timeline_report [policy] > out/v11t/report_{policy}.md"""
from __future__ import annotations

import json
import random
import statistics as stt
import sys
from collections import Counter, defaultdict

from .v11_timeline import NAME, OUT

BINS = [(0, .2), (.2, .4), (.4, .6), (.6, .8), (.8, 1.0001)]
BN = ["0〜20%", "20〜40%", "40〜60%", "60〜80%", "80〜100%"]
INTEL = {"0": "低知能", "1": "通常", "2": "高知能", "3": "戦術級"}


def binof(p):
    for k, (a, b) in enumerate(BINS):
        if a <= p < b:
            return k
    return 4


def ep_at(r, p):
    """進行度 p 時点（その行動の直前）のセレスティアEP。"""
    lim = p * r["N"]
    ep = 100
    for idx, _, kind, d in r["events"]:
        if kind == "sample" and idx <= lim + 1e-9:
            ep = d["ep"]
        elif kind == "sample":
            break
    return ep if p < 1 else r["end_ep"]


def first_below(r, th):
    for idx, _, kind, d in r["events"]:
        if kind == "sample" and d["ep"] < th:
            return idx / r["N"], idx
    if r["end_ep"] < th:
        return 1.0, r["N"]
    return None


def mean(x):
    return sum(x) / len(x) if x else float("nan")


def ep_bucket(e):
    return "40以上（炎嵐が撃てる）" if e >= 40 else ("18〜39（治療・攻撃魔法が撃てる）" if e >= 18 else ("15〜17（攻撃魔法1発だけ）" if e >= 15 else "15未満（弾切れ）"))


def main(pol="v11"):
    R = [json.loads(l) for l in open(OUT / f"timeline_{pol}.jsonl", encoding="utf-8")]
    n = len(R)
    L = [f"# Ver0.11 時間軸診断（中心条件・{pol}・{n}戦）\n"]
    L.append(f"- 勝率 {mean([r['win'] for r in R])*100:.1f}%、1戦の総行動数 平均{mean([r['N'] for r in R]):.1f}（うち敵の行動 {mean([r['E'] for r in R]):.1f}）\n")
    # 5. EP推移
    L.append("## 1. セレスティアのEP推移（進行度＝その戦闘の総行動数に対する割合）\n")
    L.append("| 時点 | 0%（開始） | 20% | 40% | 60% | 80% | 100%（終了） |\n|---|---|---|---|---|---|---|")
    pts = [0, .2, .4, .6, .8, 1.0]
    vals = [[ep_at(r, p) for r in R] for p in pts]
    L.append("| 平均EP | " + " | ".join(f"{mean(v):.1f}" for v in vals) + " |")
    L.append("| 中央値 | " + " | ".join(f"{stt.median(v):.0f}" for v in vals) + " |")
    L.append("| EP15未満の戦闘の割合 | " + " | ".join(f"{sum(1 for x in v if x < 15)/n*100:.0f}%" for v in vals) + " |")
    L.append("\n**絶対時間（累積行動数）でのEP**（その時点でまだ続いている戦闘の平均）\n")
    L.append("| 行動数 | " + " | ".join(str(k) for k in (0, 10, 20, 30, 40, 50, 60, 80, 100)) + " |\n|---|" + "---|" * 9)
    row, cnt = [], []
    for k in (0, 10, 20, 30, 40, 50, 60, 80, 100):
        live = [r for r in R if r["N"] >= k]
        cnt.append(len(live))
        row.append(mean([ep_at(r, k / r["N"]) for r in live]) if live else float("nan"))
    L.append("| 平均EP | " + " | ".join(f"{v:.1f}" for v in row) + " |")
    L.append("| 継続中の戦闘数 | " + " | ".join(str(c) for c in cnt) + " |")
    L.append("\n**EPが初めて各値を下回る時点**\n")
    L.append("| しきい値 | 到達した戦闘 | 進行度（平均 / 中央値） | 累積行動数（平均） |\n|---|---|---|---|")
    for th in (80, 60, 40, 20, 15):
        x = [first_below(r, th) for r in R]
        x = [v for v in x if v]
        L.append(f"| EP{th}未満 | {len(x)/n*100:.0f}% | {mean([v[0] for v in x])*100:.0f}% / {stt.median([v[0] for v in x])*100:.0f}% | {mean([v[1] for v in x]):.1f} |")
    # 6. 消費の内訳
    L.append("\n## 2. EPは何によって、いつ減ったか（1戦あたりのEP）\n")
    L.append("| 区間 | 炎嵐 | 攻撃魔法 | 治療 | 自衛 | 合計 |\n|---|---|---|---|---|---|")
    S = defaultdict(lambda: Counter())
    for r in R:
        for idx, _, kind, d in r["events"]:
            if kind == "spend":
                S[binof(idx / r["N"])][d["cat"]] += d["ep"]
    tot = Counter()
    for k in range(5):
        c = S[k]
        tot.update(c)
        L.append(f"| {BN[k]} | " + " | ".join(f"{c[x]/n:.1f}" for x in ("炎嵐", "攻撃魔法", "治療", "自衛")) + f" | {sum(c.values())/n:.1f} |")
    L.append("| 合計 | " + " | ".join(f"{tot[x]/n:.1f}" for x in ("炎嵐", "攻撃魔法", "治療", "自衛")) + f" | {sum(tot.values())/n:.1f} |")
    # 10. 魔法のタイミング
    L.append("\n## 3. 魔法を撃った時点と、最初に狙われた時点\n")
    L.append("| 出来事 | 起きた戦闘 | 進行度（平均 / 中央値） | 累積行動数（平均） | そのときのEP（直前） |\n|---|---|---|---|---|")
    marks = defaultdict(list)
    for r in R:
        cnts = Counter()
        epnow = 100
        for idx, _, kind, d in r["events"]:
            if kind == "sample":
                epnow = d["ep"]
            if kind == "spend" and d["cat"] in ("炎嵐", "攻撃魔法", "治療"):
                cnts[d["cat"]] += 1
                key = {"炎嵐": ["1回目の炎嵐", "2回目の炎嵐", "3回目以降の炎嵐"], "攻撃魔法": ["1回目の攻撃魔法", "2回目以降の攻撃魔法", "2回目以降の攻撃魔法"],
                       "治療": ["治療", "治療", "治療"]}[d["cat"]][min(cnts[d["cat"]] - 1, 2)]
                marks[key].append((idx / r["N"], idx, epnow))
        tg = [(idx, d) for idx, _, kind, d in r["events"] if kind == "target"]
        if tg:
            marks["最初に狙われた"].append((tg[0][0] / r["N"], tg[0][0], tg[0][1]["cel_ep"]))
        for idx, d in tg[1:]:
            marks["2回目以降に狙われた"].append((idx / r["N"], idx, d["cel_ep"]))
    for key in ("1回目の炎嵐", "2回目の炎嵐", "3回目以降の炎嵐", "1回目の攻撃魔法", "2回目以降の攻撃魔法", "治療", "最初に狙われた", "2回目以降に狙われた"):
        v = marks[key]
        if not v:
            continue
        nb = len(v) if "2回目以降" in key or "3回目" in key else len(v)
        share = f"{len(v)/n*100:.0f}%" if not ("2回目以降" in key or "3回目" in key or key == "治療") else f"{len(v)/n:.2f}回/戦"
        L.append(f"| {key} | {share} | {mean([x[0] for x in v])*100:.0f}% / {stt.median([x[0] for x in v])*100:.0f}% | {mean([x[1] for x in v]):.1f} | {mean([x[2] for x in v]):.1f} |")
    # 7. 狙われた瞬間
    T = [(r, idx, d) for r in R for idx, _, kind, d in r["events"] if kind == "target"]
    L.append(f"\n## 4. 敵がセレスティアを狙った瞬間（全{len(T)}回、1戦あたり{len(T)/n:.2f}回。狙われなかった戦闘 {sum(1 for r in R if not any(e[2]=='target' for e in r['events']))/n*100:.0f}%）\n")
    L.append("| 区間 | 狙われた回数/戦 | セレスティアHP | セレスティアEP | 戦闘不能中 | 前衛HP（2人平均） | 前衛EP（2人平均） | 介入できた（窓あり） | 実際に介入 |\n|---|---|---|---|---|---|---|---|---|")
    for k in list(range(5)) + [None]:
        g = [x for x in T if k is None or binof(x[1] / x[0]["N"]) == k]
        if not g:
            continue
        fr = lambda key: mean([mean([f[key] for f in d["fronts"]]) for _, _, d in g])
        L.append(f"| {BN[k] if k is not None else '全体'} | {len(g)/n:.2f} | {mean([d['cel_hp'] for _, _, d in g]):.0f}/70 | {mean([d['cel_ep'] for _, _, d in g]):.1f} | "
                 f"{mean([d['cel_incap'] for _, _, d in g])*100:.0f}% | {fr('hp'):.0f} | {fr('ep'):.1f} | {mean([d['window'] for _, _, d in g])*100:.0f}% | "
                 f"{mean([1 if d['iv_by'] else 0 for _, _, d in g])*100:.0f}% |")
    # 非介入の理由
    why = Counter()
    for r, idx, d in T:
        if d["iv_by"]:
            continue
        if not d["reach_ok"]:
            why["攻撃が届かず不発"] += 1
        elif not d["window"]:
            st = [f["state"] for f in d["fronts"]]
            if all(s in ("死亡", "戦闘不能") for s in st):
                why["介入できない：前衛が2人とも倒れている"] += 1
            elif all(s in ("死亡", "戦闘不能", "持ち場を離れている") for s in st):
                why["介入できない：残る前衛は持ち場を離れている（介入中・復帰中）"] += 1
            else:
                why["介入できない：その他"] += 1
        else:
            why[f"介入できたがAIが見送り：{d['ai_reason']}"] += 1
    L.append("\n**介入しなかった理由**（狙われた回数に対する割合）\n")
    L.append("| 理由 | 回/戦 | 割合 |\n|---|---|---|")
    for k, v in why.most_common():
        L.append(f"| {k} | {v/n:.2f} | {v/len(T)*100:.0f}% |")
    sk = [d for _, _, d in T if d["window"] and not d["iv_by"]]
    if sk:
        L.append(f"\nAIが見送った場面のセレスティア: 平均EP {mean([d['cel_ep'] for d in sk]):.1f}、自衛の必要EP {mean([d['need'] for d in sk]):.1f}、"
                 f"HP {mean([d['cel_hp'] for d in sk]):.0f}/70、自分で払えた割合 {mean([1 if d['cel_ep'] >= d['need'] else 0 for d in sk])*100:.0f}%。"
                 f"前衛のEP（2人平均） {mean([mean([f['ep'] for f in d['fronts']]) for d in sk]):.1f}")
    # 8. 最初に狙われた瞬間
    F = []
    for r in R:
        tg = [(idx, d) for idx, _, kind, d in r["events"] if kind == "target"]
        if tg:
            F.append((r, tg[0][0], tg[0][1]))
    L.append(f"\n## 5. その戦闘で初めて狙われた瞬間（{len(F)}戦）\n")
    L.append(f"- 平均EP **{mean([d['cel_ep'] for _, _, d in F]):.1f}**（中央値 {stt.median([d['cel_ep'] for _, _, d in F]):.0f}）、"
             f"平均HP {mean([d['cel_hp'] for _, _, d in F]):.0f}/70、進行度 平均{mean([i / r['N'] for r, i, _ in F])*100:.0f}%（累積行動 {mean([i for _, i, _ in F]):.1f}）")
    L.append(f"- そのとき前衛が介入した割合 {mean([1 if d['iv_by'] else 0 for _, _, d in F])*100:.0f}%、介入できる前衛がいた割合 {mean([d['window'] for _, _, d in F])*100:.0f}%\n")
    L.append("| EP帯 | 0〜14 | 15〜17 | 18〜39 | 40〜59 | 60〜79 | 80〜100 |\n|---|---|---|---|---|---|---|")
    edges = [(0, 14), (15, 17), (18, 39), (40, 59), (60, 79), (80, 100)]
    L.append("| 割合 | " + " | ".join(f"{sum(1 for _, _, d in F if a <= d['cel_ep'] <= b)/len(F)*100:.0f}%" for a, b in edges) + " |")
    L.append("| そのうち介入された割合 | " + " | ".join(
        (lambda g: f"{mean([1 if d['iv_by'] else 0 for d in g])*100:.0f}%" if g else "–")([d for _, _, d in F if a <= d['cel_ep'] <= b]) for a, b in edges) + " |")
    # 9. 介入
    I = [(r, idx, d) for r, idx, d in T if d["iv_by"]]
    L.append(f"\n## 6. セレスティアを守る前衛の介入（全{len(I)}回、1戦あたり{len(I)/n:.2f}回）\n")
    fi = []
    for r in R:
        g = [(idx, d) for idx, _, kind, d in r["events"] if kind == "target" and d["iv_by"]]
        if g:
            fi.append(g[0][0] / r["N"])
    L.append(f"- 最初の介入: {len(fi)/n*100:.0f}%の戦闘で発生、進行度 平均{mean(fi)*100:.0f}%（中央値 {stt.median(fi)*100:.0f}%）")
    L.append(f"- 介入時のセレスティア: 平均EP **{mean([d['cel_ep'] for _, _, d in I]):.1f}**、平均HP {mean([d['cel_hp'] for _, _, d in I]):.0f}/70、戦闘不能中 {mean([d['cel_incap'] for _, _, d in I])*100:.0f}%")
    ivf = [next(f for f in d["fronts"] if f["id"] == d["iv_by"]) for _, _, d in I]
    L.append(f"- 介入した前衛: 平均HP {mean([f['hp']/f['hpmax'] for f in ivf])*100:.0f}%、平均EP {mean([f['ep'] for f in ivf]):.1f}（EP0 {mean([1 if f['ep']==0 else 0 for f in ivf])*100:.0f}%）")
    L.append(f"- 1回あたり: セレスティアが自分で防ぐ必要EP {mean([d['need'] for _, _, d in I]):.1f}、前衛が実際に使ったEP {mean([d['front_spent'] for _, _, d in I]):.1f}\n")
    L.append("| 区間 | 介入/戦 |\n|---|---|")
    for k in range(5):
        L.append(f"| {BN[k]} | {sum(1 for r, i, d in I if binof(i / r['N']) == k)/n:.2f} |")
    L.append("\n| 介入時のセレスティアEP | 割合 |\n|---|---|")
    bc = Counter(ep_bucket(d["cel_ep"]) for _, _, d in I)
    for k in ("40以上（炎嵐が撃てる）", "18〜39（治療・攻撃魔法が撃てる）", "15〜17（攻撃魔法1発だけ）", "15未満（弾切れ）"):
        L.append(f"| {k} | {bc[k]/len(I)*100:.0f}% |")
    L.append(f"\n（累積: 40以上 {sum(1 for _,_,d in I if d['cel_ep']>=40)/len(I)*100:.0f}%／18以上 {sum(1 for _,_,d in I if d['cel_ep']>=18)/len(I)*100:.0f}%／15以上 {sum(1 for _,_,d in I if d['cel_ep']>=15)/len(I)*100:.0f}%／15未満 {sum(1 for _,_,d in I if d['cel_ep']<15)/len(I)*100:.0f}%）")
    # 11. 知能別
    L.append("\n## 7. 敵知能別（敵の知能は戦闘開始時の設定。リーダー撃破で下がる場合あり）\n")
    L.append("| 敵知能 | 勝率 | 狙われた回数/戦 | 狙われなかった戦闘 | 最初に狙われた進行度（平均/中央値） | 最初に狙われたときのEP | 狙われた全体の平均EP | 介入された割合 | 介入/戦 |\n|---|---|---|---|---|---|---|---|---|")
    for i in "0123":
        Ri = [r for r in R if str(r["intel"]) == i]
        Ti = [d for r in Ri for _, _, k, d in r["events"] if k == "target"]
        Fi = [(r, x) for r, x0, x in F if str(r["intel"]) == i for _ in [0]]
        Fi = [(r, idx, d) for r, idx, d in F if str(r["intel"]) == i]
        L.append(f"| {INTEL[i]} | {mean([r['win'] for r in Ri])*100:.0f}% | {len(Ti)/len(Ri):.2f} | {sum(1 for r in Ri if not any(e[2]=='target' for e in r['events']))/len(Ri)*100:.0f}% | "
                 f"{mean([x / r['N'] for r, x, _ in Fi])*100:.0f}% / {stt.median([x / r['N'] for r, x, _ in Fi])*100:.0f}% | {mean([d['cel_ep'] for _, _, d in Fi]):.1f} | "
                 f"{mean([d['cel_ep'] for d in Ti]):.1f} | {mean([1 if d['iv_by'] else 0 for d in Ti])*100:.0f}% | {sum(1 for d in Ti if d['iv_by'])/len(Ri):.2f} |")
    L.append("\n| 敵知能 | 狙われた回数/戦（0〜20%） | 20〜40% | 40〜60% | 60〜80% | 80〜100% |\n|---|---|---|---|---|---|")
    for i in "0123":
        Ri = [r for r in R if str(r["intel"]) == i]
        L.append(f"| {INTEL[i]} | " + " | ".join(f"{sum(1 for r in Ri for idx, _, k, d in r['events'] if k == 'target' and binof(idx / r['N']) == b)/len(Ri):.2f}" for b in range(5)) + " |")
    print("\n".join(L))
    examples(R)


def render(r, title, upto=None):
    ep = 100
    L = [f"### {title}｜seed={r['seed']}・敵知能={INTEL[str(r['intel'])]}・{'勝ち' if r['win'] else '負け'}・総行動{r['N']}・終了時EP {r['end_ep']}",
         "```", f"行動  0 ( 0%) 開始 セレスティア EP100"]
    order = {"target": 0, "cel_ko": 1}
    evs = sorted(r["events"], key=lambda e: (e[0], order.get(e[2], 0)))   # 同じ行動内では「狙われた→倒れた」の順
    for idx, ea, kind, d in evs:
        if upto and idx > upto:
            break
        pct = f"{idx:3d} ({idx / r['N'] * 100:3.0f}%)"
        if kind == "spend" and d["cat"] != "自衛":
            L.append(f"行動{pct} セレスティア {d['cat']}  EP{ep}→{ep - d['ep']}")
            ep -= d["ep"]
        elif kind == "target":
            fr = "・".join(f"{NAME[f['id']]}HP{f['hp']}/EP{f['ep']}{'' if f['state']=='介入可能' else '（' + f['state'] + '）'}" for f in d["fronts"])
            if d["iv_by"]:
                res = f"→ {NAME[d['iv_by']]}が介入（前衛EP{d['front_spent']}消費・生身{d['front_dmg']}）"
            elif not d["window"]:
                res = f"→ 介入できる前衛なし。本人が受ける（自衛EP{d['cel_spent']}・生身{d['cel_dmg']}）"
            else:
                res = f"→ 前衛は見送り（{d['ai_reason']}）。本人が受ける（自衛EP{d['cel_spent']}・生身{d['cel_dmg']}）"
            L.append(f"行動{pct} 敵 {NAME[d['attacker']]}がセレスティアを狙う（威力{d['raw']:.0f}・自衛の必要EP{d['need']}）"
                     f" セレスティアHP{d['cel_hp']}/EP{d['cel_ep']}{'・戦闘不能中' if d['cel_incap'] else ''}｜{fr}")
            L.append(f"             {res}")
            ep -= d["cel_spent"]
        elif kind == "cel_ko":
            L.append(f"行動{pct} セレスティアが{'戦闘不能' if d['incap'] else '死亡'}（EP{d['ep']}）")
        elif kind == "cel_revive":
            L.append(f"行動{pct} セレスティアが治療で戦闘復帰")
    L.append("```")
    return "\n".join(L)


def examples(R):
    rnd = random.Random(7)
    def first_t(r):
        return next((d for _, _, k, d in r["events"] if k == "target"), None)
    A = [r for r in R if (lambda d: d and d["cel_ep"] >= 40 and d["iv_by"])(first_t(r))]
    B = [r for r in R if (lambda d: d and d["cel_ep"] < 15)(first_t(r))]
    C1 = [r for r in R if any(k == "target" and d["window"] and not d["iv_by"] and d["cel_ep"] >= 15 for _, _, k, d in r["events"])]
    C2 = [r for r in R if any(k == "target" and not d["window"] and d["reach_ok"] and any(f["state"] == "持ち場を離れている" for f in d["fronts"]) for _, _, k, d in r["events"])]
    D = []
    for r in R:
        ev = r["events"]
        for j, (idx, _, k, d) in enumerate(ev):
            if k == "target" and d["iv_by"] and d["cel_ep"] >= 15 and d["cel_ep"] - d["need"] < 15:
                nxt = next(((kk, dd) for _, _, kk, dd in ev[j + 1:] if kk in ("spend", "target")), None)
                if nxt and nxt[0] == "spend" and nxt[1]["cat"] in ("炎嵐", "攻撃魔法"):
                    D.append(r)
                    break
    print("\n## 8. 代表的な戦闘ログ（時系列。行動＝累積行動数、括弧＝進行度）\n")
    print(f"- 候補数: A 高EPのうちに狙われ前衛が守った {len(A)}戦／B EPを使い切った後に初めて狙われた {len(B)}戦／"
          f"C 介入できたのに見送った（EP15以上） {len(C1)}戦・前衛が離れていて介入できなかった {len(C2)}戦／"
          f"D 介入がなければ自衛で魔法が撃てなくなっていたはずの直後に魔法を撃った {len(D)}戦\n")
    for lab, pool, k in (("A｜高EPのうちに狙われ、前衛が守った", A, 2), ("B｜EPを使い切った後に初めて狙われた", B, 2),
                         ("C｜前衛が介入しなかった（AIの見送り）", C1, 1), ("C｜前衛が介入できなかった（持ち場を離れていた）", C2, 1),
                         ("D｜介入のおかげで、次に攻撃魔法・炎嵐が撃てたように見える", D, 2)):
        for r in rnd.sample(pool, min(k, len(pool))):
            print(render(r, lab) + "\n")


if __name__ == "__main__":
    main(*sys.argv[1:])
