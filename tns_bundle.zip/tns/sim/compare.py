"""複数の実験(summary.csv)を並べて比較する。 python cli.py compare --summaries A.csv B.csv --labels v02 v03"""
from __future__ import annotations

import csv

from ..model.enums import INTEL_NAMES

DEFAULT_METRICS = [
    ("win_rate", "勝率"), ("avg_rounds", "巡数"), ("avg_ally_hp_ratio", "味方HP残"),
    ("avg_rear_dead_ally", "後衛死(人)"), ("avg_front_dead_ally", "前衛死(人)"),
    ("enemy_front_attack_rate", "敵のFRONT狙い率"), ("enemy_switch_rate", "敵の標的変更率"),
    ("enemy_avg_streak", "敵の同一標的連続"), ("first_ko_ally_avg_attacks", "味方初撃破までの敵攻撃数"),
    ("avg_intervention_ally", "味方介入"), ("avg_front_open_by_intervention_ally", "介入でFRONT OPEN"),
    ("avg_intrusion_ally", "OPEN経路利用"), ("avg_intrusion_hit_ally", "侵入命中"),
    ("avg_intrusion_damage_ally", "侵入ダメージ"), ("avg_prevented_ally", "介入で防いだ"),
    ("avg_breach_damage_ally", "穴被害"),
]


def load(path):
    with open(path, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def compare(paths, labels, policies=("always", "never", "situational"), metrics=DEFAULT_METRICS) -> str:
    data = [{(r["enemy_intel"], r["policy"]): r for r in load(p)} for p in paths]
    intels = sorted({k[0] for d in data for k in d}, key=lambda x: (x == "", x))
    L = []
    for intel in intels:
        name = "設定値" if intel == "" else f"{intel}:{INTEL_NAMES[int(intel)]}"
        L.append(f"\n### 敵知能 {name}\n")
        L.append("| 指標 | 方針 | " + " | ".join(labels) + " |")
        L.append("|---|---|" + "---|" * len(labels))
        for key, ja in metrics:
            for p in policies:
                vals = []
                for d in data:
                    r = d.get((intel, p))
                    v = r.get(key, "") if r else ""
                    try:
                        v = f"{float(v):.1%}" if key.endswith("rate") and key != "enemy_switch_rate" or key == "win_rate" else f"{float(v):.2f}"
                    except (TypeError, ValueError):
                        v = v or "-"
                    vals.append(v)
                L.append(f"| {ja} | {p} | " + " | ".join(vals) + " |")
    return "\n".join(L)
