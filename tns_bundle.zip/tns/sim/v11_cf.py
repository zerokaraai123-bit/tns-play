"""Ver0.11 反実仮想: 同じ局面から「介入する」「介入しない」を両方走らせて結果を比べる。
方法: シードが決まれば戦闘は完全に再現される。REARを狙う k 番目の介入判断だけを固定して2回再生する
（k より前はまったく同じ戦闘）。k 以降は両方とも同じ方針（既定 v11）が判断する。乱数はその後で分岐しうるので、
差は「その局面から先の結果の分布」の差として、多数の局面で平均する。
python -m tns.sim.v11_cf [cond] [policy] [n]
"""
from __future__ import annotations

import csv
import os
import random
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..model.enums import Side
from .csv_export import write_csv
from .v11 import OUT, build


def outcome(eng):
    al = [u for u in eng.state.units.values() if u.side is Side.ALLY]
    return {"win": int(eng.stats.winner == "ally"),
            "out_F": sum(1 for u in al if u.rank.value == "FRONT" and not u.alive),
            "out_R": sum(1 for u in al if u.rank.value == "REAR" and not u.alive),
            "dead": sum(1 for u in al if u.hp <= 0)}


def _pair(job):
    cond, pol, seed, intel, k, rec = job
    res = {}
    for want in ("iv", "self"):
        eng, ally = build(cond, pol, seed, intel, force=(k, want))
        eng.run()
        res[want] = outcome(eng)
    row = dict(seed=seed, enemy_intel=intel, k=k, choice=rec["choice"], f_ep=rec["f_ep"], f_hp=rec["f_hp"],
               t=rec["target"], L_self=rec["L_self"], L_iv=rec["L_iv"], round=rec["round"])
    for w in ("iv", "self"):
        for kk, v in res[w].items():
            row[f"{w}_{kk}"] = v
    return row


def run(cond="q058_f85_incap4", pol="v11", n=1000, seed0=11):
    p = OUT / f"{cond}_{pol}_ivdecisions.csv"
    R = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    by = {}
    for r in R:
        by.setdefault((int(r["seed"]), int(r["enemy_intel"])), []).append(r)
    rng = random.Random(seed0)
    keys = sorted(by)
    rng.shuffle(keys)
    jobs = []
    for key in keys[:n]:
        lst = by[key]
        k = rng.randrange(len(lst))
        r = lst[k]
        r = {**r, "f_ep": int(float(r["f_ep"])), "f_hp": float(r["f_hp"]), "L_self": float(r["L_self"]),
             "L_iv": float(r["L_iv"])}
        jobs.append((cond, pol, key[0], key[1], k, r))
    with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
        rows = list(ex.map(_pair, jobs, chunksize=10))
    write_csv(OUT / f"cf_{cond}_{pol}.csv", rows)
    print("done", len(rows))


if __name__ == "__main__":
    a = sys.argv[1:]
    run(*(a[:2]), *(int(x) for x in a[2:3]))
