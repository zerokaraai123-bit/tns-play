"""Ver0.10: 介入後の「穴」の見積もりだけを改善した価値AIの検証。

ルールは Ver0.9 と同じ（変えたのは価値AIの介入判断の中の「離脱後の危険の見積もり」だけ）。
方針: v9（Ver0.9の価値AI）/ v10（離脱後の危険を敵の行動ごとに見積もる価値AI）/ never / always。各1,000戦・同一シード。
介入1件ごとに「予測した追加被害」と「実際に起きたこと（その前衛が戻るまで）」を突き合わせる。

使い方: python -m tns.sim.v10
"""
from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..model.enums import Side
from .csv_export import write_csv
from .v08 import summarize_records
from .v09 import V09Tracer, rules_of, seeds

OUT = Path("out/v10")
CONDS = ["q058_f85", "q058_f70", "q058_fP2", "q058_f100", "q058_f50", "q075_f85"]
POLICIES = {"v9": (None, "v9"), "v10": (None, "v10"), "never": ("never_iv", "v9"), "always": ("always_iv", "v9")}
PRED_KEYS = ("pred_extra_rear_hits", "pred_rear_hp", "pred_rear_ep", "pred_front_hits", "pred_front_dmg")


def build(cond, policy, seed, intel, log=False):
    cfg = load_battle_config(party="party_v08", rules=rules_of(cond), ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    probe, hm = POLICIES[policy]
    ally = ValueAllyController(cfg.ally_policies, probe=probe, hole_model=hm)
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)},
                       seed=seed, enemy_intel=intel, log_enabled=log)
    return eng, ally


class V10Tracer(V09Tracer):
    """介入ごとに、前衛が持ち場に戻るまでの「実際の結果」を記録して予測と並べる。"""

    def __init__(self, eng, ally):
        super().__init__(eng)
        self.ally = ally
        self.win = {}            # 介入した前衛 -> 進行中の観察
        self.closed = []
        self.pending_intr = None

    def __call__(self, ev, eng):
        t = ev["t"]
        c = self.c
        if t == "intervened":
            f, tg = eng.u(ev["unit"]), eng.u(ev["target"])
            if f.side is Side.ALLY and tg.rank.value == "REAR":
                rec = next((r for r in reversed(self.ally.records) if r["kind"] == "iv"), {})
                atk = eng.u(ev["attacker"])
                raw = eng.damage.expected(atk, self._first_attack(atk))
                need = eng.defense.required_ep(tg, raw)
                spend = min(tg.ep, math.ceil(need - 1e-9)) if eng.defense_allowed(tg) else 0
                blocked = spend / max(eng.defense.required_ep(tg, 1.0), 1e-9)
                c["iv_prevented_hp"] += max(0.0, raw - blocked) * eng.body_mult
                self.win[f.id] = {"f": f.id, **{k: rec.get(k, 0) or 0 for k in PRED_KEYS},
                                  "real_intr": 0, "real_intr_hp": 0, "real_intr_ep": 0,
                                  "real_front_hits": 0, "real_front_dmg": 0, "real_rear_hits": 0,
                                  "real_rear_hp": 0, "real_rear_ep": 0, "first": True}
        elif t == "intrusion":
            tg = eng.u(ev["target"])
            w = self.win.get(ev.get("caused_by"))
            if tg.side is Side.ALLY and w is not None:
                w["real_intr"] += 1
                self.pending_intr = w
        elif t == "damage":
            u = eng.u(ev["unit"])
            if u.side is Side.ALLY:
                if self.pending_intr is not None:
                    self.pending_intr["real_intr_hp"] += ev["dmg"]
                    self.pending_intr["real_intr_ep"] += ev.get("ep_spent", 0) or 0
                    self.pending_intr = None
                w = self.win.get(u.id)
                if w is not None:
                    if w["first"]:
                        w["first"] = False          # 介入して受けた一撃そのもの
                        c["iv_front_hit_dmg"] += ev["dmg"]
                    elif eng.u(ev["attacker"]).side is Side.ENEMY:
                        w["real_front_hits"] += 1
                        w["real_front_dmg"] += ev["dmg"]
                if u.rank.value == "REAR" and eng.u(ev["attacker"]).side is Side.ENEMY:
                    for w in self.win.values():
                        w["real_rear_hits"] += 1
                        w["real_rear_hp"] += ev["dmg"]
                        w["real_rear_ep"] += ev.get("ep_spent", 0) or 0
        elif t == "stance":
            if ev["unit"] in self.win and ev["new"] == "READY":
                self.closed.append(self.win.pop(ev["unit"]))
        elif t == "ko":
            if ev["unit"] in self.win:
                self.closed.append(self.win.pop(ev["unit"]))
        elif t == "battle_end":
            self.closed += list(self.win.values())
            self.win = {}
        super().__call__(ev, eng)


def _one(job):
    cond, policy, seed, intel = job
    eng, ally = build(cond, policy, seed, intel)
    tr = V10Tracer(eng, ally)
    eng.listeners.append(tr)
    eng.run()
    row = {"cond": cond, "policy": policy, "seed": seed, "enemy_intel": intel, "winner": eng.stats.winner,
           "rounds": eng.stats.rounds}
    row.update(tr.c)
    row.update(summarize_records(ally.records, tr))
    ivs = [r for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR"]
    row["ivrec_n"] = len(ivs)
    row["ivrec_protect"] = sum(1 for r in ivs if r["choice"] != "self")
    row["win_n"] = len(tr.closed)
    for k in PRED_KEYS + ("real_intr", "real_intr_hp", "real_intr_ep", "real_front_hits", "real_front_dmg",
                          "real_rear_hits", "real_rear_hp", "real_rear_ep"):
        row["sum_" + k] = sum(w[k] for w in tr.closed)
    ivrows = [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k != "text"}
              | {"cond": cond, "policy": policy, "seed": seed, "enemy_intel": intel}
              for r in ivs] if policy in ("v9", "v10") else []
    return row, ivrows


def run(workers=None):
    OUT.mkdir(parents=True, exist_ok=True)
    workers = workers or max(1, os.cpu_count() or 2)
    for cond in CONDS:
        S = seeds(cond)
        for pol in POLICIES:
            tag = f"{cond}_{pol}"
            if (OUT / f"{tag}_battles.csv").exists():
                print("skip", tag, flush=True)
                continue
            B, IV = [], []
            with ProcessPoolExecutor(workers) as ex:
                for b, iv in ex.map(_one, [(cond, pol, s, i) for s, i in S], chunksize=20):
                    B.append(b)
                    IV += iv
            keys = sorted({k for b in B for k in b})
            write_csv(OUT / f"{tag}_battles.csv", [{k: b.get(k, 0) for k in keys} for b in B])
            if IV:
                keys = sorted({k for r in IV for k in r})
                write_csv(OUT / f"{tag}_ivdecisions.csv", [{k: r.get(k, "") for k in keys} for r in IV])
            print("done", tag, flush=True)


if __name__ == "__main__":
    run()
