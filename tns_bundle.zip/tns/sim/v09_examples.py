"""Ver0.9 分岐点付近の判断ログ（価値AIの判断記録から、人が読める文章にする）。
python -m tns.sim.v09_examples > out/v09_boundary_logs.md"""
from __future__ import annotations

import csv
import random
from pathlib import Path

OUT = Path("out/v09")
NAME = {"adel": "アデル", "vanguard": "前衛2", "celestia": "セレスティア", "archer": "弓手", "toolsmith": "エーテル学者",
        "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "leader": "狼リーダー", "thrower": "投擲兵"}
ACT = {"storm": "炎嵐（40EP）", "fire": "攻撃魔法（15EP）", "heal": "治療（18EP）", "wait": "待機", "arrow": "射撃", "": "-"}
PARTJ = {"EPの痛み": "前衛がEPを使う痛み", "自分の生身": "前衛が防ぎきれず生身で受ける分", "自衛不能": "次の手番まで自衛できない危険",
         "穴": "持ち場が空いて後ろが突かれる危険", "漏れ": "障壁から漏れる分"}


def f(x):
    return float(x)


def explain(r):
    t, fr = NAME.get(r["target"], r["target"]), NAME.get(r["f"], r["f"])
    prot = r["choice"] != "self"
    diff = f(r["L_self"]) - f(r["L_iv"])
    parts = r["parts"]
    for k, v in PARTJ.items():
        parts = parts.replace(k, v)
    lines = [
        f"- 攻撃: {NAME.get(r['attacker'], r['attacker'])} → {t}（期待威力 {r['raw']}）",
        f"- {fr}: HP {r['f_hpabs']}/{r['f_hpmax']}・実効肉体強度 {r['f_S']}・この一撃を防ぐ必要EP {r['f_need']}・残EP {r['f_ep']}",
        f"- {t}: HP {r['t_hp']}/{r['t_hpmax']}・実効肉体強度 {r['t_S']}・この一撃を防ぐ必要EP {r['t_need']}・残EP {r['t_ep']}",
        f"- {t}が温存EPでできること: 次の手番の最善手は「{ACT.get(r['t_next'], r['t_next'])}」"
        + (f"。自衛すると「{ACT.get(r['t_next_after'], r['t_next_after'])}」に落ちる" if r["t_next_after"] and r["t_next_after"] != r["t_next"] else "。自衛しても変わらない"),
        f"- {t}が自分で対応した場合の損失: {f(r['L_self']):.2f}（EPで防ぐ痛み {f(r['pain_t']):.2f}／生身で受けた場合 {f(r['self_body']):.2f}"
        + ("。EPを使うより生身で受ける方が安いと見ている）" if abs(f(r['L_self']) - f(r['self_body'])) < 1e-3 and f(r['pain_t']) > 0 else "）"),
        f"- {fr}が介入した場合の損失: {f(r['L_iv']):.2f}（内訳: {parts}）",
        f"- **AIの選択: {'★ ' + fr + 'が介入して受ける' if prot else '☆ ' + t + '自身に防御させる'}**",
        "- 理由: " + (f"{t}が自分で受けると {f(r['L_self']):.2f} の損、{fr}が出れば {f(r['L_iv']):.2f} で済む（差 {diff:+.2f}）。"
                     + ("自衛すると次の魔法が撃てなくなるため、その選択肢を守る価値が大きい。" if r["lost_option"] else "")
                     if prot else
                     f"{fr}が出ると {f(r['L_iv']):.2f} の損（自衛不能の時間や穴の危険を含む）で、{t}の自衛 {f(r['L_self']):.2f} より高い（差 {diff:+.2f}）。"
                     + ("ただし" + t + "は魔法のEPを守るため、この一撃を生身で受ける判断。" if abs(f(r['L_self']) - f(r['self_body'])) < 1e-3 and f(r['pain_t']) > 0 else "")),
    ]
    return "\n".join(lines)


def pick(cond, k=3, seed=7):
    p = OUT / f"{cond}_value_ivdecisions.csv"
    R = [r for r in csv.DictReader(open(p, encoding="utf-8-sig")) if r["target"] == "celestia"]
    close = [r for r in R if abs(f(r["L_self"]) - f(r["L_iv"])) < 0.15 and f(r["t_ep"]) > 0]
    rnd = random.Random(seed)
    pro = [r for r in close if r["choice"] != "self"]
    slf = [r for r in close if r["choice"] == "self"]
    return rnd.sample(pro, min(k, len(pro))), rnd.sample(slf, min(k, len(slf))), len(R), len(close)


def main():
    out = ["# Ver0.9 分岐点付近の判断ログ（価値AIの判断記録。セレスティアが狙われ、自衛と介入の損失差が0.15未満の「僅差」の場面から抽出）\n",
           "損失の単位は「戦力点」（味方の損失＝重要度×失うHP割合＋倒れるなら1.2×重要度。セレスティアの重要度は1.5）。",
           "実効肉体強度 S＝現在HP×(現在HP/最大HP)^α。必要EP＝威力×0.5×(100/S)^q を切り上げ。\n"]
    for cond, title in (("q058_f70", "B領域: q=0.585（防御効率比2倍）・f(0.5)=0.70"),
                        ("q058_fP2", "B領域: 現行P2相当（q=0.585・f(0.5)≒0.61）"),
                        ("q058_f50", "A領域との境目: q=0.585・f(0.5)=0.50"),
                        ("q10_f70", "A領域: q=1.0（防御効率比3.3倍）・f(0.5)=0.70")):
        pro, slf, nall, nclose = pick(cond)
        out.append(f"\n## {title}\n（セレスティア狙いの判断 {nall}件、うち僅差 {nclose}件）\n")
        for i, (a, b) in enumerate(zip(pro, slf), 1):
            out.append(f"### 例{i}-介入した（seed={a['seed']}・敵知能={a['enemy_intel']}・{a['round']}巡）\n{explain(a)}\n")
            out.append(f"### 例{i}-介入しなかった（seed={b['seed']}・敵知能={b['enemy_intel']}・{b['round']}巡）\n{explain(b)}\n")
    print("\n".join(out))


if __name__ == "__main__":
    main()
