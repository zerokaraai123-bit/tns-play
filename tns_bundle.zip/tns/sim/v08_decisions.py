"""Ver0.8: 同じ「REARが狙われた」場面で、状況によって判断がどう変わったか（判断記録から）。
python -m tns.sim.v08_decisions > out/v08_decisions.md"""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path("out/v08")
MJ = {"M1": "M1 機会費用AI", "M2": "M2 エーテル呼吸", "M3": "M3 二層エーテル", "M4": "M4 庇護の構え", "M5": "M5 遠隔障壁"}


def eb(x):
    x = float(x)
    return "0" if x <= 0 else "1-17" if x < 18 else "18-39" if x < 40 else "40+"


def fb(x):
    x = float(x)
    return "0-9" if x < 10 else "10-24" if x < 25 else "25+"


def main(level="D15"):
    L = [f"## 判断の変化（{level}・各1,000戦の判断記録。REARが狙われ、介入可能な前衛がいた場面だけ）",
         "数値は「前衛が守った割合（介入＋障壁）」。行＝狙われたREARのEP、列＝出られる前衛のうち最も安い前衛のEP。括弧内は件数。"]
    for m, mj in MJ.items():
        p = OUT / f"main_{level}_{m}_ivdecisions.csv"
        if not p.exists():
            continue
        R = [r for r in csv.DictReader(open(p, encoding="utf-8-sig")) if r["trank"] == "REAR"]
        g = defaultdict(Counter)
        for r in R:
            g[(eb(r["t_ep"]), fb(r["f_ep"]))]["n"] += 1
            if r["choice"] != "self":
                g[(eb(r["t_ep"]), fb(r["f_ep"]))]["p"] += 1
        L.append(f"\n### {mj}（REAR狙い {len(R)}件、守った {sum(1 for r in R if r['choice'] != 'self')}件）")
        L.append("| REARのEP＼前衛のEP | 0-9 | 10-24 | 25+ |")
        L.append("|---|---|---|---|")
        for e in ("0", "1-17", "18-39", "40+"):
            cells = []
            for f in ("0-9", "10-24", "25+"):
                c = g[(e, f)]
                cells.append(f"{c['p'] / c['n']:.0%}（{c['n']}）" if c["n"] else "-")
            L.append(f"| {e} | " + " | ".join(cells) + " |")
        hp = defaultdict(Counter)
        for r in R:
            k = "前衛HP>60%" if float(r["f_hp"]) > 0.6 else "前衛HP30-60%" if float(r["f_hp"]) > 0.3 else "前衛HP≤30%"
            hp[k]["n"] += 1
            hp[k]["p"] += r["choice"] != "self"
        L.append("前衛のHP別の守った割合: " + "、".join(f"{k} {v['p'] / v['n']:.0%}（{v['n']}）" for k, v in hp.items() if v["n"]))
        thr = [r for r in R if r["threshold"] == "1"]
        L.append(f"自衛すると次の手番の最善手が落ちる場面（{len(thr)}件）で守った割合: "
                 f"{sum(1 for r in thr if r['choice'] != 'self') / max(1, len(thr)):.0%}。落ちない場面: "
                 f"{sum(1 for r in R if r['threshold'] != '1' and r['choice'] != 'self') / max(1, len(R) - len(thr)):.0%}")
        lo = Counter(r["lost_option"] for r in thr)
        L.append("落ちる選択肢の内訳（自衛した場合: 最善手→次善手）: " + "、".join(f"{k} {v}" for k, v in lo.most_common(6)))
    print("\n".join(L))


if __name__ == "__main__":
    main()
