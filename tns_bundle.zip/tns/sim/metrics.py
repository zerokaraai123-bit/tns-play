"""集計: 1戦闘1行のデータ化と、条件ごとのまとめ。"""
from __future__ import annotations

import math
from collections import defaultdict

PHASE_KEYS = ["decisions", "target_rear", "via_open_route", "via_intervention_hole", "plan_bait", "intervene_windows", "intervened"]
COUNTER_KEYS = [
    "intervention_ally", "intervention_enemy", "hp_hit_ally", "hp_hit_enemy",
    "unshielded_hit_ally", "unshielded_hit_enemy", "defense_ally", "defense_enemy",
    "heal_ally", "ep_supply_ally", "ep_exhaust_ally", "ep_exhaust_enemy",
    "front_open_ally", "front_open_enemy", "front_open_by_intervention_ally", "front_open_by_intervention_enemy",
    "front_open_by_ko_ally", "front_open_by_ko_enemy", "intrusion_ally", "intrusion_enemy", "ko_ally", "ko_enemy",
    # Ver0.3
    "attacks_enemy", "attacks_enemy_on_front", "attacks_enemy_on_rear", "target_switch_enemy", "team_switch_enemy",
    "attacks_ally", "intrusion_hit_ally", "intrusion_damage_ally", "intrusion_hit_enemy", "intrusion_damage_enemy",
    "dmg_taken_ally_front", "dmg_taken_ally_rear",
    "focus_acquire", "focus_keep", "focus_switch_better", "focus_release_dead", "focus_release_unreachable",
    "focus_release_hopeless", "focus_shared_unreachable",
    # Ver0.4
    "partial_pierce_ally", "partial_pierce_enemy", "full_block_ally", "full_block_enemy",
    "iv_prevented_hp_hit_ally", "iv_prevented_collapse_ally", "iv_prevented_ko_ally",
    "iv_prevented_hp_hit_enemy", "iv_prevented_collapse_enemy", "iv_prevented_ko_enemy",
    "breach_hp_hit_ally", "breach_first_hp_hit_ally", "breach_hp_hit_enemy", "breach_first_hp_hit_enemy",
    "attacks_enemy_on_wounded", "attacks_enemy_on_weakest", "attacks_ally_on_wounded", "attacks_ally_on_weakest",
]


def battle_row(stats, encounter: str, units: list) -> dict:
    """units: [(id, side, rank), ...]"""
    c = stats.c
    row = {
        "encounter": encounter, "seed": stats.seed, "policy": stats.ally_policy,
        "enemy_intel": "" if stats.enemy_intel is None else stats.enemy_intel,
        "winner": stats.winner, "win": int(stats.winner == "ally"), "rounds": stats.rounds,
        "ally_hp_ratio": round(stats.final["ally_hp_ratio"], 4),
        "enemy_hp_ratio": round(stats.final["enemy_hp_ratio"], 4),
        "ally_ep_ratio": round(stats.final["ally_ep_ratio"], 4),
        "enemy_ep_ratio": round(stats.final["enemy_ep_ratio"], 4),
        "ally_alive": stats.final["ally_alive"],
    }
    for k in COUNTER_KEYS:
        row[k] = c.get(k, 0)
    for side in ("ally", "enemy"):
        recs = [r for r in stats.interventions if r.side == side]
        row[f"prevented_{side}"] = round(sum(r.prevented_damage for r in recs), 1)
        row[f"interceptor_taken_{side}"] = sum(r.interceptor_damage_taken for r in recs)
        row[f"breach_damage_{side}"] = sum(r.breach_damage for r in recs)
        row[f"breach_attempts_{side}"] = sum(r.breach_attempts for r in recs)
        row[f"breach_kos_{side}"] = sum(r.breach_kos for r in recs)
        row[f"net_value_{side}"] = round(sum(r.net_value for r in recs), 1)
    row["plans"] = len(stats.plans)
    row["plans_success"] = sum(1 for p in stats.plans if p["success"])
    row["leader_down_round"] = stats.leader_down_round if stats.leader_down_round is not None else ""
    for ph in ("pre", "post"):
        for k in PHASE_KEYS:
            row[f"ai_{ph}_{k}"] = stats.ai_phase[ph].get(k, 0)
    for side in ("ally", "enemy"):
        st = stats.streaks[side]
        row[f"streak_sum_{side}"], row[f"streak_count_{side}"] = sum(st), len(st)
        row[f"streak_max_{side}"] = max(st) if st else 0
        ts = stats.team_streaks[side]
        row[f"team_streak_sum_{side}"], row[f"team_streak_count_{side}"] = sum(ts), len(ts)
    for side, other in (("ally", "enemy"), ("enemy", "ally")):
        fk = stats.first_ko.get(side)
        row[f"first_ko_{side}_round"] = fk["round"] if fk else ""
        row[f"first_ko_{side}_attacks"] = fk["attacks"] if fk else ""   # 相手陣営が要した攻撃回数
    row["actions"] = stats.final.get("actions", "")
    for k, v in c.items():
        if k.startswith(("def_n_", "def_ep_", "def_raw_", "def_need_", "v5_")):
            row[k] = round(v, 1)
    row["front_dead_ally"] = row["rear_dead_ally"] = 0
    for uid, side, rank in units:
        row[f"targeted_{uid}"] = stats.targeted.get(uid, 0)
        row[f"hp_end_{uid}"] = stats.final["unit_hp"].get(uid, 0)
        dead = uid in stats.ko_round
        row[f"dead_{uid}"] = int(dead)
        row[f"survive_rounds_{uid}"] = stats.ko_round[uid] if dead else stats.rounds   # 生存した場合は戦闘巡数（打ち切り）
        tr = stats.track.get(uid)
        if tr:
            for k in ("first_hp", "first_hp_round", "half", "ep_out", "ep_out_round", "death"):
                row[f"t_{k}_{uid}"] = "" if tr[k] is None else tr[k]
            for k in ("att_before", "opp_before", "att_after", "opp_after", "hits_after"):
                row[f"t_{k}_{uid}"] = tr[k]
            for k, v in tr.items():
                if k.startswith("v6_"):
                    row[f"{k}_{uid}"] = "" if v is None else (round(v, 4) if isinstance(v, float) else v)
        if side == "ally":
            row[f"{'front' if rank == 'FRONT' else 'rear'}_dead_ally"] += int(dead)
    return row


def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return 0.0, 0.0
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def _ratio(a, b):
    return round(a / b, 3) if b else ""


def summarize(rows: list[dict]) -> list[dict]:
    groups = defaultdict(list)
    for r in rows:
        groups[(r["encounter"], r["enemy_intel"], r["policy"])].append(r)
    out = []
    for (enc, intel, pol), rs in sorted(groups.items(), key=lambda kv: (kv[0][0], str(kv[0][1]), kv[0][2])):
        n = len(rs)
        wins = sum(r["win"] for r in rs)
        lo, hi = wilson(wins, n)
        S = lambda k: sum(r[k] for r in rs)
        M = lambda k: round(S(k) / n, 3)
        s = {"encounter": enc, "enemy_intel": intel, "policy": pol, "n": n,
             "win_rate": round(wins / n, 3), "win_ci_low": round(lo, 3), "win_ci_high": round(hi, 3),
             "avg_rounds": M("rounds"), "avg_ally_hp_ratio": M("ally_hp_ratio"), "avg_ally_ep_ratio": M("ally_ep_ratio"),
             "avg_ally_alive": M("ally_alive")}
        for k in COUNTER_KEYS:
            s[f"avg_{k}"] = M(k)
        for side in ("ally", "enemy"):
            iv = S(f"intervention_{side}")
            s[f"avg_prevented_{side}"] = M(f"prevented_{side}")
            s[f"avg_interceptor_taken_{side}"] = M(f"interceptor_taken_{side}")
            s[f"avg_breach_damage_{side}"] = M(f"breach_damage_{side}")
            s[f"avg_breach_attempts_{side}"] = M(f"breach_attempts_{side}")
            s[f"avg_breach_kos_{side}"] = M(f"breach_kos_{side}")
            s[f"net_per_intervention_{side}"] = _ratio(S(f"net_value_{side}"), iv)
        s["avg_plans"] = M("plans")
        s["plan_success_rate"] = _ratio(S("plans_success"), S("plans"))
        for ph in ("pre", "post"):
            d = S(f"ai_{ph}_decisions")
            s[f"ai_{ph}_decisions"] = d
            s[f"ai_{ph}_target_rear_rate"] = _ratio(S(f"ai_{ph}_target_rear"), d)
            s[f"ai_{ph}_open_route_rate"] = _ratio(S(f"ai_{ph}_via_open_route"), d)
            s[f"ai_{ph}_hole_exploit_rate"] = _ratio(S(f"ai_{ph}_via_intervention_hole"), d)
            s[f"ai_{ph}_bait_rate"] = _ratio(S(f"ai_{ph}_plan_bait"), d)
            s[f"ai_{ph}_intervene_rate"] = _ratio(S(f"ai_{ph}_intervened"), S(f"ai_{ph}_intervene_windows"))
        # Ver0.3: 標的の集中度・FRONT/REAR・初撃破・生存
        s["enemy_front_attack_rate"] = _ratio(S("attacks_enemy_on_front"), S("attacks_enemy"))
        s["enemy_rear_attack_rate"] = _ratio(S("attacks_enemy_on_rear"), S("attacks_enemy"))
        s["enemy_switch_rate"] = _ratio(S("target_switch_enemy"), S("attacks_enemy"))
        s["enemy_avg_streak"] = _ratio(S("streak_sum_enemy"), S("streak_count_enemy"))
        s["enemy_avg_max_streak"] = M("streak_max_enemy")
        s["enemy_team_avg_streak"] = _ratio(S("team_streak_sum_enemy"), S("team_streak_count_enemy"))
        for side in ("ally", "enemy"):
            ko = [r[f"first_ko_{side}_attacks"] for r in rs if r[f"first_ko_{side}_attacks"] != ""]
            kr = [r[f"first_ko_{side}_round"] for r in rs if r[f"first_ko_{side}_round"] != ""]
            s[f"first_ko_{side}_rate"] = round(len(ko) / n, 3)
            s[f"first_ko_{side}_avg_attacks"] = round(sum(ko) / len(ko), 2) if ko else ""
            s[f"first_ko_{side}_avg_round"] = round(sum(kr) / len(kr), 2) if kr else ""
        s["avg_front_dead_ally"] = M("front_dead_ally")
        s["avg_rear_dead_ally"] = M("rear_dead_ally")
        s["avg_intrusion_damage_per_hit_ally"] = _ratio(S("intrusion_damage_ally"), S("intrusion_hit_ally"))
        for k in rs[0]:
            if k.startswith(("targeted_", "dead_", "survive_rounds_")):
                s[f"avg_{k}"] = M(k)
        out.append(s)
    return out
