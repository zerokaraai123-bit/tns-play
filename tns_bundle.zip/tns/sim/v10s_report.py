"""Ver0.10.1 感度確認の集計表。 python -m tns.sim.v10s_report"""
import csv
import math
from pathlib import Path

OUT = Path("out/v10s")
RK = (("current", "現行仮仕様"), ("inctgt", "敵だけが戦闘不能者を攻撃可"), ("inctgt2", "補足: 双方が攻撃可"))
POLS = (("v9", "価値AI(Ver0.9)"), ("v10", "価値AI(Ver0.10)"), ("never", "Never"), ("always", "Always"))
f = lambda x: float(x or 0)


def load(rk, p):
    return {r["seed"] + "_" + r["enemy_intel"]: r for r in csv.DictReader(open(OUT / f"{rk}_{p}_battles.csv", encoding="utf-8-sig"))}


def pair(A, B):
    d = [(A[k]["winner"] == "ally") - (B[k]["winner"] == "ally") for k in A]
    n = len(d); m = sum(d) / n; sd = math.sqrt(sum((x - m) ** 2 for x in d) / (n - 1))
    return m * 100, (m / (sd / math.sqrt(n)) if sd else 0)


def main():
    D = {(rk, p): load(rk, p) for rk, _ in RK for p, _ in POLS}
    L = ["| 方針 | ルール | 勝率 | 現行比 | FRONT 離脱率（死亡/戦闘不能） | REAR 離脱率（死亡/戦闘不能） | REARのための介入/戦 | 戦闘不能後の被攻撃/戦（F/R） | 戦闘不能→死亡/戦（F/R） | 介入した前衛の生存率 |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    for p, pn in POLS:
        for rk, rn in RK:
            B = D[rk, p]; n = len(B); s = lambda k: sum(f(b.get(k)) for b in B.values()) / n
            win = sum(b["winner"] == "ally" for b in B.values()) / n * 100
            dd = "–" if rk == "current" else "%+.1f（z=%.1f）" % pair(B, D["current", p])
            ni = sum(f(b["n_interveners"]) for b in B.values())
            sv = "–" if not ni else "%.0f%%" % (sum(f(b["interveners_survived"]) for b in B.values()) / ni * 100)
            L.append(f"| {pn} | {rn} | {win:.1f}% | {dd} | {s('end_out_FRONT')/2*100:.0f}%（{s('end_dead_FRONT')/2*100:.0f}/{s('end_incap_FRONT')/2*100:.0f}） | "
                     f"{s('end_out_REAR')/3*100:.0f}%（{s('end_dead_REAR')/3*100:.0f}/{s('end_incap_REAR')/3*100:.0f}） | {s('ivrec_protect'):.2f} | "
                     f"{s('att_on_incap_FRONT'):.2f}/{s('att_on_incap_REAR'):.2f} | {s('incap_to_dead_FRONT'):.2f}/{s('incap_to_dead_REAR'):.2f} | {sv} |")
    L.append("\n| ルール | 価値AI(Ver0.9)−Never | 価値AI(Ver0.10)−Never | Always−Never | Ver0.10−Ver0.9 |\n|---|---|---|---|---|")
    for rk, rn in RK:
        c = [pair(D[rk, a], D[rk, b]) for a, b in (("v9", "never"), ("v10", "never"), ("always", "never"), ("v10", "v9"))]
        L.append(f"| {rn} | " + " | ".join("%+.1f（z=%.1f）" % x for x in c) + " |")
    print("\n".join(L))


if __name__ == "__main__":
    main()
