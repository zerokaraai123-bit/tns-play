"""Ver0.9 集計。 python -m tns.sim.v09_report > out/v09_tables.md"""
from __future__ import annotations

import csv
import math
from collections import Counter, defaultdict
from pathlib import Path

from .v09 import EXTRA, GRID

OUT = Path("out/v09")
QV = {"q0": 0.0, "q058": 0.584963, "q075": 0.75, "q10": 1.0, "q15": 1.5, "q20": 2.0}
FV = {"f100": 1.0, "f85": 0.85, "f70": 0.70, "f50": 0.50, "fP2": 0.5 ** (1 / 0.584963 - 1)}
ADEL, CEL = 228, 70


def load(tag):
    p = OUT / f"{tag}_battles.csv"
    if not p.exists():
        return None
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def n(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def avg(B, k):
    return sum(n(b.get(k)) for b in B) / len(B)


def win(B):
    return sum(1 for b in B if b["winner"] == "ally") / len(B)


def paired(A, B):
    """同じシードでの勝ち（1/0）の差の平均と標準誤差。"""
    a = {(x["seed"], x["enemy_intel"]): int(x["winner"] == "ally") for x in A}
    d = [a[(y["seed"], y["enemy_intel"])] - int(y["winner"] == "ally") for y in B if (y["seed"], y["enemy_intel"]) in a]
    m = sum(d) / len(d)
    var = sum((x - m) ** 2 for x in d) / max(1, len(d) - 1)
    return m, math.sqrt(var / len(d))


def label(cond):
    parts = cond.split("_")
    q, f = parts[-2], parts[-1]
    eff = (ADEL / CEL) ** QV[q]
    fl = "P2相当" if f == "fP2" else f"{FV[f]:.2f}"
    if cond.startswith("D2_"):
        fl += "（D2）"
    return QV[q], FV[f], eff, fl


def td(B):
    return avg(B, "phys_dmg") + avg(B, "magic_dmg")


def region(v, nv, al, prate):
    """A: 守らない方が良い／同等、C: 常に守るのが最良、B: 価値AIが両方を有意に上回る。"""
    if max(win(v), win(nv), win(al)) < 0.05 or min(win(v), win(nv), win(al)) > 0.95:
        return "判定不能（勝率が床/天井）", paired(v, nv)[0], paired(v, al)[0]
    dvn, sevn = paired(v, nv)
    dva, seva = paired(v, al)
    dan, sean = paired(al, nv)
    if dvn > 1.96 * sevn and dva > 1.96 * seva:
        return "**B**（状況依存が最良）", dvn, dva
    if dan > 1.96 * sean and dva <= 1.96 * seva:
        return "C（常に守るが最良）", dvn, dva
    if dvn <= 1.96 * sevn and dan <= 1.96 * sean:
        return "A（守る得なし）", dvn, dva
    return "境界（価値AI＞一方のみ）", dvn, dva


def build():
    L = ["## Ver0.9 実効肉体強度モデル × 介入価値（D1.5×P2・Speed+Incap・M1土台。各1,000戦・同一シード・敵知能均等）",
         "S＝現在HP×f(現在HP/最大HP)、f(r)=r^α。必要EP/1ダメージ＝0.5×(100/S)^q。",
         "防御効率比＝無傷アデル（228）と無傷セレスティア（70）の必要EPの比＝(228/70)^q。",
         "勝率差は同一シードの対応のある比較（±は95%）。"]
    L.append("\n#### V1 3方針の勝率と領域判定")
    L.append("| q | 防御効率比 | f(0.5) | 価値AI | Never | Always | 価値AI−Never | 価値AI−Always | 価値AIの介入率（REAR狙い） | チーム総与ダメ V/N/A | 領域 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    rows = {}
    for cond in GRID + EXTRA:
        v, nv, al = load(f"{cond}_value"), load(f"{cond}_never"), load(f"{cond}_always")
        if not (v and nv and al):
            continue
        q, f50, eff, fl = label(cond)
        prate = avg(v, "ivrec_protect") / max(avg(v, "ivrec_n"), 1e-9)
        reg, dvn, dva = region(v, nv, al, prate)
        _, sevn = paired(v, nv)
        _, seva = paired(v, al)
        rows[cond] = (v, nv, al)
        L.append(f"| {q:.3g} | {eff:.1f}倍 | {fl} | {win(v):.1%} | {win(nv):.1%} | {win(al):.1%} | {dvn:+.1%}±{1.96 * sevn:.1%} | "
                 f"{dva:+.1%}±{1.96 * seva:.1%} | {prate:.0%} | {td(v):.0f}/{td(nv):.0f}/{td(al):.0f} | {reg} |")

    L.append("\n#### V2 価値AIの中身（1戦あたり。REAR狙い＝敵がREARを攻撃した場面）")
    L.append("| q | f(0.5) | 介入/戦（REARのため） | REAR狙いの平均 実効肉体強度 FRONT/REAR | 同じ攻撃の必要EP REAR−FRONT（平均） | 介入で節約したREARのEP | 介入でFRONTが使ったEP | 差し引き（FRONT−REAR） | 介入後のFRONT追加被弾/ダメ | 開いた経路からREARへ | 温存EPが魔法・治療に変わった量 | 介入した場面の期待価値（平均） | しなかった場面の期待価値（平均） |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for cond, (v, nv, al) in rows.items():
        q, f50, eff, fl = label(cond)
        wf = max(avg(v, "rearatk_withfront"), 1e-9)
        sF, sR = avg(v, "rearatk_S_front") / wf, avg(v, "rearatk_S_rear") / max(avg(v, "rearatk_n"), 1e-9)
        nd = (avg(v, "rearatk_need_rear_wf") - avg(v, "rearatk_need_front")) / wf
        pr = max(avg(v, "ivrec_protect"), 1e-9)
        sf = max(avg(v, "ivrec_n") - avg(v, "ivrec_protect"), 1e-9)
        L.append(f"| {q:.3g} | {fl} | {avg(v, 'iv_move_rear'):.2f} | {sF:.0f} / {sR:.0f} | {nd:+.1f} | {avg(v, 'iv_rear_saved_ep'):.1f} | "
                 f"{avg(v, 'ep_front_iv'):.1f} | {avg(v, 'ep_front_iv') - avg(v, 'iv_rear_saved_ep'):+.1f} | "
                 f"{avg(v, 'front_disp_hits'):.2f}/{avg(v, 'front_disp_dmg'):.0f} | {avg(v, 'enemy_att_rear_open'):.2f} | {avg(v, 'saved_converted'):.1f} | "
                 f"{avg(v, 'ev_protect_sum') / pr:+.2f} | {avg(v, 'ev_self_sum') / sf:+.2f} |")

    L.append("\n#### V3 死亡・戦闘不能（1人あたり）と魔法（1戦あたり）: 価値AI / Never / Always")
    L.append("| q | f(0.5) | FRONT離脱 V/N/A | REAR離脱 V/N/A | 炎嵐 V/N/A | 治療 V/N/A | REAR自衛EP V/N/A | 開いた経路からREAR V/N/A |")
    L.append("|---|---|---|---|---|---|---|---|")
    for cond, (v, nv, al) in rows.items():
        q, f50, eff, fl = label(cond)
        fo = lambda B: (avg(B, "dead_FRONT") + avg(B, "incap_FRONT")) / 2
        ro = lambda B: (avg(B, "dead_REAR") + avg(B, "incap_REAR")) / 3
        L.append(f"| {q:.3g} | {fl} | {fo(v):.0%}/{fo(nv):.0%}/{fo(al):.0%} | {ro(v):.0%}/{ro(nv):.0%}/{ro(al):.0%} | "
                 f"{avg(v, 'storm'):.2f}/{avg(nv, 'storm'):.2f}/{avg(al, 'storm'):.2f} | {avg(v, 'heal'):.2f}/{avg(nv, 'heal'):.2f}/{avg(al, 'heal'):.2f} | "
                 f"{avg(v, 'selfdef_ep_REAR'):.0f}/{avg(nv, 'selfdef_ep_REAR'):.0f}/{avg(al, 'selfdef_ep_REAR'):.0f} | "
                 f"{avg(v, 'enemy_att_rear_open'):.2f}/{avg(nv, 'enemy_att_rear_open'):.2f}/{avg(al, 'enemy_att_rear_open'):.2f} |")

    # 状況依存: 価値AIの判断記録
    L.append("\n#### V4 価値AIの判断が状況でどう分かれたか（REAR狙いで介入可能な前衛がいた場面。前衛が守った割合）")
    L.append("| q | f(0.5) | 判断件数 | REARのEP 0 | 1-17 | 18-39 | 40+ | 前衛のHP>60% | 30-60% | ≤30% | 前衛の必要EPがREARの半分以下 | 半分超 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for cond in rows:
        p = OUT / f"{cond}_value_ivdecisions.csv"
        if not p.exists():
            continue
        R = list(csv.DictReader(open(p, encoding="utf-8-sig")))
        q, f50, eff, fl = label(cond)
        g = defaultdict(Counter)
        for r in R:
            e = n(r["t_ep"])
            eb = "0" if e <= 0 else "1-17" if e < 18 else "18-39" if e < 40 else "40+"
            fh = n(r["f_hp"])
            hb = ">60" if fh > 0.6 else "30-60" if fh > 0.3 else "<=30"
            rb = "half" if n(r["f_need"]) <= 0.5 * max(n(r["t_need"]), 1) else "more"
            for k in (eb, hb, rb):
                g[k]["n"] += 1
                g[k]["p"] += r["choice"] != "self"
        cell = lambda k: f"{g[k]['p'] / g[k]['n']:.0%}" if g[k]["n"] else "-"
        L.append(f"| {q:.3g} | {fl} | {len(R)} | " + " | ".join(cell(k) for k in ("0", "1-17", "18-39", "40+", ">60", "30-60", "<=30", "half", "more")) + " |")
    return "\n".join(L)


if __name__ == "__main__":
    print(build())
