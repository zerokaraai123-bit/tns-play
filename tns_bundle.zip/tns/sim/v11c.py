"""Ver0.11 炎嵐・詠唱実験（PA-130/131）。python -m tns.sim.v11c
条件: 詠唱 0/2/4/6 行動相当（0 / 0.2 / 0.4 / 0.6 巡）。方針: v11（Ver0.11介入AIそのまま）、v11c（詠唱価値を認識する介入AI）、never。
"""
from __future__ import annotations

import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..model.enums import Side
from .v09 import seeds

OUT = Path("out/v11c")
CASTS = (0, 2, 4, 6)
POLS = {"v11": ("v11", False, None), "v11c": ("v11", True, None), "never": ("v9", False, "never_iv")}


def build(n, pol, seed, intel):
    rules = "rules_v09_q058_f85_incap4.yaml" if n == 0 else f"rules_v09_q058_f85_incap4_cast{n}.yaml"
    cfg = load_battle_config(party="party_v08", rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    hm, aware, probe = POLS[pol]
    ally = ValueAllyController(cfg.ally_policies, probe=probe, hole_model=hm)
    ally.cast_aware = aware
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)}, seed=seed, enemy_intel=intel)
    return eng, ally


def _one(job):
    n, pol, seed, intel = job
    eng, ally = build(n, pol, seed, intel)
    cel = eng.u("celestia")
    fronts = [u for u in eng.state.units.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    E = []
    st = {"cast": None, "pending": None}

    def close():
        p = st["pending"]
        if p is not None:
            E.append(("target", p))
            st["pending"] = None

    def lis(ev, e):
        t = ev["t"]
        idx = e.action_index
        if t == "turn_start":
            close()
            E.append(("sample", {"idx": idx, "time": e.cur_time, "ep": cel.ep, "hp": cel.hp,
                                 "casting": int("celestia" in e.casting)}))
        elif t == "cast_start" and ev["unit"] == "celestia":
            st["cast"] = {"idx": idx, "time": e.cur_time, "hp": cel.hp, "ep": cel.ep, "hits": [], "iv": 0, "tg": 0}
            E.append(("cast_start", dict(st["cast"])))
        elif t in ("cast_complete", "cast_cancel", "cast_fail") and ev["unit"] == "celestia":
            c = st["cast"] or {}
            close() if t != "cast_complete" else None
            E.append((t, {"idx": idx, "time": e.cur_time, "took": ev.get("took"), "reason": ev.get("reason"),
                          "actions": ev.get("actions"), "start_idx": c.get("idx"), "tg": c.get("tg", 0), "iv": c.get("iv", 0),
                          "hits": c.get("hits", [])}))
            st["cast"] = None
        elif t == "attack_declared":
            a, tg = e.u(ev["unit"]), e.u(ev["target"])
            if a.side is Side.ENEMY and tg.id == "celestia":
                close()
                casting = "celestia" in e.casting
                st["pending"] = {"idx": idx, "time": e.cur_time, "attacker": a.id, "intel": a.intel_effective,
                                 "casting": int(casting), "hp": cel.hp, "ep": cel.ep, "incap": int(cel.incapacitated),
                                 "window": 0, "iv_by": None, "dmg": 0, "spent": 0, "delay": 0.0, "hp_after": None,
                                 "reach_ok": int(ev["reach_ok"]), "ai_reason": None, "stake": None}
                if casting and st["cast"] is not None:
                    st["cast"]["tg"] += 1
            elif a.id == "celestia" and ev["action"] == "fire":
                E.append(("spend", {"idx": idx, "cat": "攻撃魔法", "ep": 15}))
        elif t == "area_attack" and ev["unit"] == "celestia":
            E.append(("spend", {"idx": idx, "cat": "炎嵐", "ep": 40}))
            E.append(("storm", {"idx": idx, "time": e.cur_time}))
        elif t == "heal" and ev["unit"] == "celestia":
            E.append(("spend", {"idx": idx, "cat": "治療", "ep": ev.get("ep_cost", 0) or 0}))
        elif t == "intervention_window" and ev["target"] == "celestia" and st["pending"]:
            st["pending"]["window"] = 1
        elif t == "intervened" and ev["target"] == "celestia" and st["pending"]:
            st["pending"]["iv_by"] = ev["unit"]
            if st["pending"]["casting"] and st["cast"] is not None:
                st["cast"]["iv"] += 1
        elif t == "no_intervention" and ev["target"] == "celestia" and st["pending"]:
            rec = next((r for r in reversed(ally.records) if r["kind"] == "iv" and r["target"] == "celestia"), {})
            st["pending"]["ai_reason"] = rec.get("reason")
            st["pending"]["stake"] = rec.get("cast_stake")
        elif t == "damage" and ev["unit"] == "celestia" and e.u(ev["attacker"]).side is Side.ENEMY:
            p = st["pending"]
            sp = ev.get("ep_spent", 0) or 0
            if sp:
                E.append(("spend", {"idx": idx, "cat": "自衛", "ep": sp}))
            if p is not None:
                p["dmg"] += ev.get("dmg", 0) or 0
                p["spent"] += sp
                p["hp_after"] = cel.hp
        elif t == "cast_delay" and ev["unit"] == "celestia":
            if st["pending"] is not None:
                st["pending"]["delay"] += ev["new"] - ev["old"]
            if st["cast"] is not None:
                st["cast"]["hits"].append(round(ev["new"] - ev["old"], 4))
    eng.listeners.append(lis)
    eng.run()
    close()
    al = [u for u in eng.state.units.values() if u.side is Side.ALLY]
    out = {"n": n, "pol": pol, "seed": seed, "intel": intel, "win": int(eng.stats.winner == "ally"), "N": eng.action_index,
           "T": max(eng.cur_time, 0.0), "rounds": eng.stats.rounds, "end_ep": cel.ep,
           "dead_F": sum(1 for u in al if u.rank.value == "FRONT" and u.hp <= 0),
           "incap_F": sum(1 for u in al if u.rank.value == "FRONT" and u.incapacitated),
           "dead_R": sum(1 for u in al if u.rank.value == "REAR" and u.hp <= 0),
           "incap_R": sum(1 for u in al if u.rank.value == "REAR" and u.incapacitated),
           "cel_dead": int(cel.hp <= 0), "cel_incap": int(cel.incapacitated),
           "unfinished": int("celestia" in eng.casting),
           "iv_rear": sum(1 for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR" and r["choice"] != "self"),
           "E": E}
    return out


def run():
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")
    for n in CASTS:
        for pol in POLS:
            if n == 0 and pol == "v11c":
                continue
            path = OUT / f"cast{n}_{pol}.jsonl"
            if path.exists():
                print("skip", path, flush=True)
                continue
            with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                R = list(ex.map(_one, [(n, pol, s, i) for s, i in S], chunksize=20))
            with open(path, "w", encoding="utf-8") as fh:
                for r in R:
                    fh.write(json.dumps(r, ensure_ascii=False) + "\n")
            print("done", path, sum(r["win"] for r in R) / len(R), flush=True)


if __name__ == "__main__":
    run()
