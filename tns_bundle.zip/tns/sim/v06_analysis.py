"""Ver0.6 解析: 生身ダメージ × 負傷補正。救援猶予（Rescue Window）など。"""
from __future__ import annotations

import math
import statistics
from collections import defaultdict
from pathlib import Path

from .v04_analysis import analyze as analyze_v04, load

ALLY = {"adel": "front", "vanguard": "front", "celestia": "rear", "toolsmith": "rear", "archer": "rear"}


def _f(r, k):
    v = r.get(k)
    return None if v in ("", None) else float(v)


def _pct(xs, q):
    if not xs:
        return math.nan
    xs = sorted(xs)
    i = min(len(xs) - 1, max(0, int(round(q * (len(xs) - 1)))))
    return xs[i]


def analyze(rows) -> dict:
    out = analyze_v04(rows)
    n = len(rows)
    S = lambda k: sum((_f(r, k) or 0) for r in rows)
    for grp in ("front", "rear"):
        ids = [u for u, g in ALLY.items() if g == grp]
        first_dmg, body_dead, full_blocks, hit_to_death, rw_side, rw_self = [], [], [], [], [], []
        hit_units = returned = full_after = survived_hit = 0
        disp_hits = disp_dmg = disp_ko = 0
        for r in rows:
            for u in ids:
                fd = _f(r, f"v6_first_dmg_{u}")
                full_blocks.append(_f(r, f"v6_full_blocks_{u}") or 0)
                disp_hits += _f(r, f"v6_disp_hits_{u}") or 0
                disp_dmg += _f(r, f"v6_disp_dmg_{u}") or 0
                disp_ko += _f(r, f"v6_disp_ko_{u}") or 0
                if fd is None:
                    continue
                hit_units += 1
                first_dmg.append(fd)
                fa = _f(r, f"v6_full_after_hit_{u}") or 0
                if fa > 0:
                    returned += 1
                    full_after += fa
                death = _f(r, f"t_death_{u}")
                if death is None:
                    survived_hit += 1
                    continue
                body_dead.append(_f(r, f"v6_body_hits_{u}") or 0)
                hit_to_death.append(death - _f(r, f"t_first_hp_{u}"))
                rs, rf = _f(r, f"v6_rw_side_{u}"), _f(r, f"v6_rw_self_{u}")
                if rs is not None:
                    rw_side.append(rs)
                    rw_self.append(rf)
        mean = lambda xs: sum(xs) / len(xs) if xs else math.nan
        out[f"{grp}_first_dmg"] = mean(first_dmg)                    # ④
        out[f"{grp}_first_dmg_med"] = _pct(first_dmg, 0.5)
        out[f"{grp}_body_hits_to_death"] = mean(body_dead)           # ⑤（死亡した個体）
        out[f"{grp}_full_blocks"] = mean(full_blocks)                # ⑥
        out[f"{grp}_hit_to_death_mean"] = mean(hit_to_death)         # ⑦
        out[f"{grp}_hit_to_death_med"] = _pct(hit_to_death, 0.5)
        out[f"{grp}_hit_to_death_p10"] = _pct(hit_to_death, 0.1)
        out[f"{grp}_hit_to_death_p90"] = _pct(hit_to_death, 0.9)
        out[f"{grp}_rw_side_mean"] = mean(rw_side)                   # ⑧（味方の行動回数）
        out[f"{grp}_rw_side_med"] = _pct(rw_side, 0.5)
        out[f"{grp}_rw_self_mean"] = mean(rw_self)                   # ⑧（本人の行動回数）
        out[f"{grp}_rw0_rate"] = mean([1.0 if x <= 0 else 0.0 for x in rw_side])        # 救援猶予0（即死）
        out[f"{grp}_rw_le2_rate"] = mean([1.0 if x <= 2 else 0.0 for x in rw_side])
        for lo, hi, key in ((0, 0, "0"), (1, 2, "1_2"), (3, 5, "3_5"), (6, 9, "6_9"), (10, 10 ** 9, "10p")):
            out[f"{grp}_rw_hist_{key}"] = mean([1.0 if lo <= x <= hi else 0.0 for x in rw_side])    # ⑭
        out[f"{grp}_returned_rate"] = returned / hit_units if hit_units else math.nan               # ⑪
        out[f"{grp}_full_after_returned"] = full_after / returned if returned else math.nan          # ⑫
        out[f"{grp}_hit_survived_rate"] = survived_hit / hit_units if hit_units else math.nan       # ⑬（代替）
        out[f"{grp}_hit_units"] = hit_units / n
        out[f"{grp}_disp_hits"] = disp_hits / n
        out[f"{grp}_disp_dmg"] = disp_dmg / n
        out[f"{grp}_disp_ko"] = disp_ko / n
        # ⑨⑩ 必要EPの増加率（HP75%以上の帯を1とする）
        b0 = out.get(f"need_per_dmg_ally_{grp}_b0")
        for b, name in ((2, "under50"), (3, "under25")):
            v = out.get(f"need_per_dmg_ally_{grp}_b{b}")
            out[f"{grp}_ep_increase_{name}"] = v / b0 if (b0 and v and v == v and b0 == b0) else math.nan
            out[f"{grp}_def_share_{name}"] = out.get(f"def_count_ally_{grp}_b{b}", 0)
    out["interventions"] = S("intervention_ally") / n
    return out


def collect(out_dir, prefix, by=("enemy_intel",)):
    data = {}
    for p in sorted(Path(out_dir).glob(f"wolves_5v5_{prefix}_*_battles.csv")):
        tag = p.name[len(f"wolves_5v5_{prefix}_"):-len("_battles.csv")]
        rows = load(p)
        g = defaultdict(list)
        for r in rows:
            g["all"].append(r)
            for b in by:
                g[(b, r[b])].append(r)
        data[tag] = {k: analyze(v) for k, v in g.items()}
    return data
