"""連戦シミュ（PA-220〜223）: 雑魚の群れ4戦 → 最後に今の5体（ボス）。戦闘のあいだに回復はない。

持ち越すもの: 味方のHP・EP・応急整備の残り回数・戦闘不能/死亡（戦闘不能は戦闘中の治療でだけ復帰できる）。
戦闘の合間に「引き返す」判断（PA-222）。結果は クリア／引き返し（生還）／敗北 に分ける。
python -m tns.sim.v15_exp
"""
from __future__ import annotations

import os
from collections import Counter
from concurrent.futures import ProcessPoolExecutor

from ..ai.ally.v15_controller import V15AllyController
from ..ai.enemy.v15_enemy import V15EnemyAI
from ..config_loader import load_battle_config
from ..engine.timeline_engine import make_engine
from ..model.enums import Side, Stance
from .v15 import PARTY, RULES, apply_mods

ROUTE = ["exp_mob_wolves3", "exp_mob_wolves2_thrower", "exp_mob_wolves3", "exp_mob_wolves2_thrower", "v15_caster5"]
ALLY = ("adel", "vanguard", "vanguard3", "celestia", "toolsmith")
BOSS = len(ROUTE) - 1


def _cfg(enc, mods, mob_mods, boss_mods=None, party=None, rules=None, boss_enc=None):
    if boss_enc and enc == ROUTE[-1]:
        enc = boss_enc                               # Ver0.17: ボスの編成を差し替え（v17_caster5 など）
    cfg = load_battle_config(party=party or PARTY, encounter=enc, rules=rules or RULES, ai_weights="ai_weights_v15.yaml",
                             ally_policies="ally_policies_v15.yaml", front_hp_mult=1.75)
    cfg = apply_mods(cfg, mods)
    if enc.startswith("exp_mob") and mob_mods:
        cfg = apply_mods(cfg, mob_mods)
    if not enc.startswith("exp_mob") and boss_mods:
        cfg = apply_mods(cfg, boss_mods)          # Ver0.16: ボス戦だけに掛ける倍率
    return cfg


def _carry_in(eng, carry):
    """前の戦闘の結果を、この戦闘の開始状態に写す。"""
    if not carry:
        return
    for uid, st in carry.items():
        u = eng.u(uid)
        u.hp, u.ep = st["hp"], st["ep"]
        u.uses = dict(st["uses"])
        if not u.alive:
            u.stance = Stance.DOWN
            eng.next_time[uid] = float("inf")
        else:
            eng._set_next(u, eng.interval(u) + eng.init_offset.get(uid, 0.0), 0.0)
    eng._ep_low = {u.id for u in eng.state.units.values() if eng.defense.exhausted(u)}


def _carry_out(eng):
    return {uid: {"hp": eng.u(uid).hp, "ep": eng.u(uid).ep, "uses": dict(eng.u(uid).uses)} for uid in ALLY}


def party_state(carry, cfg_party):
    hpmax = {u["id"]: u["hp"] for u in cfg_party["units"]}
    epmax = {u["id"]: u["ep"] for u in cfg_party["units"]}
    hp = sum(carry[u]["hp"] for u in ALLY) / sum(hpmax.values())
    ep = sum(carry[u]["ep"] for u in ALLY) / sum(epmax.values())
    able = sum(1 for u in ALLY if carry[u]["hp"] > 0.15 * hpmax[u])
    dead = sum(1 for u in ALLY if carry[u]["hp"] <= 0)
    cel = carry["celestia"]["hp"] > 0.15 * hpmax["celestia"]
    return dict(hp=hp, ep=ep, able=able, dead=dead, cel=cel)


def should_retreat(policy, stage, ps):
    """PA-222 引き返す判断（キャラクターが知り得る自分たちの状態だけで決める）。"""
    if policy.get("mode", "rule") == "never" or stage == 0:
        return False
    if ps["able"] < policy.get("min_able", 4):
        return True
    if ps["hp"] < policy.get("hp", 0.35):
        return True
    if stage == BOSS and (ps["hp"] < policy.get("boss_hp", 0.55) or ps["ep"] < policy.get("boss_ep", 0.3)
                          or (policy.get("need_celestia", True) and not ps["cel"])):
        return True
    return False


def run_expedition(job):
    seed, intel = job["seed"], job.get("intel", 1)
    mods, mob_mods = job.get("mods"), job.get("mob_mods")
    ck = dict(boss_mods=job.get("boss_mods"), party=job.get("party"), rules=job.get("rules"), boss_enc=job.get("boss_enc"))
    policy = job.get("retreat", {"mode": "rule"})
    carry = None
    C = Counter()
    out = {"seed": seed, "result": None, "stage": None, "fights": []}
    for stage, enc in enumerate(ROUTE):
        cfg = _cfg(enc, mods, mob_mods, **ck)
        if carry is not None:
            ps = party_state(carry, cfg.party)
            if should_retreat(policy, stage, ps):
                out.update(result="retreat", stage=stage, at=ps)
                break
        ally = V15AllyController(cfg.ally_policies, disabled=job.get("ally_disabled", ()))
        ally.remaining_fights = len(ROUTE) - 1 - stage
        enemy = V15EnemyAI(cfg.ai_weights)
        eng = make_engine(cfg, {Side.ALLY: ally, Side.ENEMY: enemy}, seed=seed * 101 + stage, enemy_intel=intel)
        _carry_in(eng, carry)
        start = party_state(_carry_out(eng), cfg.party)

        def lis(ev, e, C=C, stage=stage):
            t = ev["t"]
            if t == "heal":
                C[f"heal_s{stage}"] += 1
            elif t == "ep_supply":
                C[f"maint_s{stage}"] += 1
            elif t == "area_attack" and ev["unit"] == "celestia":
                C[f"storm_s{stage}"] += 1
            elif t == "revive" and e.u(ev["unit"]).side is Side.ALLY:
                C[f"revive_s{stage}"] += 1
            elif t == "focus":
                C[f"focus_s{stage}"] += 1
            elif t == "blood_pay" and e.u(ev["unit"]).side is Side.ALLY:
                C[f"blood_s{stage}"] += 1
        eng.listeners.append(lis)
        eng.run()
        carry = _carry_out(eng)
        end = party_state(carry, cfg.party)
        out["fights"].append(dict(stage=stage, enc=enc, winner=eng.state.winner, time=round(eng.cur_time, 2),
                                  start=start, end=end))
        if eng.state.winner != "ally":
            out.update(result="defeat" if eng.state.winner == "enemy" else "timeout", stage=stage)
            break
    else:
        out.update(result="clear", stage=BOSS)
    out["final"] = party_state(carry, _cfg(ROUTE[0], mods, mob_mods, **ck).party) if carry else None
    out["C"] = dict(C)
    return out


def run_batch(jobs, workers=None):
    workers = workers or (os.cpu_count() or 2)
    with ProcessPoolExecutor(workers) as ex:
        return list(ex.map(run_expedition, jobs, chunksize=4))


def summarize(res):
    n = len(res)
    R = Counter(r["result"] for r in res)
    S = Counter()
    reach = Counter()
    for r in res:
        for k, v in r["C"].items():
            S[k] += v
        for f in r["fights"]:
            reach[f["stage"]] += 1
            S[f"time_s{f['stage']}"] += f["time"]
            S[f"hploss_s{f['stage']}"] += f["start"]["hp"] - f["end"]["hp"]
            S[f"eploss_s{f['stage']}"] += f["start"]["ep"] - f["end"]["ep"]
            if f["winner"] == "ally":
                S[f"win_s{f['stage']}"] += 1
            if f["stage"] == BOSS:
                S["boss_start_hp"] += f["start"]["hp"]
                S["boss_start_ep"] += f["start"]["ep"]
                S["boss_start_able"] += f["start"]["able"]
        if r["result"] == "retreat":
            S[f"retreat_at_s{r['stage']}"] += 1
        if r.get("final"):
            S["dead_total"] += r["final"]["dead"]
    out = {"n": n, "clear": R["clear"] / n, "retreat": R["retreat"] / n, "defeat": (R["defeat"] + R["timeout"]) / n,
           "timeout": R["timeout"] / n, "reach": {k: reach[k] / n for k in sorted(reach)},
           "dead_per_run": S["dead_total"] / n}
    for st in range(len(ROUTE)):
        m = reach.get(st, 0)
        if m:
            out[f"s{st}"] = {"win": S[f"win_s{st}"] / m, "time": S[f"time_s{st}"] / m, "hploss": S[f"hploss_s{st}"] / m,
                             "eploss": S[f"eploss_s{st}"] / m, "heal": S[f"heal_s{st}"] / m, "maint": S[f"maint_s{st}"] / m,
                             "storm": S[f"storm_s{st}"] / m, "revive": S[f"revive_s{st}"] / m,
                             "focus": S[f"focus_s{st}"] / m, "blood": S[f"blood_s{st}"] / m}
    b = reach.get(BOSS, 0)
    if b:
        out["boss_start"] = {"hp": S["boss_start_hp"] / b, "ep": S["boss_start_ep"] / b, "able": S["boss_start_able"] / b}
    out["retreat_at"] = {k: v / n for k, v in S.items() if k.startswith("retreat_at")}
    return out
