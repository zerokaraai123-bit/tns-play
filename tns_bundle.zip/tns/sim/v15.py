"""Ver0.15 検証（PA-200〜213）: 役割の差別化・敵の行動選択・観測固定・能力値の効き。
python -m tns.sim.v15 <command>
"""
from __future__ import annotations

import copy
import json
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.v15_controller import V15AllyController
from ..ai.enemy.v15_enemy import V15EnemyAI
from ..config_loader import load_battle_config
from ..engine.timeline_engine import make_engine
from ..model.enums import Side

OUT = Path("out/v15")
PARTY = "party_v15"
ENC = "v15_caster5"
RULES = "rules_v15.yaml"
ALLY = ("adel", "vanguard", "vanguard3", "celestia", "toolsmith")
ENEMY = ("wolf_a", "wolf_c", "wolf_b", "leader", "shaman")


def apply_mods(cfg, mods):
    """能力値・ルール値の上書き（分析・調整用）。
    mods = {"stat": {"ally"|"enemy"|ユニットID: {"speed": 倍率, "power": 倍率, "magic": 倍率, ...}},
            "unit": {ユニットID: {"hp": 値, ...}}, "rules": {"v15": {...}}, "action": {行動ID: {...}}}"""
    if not mods:
        return cfg
    cfg.encounter = copy.deepcopy(cfg.encounter)
    cfg.party = copy.deepcopy(cfg.party)
    cfg.rules = copy.deepcopy(cfg.rules)
    for side, units in (("enemy", cfg.encounter["units"]), ("ally", cfg.party["units"])):
        for u in units:
            for key in (side, u["id"]):
                for k, f in (mods.get("stat", {}).get(key) or {}).items():
                    u[k] = u.get(k, 0) * f
            for k, val in (mods.get("unit", {}).get(u["id"]) or {}).items():
                u[k] = val
    for sec, d in (mods.get("rules") or {}).items():
        cfg.rules.setdefault(sec, {})
        cfg.rules[sec] = {**cfg.rules[sec], **d}
    for aid, d in (mods.get("action") or {}).items():
        cfg.rules["actions"][aid] = {**cfg.rules["actions"].get(aid, {}), **d}
    if mods.get("policy"):
        cfg.ally_policies = copy.deepcopy(cfg.ally_policies)
        cfg.ally_policies["policies"]["situational"].update(mods["policy"])
    if mods.get("enemy_ai"):
        cfg.ai_weights = copy.deepcopy(cfg.ai_weights)
        for k, d in mods["enemy_ai"].items():
            cfg.ai_weights["v15"][k] = {**cfg.ai_weights["v15"].get(k, {}), **d}
    return cfg


def build(seed, intel=1, mods=None, ally_disabled=(), enemy_disabled=(), observe_mode="ai", log=False,
          ally_ctl=None):
    cfg = load_battle_config(party=PARTY, encounter=ENC, rules=RULES, ai_weights="ai_weights_v15.yaml",
                             ally_policies="ally_policies_v15.yaml", front_hp_mult=1.75)
    cfg = apply_mods(cfg, mods)
    ally = ally_ctl or V15AllyController(cfg.ally_policies, disabled=ally_disabled, observe_mode=observe_mode)
    enemy = V15EnemyAI(cfg.ai_weights, disabled=enemy_disabled)
    eng = make_engine(cfg, {Side.ALLY: ally, Side.ENEMY: enemy}, seed=seed, enemy_intel=intel, log_enabled=log)
    return eng, ally


def _listener(C, eng0):
    def lis(ev, e):
        t = ev["t"]
        if t == "attack_declared":
            act = e.actions[ev["action"]]
            if act.area == "all":
                return
            C[f"act_{ev['unit']}_{ev['action']}"] += 1
            if ev["unit"] in ALLY and e.u(ev["target"]).rank.value == "REAR":
                C["ally_hit_rear_decl"] += 1
        elif t == "area_attack":
            C[f"act_{ev['unit']}_{ev['action']}"] += 1
        elif t in ("hold", "howl", "observe"):
            C[f"act_{ev['unit']}_{t}"] += 1
            if t == "observe":
                C[f"obs_target_{ev['target']}"] += 1
                C[f"obs_intent_{ev['action']}"] += 1
        elif t == "ep_supply":
            C[f"act_{ev['unit']}_maintain"] += 1
        elif t == "wait":
            C[f"act_{ev['unit']}_wait"] += 1
        elif t == "cast_start":
            C[f"cast_start_{ev['unit']}"] += 1
        elif t == "cast_complete":
            C[f"cast_done_{ev['unit']}"] += 1
        elif t == "cast_cancel":
            C[f"cast_cancel_{ev['unit']}"] += 1
        elif t == "damage":
            if ev["action"] == "curse":
                C["curse_dmg"] += ev.get("dmg", 0) or 0
                C["curse_ep"] += ev.get("ep_spent", 0) or 0
            if ev["action"] == "storm":
                C["storm_dmg"] += ev.get("dmg", 0) or 0
            if ev["attacker"] in ENEMY:
                C["dmg_to_ally"] += ev.get("dmg", 0) or 0
            else:
                C["dmg_to_enemy"] += ev.get("dmg", 0) or 0
        elif t == "ko":
            C[f"ko_{ev['unit']}"] += 1
            if not ev.get("incap"):
                C[f"dead_{ev['unit']}"] += 1
        elif t == "intervened":
            C[f"iv_{e.u(ev['unit']).side.value}"] += 1
        elif t == "fixed_execute":
            C["fixed_exec"] += 1
        elif t == "fixed_broken":
            C["fixed_broken"] += 1
    return lis


def run_one(job):
    """job = dict(seed, intel, mods, ally_disabled, enemy_disabled, observe_mode)"""
    eng, ally = build(job["seed"], job.get("intel", 1), job.get("mods"), job.get("ally_disabled", ()),
                      job.get("enemy_disabled", ()), job.get("observe_mode", "ai"))
    C = Counter()
    eng.listeners.append(_listener(C, eng))
    st = eng.run()
    for k, v in st.c.items():
        if k.startswith("v15_") or k.startswith("intervention_") or k.startswith("cast_"):
            C["c_" + k] += v
    C["win"] = 1 if st.winner == "ally" else 0
    C["draw"] = 1 if st.winner == "draw" else 0
    C["time"] = eng.cur_time
    C["actions"] = eng.action_index
    for u in ALLY:
        C[f"alive_end_{u}"] = 1 if eng.u(u).alive else 0
    return {"seed": job["seed"], "C": dict(C)}


def run_batch(jobs, workers=None):
    workers = workers or max(1, (os.cpu_count() or 2))
    if workers == 1:
        return [run_one(j) for j in jobs]
    with ProcessPoolExecutor(workers) as ex:
        return list(ex.map(run_one, jobs, chunksize=8))


def summarize(res):
    n = len(res)
    S = Counter()
    for r in res:
        for k, v in r["C"].items():
            S[k] += v
    return n, {k: v / n for k, v in S.items()}
