"""Ver0.11 集計表。 python -m tns.sim.v11_report > out/v11/report_tables.md"""
from __future__ import annotations

import csv
import math

from .v11 import CONDS, OUT

PN = {"v9": "Ver0.9", "v10": "Ver0.10", "v11": "Ver0.11", "never": "Never", "always": "Always"}
CN = {"q058_f85_incap4": "2.0倍・f=0.85", "q058_f70_incap4": "2.0倍・f=0.70", "q058_fP2_incap4": "2.0倍・現行P2"}
f = lambda x: float(x or 0)


def load(cond, p):
    return {r["seed"] + "_" + r["enemy_intel"]: r for r in csv.DictReader(open(OUT / f"{cond}_{p}_battles.csv", encoding="utf-8-sig"))}


def pair(A, B):
    d = [(A[k]["winner"] == "ally") - (B[k]["winner"] == "ally") for k in A]
    n = len(d); m = sum(d) / n; sd = math.sqrt(sum((x - m) ** 2 for x in d) / (n - 1))
    return m * 100, (m / (sd / math.sqrt(n)) if sd else 0.0)


def main(conds=None):
    conds = conds or [c for c in CONDS if (OUT / f"{c}_always_battles.csv").exists()]
    D = {(c, p): load(c, p) for c in conds for p in PN}
    L = ["## 勝率（同一シード1,000戦）と対応差\n", "| 条件 | Ver0.9 | Ver0.10 | Ver0.11 | Never | Always | Ver0.11−Never | Ver0.11−Ver0.9 | Ver0.11−Ver0.10 | Ver0.9−Never |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    for c in conds:
        w = {p: sum(b["winner"] == "ally" for b in D[c, p].values()) / len(D[c, p]) * 100 for p in PN}
        ds = [pair(D[c, a], D[c, b]) for a, b in (("v11", "never"), ("v11", "v9"), ("v11", "v10"), ("v9", "never"))]
        L.append(f"| {CN[c]} | " + " | ".join(f"{w[p]:.1f}%" for p in PN) + " | "
                 + " | ".join("%+.1f（z=%.1f）" % x for x in ds) + " |")
    rows = [
        ("FRONT 離脱率（死亡/戦闘不能）", lambda s, n: f"{s('end_out_FRONT')/2*100:.0f}%（{s('end_dead_FRONT')/2*100:.0f}/{s('end_incap_FRONT')/2*100:.0f}）"),
        ("REAR 離脱率（死亡/戦闘不能）", lambda s, n: f"{s('end_out_REAR')/3*100:.0f}%（{s('end_dead_REAR')/3*100:.0f}/{s('end_incap_REAR')/3*100:.0f}）"),
        ("戦闘不能→死亡（F/R）", lambda s, n: f"{s('incap_to_dead_FRONT'):.2f}/{s('incap_to_dead_REAR'):.2f}"),
        ("治療による復帰（F/R）", lambda s, n: f"{s('revive_FRONT'):.2f}/{s('revive_REAR'):.2f}"),
        ("REARのための介入", lambda s, n: f"{s('ivrec_protect'):.2f}"),
        ("介入できたが見送った", lambda s, n: f"{s('ivrec_n') - s('ivrec_protect'):.2f}"),
        ("介入した前衛の平均HP / EP", lambda s, n: (f"{s('iv_f_hp_sum')/s('ivrec_protect')*100:.0f}% / {s('iv_f_ep_sum')/s('ivrec_protect'):.1f}" if s('ivrec_protect') else "–")),
        ("EP0の前衛の介入（回 / 介入に占める割合）", lambda s, n: (f"{s('iv_f_ep0'):.2f} / {s('iv_f_ep0')/s('ivrec_protect')*100:.0f}%" if s('ivrec_protect') else "–")),
        ("介入後、前衛が持ち場外で受けた攻撃（回 / 生身）", lambda s, n: f"{s('front_disp_hits'):.2f} / {s('front_disp_dmg'):.0f}"),
        ("介入した前衛の生存率（戦闘終了時）", lambda s, n: (f"{s('interveners_survived')/s('n_interveners')*100:.0f}%" if s('n_interveners') else "–")),
        ("介入で防いだREARの生身ダメ", lambda s, n: f"{s('iv_prevented_hp'):.1f}"),
        ("介入が原因の穴からの追加攻撃（回 / REARのHP・EP）", lambda s, n: f"{s('sum_real_intr'):.2f} / {s('sum_real_intr_hp'):.1f}・{s('sum_real_intr_ep'):.1f}"),
        ("介入で節約したREARのEP", lambda s, n: f"{s('iv_rear_saved_ep'):.1f}"),
        ("節約EPのうち魔法・治療に使われた分", lambda s, n: f"{s('saved_converted'):.1f}"),
        ("戦闘終了時のREARの残りEP", lambda s, n: f"{s('rear_ep_end'):.1f}"),
        ("炎 / 炎嵐 / 治療（回）", lambda s, n: f"{s('fire'):.2f} / {s('storm'):.2f} / {s('heal'):.2f}"),
        ("戦闘不能者への敵の攻撃", lambda s, n: f"{s('att_on_incap_FRONT') + s('att_on_incap_REAR'):.2f}"),
    ]
    for c in conds:
        L.append(f"\n## {CN[c]}：中身（1戦あたり）\n")
        L.append("| | " + " | ".join(PN.values()) + " |")
        L.append("|---|" + "---|" * len(PN))
        for name, fn in rows:
            cells = []
            for p in PN:
                B = D[c, p]; n = len(B)
                s = lambda k, B=B, n=n: sum(f(b.get(k)) for b in B.values()) / n
                cells.append(fn(s, n))
            L.append(f"| {name} | " + " | ".join(cells) + " |")
        L.append("\n**予測と実績（介入1件あたり、前衛が持ち場に戻るまで）**\n")
        L.append("| | Ver0.10 予測 | Ver0.10 実績 | Ver0.11 予測 | Ver0.11 実績 |\n|---|---|---|---|---|")
        for lab, kp, kr in (("前衛への攻撃（回）", "pred_front_hits", "real_front_hits"), ("前衛の生身", "pred_front_dmg", "real_front_dmg"),
                            ("穴からの追加攻撃（回）", "pred_extra_rear_hits", "real_intr")):
            cells = []
            for p in ("v10", "v11"):
                B = D[c, p].values()
                n = sum(f(b["win_n"]) for b in B)
                cells += [f"{sum(f(b['sum_' + kp]) for b in B)/n:.2f}", f"{sum(f(b['sum_' + kr]) for b in B)/n:.2f}"]
            L.append(f"| {lab} | " + " | ".join(cells) + " |")
    L.append("\n## 敵知能別の勝率（中心条件）\n")
    c = conds[0]
    L.append("| 敵知能 | " + " | ".join(PN.values()) + " |\n|---|" + "---|" * len(PN))
    for i in "0123":
        L.append(f"| {i} | " + " | ".join(
            f"{sum(b['winner'] == 'ally' for b in D[c, p].values() if b['enemy_intel'] == i) / max(1, sum(1 for b in D[c, p].values() if b['enemy_intel'] == i)) * 100:.1f}%"
            for p in PN) + " |")
    print("\n".join(L))


if __name__ == "__main__":
    main()
