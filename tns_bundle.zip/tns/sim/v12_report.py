"""Ver0.12 集計（out/v12 → 表とグラフ）。python -m tns.sim.v12_report"""
from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from functools import lru_cache

from .v12 import ENEMY, FRONTS, OUT, UNITS, path_of

SPEED = {"leader": 15, "wolf_a": 14, "wolf_b": 13, "wolf_c": 12, "toolsmith": 12, "celestia": 11, "adel": 10,
         "vanguard": 9, "vanguard3": 9, "thrower": 8, "thrower2": 8}
JP = {"leader": "リーダー", "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "thrower": "投擲兵", "thrower2": "投擲兵2",
      "celestia": "セレスティア", "toolsmith": "学者", "adel": "左FRONT(アデル)", "vanguard3": "中央FRONT(前衛3)",
      "vanguard": "右FRONT(前衛2)"}
INAME = {0: "低知能", 1: "通常", 2: "高知能", 3: "戦術級"}
MNAME = {"A": "A 比例型(指数1.0)", "B": "B 緩和型(指数0.5)", "C": "C 中間型(指数0.75)", "old": "旧方式(Ver0.11)",
         "Cx0": "対照 指数0(新時間軸・速度は順番だけ)"}
EQ = "@wolves_5v5"
for _k in list(MNAME):
    MNAME[_k + EQ] = MNAME[_k] + "［5体］"
CASTS = (0, 2, 4, 6)


def avg(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else float("nan")


def pct(x, d=1):
    return "—" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{100 * x:.{d}f}"


def laps(seq, x, y):
    """y の連続する2回の行動の間に、x が2回以上行動した回数"""
    n, cnt, seen = 0, 0, False
    for u in seq:
        if u == y:
            if seen and cnt >= 2:
                n += 1
            cnt, seen = 0, True
        elif u == x:
            cnt += 1
    return n


def parse(r):
    seq = [UNITS[i] for i in r["seq"]]
    C = Counter(r["C"])
    q = {"win": r["win"], "seed": r["seed"], "draw": r["draw"], "N": r["N"], "time": r["time"], "C": C}
    q["act"] = Counter(seq)
    q["first"] = {}
    for i, u in enumerate(seq):
        q["first"].setdefault(u, i + 1)
    q["open15"] = tuple(r["seq"][:15])
    q["open11"] = tuple(r["seq"][:11])
    q["lost"] = r.get("lost", {})
    q["dead_A"], q["incap_A"] = r["dead_A"], r["incap_A"]
    K = r["K"]
    q["cel_dead"] = r["cel_dead"]
    q["cel_incap_any"] = int(any(UNITS[k[1]] == "celestia" and k[2] for k in K) or r["cel_incap_end"])
    q["ally_incap_ever"] = len({k[1] for k in K if k[2] and UNITS[k[1]] not in ENEMY})
    # 行動前に倒された（最初の行動より前に戦闘不能・死亡）
    q["ko_before_act"] = Counter(UNITS[k[1]] for k in K if q["first"].get(UNITS[k[1]], 10 ** 9) > k[0])
    # 連続行動（周回）
    q["lap_leader_front"] = sum(laps(seq, "leader", f) for f in FRONTS) / 3
    q["lap_leader_cel"] = laps(seq, "leader", "celestia")
    q["lap_enemy_front"] = sum(laps(seq, e, f) for e in ENEMY for f in FRONTS)
    q["lap_ally_enemy"] = sum(laps(seq, a, e) for a in ("celestia", "toolsmith", "adel", "vanguard3", "vanguard") for e in ENEMY)
    q["ret"] = r.get("ret", {})
    eK = [k for k in K if UNITS[k[1]] in ENEMY]
    q["ko1_idx"] = eK[0][0] if eK else None
    q["ko1_t"] = eK[0][3] if eK else None
    return q


@lru_cache(maxsize=None)
def P(m, n, pol, intel, tag=""):
    p = path_of(m, n, pol, intel, tag)
    if not p.exists():
        return None
    with open(p, encoding="utf-8") as fh:
        return [parse(json.loads(l)) for l in fh]


def wr(Q):
    return sum(q["win"] for q in Q) / len(Q)


def pair(Q1, Q2):
    m1 = {q["seed"]: q["win"] for q in Q1}
    d = [m1[q["seed"]] - q["win"] for q in Q2 if q["seed"] in m1]
    n = len(d)
    mu = sum(d) / n
    var = sum((x - mu) ** 2 for x in d) / (n - 1)
    se = math.sqrt(var / n) if var > 0 else 0
    return mu, (mu / se if se else 0.0)


def tbl(head, rows):
    s = "| " + " | ".join(head) + " |\n|" + "---|" * len(head) + "\n"
    for r in rows:
        s += "| " + " | ".join(str(x) for x in r) + " |\n"
    return s


METHODS_ALL = ("old", "Cx0", "A", "B", "C")
METHODS_EQ = tuple(m + EQ for m in ("old", "A", "B", "C"))


def sec_win(pol="v11", methods=METHODS_ALL, tag=""):
    rows = []
    for it in (0, 1, 2, 3):
        for m in methods:
            row = [INAME[it], MNAME[m]]
            ok = False
            for n in CASTS:
                Q = P(m, n, pol, it, tag)
                row.append(pct(wr(Q)) if Q else "—")
                ok = ok or bool(Q)
            if ok:
                rows.append(row)
    return tbl(["知能", "方式"] + [f"詠唱{n}" for n in CASTS], rows)


def sec_never(methods=METHODS_ALL):
    rows = []
    for it in (0, 1, 2, 3):
        for m in methods:
            row = [INAME[it], m]
            ok = False
            for n in CASTS:
                Q1, Q0 = P(m, n, "v11", it), P(m, n, "never", it)
                if Q1 and Q0:
                    d, z = pair(Q1, Q0)
                    row.append(f"{pct(wr(Q1))} / {pct(wr(Q0))} / {100*d:+.1f} (z={z:.1f})")
                    ok = True
                else:
                    row.append("—")
            if ok:
                rows.append(row)
    return tbl(["知能", "方式"] + [f"詠唱{n} 介入AI/Never/差" for n in CASTS], rows)


def sec_overall(intel, pol="v11", methods=METHODS_ALL, casts=CASTS):
    rows = []
    for m in methods:
        for n in casts:
            Q = P(m, n, pol, intel)
            if not Q:
                continue
            rows.append([m, n, pct(wr(Q)), f"{avg([q['time'] for q in Q]):.2f}", f"{avg([q['N'] for q in Q]):.1f}",
                         f"{avg([q['dead_A'] for q in Q]):.2f}", f"{avg([q['ally_incap_ever'] for q in Q]):.2f}",
                         pct(avg([q['draw'] for q in Q]))])
    return tbl(["方式", "詠唱", "勝率%", "戦闘時間(T)", "総行動数", "味方死亡/戦", "味方戦闘不能(一度でも)/戦", "時間切れ%"], rows)


def sec_actions(intel, n=0, pol="v11", methods=METHODS_ALL):
    rows = []
    for u in UNITS:
        if u not in JP:
            continue
        row = [JP[u], SPEED[u]]
        for m in methods:
            Q = P(m, n, pol, intel)
            if not Q:
                row.append("—")
                continue
            a = avg([q["act"][u] for q in Q])
            rate = avg([q["act"][u] / q["time"] for q in Q if q["time"] > 0])
            row.append(f"{a:.2f} ({rate:.2f}/T)")
        rows.append(row)
    rat = ["高速/低速の比"]
    rat.append("")
    for m in methods:
        Q = P(m, n, pol, intel)
        if not Q:
            rat.append("—")
            continue
        lt = avg([q["act"]["leader"] / max(1, q["act"]["thrower"]) for q in Q if q["act"]["thrower"] > 0])
        cf = avg([q["act"]["celestia"] / max(1, q["act"]["vanguard"]) for q in Q if q["act"]["vanguard"] > 0])
        rat.append(f"リーダー/投擲兵 {lt:.2f}・セレ/右FRONT {cf:.2f}")
    rows.append(rat)
    return tbl(["ユニット", "速度"] + [f"{m}: 行動回数(1Tあたり)" for m in methods], rows)


def sec_lost(intel, n=0, pol="v11", methods=("A", "B", "C")):
    rows = []
    for m in methods:
        Q = P(m, n, pol, intel)
        if not Q:
            continue
        al = avg([sum(v for k, v in q["lost"].items() if k not in ENEMY) for q in Q])
        en = avg([sum(v for k, v in q["lost"].items() if k in ENEMY) for q in Q])
        per = {u: avg([q["lost"].get(u, 0) for q in Q]) for u in ("adel", "vanguard3", "vanguard", "celestia", "leader", "wolf_a")}
        rows.append([m, f"{al:.2f}", f"{en:.2f}"] + [f"{per[u]:.2f}" for u in per])
    return tbl(["方式", "味方合計", "敵合計", "左FRONT", "中央FRONT", "右FRONT", "セレスティア", "リーダー", "狼A"], rows)


def sec_order(intel, n=0, pol="v11", methods=METHODS_ALL, tag=""):
    rows = []
    for m in methods:
        Q = P(m, n, pol, intel, tag)
        if not Q:
            continue
        c15 = Counter(q["open15"] for q in Q)
        c11 = Counter(q["open11"] for q in Q)
        top = c15.most_common(1)[0][1] / len(Q)
        top11 = c11.most_common(1)[0][1] / len(Q)
        first = {u: avg([q["first"].get(u) for q in Q]) for u in ("leader", "celestia", "adel", "vanguard", "thrower")}
        rows.append([m + (tag and f"({tag})"), len(c11), pct(top11), len(c15), pct(top15 := top)] +
                    [f"{first[u]:.1f}" for u in first])
    return tbl(["方式", "最初の11行動の並びの種類", "最多の並びの割合%", "最初の15行動の種類", "最多%",
                "1回目の行動番号: リーダー", "セレ", "左FRONT", "右FRONT", "投擲兵"], rows)


def sec_iv(intel, pol="v11", methods=METHODS_ALL, casts=CASTS):
    rows = []
    for m in methods:
        for n in casts:
            Q = P(m, n, pol, intel)
            if not Q:
                continue
            g = lambda k: f"{avg([q['C'][k] for q in Q]):.2f}"
            rt = []
            for f in FRONTS:
                nn = sum(q["ret"].get(f"{f}_n", 0) for q in Q)
                tt = sum(q["ret"].get(f"{f}_t", 0) for q in Q)
                rt.append(f"{tt/nn:.2f}" if nn else "—")
            rows.append([m, n, g("iv"), g("iv_adel"), g("iv_vanguard3"), g("iv_vanguard"),
                         f"{g('iv_vanguard3_celestia')} / {g('iv_vanguard3_toolsmith')}", g("iv_to_celestia"),
                         g("iv_to_toolsmith"), g("breach"), g("front_iv_hit"), g("front_disp_hit"), " / ".join(rt)])
    return tbl(["方式", "詠唱", "介入計", "左", "中央", "右", "中央→セレ/学者", "→セレ", "→学者", "前線突破",
                "介入の一撃でFRONTが受けたHP", "離脱中にFRONTが受けたHP", "介入→持ち場復帰までの時間T(左/中/右)"], rows)


def sec_magic(intel, pol="v11", methods=METHODS_ALL, casts=CASTS):
    rows = []
    for m in methods:
        for n in casts:
            Q = P(m, n, pol, intel)
            if not Q:
                continue
            g = lambda k: f"{avg([q['C'][k] for q in Q]):.2f}"
            rows.append([m, n, g("cast_start"), g("storm"), g("cancel"), g("fire"), g("heal"), g("cel_ep_spent"),
                         g("raw_cel"), g("tg_cast"), g("iv_cast"), g("raw_cast"), g("cast_delay"),
                         pct(avg([q["cel_incap_any"] for q in Q])), pct(avg([q["cel_dead"] for q in Q])),
                         f"{avg([q['C'].get('storm1_t') for q in Q]):.2f}", f"{avg([q['C'].get('storm1_ep') for q in Q]):.0f}"])
    return tbl(["方式", "詠唱", "詠唱開始", "炎嵐", "キャンセル", "攻撃魔法", "治療", "セレEP消費", "セレ生身被弾",
                "詠唱中に狙われた", "詠唱中の介入", "詠唱中の生身被弾", "詠唱遅延(負傷)", "セレ戦闘不能%", "セレ死亡%",
                "最初の炎嵐の時刻T", "そのときの敵EP"], rows)


def sec_tactics(intel, pol="v11", methods=METHODS_ALL, n=4):
    rows = []
    for m in methods:
        Q = P(m, n, pol, intel)
        if not Q:
            continue
        kb = Counter()
        for q in Q:
            kb.update(q["ko_before_act"])
        rows.append([m, f"{avg([q['C']['heal_save'] for q in Q]):.2f}", f"{avg([q['lap_leader_front'] for q in Q]):.2f}",
                     f"{avg([q['lap_leader_cel'] for q in Q]):.2f}", f"{avg([q['lap_enemy_front'] for q in Q]):.2f}",
                     f"{avg([q['lap_ally_enemy'] for q in Q]):.2f}",
                     ", ".join(f"{JP[u]} {v/len(Q)*100:.1f}%" for u, v in kb.most_common(4)) or "なし",
                     f"{avg([q['C']['cast_delay'] for q in Q]):.2f}"])
    return tbl(["方式", "治療が間に合って戦闘不能を防いだ/戦", "リーダーがFRONTの1手番の間に2回動いた/戦(FRONT1人あたり)",
                "リーダーがセレの1手番の間に2回動いた/戦", "敵がFRONTを周回した合計/戦", "味方が敵を周回した合計/戦",
                "最初の行動前に倒された", "詠唱が負傷で遅れた/戦"], rows)


def sec_contrib(intel, pol="v11", methods=METHODS_ALL, n=0):
    rows = []
    for u in UNITS:
        if u not in JP:
            continue
        row = [JP[u], SPEED[u]]
        for m in methods:
            Q = P(m, n, pol, intel)
            if not Q:
                row.append("—")
                continue
            d = avg([q["C"][f"dmg_by_{u}"] for q in Q])
            e = avg([q["C"][f"epstrip_by_{u}"] for q in Q])
            a = avg([q["act"][u] for q in Q])
            row.append(f"{d:.0f} / {e:.0f} ({d/max(a,1e-9):.1f}/行動)")
        rows.append(row)
    return tbl(["ユニット", "速度"] + [f"{m}: 与HPダメージ / 削ったEP" for m in methods], rows)


ROB = (("基準(ずらしなし)", "", None), ("初回+[0,0.05T)", "off0.05", None), ("初回+[0,0.10T)", "off0.1", None),
       ("同時刻は味方優先", "tieally_first", None), ("同時刻は敵優先", "tieenemy_first", None))


EXPS = ((0.0, "Cx0"), (0.25, "Cx0.25"), (0.35, "Cx0.35"), (0.5, "B"), (0.65, "Cx0.65"), (0.75, "C"), (1.0, "A"))


def sec_exp():
    rows = []
    for x, m in EXPS:
        row = [x, f"{(15/9)**x:.2f}倍"]
        for it in (0, 1, 2, 3):
            for n in (0, 4):
                Q = P(m, n, "v11", it)
                row.append(pct(wr(Q)) if Q else "—")
        rows.append(row)
    return tbl(["指数", "速度15/速度9の回数比"] + [f"{INAME[it]} 詠唱{n}" for it in (0, 1, 2, 3) for n in (0, 4)], rows)


def graph_exp(path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for f in font_manager.findSystemFonts():
        if "NotoSansCJK" in f.replace(" ", ""):
            font_manager.fontManager.addfont(f)
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "sans-serif"]
    fig, ax = plt.subplots(figsize=(8, 4.6))
    cols = {0: "tab:green", 1: "tab:blue", 2: "tab:orange", 3: "tab:red"}
    for it in (0, 1, 2, 3):
        for n, ls in ((0, "o-"), (4, "s--")):
            xs, ys = [], []
            for x, m in EXPS:
                Q = P(m, n, "v11", it)
                if Q:
                    xs.append(x)
                    ys.append(100 * wr(Q))
            ax.plot(xs, ys, ls, color=cols[it], alpha=1.0 if n == 0 else 0.55, label=f"{INAME[it]}・詠唱{n}")
    for x, lab in ((0.5, "B"), (0.75, "C"), (1.0, "A")):
        ax.axvline(x, color="gray", lw=0.6, ls=":")
        ax.text(x, 97, lab, ha="center", fontsize=9)
    ax.set_xlabel("速度の指数（0＝速度は順番だけ, 1＝比例）")
    ax.set_ylabel("味方勝率 %（介入AI, 各1,000戦）")
    ax.set_ylim(-3, 100)
    ax.set_title("指数ごとの勝率（敵: 6体・投擲兵追加）")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(path, dpi=110)


def sec_rob():
    rows = []
    for m in ("A", "B", "C"):
        for n in CASTS:
            row = [m, n]
            base = P(m + EQ, n, "v11", 3)
            for lab, tg, _ in ROB:
                Q = base if not tg else P(m + EQ + tg, n, "v11", 3)
                if not Q:
                    row.append("—")
                    continue
                if tg and base:
                    common = {q["seed"] for q in base}
                    Qc = [q for q in Q if q["seed"] in common]
                    d, z = pair(Qc, base)
                    row.append(f"{pct(wr(Q))}（差{100*d:+.1f}, z={z:.1f}）")
                else:
                    row.append(pct(wr(Q)))
            rows.append(row)
    return tbl(["方式", "詠唱"] + [x[0] for x in ROB], rows)


def sec_rob_order():
    rows = []
    for m in ("A", "B", "C"):
        for lab, tg, _ in ROB:
            Q = P(m + EQ + tg, 0, "v11", 3) if tg else P(m + EQ, 0, "v11", 3)
            if not Q:
                continue
            c11 = Counter(q["open11"] for q in Q)
            first = {u: avg([q["first"].get(u) for q in Q]) for u in ("leader", "celestia", "adel", "vanguard", "thrower")}
            rows.append([m, lab, len(Q), len(c11), pct(c11.most_common(1)[0][1] / len(Q))] + [f"{first[u]:.2f}" for u in first])
    return tbl(["方式", "条件", "戦闘数", "最初の11行動の並びの種類", "最多%", "1回目の行動番号: リーダー", "セレ", "左FRONT", "右FRONT", "投擲兵"], rows)


def graph(path, methods=None, title="Ver0.12 時間管理方式別の勝率（濃い線＝介入AI、薄い線＝Never）"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for f in font_manager.findSystemFonts():
        if "NotoSansCJK" in f.replace(" ", ""):
            font_manager.fontManager.addfont(f)
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "sans-serif"]
    fig, axes = plt.subplots(1, 4, figsize=(18, 4.6), sharey=True)
    sty0 = {"old": ("black", "o--"), "Cx0": ("gray", "x:"), "A": ("tab:red", "o-"), "B": ("tab:blue", "s-"), "C": ("tab:green", "^-")}
    sty = {}
    for m in (methods or METHODS_ALL):
        sty[m] = sty0[m.split("@")[0]]
    for ax, it in zip(axes, (0, 1, 2, 3)):
        for m, (c, mk) in sty.items():
            for pol, al in (("v11", 1.0), ("never", 0.35)):
                ys = []
                for n in CASTS:
                    Q = P(m, n, pol, it)
                    ys.append(100 * wr(Q) if Q else float("nan"))
                if not all(math.isnan(y) for y in ys):
                    ax.plot(CASTS, ys, mk, color=c, alpha=al, label=f"{MNAME[m]}{'' if pol == 'v11' else '・Never'}")
        ax.set_title(f"{INAME[it]}（各1,000戦）")
        ax.set_xticks(CASTS)
        ax.set_xlabel("炎嵐の詠唱")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("味方勝率 %")
    axes[0].legend(fontsize=7)
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=110)


def main():
    out = []
    w = out.append
    w("## 勝率（介入AI）\n" + sec_win())
    w("## 勝率（Never）\n" + sec_win("never"))
    w("## 介入AI vs Never（同seed）\n" + sec_never())
    for it in (3, 1, 0, 2):
        w(f"## 戦闘全体（{INAME[it]}）\n" + sec_overall(it))
        w(f"## ユニット別の行動回数（{INAME[it]}, 詠唱0, 介入AI）\n" + sec_actions(it))
        w(f"## HP低下で失った行動機会（{INAME[it]}, 詠唱0, 介入AI, 1戦あたり・行動数換算）\n" + sec_lost(it))
        w(f"## 行動順の固定度（{INAME[it]}, 詠唱0）\n" + sec_order(it))
        w(f"## 介入（{INAME[it]}）\n" + sec_iv(it))
        w(f"## 魔法とセレスティア（{INAME[it]}）\n" + sec_magic(it))
        w(f"## 速度が生む場面（{INAME[it]}, 詠唱4, 介入AI）\n" + sec_tactics(it))
        w(f"## ユニット別の貢献（{INAME[it]}, 詠唱0, 介入AI）\n" + sec_contrib(it))
    w("## 指数ごとの勝率（主比較の敵, 介入AI, 各1,000戦）\n" + sec_exp())
    w("# 補足: 易しい既存編成（5体 wolves_5v5, 各方式・各詠唱 250戦×4知能）\n")
    w("## 勝率（介入AI, 5体）\n" + sec_win(methods=METHODS_EQ))
    w("## 勝率（Never, 5体）\n" + sec_win("never", methods=METHODS_EQ))
    w("## 介入AI vs Never（5体）\n" + sec_never(methods=METHODS_EQ))
    for it in (3, 1, 0, 2):
        w(f"## 戦闘全体（5体, {INAME[it]}）\n" + sec_overall(it, methods=METHODS_EQ))
        w(f"## 介入（5体, {INAME[it]}）\n" + sec_iv(it, methods=METHODS_EQ))
        w(f"## 魔法とセレスティア（5体, {INAME[it]}）\n" + sec_magic(it, methods=METHODS_EQ))
        w(f"## 速度が生む場面（5体, {INAME[it]}, 詠唱4）\n" + sec_tactics(it, methods=METHODS_EQ))
        w(f"## ユニット別の行動回数（5体, {INAME[it]}, 詠唱0）\n" + sec_actions(it, methods=METHODS_EQ))
    w("# 補足: 行動順への依存（戦術級, 5体, ずらし・同時刻の並べ方を変えた比較。基準250戦・各変化500戦, 差は共通seed250戦で）\n")
    w("## 勝率\n" + sec_rob())
    w("## 行動順の散らばり（詠唱0）\n" + sec_rob_order())
    txt = "\n".join(out)
    (OUT / "report_tables.md").write_text(txt, encoding="utf-8")
    graph(OUT / "winrate.png")
    graph_exp(OUT / "exponent.png")
    graph(OUT / "winrate_5v5.png", METHODS_EQ, "補足: 5体編成での勝率（濃い線＝介入AI、薄い線＝Never）")
    print(txt)


if __name__ == "__main__":
    main()
