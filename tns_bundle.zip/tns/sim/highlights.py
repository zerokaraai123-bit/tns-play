"""見どころ戦闘の判定・保存・再生。"""
from __future__ import annotations

import json
from pathlib import Path

from ..config_loader import load_battle_config
from ..log.text_renderer_ja import render_all
from .runner import run_battle


def tags_for(stats, hcfg: dict) -> list[str]:
    tags = []
    if stats.winner == "ally" and stats.final["ally_hp_ratio"] <= hcfg.get("close_win_hp_ratio", 0.25):
        tags.append("close_win")
    if any(p["success"] for p in stats.plans):
        tags.append("bait_success")
    if any(r.side == "enemy" and r.breach_hits > 0 for r in stats.interventions):
        tags.append("player_bait")
    if any(r.side == "ally" and r.breach_damage >= hcfg.get("big_breach_damage", 25) for r in stats.interventions):
        tags.append("big_breach")
    if hcfg.get("leader_swing", True) and stats.winner == "ally" and stats.leader_down_round is not None \
            and stats.leader_down_ally_hp_ratio < stats.leader_down_enemy_hp_ratio:
        tags.append("leader_swing")
    return tags


class HighlightStore:
    def __init__(self, max_per_tag: int):
        self.max = max_per_tag
        self.items = []
        self.count = {}

    def add(self, tags, entry):
        keep = [t for t in tags if self.count.get(t, 0) < self.max]
        if not keep:
            return
        for t in keep:
            self.count[t] = self.count.get(t, 0) + 1
        e = dict(entry, tags=tags, id=len(self.items) + 1)
        self.items.append(e)

    def save(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            for e in self.items:
                f.write(json.dumps(e, ensure_ascii=False) + "\n")


def load_highlight(path, hid: int) -> dict:
    with open(path, encoding="utf-8") as f:
        for line in f:
            e = json.loads(line)
            if e["id"] == hid:
                return e
    raise KeyError(f"highlight id {hid} not found in {path}")


def replay(entry: dict) -> str:
    cfg = load_battle_config(party=entry["party"], encounter=entry["encounter"],
                             rules=entry.get("rules", "rules.yaml"),
                             ai_weights=entry.get("ai_weights", "ai_weights.yaml"),
                             front_hp_mult=entry.get("front_hp_mult", 1.0),
                             ally_policies=entry.get("ally_policies", "ally_policies.yaml"))
    head = (f"# 再生: id={entry['id']} tags={','.join(entry['tags'])} seed={entry['seed']} "
            f"policy={entry['policy']} enemy_intel={entry['enemy_intel']}\n# {entry.get('summary', '')}\n")
    if cfg.hash != entry["config_hash"]:
        head += (f"# ⚠ 設定が保存時({entry['config_hash']})から変更されています(現在{cfg.hash})。"
                 f"調整後のため結果が変わる可能性があります。\n")
    eng = run_battle(cfg, entry["seed"], entry["policy"], entry["enemy_intel"], log=True)
    return head + render_all(eng)
