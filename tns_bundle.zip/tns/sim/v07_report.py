"""Ver0.7 集計表。 python -m tns.sim.v07_report > out/v07_tables.md"""
from __future__ import annotations

import csv
import statistics
from collections import defaultdict
from pathlib import Path

OUT = Path("out/v07")
DJ = {"D1": "D1", "D2": "D2", "D3": "D3"}
VJ = {"A": "A Baseline", "S": "B Speed only", "I": "C Incap only", "SI": "D Speed+Incap", "SIa": "D' 味方だけSpeed+Incap"}
IJ = {"0": "低", "1": "通常", "2": "高", "3": "戦術"}


def load(tag):
    b = OUT / f"{tag}_battles.csv"
    u = OUT / f"{tag}_units.csv"
    if not u.exists():
        return None, None
    with open(b, encoding="utf-8-sig") as f:
        B = list(csv.DictReader(f))
    with open(u, encoding="utf-8-sig") as f:
        U = list(csv.DictReader(f))
    return B, U


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def pct(a, b, d=1):
    return f"{a / b:.{d}%}" if b else "-"


def mean(xs):
    xs = [x for x in xs if x is not None]
    return statistics.mean(xs) if xs else float("nan")


def med(xs):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else float("nan")


def f1(x):
    return "-" if x != x else f"{x:.1f}"


def f2(x):
    return "-" if x != x else f"{x:.2f}"


def ally(U):
    return [u for u in U if u["side"] == "ally"]


def summarize(B, U):
    n = len(B)
    A = ally(U)
    F = [u for u in A if u["rank"] == "FRONT"]
    R = [u for u in A if u["rank"] == "REAR"]
    E = [u for u in U if u["side"] == "enemy"]
    s = {"n": n}
    s["win"] = sum(1 for b in B if b["winner"] == "ally") / n
    s["draw"] = sum(1 for b in B if b["winner"] == "draw") / n
    for g, xs in (("F", F), ("R", R), ("A", A), ("E", E)):
        s[f"{g}_dead"] = sum(1 for u in xs if u["out"] == "dead") / len(xs)
        s[f"{g}_incap"] = sum(1 for u in xs if u["out"] == "incap") / len(xs)
        s[f"{g}_le15"] = sum(1 for u in xs if u["reached_le15"] == "1") / len(xs)
        s[f"{g}_skip"] = sum(1 for u in xs if u["skipped15"] == "1") / len(xs)
    s["incap_pb"] = sum(1 for u in A if u["out"] == "incap") / n
    s["dead_pb"] = sum(1 for u in A if u["out"] == "dead") / n
    s["le15_pb"] = sum(1 for u in A if u["reached_le15"] == "1") / n
    s["skip_pb"] = sum(1 for u in A if u["skipped15"] == "1") / n
    for k in ("turns_lt60", "turns_lt40", "turns_lt20", "delays", "overtaken", "overtaken_by_n", "turns"):
        s[k + "_pb"] = sum(num(u[k]) for u in A) / n
        s["E_" + k + "_pb"] = sum(num(u[k]) for u in E) / n
    s["delay_mean"] = sum(num(u["delay_sum"]) for u in A) / max(1, sum(num(u["delays"]) for u in A))
    for how in ("incap", "dead"):
        xs = [u for u in A if u["out"] == how and u["out_turns_after_hit"] != ""]
        s[f"hit2{how}_turns"] = med(num(u["out_turns_after_hit"]) for u in xs)
        s[f"hit2{how}_turns_mean"] = mean(num(u["out_turns_after_hit"]) for u in xs)
        s[f"hit2{how}_side"] = med(num(u["out_side_turns_after_hit"]) for u in xs)
        s[f"hit2{how}_time"] = med(num(u["out_time"]) - num(u["first_hit_time"]) for u in xs)
        s[f"hit2{how}_n"] = len(xs)
    s["end_time"] = mean(num(b["end_time"]) for b in B)
    s["rounds"] = mean(num(b["rounds"]) for b in B)
    return s


def spiral(U, rank=None):
    """HP帯に入ってからの自分の行動回数・被弾回数・結末。"""
    A = [u for u in ally(U) if rank is None or u["rank"] == rank]
    out = {}
    for b in (40, 30, 20):
        xs = [u for u in A if u[f"b{b}_enter"] == "1"]
        closed = [u for u in xs if u[f"b{b}_out"] in ("dead", "incap")]
        surv = [u for u in xs if u[f"b{b}_out"] == "survived" or u[f"b{b}_out"] == ""]
        t = [num(u[f"b{b}_turns_after"]) for u in closed]
        out[b] = {
            "enter": len(xs), "enter_rate": len(xs) / len(A) if A else 0,
            "closed": len(closed), "survived": len(xs) - len(closed),
            "zero": sum(1 for x in t if x == 0), "one": sum(1 for x in t if x == 1),
            "turns_med": med(t), "turns_mean": mean(t),
            "hits_mean": mean(num(u[f"b{b}_hits_after"]) for u in closed),
            "time_med": med(num(u[f"b{b}_time_to_out"]) for u in closed),
        }
    return out


def build():
    L = []
    # ================= 実験A
    S = {}
    for D in DJ:
        for P in ("P0", "P2"):
            for V in ("A", "S", "I", "SI"):
                B, U = load(f"A_{D}_{P}_{V}")
                if B:
                    S[(D, P, V)] = (B, U, summarize(B, U))
    L.append("## 実験A｜HPシステム検証（前衛HP×1.75・Ver0.6主実験と同じシード・各1,000戦・介入方針は状況判断・HP新仕様は敵味方両方）")
    L.append("\n#### A1 勝率・死亡・戦闘不能（味方。死亡＝HP0、戦闘不能＝HP15%以下で離脱）")
    L.append("| D×P | 条件 | 味方勝率 | 引分 | FRONT死亡率 | FRONT戦闘不能率 | REAR死亡率 | REAR戦闘不能率 | 1戦あたり死亡人数 | 1戦あたり戦闘不能人数 | 敵の死亡率/戦闘不能率 | 戦闘時間(巡) |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for (D, P, V), (B, U, s) in S.items():
        L.append(f"| {DJ[D]}×{P} | {VJ[V]} | {pct(s['win'], 1)} | {pct(s['draw'], 1)} | {pct(s['F_dead'], 1)} | {pct(s['F_incap'], 1)} | "
                 f"{pct(s['R_dead'], 1)} | {pct(s['R_incap'], 1)} | {f2(s['dead_pb'])} | {f2(s['incap_pb'])} | "
                 f"{pct(s['E_dead'], 1)}/{pct(s['E_incap'], 1)} | {f1(s['end_time'])} |")

    L.append("\n#### A2 15%ラインの通過（味方。1戦あたり人数）")
    L.append("| D×P | 条件 | HP15%以下(>0)に到達 | 15%超から一撃でHP0（飛び越え） | 戦闘不能 | 死亡 | 離脱者のうち飛び越え死の割合 |")
    L.append("|---|---|---|---|---|---|---|")
    for (D, P, V), (B, U, s) in S.items():
        tot = s["incap_pb"] + s["dead_pb"]
        L.append(f"| {DJ[D]}×{P} | {VJ[V]} | {f2(s['le15_pb'])} | {f2(s['skip_pb'])} | {f2(s['incap_pb'])} | {f2(s['dead_pb'])} | {pct(s['skip_pb'], tot)} |")

    L.append("\n#### A3 最初の肉体ダメージから離脱まで（味方。中央値。行動機会＝本人の手番数／味方陣営の手番数）")
    L.append("| D×P | 条件 | →戦闘不能: 件数 | 本人の手番 | 味方の手番 | 時間(巡) | →死亡: 件数 | 本人の手番 | 味方の手番 | 時間(巡) |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for (D, P, V), (B, U, s) in S.items():
        L.append(f"| {DJ[D]}×{P} | {VJ[V]} | {s['hit2incap_n']} | {f1(s['hit2incap_turns'])} | {f1(s['hit2incap_side'])} | {f2(s['hit2incap_time'])} | "
                 f"{s['hit2dead_n']} | {f1(s['hit2dead_turns'])} | {f1(s['hit2dead_side'])} | {f2(s['hit2dead_time'])} |")

    L.append("\n#### A4 行動速度低下はどれだけ発動したか（1戦あたり、味方全体／敵全体）")
    L.append("| D×P | 条件 | 味方の手番 | うちHP60%未満 | HP40%未満 | HP20%未満 | 遅延が発生した手番（味方） | 平均遅延(巡) | 遅延で敵に追い越された（味方） | 追い越した敵の行動数 | 遅延（敵） | 敵が味方に追い越された |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for (D, P, V), (B, U, s) in S.items():
        L.append(f"| {DJ[D]}×{P} | {VJ[V]} | {f1(s['turns_pb'])} | {f2(s['turns_lt60_pb'])} | {f2(s['turns_lt40_pb'])} | {f2(s['turns_lt20_pb'])} | "
                 f"{f2(s['delays_pb'])} | {f2(s['delay_mean'])} | {f2(s['overtaken_pb'])} | {f2(s['overtaken_by_n_pb'])} | {f2(s['E_delays_pb'])} | {f2(s['E_overtaken_pb'])} |")

    L.append("\n#### A5 デススパイラル確認: HP帯に入った味方が、その後に離脱（死亡/戦闘不能）するまでに自分で行動できた回数")
    L.append("（「0回」＝その帯に入ってから一度も自分の手番が来ないまま離脱。速度低下なしのA/Cと、ありのB/Dの差が速度低下の寄与）")
    L.append("| D×P | 条件 | 対象 | HP40%以下に入った | うち離脱 | 離脱までの手番 0回 | 1回 | 平均 | 被弾/人 | HP30%以下: 0回 | 平均 | HP20%以下: 入った | 0回 | 平均 | 被弾/人 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for (D, P, V), (B, U, s) in S.items():
        for rk in ("FRONT", "REAR"):
            sp = spiral(U, rk)
            a, c, e = sp[40], sp[30], sp[20]
            L.append(f"| {DJ[D]}×{P} | {VJ[V]} | {rk} | {a['enter']} | {a['closed']} | {pct(a['zero'], a['closed'])} | {pct(a['one'], a['closed'])} | "
                     f"{f2(a['turns_mean'])} | {f2(a['hits_mean'])} | {pct(c['zero'], c['closed'])} | {f2(c['turns_mean'])} | "
                     f"{e['enter']} | {pct(e['zero'], e['closed'])} | {f2(e['turns_mean'])} | {f2(e['hits_mean'])} |")

    # 統制: 味方だけ
    L.append("\n#### A6 統制: HP新仕様を味方だけに掛けた場合（D' ）と敵味方両方（D）")
    L.append("| D×P | 条件 | 味方勝率 | FRONT死亡/戦闘不能 | REAR死亡/戦闘不能 | 敵 死亡/戦闘不能 | 戦闘時間 |")
    L.append("|---|---|---|---|---|---|---|")
    for D in ("D1", "D2"):
        for V in ("A", "SI", "SIa"):
            B, U = load(f"A_{D}_P2_{V}")
            if not B:
                continue
            s = summarize(B, U)
            L.append(f"| {DJ[D]}×P2 | {VJ[V]} | {pct(s['win'], 1)} | {pct(s['F_dead'], 1)}/{pct(s['F_incap'], 1)} | {pct(s['R_dead'], 1)}/{pct(s['R_incap'], 1)} | "
                     f"{pct(s['E_dead'], 1)}/{pct(s['E_incap'], 1)} | {f1(s['end_time'])} |")

    # 敵知能別
    L.append("\n#### A7 敵知能別の味方勝率（D2×P2）")
    L.append("| 条件 | 低 | 通常 | 高 | 戦術 |")
    L.append("|---|---|---|---|---|")
    for V in ("A", "S", "I", "SI"):
        if ("D2", "P2", V) not in S:
            continue
        B = S[("D2", "P2", V)][0]
        cells = []
        for i in "0123":
            bs = [b for b in B if b["enemy_intel"] == i]
            cells.append(pct(sum(1 for b in bs if b["winner"] == "ally"), len(bs)))
        L.append(f"| {VJ[V]} | " + " | ".join(cells) + " |")

    # ================= 実験B
    L.append("\n## 実験B｜EP配分・介入検証（Current AI＝状況判断 vs REAR EP Protection＝比較実験用。前衛HP×1.75・各1,000戦・同一シード）")
    rowsB = []
    for D, P in (("D1", "P0"), ("D1", "P2"), ("D2", "P0"), ("D2", "P2"), ("D3", "P2")):
        for V in ("A", "SI"):
            cur = load(f"A_{D}_{P}_{V}")
            pro = load(f"B_{D}_{P}_{V}_protect")
            if cur[0] and pro[0]:
                rowsB.append((D, P, V, cur, pro))
    L.append("\n#### B1 勝率・死亡・介入（HP新仕様: A=なし／SI=Speed+Incap）")
    L.append("| D×P | HP仕様 | 方針 | 味方勝率 | FRONT死亡 | FRONT戦闘不能 | REAR死亡 | REAR戦闘不能 | 介入/戦 | うちREAR狙い | 最初の介入（敵の何回目の行動） | 前衛の離脱中被弾/戦 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for D, P, V, cur, pro in rowsB:
        for name, (B, U) in (("Current", cur), ("Protect", pro)):
            s = summarize(B, U)
            A = ally(U)
            F = [u for u in A if u["rank"] == "FRONT"]
            fi = [num(b["first_iv_enemy_turns"]) for b in B if b["first_iv_enemy_turns"] != ""]
            L.append(f"| {DJ[D]}×{P} | {V} | {name} | {pct(s['win'], 1)} | {pct(s['F_dead'], 1)} | {pct(s['F_incap'], 1)} | {pct(s['R_dead'], 1)} | {pct(s['R_incap'], 1)} | "
                     f"{f1(mean(num(b['n_iv']) for b in B))} | {f1(mean(num(b['n_iv_rear']) for b in B))} | {f1(mean(fi))}（中央値{f1(med(fi))}） | "
                     f"{f2(sum(num(u['disp_hits']) for u in F) / len(B))} |")

    L.append("\n#### B2 EPの使い道（1戦あたり合計。FRONT=2人、REAR=3人の合計）")
    L.append("| D×P | HP仕様 | 方針 | FRONT 自己防御EP | FRONT 介入防御EP | FRONT EP合計 | REAR 自己防御EP | REAR 魔法EP | REAR EP合計 | FRONTがEP0になった時点（敵行動数・平均） | REARがEP0になった時点（同） | 魔導士がEP0に（到達率） | REAR平均残EP（敵手番ごと） | 戦闘終了時のREAR残EP |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for D, P, V, cur, pro in rowsB:
        for name, (B, U) in (("Current", cur), ("Protect", pro)):
            n = len(B)
            A = ally(U)
            F = [u for u in A if u["rank"] == "FRONT"]
            R = [u for u in A if u["rank"] == "REAR"]
            fs, fi = sum(num(u["ep_self_def"]) for u in F) / n, sum(num(u["ep_iv_def"]) for u in F) / n
            rs, rm = sum(num(u["ep_self_def"]) for u in R) / n, sum(num(u["ep_magic"]) for u in R) / n
            f0 = [num(u["ep0_enemy_turns"]) for u in F if u["ep0_enemy_turns"] != ""]
            mg = [u for u in R if u["role"] == "mage"]
            m0 = sum(1 for u in mg if u["ep0_enemy_turns"] != "")
            r0 = [num(u["ep0_enemy_turns"]) for u in R if u["ep0_enemy_turns"] != ""]
            L.append(f"| {DJ[D]}×{P} | {V} | {name} | {f1(fs)} | {f1(fi)} | {f1(fs + fi)} | {f1(rs)} | {f1(rm)} | {f1(rs + rm)} | "
                     f"{f1(mean(f0))}（到達{pct(len(f0), len(F))}） | {f1(mean(r0))}（到達{pct(len(r0), len(R))}） | {pct(m0, len(mg))} | {f1(mean(num(b['rear_ep_mean']) for b in B))} | "
                     f"{f1(sum(num(u['ep_end']) for u in R) / n)} |")

    L.append("\n#### B3 魔法とチーム与ダメージ（1戦あたり）")
    L.append("| D×P | HP仕様 | 方針 | 攻撃魔法の使用回数 | うち「とどめ」撃ち | 魔法の総与ダメージ | 通常攻撃の総与ダメージ | チーム総与ダメージ | 回復魔法 |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for D, P, V, cur, pro in rowsB:
        for name, (B, U) in (("Current", cur), ("Protect", pro)):
            n = len(B)
            A = ally(U)
            L.append(f"| {DJ[D]}×{P} | {V} | {name} | {f2(sum(num(u['fire']) for u in A) / n)} | {f2(sum(num(u['fire_kill_cast']) for u in A) / n)} | "
                     f"{f1(sum(num(u['fire_dmg']) for u in A) / n)} | {f1(sum(num(u['phys_dmg']) for u in A) / n)} | "
                     f"{f1(sum(num(u['fire_dmg']) + num(u['phys_dmg']) for u in A) / n)} | {f2(sum(num(u['heal']) for u in A) / n)} |")

    L.append("\n#### B4 EP閾値: 前衛の介入で、魔導士が攻撃魔法を撃てるEP（43=魔法15＋温存ライン28）を保てた場面")
    L.append("| D×P | HP仕様 | 方針 | REARが介入で守られた回数/戦 | 温存EP（推定）/戦 | 閾値43を保てた/戦 | とどめ用閾値15を保てた/戦 | 温存がなければ撃てなかった攻撃魔法（推定）/戦 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for D, P, V, cur, pro in rowsB:
        for name, (B, U) in (("Current", cur), ("Protect", pro)):
            n = len(B)
            R = [u for u in ally(U) if u["rank"] == "REAR"]
            L.append(f"| {DJ[D]}×{P} | {V} | {name} | {f2(sum(num(u['protected']) for u in R) / n)} | {f1(sum(num(u['saved_ep_est']) for u in R) / n)} | "
                     f"{f2(sum(num(u['thr_kept_fire']) for u in R) / n)} | {f2(sum(num(u['thr_kept_kill']) for u in R) / n)} | "
                     f"{f2(sum(num(u['fire_enabled_est']) for u in R) / n)} |")

    L.append("\n#### B5 魔導士の判断（1戦あたり）: 撃てるのに温存した手番・前衛の状態別の攻撃魔法の頻度・大消費後の被弾")
    L.append("| D×P | HP仕様 | 方針 | 魔導士の手番 | 撃てるEP(15以上)があるのに温存ラインで見送り | 前衛が介入可能な手番での攻撃魔法率 | 前衛が介入不能（離脱/EP0/離脱済）な手番での攻撃魔法率 | 撃った後EPが1発分を切った | その後EP不足で被弾 |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for D, P, V, cur, pro in rowsB:
        for name, (B, U) in (("Current", cur), ("Protect", pro)):
            n = len(B)
            M = [u for u in ally(U) if u["role"] == "mage"]
            tok, tng = sum(num(u["mage_turns_front_ok"]) for u in M), sum(num(u["mage_turns_front_ng"]) for u in M)
            fok, fng = sum(num(u["fire_front_ok"]) for u in M), sum(num(u["fire_front_ng"]) for u in M)
            L.append(f"| {DJ[D]}×{P} | {V} | {name} | {f2((tok + tng) / n)} | {f2(sum(num(u['held_back']) for u in M) / n)} | {pct(fok, tok)} | {pct(fng, tng)} | "
                     f"{f2(sum(num(u['lowep_after_cast']) for u in M) / n)} | {f2(sum(num(u['hit_unshielded_after_lowep']) for u in M) / n)} |")

    # 補助: 治療魔法
    L.append("\n#### B6 補助（正式結果とは別）: 既存の治療魔法（Ver0.5仕様: 最大HPの35%回復・18EP）を持つ編成 party_v05_C1。HP新仕様なし")
    L.append("| D×P | 方針 | 味方勝率 | FRONT死亡 | REAR死亡 | 回復魔法/戦 | 総回復量/戦 | 攻撃魔法/戦 | 魔法与ダメ/戦 | REAR自己防御EP | FRONT介入防御EP | 治療閾値18を保てた/戦 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for D, P in (("D1", "P2"), ("D2", "P2")):
        for pol in ("situational", "rear_ep_protect"):
            B, U = load(f"Bh_{D}_{P}_A_heal_{pol}")
            if not B:
                continue
            s = summarize(B, U)
            n = len(B)
            A = ally(U)
            F = [u for u in A if u["rank"] == "FRONT"]
            R = [u for u in A if u["rank"] == "REAR"]
            L.append(f"| {DJ[D]}×{P} | {'Current' if pol == 'situational' else 'Protect'} | {pct(s['win'], 1)} | {pct(s['F_dead'], 1)} | {pct(s['R_dead'], 1)} | "
                     f"{f2(sum(num(u['heal']) for u in A) / n)} | {f1(sum(num(u['heal_amt']) for u in A) / n)} | {f2(sum(num(u['fire']) for u in A) / n)} | "
                     f"{f1(sum(num(u['fire_dmg']) for u in A) / n)} | {f1(sum(num(u['ep_self_def']) for u in R) / n)} | {f1(sum(num(u['ep_iv_def']) for u in F) / n)} | "
                     f"{f2(sum(num(u['thr_kept_heal']) for u in R) / n)} |")
    return "\n".join(L)


if __name__ == "__main__":
    print(build())
