"""Ver0.6 統制実験: HP/EP交換率と、同じ攻撃を受け続けたときの耐久（戦闘AIを介さない。PA-52）

対象: アデル（前衛HP×1.5 → 最大HP195・EP50）とセレスティア（最大HP70・EP100）
攻撃: 狼の爪（威力の期待値21）。乱数なしの期待値で計算する。
"""
from __future__ import annotations

import math
from types import SimpleNamespace as NS

from ..config_loader import load_battle_config
from ..rules.combat_math import make_defense

PS = (("P0", 0.0), ("P1", 0.5), ("P2", 1.0), ("P3", 2.0))
DS = (("D1", 1.0), ("D1.5", 1.5), ("D2", 2.0), ("D3", 3.0))
UNITS = (("アデル（前衛・最大HP195・EP50）", 195, 50), ("セレスティア（後衛・最大HP70・EP100）", 70, 100))
HIT = 21.0


def _defense(p):
    cfg = load_battle_config(rules="rules_v06.yaml")
    a = dict(cfg.rules["aether_defense"])
    a["exponent"] = p
    return make_defense(a)


def _u(H, hp, ep):
    return NS(hp=hp, ep=ep, d=NS(hp_max=H, ep_max=ep))


def wound_table():
    L = ["#### X1 負傷補正 W（HP100%のときの必要EPを1とした倍率。全モデルともHP100%で同じ効率）",
         "| 現在HP | " + " | ".join(f"{n}（p={p}）" for n, p in PS) + " |", "|---|" + "---|" * len(PS)]
    for h in (1.0, 0.75, 0.5, 0.25, 0.10):
        L.append(f"| {h:.0%} | " + " | ".join(f"×{(h ** -p):.2f}" for _, p in PS) + " |")
    return "\n".join(L)


def exchange_table():
    L = ["#### X2 HP/EP交換率: 狼の一撃（威力21）を「生身で受けたときのHP減少」と「完全防御に必要なEP」",
         "| 対象 | 現在HP | 生身HP減少 D1 / D1.5 / D2 / D3 | 必要EP P0 | P1 | P2 | P3 |", "|---|---|---|---|---|---|---|"]
    for name, H, EP in UNITS:
        for h in (1.0, 0.75, 0.5, 0.25):
            u = _u(H, max(1, round(H * h)), EP)
            body = " / ".join(f"{HIT * d:.0f}" for _, d in DS)
            eps = [f"{math.ceil(_defense(p).required_ep(u, HIT) - 1e-9)}" for _, p in PS]
            L.append(f"| {name.split('（')[0]} | {h:.0%} | {body} | " + " | ".join(eps) + " |")
    L.append("")
    L.append("#### X3 「生身なら100HPになる攻撃」を健康時に防ぎ切るのに必要なEP")
    L.append("| 対象 | D1 | D1.5 | D2 | D3 |")
    L.append("|---|---|---|---|---|")
    for name, H, EP in UNITS:
        u = _u(H, H, EP)
        d0 = _defense(0.0)
        L.append(f"| {name} | " + " | ".join(f"{d0.required_ep(u, 100 / d):.1f}" for _, d in DS) + " |")
    L.append("（D倍率が高いほど「100HP相当」の攻撃の威力は小さく、防ぐのに必要なEPも少ない。"
             "＝生身が脆い世界ほど、EPの価値が相対的に高い）")
    return "\n".join(L)


def endurance(H, EP, start_ratio, D, p):
    """同じ一撃を受け続ける: EPがある限り防御（完全→部分）、なくなれば生身。"""
    d = _defense(p)
    u = _u(H, max(1, round(H * start_ratio)), EP)
    full = partial = body = 0
    first_body = None
    hits = 0
    while u.hp > 0 and hits < 500:
        hits += 1
        if u.ep > 0:
            hp_f, spent, blocked, mode = d.resolve(u, HIT)
            u.ep -= spent
            if mode == "full":
                full += 1
                continue
            partial += 1
        else:
            hp_f = HIT
            body += 1
        dmg = round(hp_f * D)
        if first_body is None and dmg > 0:
            first_body = hits
        u.hp -= dmg
    return {"full": full, "partial": partial, "body": body, "hits": hits, "after_first": hits - (first_body or hits)}


def endurance_table():
    L = ["#### X4 同じ一撃を受け続けた場合（EP満タンから）: 完全防御できた回数 ／ 部分防御 ／ 生身で耐えた回数 → 死亡までの総被弾数",
         "| 対象 | 開始HP | D | " + " | ".join(n for n, _ in PS) + " |", "|---|---|---|" + "---|" * len(PS)]
    for name, H, EP in UNITS:
        for h in (1.0, 0.75, 0.5, 0.25):
            for dn, D in DS:
                cells = []
                for _, p in PS:
                    r = endurance(H, EP, h, D, p)
                    cells.append(f"{r['full']}/{r['partial']}/{r['body']}→{r['hits']}")
                L.append(f"| {name.split('（')[0]} | {h:.0%} | {dn} | " + " | ".join(cells) + " |")
    L.append("")
    L.append("#### X5 EPなし（生身のみ）で、HP100%から何発で死ぬか")
    L.append("| 対象 | D1 | D1.5 | D2 | D3 |")
    L.append("|---|---|---|---|---|")
    for name, H, EP in UNITS:
        L.append(f"| {name} | " + " | ".join(str(math.ceil(H / round(HIT * D))) for _, D in DS) + " |")
    return "\n".join(L)


if __name__ == "__main__":
    print(wound_table())
    print()
    print(exchange_table())
    print()
    print(endurance_table())
