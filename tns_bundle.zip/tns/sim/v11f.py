"""Ver0.11 3FRONT・2REAR × 炎嵐詠唱 比較（PA-140）。ルール・AIは変更なし。編成だけを変える。
編成: old = 2FRONT・3REAR（party_v08）／center・L・R = 3FRONT・2REAR（弓手→前衛3。前衛3の受け持ち経路だけが違う）
python -m tns.sim.v11f [form ...]
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..formation.route import blocker_is_holding
from ..model.enums import Reach, Side
from .v09 import seeds

OUT = Path("out/v11f")
FORMS = {"old": "party_v08", "center": "party_v08_3f_center", "L": "party_v08_3f_L", "R": "party_v08_3f_R"}
CASTS = (0, 2, 4, 6)
POLS = {"v11": ("v11", None), "never": ("v9", "never_iv")}


def build(form, n, pol, seed, intel, enc="wolves_5v5", suffix=""):
    rules = (f"rules_v09_q058_f85_incap4{suffix}.yaml" if n == 0 else f"rules_v09_q058_f85_incap4_cast{n}{suffix}.yaml")
    cfg = load_battle_config(party=FORMS[form], encounter=enc, rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    hm, probe = POLS[pol]
    ally = ValueAllyController(cfg.ally_policies, probe=probe, hole_model=hm)
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)}, seed=seed, enemy_intel=intel)
    return eng, ally


def _one(job):
    form, n, pol, seed, intel = job[:5]
    enc = job[5] if len(job) > 5 else "wolves_5v5"
    suffix = job[6] if len(job) > 6 else ""
    eng, ally = build(form, n, pol, seed, intel, enc, suffix)
    cel = eng.u("celestia")
    fronts = [u for u in eng.state.units.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    E, C = [], Counter()
    st = {"cast": None, "pending": None}

    def close():
        p = st["pending"]
        if p is not None:
            E.append(("target", p))
            st["pending"] = None

    def lis(ev, e):
        t = ev["t"]
        idx = e.action_index
        if t == "turn_start":
            close()
            casting = "celestia" in e.casting
            hold = sum(1 for f in fronts if blocker_is_holding(f))
            E.append(("sample", {"idx": idx, "ep": cel.ep, "hp": cel.hp, "casting": int(casting), "hold": hold}))
            if casting and st["cast"] is not None:
                st["cast"]["hold"][hold] += 1
        elif t == "cast_start" and ev["unit"] == "celestia":
            st["cast"] = {"idx": idx, "hp": cel.hp, "ep": cel.ep, "iv_by": set(), "tg": 0, "raw_hits": 0, "melee_reach": 0,
                          "hold": Counter(), "dmg_taken": 0}
            E.append(("cast_start", {"idx": idx, "hp": cel.hp, "ep": cel.ep}))
        elif t in ("cast_complete", "cast_cancel", "cast_fail") and ev["unit"] == "celestia":
            c = st["cast"] or {"iv_by": set(), "tg": 0, "raw_hits": 0, "melee_reach": 0, "hold": Counter(), "dmg_taken": 0, "idx": idx}
            if t != "cast_complete":
                close()
            E.append(("cast_end", {"idx": idx, "kind": t, "reason": ev.get("reason"), "start": c["idx"],
                                   "n_iv_fronts": len(c["iv_by"]), "iv_list": sorted(c["iv_by"]), "tg": c["tg"], "raw_hits": c["raw_hits"],
                                   "melee_reach": c["melee_reach"], "dmg": c["dmg_taken"],
                                   "hold": {str(k): v for k, v in c["hold"].items()}}))
            st["cast"] = None
        elif t == "attack_declared":
            a, tg = e.u(ev["unit"]), e.u(ev["target"])
            if a.side is Side.ENEMY and tg.id == "celestia":
                close()
                casting = "celestia" in e.casting
                st["pending"] = {"idx": idx, "attacker": a.id, "casting": int(casting), "hp": cel.hp, "ep": cel.ep,
                                 "window": 0, "iv_by": None, "dmg": 0, "hp_after": cel.hp, "melee": int(ev["reach"] == "MELEE"),
                                 "via": ev.get("via_route"), "hold": sum(1 for f in fronts if blocker_is_holding(f))}
                if casting and st["cast"] is not None:
                    st["cast"]["tg"] += 1
            elif a.id == "celestia" and ev["action"] == "fire":
                E.append(("spend", {"idx": idx, "cat": "攻撃魔法", "ep": 15}))
        elif t == "intrusion":
            tg = e.u(ev["target"])
            if tg.side is Side.ALLY:
                casting = "celestia" in e.casting
                C["intr"] += 1
                C["intr_cast"] += int(casting)
                C["intr_by_iv"] += int(ev.get("caused_by") is not None)
                if tg.id == "celestia":
                    C["intr_cel"] += 1
                    C["intr_cel_cast"] += int(casting)
                    if casting and st["cast"] is not None:
                        st["cast"]["melee_reach"] += 1
        elif t == "area_attack" and ev["unit"] == "celestia":
            E.append(("spend", {"idx": idx, "cat": "炎嵐", "ep": 40}))
            E.append(("storm", {"idx": idx}))
        elif t == "heal" and ev["unit"] == "celestia":
            E.append(("spend", {"idx": idx, "cat": "治療", "ep": ev.get("ep_cost", 0) or 0}))
        elif t == "intervention_window" and ev["target"] == "celestia" and st["pending"]:
            st["pending"]["window"] = 1
        elif t == "intervened" and e.u(ev["unit"]).side is Side.ALLY:
            C[f"iv_{ev['unit']}_{ev['target']}"] += 1
            if "celestia" in e.casting:
                C[f"ivcast_{ev['unit']}_{ev['target']}"] += 1
            if ev["target"] == "celestia" and st["pending"]:
                st["pending"]["iv_by"] = ev["unit"]
                if st["pending"]["casting"] and st["cast"] is not None:
                    st["cast"]["iv_by"].add(ev["unit"])
        elif t == "damage":
            u, a = e.u(ev["unit"]), e.u(ev["attacker"])
            if u.id == "celestia" and a.side is Side.ENEMY:
                sp = ev.get("ep_spent", 0) or 0
                if sp:
                    E.append(("spend", {"idx": idx, "cat": "自衛", "ep": sp}))
                p = st["pending"]
                if p is not None:
                    p["dmg"] += ev.get("dmg", 0) or 0
                    p["hp_after"] = cel.hp
                if st["cast"] is not None and "celestia" in e.casting and (ev.get("dmg", 0) or 0) > 0:
                    st["cast"]["raw_hits"] += 1
                    st["cast"]["dmg_taken"] += ev["dmg"]
            if u.side is Side.ENEMY and a.side is Side.ALLY and a.id != "celestia":
                d, sp = ev.get("dmg", 0) or 0, ev.get("ep_spent", 0) or 0
                C["phys_dmg"] += d
                C[f"phys_dmg_{a.id}"] += d
                C["phys_enemy_ep"] += sp
                C["phys_hits"] += 1
                if idx <= 20:
                    C["phys_dmg_early"] += d
                    C["phys_enemy_ep_early"] += sp
            if u.side is Side.ENEMY and a.id == "celestia":
                C["mag_dmg"] += ev.get("dmg", 0) or 0
                C["mag_enemy_ep"] += ev.get("ep_spent", 0) or 0
    eng.listeners.append(lis)
    eng.run()
    close()
    al = [u for u in eng.state.units.values() if u.side is Side.ALLY]
    nf = sum(1 for u in al if u.rank.value == "FRONT")
    nr = sum(1 for u in al if u.rank.value == "REAR")
    return {"form": form, "n": n, "pol": pol, "seed": seed, "intel": intel, "win": int(eng.stats.winner == "ally"),
            "N": eng.action_index, "rounds": eng.stats.rounds, "end_ep": cel.ep, "nf": nf, "nr": nr,
            "dead_F": sum(1 for u in al if u.rank.value == "FRONT" and u.hp <= 0),
            "incap_F": sum(1 for u in al if u.rank.value == "FRONT" and u.incapacitated),
            "dead_R": sum(1 for u in al if u.rank.value == "REAR" and u.hp <= 0),
            "incap_R": sum(1 for u in al if u.rank.value == "REAR" and u.incapacitated),
            "cel_dead": int(cel.hp <= 0), "cel_incap": int(cel.incapacitated),
            "iv_rear": sum(1 for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR" and r["choice"] != "self"),
            "C": dict(C), "E": E}


def run(forms=None):
    OUT.mkdir(parents=True, exist_ok=True)
    S = seeds("q058_f85")
    for form in forms or FORMS:
        for n in CASTS:
            for pol in POLS:
                path = OUT / f"{form}_cast{n}_{pol}.jsonl"
                if path.exists():
                    print("skip", path, flush=True)
                    continue
                with ProcessPoolExecutor(os.cpu_count() or 2) as ex:
                    R = list(ex.map(_one, [(form, n, pol, s, i) for s, i in S], chunksize=20))
                with open(path, "w", encoding="utf-8") as fh:
                    for r in R:
                        fh.write(json.dumps(r, ensure_ascii=False) + "\n")
                print("done", path, round(sum(r["win"] for r in R) / len(R), 3), flush=True)


if __name__ == "__main__":
    run(sys.argv[1:] or None)
