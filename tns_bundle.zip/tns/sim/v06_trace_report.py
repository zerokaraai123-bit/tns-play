"""v06_trace の集計表。 python -m tns.sim.v06_trace_report > out/v06_trace_tables.md"""
from __future__ import annotations

import csv
import statistics
from collections import defaultdict

DJ = {"D1": "D1", "D15": "D1.5", "D2": "D2", "D3": "D3"}
IJ = {"0": "低", "1": "通常", "2": "高", "3": "戦術"}


def load(p):
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def pct(a, b):
    return f"{a / b:.1%}" if b else "-"


def funnel(E):
    n = len(E)
    g = lambda k: sum(1 for e in E if k(e))
    r = {"n": n}
    r["pre_ep0"] = g(lambda e: num(e["pre_ep"]) <= 0)
    r["iv_ep_left"] = g(lambda e: num(e["post_iv_ep"]) > 0)
    r["disp_hit"] = g(lambda e: num(e["disp_hits"]) > 0)
    r["disp_hit_ep"] = g(lambda e: num(e["disp_hits"]) > 0 and num(e["post_iv_ep"]) > 0)
    for k in ("w75", "w50", "w25"):
        r[k] = g(lambda e, k=k: e[k] == "1")
        r[k + "_events"] = sum(int(num(e[k + "_n"]) or 0) for e in E)
    r["returned"] = g(lambda e: e["returned"] == "1")
    r["ret_ep"] = g(lambda e: e["returned"] == "1" and num(e.get("ret_ep")) and num(e["ret_ep"]) > 0)
    r["ret_wounded_ep"] = g(lambda e: e["returned"] == "1" and (num(e.get("ret_ep")) or 0) > 0 and (num(e.get("ret_hp_ratio")) or 1) <= 0.75)
    for o in ("USED", "A", "B", "C", "D", "E"):
        r["o_" + o] = g(lambda e, o=o: e["outcome"] == o)
    used = [e for e in E if e["outcome"] == "USED"]
    r["used_wounded"] = sum(1 for e in used if (num(e.get("post_hp_ratio")) or 1) < 0.999)
    r["used_W_gt_1_1"] = sum(1 for e in used if (num(e.get("post_W")) or 1) > 1.1)
    r["used_extra_ep"] = sum(1 for e in used if (num(e.get("post_extra_ep_by_P")) or 0) > 0)
    r["used_extra_ep_sum"] = sum((num(e.get("post_extra_ep_by_P")) or 0) for e in used)
    r["used_pierce_by_P"] = sum(1 for e in used if e.get("post_pierce_by_P") == "1")
    r["used_via_iv"] = sum(1 for e in used if e.get("post_via_intervention") == "1")
    r["d_reasons"] = defaultdict(int)
    for e in E:
        if e["outcome"] == "D":
            r["d_reasons"][e.get("post_reason", "")] += 1
    return r


def build():
    E = load("out/v06_trace_episodes.csv")
    H = load("out/v06_trace_hits.csv")
    by = defaultdict(list)
    for e in E:
        by[(e["D"], e["P"])].append(e)
    L = []
    L.append("#### T1 介入エピソードの流れ（前衛HP×1.75・状況判断。1エピソード＝前衛の介入1回）")
    L.append("| D×P | 介入数 | 介入時EP0 | 介入の一撃後もEP残存 | 離脱中に生身被弾 | うちEPを持ったまま被弾 | HP75%以下＋EP残存 | HP50%以下＋EP残存 | HP25%以下＋EP残存 | 復帰 | 復帰時EP残存 | 復帰時に負傷(≤75%)＋EP残存 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    tot = defaultdict(float)
    for D in DJ:
        for P in ("P0", "P1", "P2", "P3"):
            r = funnel(by[(D, P)])
            n = r["n"]
            for k, v in r.items():
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    tot[k] += v
            L.append(f"| {DJ[D]}×{P} | {n} | {pct(r['pre_ep0'], n)} | {pct(r['iv_ep_left'], n)} | {pct(r['disp_hit'], n)} | {pct(r['disp_hit_ep'], n)} | "
                     f"{r['w75']}（{pct(r['w75'], n)}） | {r['w50']}（{pct(r['w50'], n)}） | {r['w25']}（{pct(r['w25'], n)}） | "
                     f"{pct(r['returned'], n)} | {pct(r['ret_ep'], n)} | {pct(r['ret_wounded_ep'], n)} |")
    n = tot["n"]
    L.append(f"| **全体** | {n:.0f} | {pct(tot['pre_ep0'], n)} | {pct(tot['iv_ep_left'], n)} | {pct(tot['disp_hit'], n)} | {pct(tot['disp_hit_ep'], n)} | "
             f"{tot['w75']:.0f}（{pct(tot['w75'], n)}） | {tot['w50']:.0f}（{pct(tot['w50'], n)}） | {tot['w25']:.0f}（{pct(tot['w25'], n)}） | "
             f"{pct(tot['returned'], n)} | {pct(tot['ret_ep'], n)} | {pct(tot['ret_wounded_ep'], n)} |")
    L.append("（「HP○%以下＋EP残存」は、介入後〜復帰までの間に一度でもその状態になったエピソードの数）")

    L.append("\n#### T2 復帰後にエーテル防御を使えたか（全エピソードの行き先）")
    L.append("| D×P | 使用した | A 復帰前に死亡 | B 復帰したがEP0 | C 復帰・EPありだが以後攻撃されず | D 復帰・EPあり・攻撃されたが防御せず | E その他（復帰前に戦闘終了） |")
    L.append("|---|---|---|---|---|---|---|")
    for D in DJ:
        for P in ("P0", "P1", "P2", "P3"):
            r = funnel(by[(D, P)])
            n = r["n"]
            L.append(f"| {DJ[D]}×{P} | " + " | ".join(pct(r['o_' + o], n) for o in ("USED", "A", "B", "C", "D", "E")) + " |")
    L.append(f"| **全体** | " + " | ".join(pct(tot['o_' + o], tot['n']) for o in ("USED", "A", "B", "C", "D", "E")) + " |")
    reasons = defaultdict(int)
    for D in DJ:
        for P in ("P0", "P1", "P2", "P3"):
            for k, v in funnel(by[(D, P)])["d_reasons"].items():
                reasons[k] += v
    L.append("D（防御しなかった）の理由の内訳: " + "、".join(f"{k or '不明'} {v}件" for k, v in sorted(reasons.items(), key=lambda x: -x[1])))

    L.append("\n#### T3 復帰後に防御を使った場面で、負傷補正Pはどれだけ効いたか")
    L.append("| D×P | 使用した件数 | うち負傷した体での使用 | うち補正倍率W>1.1 | 補正で余分にEPを払った件数 | 余分なEPの合計 | 補正のせいで完全防御→部分防御になった件数 | 使用が再介入の一撃だった件数 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for D in DJ:
        for P in ("P0", "P1", "P2", "P3"):
            r = funnel(by[(D, P)])
            u = r["o_USED"]
            L.append(f"| {DJ[D]}×{P} | {u} | {r['used_wounded']}（{pct(r['used_wounded'], u)}） | {r['used_W_gt_1_1']} | {r['used_extra_ep']} | {r['used_extra_ep_sum']:.0f} | {r['used_pierce_by_P']} | {r['used_via_iv']} |")
    L.append(f"| **全体** | {tot['o_USED']:.0f} | {tot['used_wounded']:.0f}（{pct(tot['used_wounded'], tot['o_USED'])}） | {tot['used_W_gt_1_1']:.0f} | {tot['used_extra_ep']:.0f} | {tot['used_extra_ep_sum']:.0f} | {tot['used_pierce_by_P']:.0f} | {tot['used_via_iv']:.0f} |")

    # 被弾ごと
    L.append("\n#### T4 自己防御不能中の生身被弾（1件ずつ）: 被弾時にEPが残っていたか、被弾直後のHP、次の一撃を防ぐ必要EP")
    L.append("| D×P | 被弾数 | EPが残っていた | うち被弾直後HP≤50% | 死亡 | 被弾直後HP（中央値） | 次の一撃を防ぐ必要EP: 中央値（無傷時の値） | EP残存時の残EP（中央値） |")
    L.append("|---|---|---|---|---|---|---|---|")
    byh = defaultdict(list)
    for h in H:
        byh[(h["D"], h["P"])].append(h)
    for D in DJ:
        for P in ("P0", "P1", "P2", "P3"):
            hs = byh[(D, P)]
            if not hs:
                continue
            ep_left = [h for h in hs if num(h["ep"]) > 0]
            ep50 = [h for h in ep_left if num(h["hp_ratio_after"]) <= 0.5]
            died = sum(1 for h in hs if h["died"] == "1")
            hp_med = statistics.median(num(h["hp_ratio_after"]) for h in hs)
            needs = [num(h["need_next_ep"]) for h in hs if num(h["need_next_ep"]) is not None]
            full = statistics.median(num(h["need_next_ep_full_hp"]) for h in hs)
            eps = [num(h["ep"]) for h in ep_left]
            L.append(f"| {DJ[D]}×{P} | {len(hs)} | {len(ep_left)}（{pct(len(ep_left), len(hs))}） | {len(ep50)} | {died}（{pct(died, len(hs))}） | {hp_med:.0%} | "
                     f"{statistics.median(needs) if needs else '-':.0f}（{full:.0f}） | {statistics.median(eps) if eps else '-'} |")

    # 知能別
    L.append("\n#### T5 敵知能別（全D×P合算）")
    L.append("| 敵知能 | 介入数 | 離脱中に生身被弾 | HP50%以下＋EP残存 | 復帰時に負傷＋EP残存 | 使用した | A | B | C | D | E | 補正で余分にEPを払った件数 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    byi = defaultdict(list)
    for e in E:
        byi[e["enemy_intel"]].append(e)
    for i in "0123":
        r = funnel(byi[i])
        n = r["n"]
        L.append(f"| {IJ[i]} | {n} | {pct(r['disp_hit'], n)} | {r['w50']}（{pct(r['w50'], n)}） | {pct(r['ret_wounded_ep'], n)} | "
                 + " | ".join(pct(r['o_' + o], n) for o in ("USED", "A", "B", "C", "D", "E")) + f" | {r['used_extra_ep']} |")

    # T6 B の内訳と各時点の中央値
    L.append("\n#### T6 B（復帰したがEP0）の内訳と、各時点のHP・EP（中央値）")
    L.append("| D×P | B件数 | うち介入時点で既にEP0 | うち介入の一撃でEPを使い切った | うち離脱中の被弾でEP0に | 介入直前 HP%/EP | 介入で使ったEP（使った場合） | 介入直後 HP%/EP | 復帰時 HP%/EP（復帰した場合） |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    med = lambda xs: statistics.median(xs) if xs else float('nan')
    for D in DJ:
        for P in ("P0", "P1", "P2", "P3"):
            es = by[(D, P)]
            B = [e for e in es if e["outcome"] == "B"]
            b0 = sum(1 for e in B if num(e["pre_ep"]) <= 0)
            b1 = sum(1 for e in B if num(e["pre_ep"]) > 0 and num(e["post_iv_ep"]) <= 0)
            b2 = len(B) - b0 - b1
            hm = lambda k: med([num(e[k]) / num(e["hp_max"]) for e in es if num(e.get(k)) is not None])
            em = lambda k: med([num(e[k]) for e in es if num(e.get(k)) is not None])
            used = med([num(e["iv_ep_used"]) for e in es if (num(e["iv_ep_used"]) or 0) > 0])
            L.append(f"| {DJ[D]}×{P} | {len(B)} | {b0}（{pct(b0, len(B))}） | {b1}（{pct(b1, len(B))}） | {b2}（{pct(b2, len(B))}） | "
                     f"{hm('pre_hp'):.0%}/{em('pre_ep'):.0f} | {used:.0f} | {hm('post_iv_hp'):.0%}/{em('post_iv_ep'):.0f} | {hm('ret_hp'):.0%}/{em('ret_ep'):.0f} |")

    # T7 知能×D
    L.append("\n#### T7 敵知能×D（P合算）: HP50%以下＋EP残存の発生率 ／ 使用率 ／ B率")
    L.append("| D | 低 | 通常 | 高 | 戦術 |")
    L.append("|---|---|---|---|---|")
    byid = defaultdict(list)
    for e in E:
        byid[(e["D"], e["enemy_intel"])].append(e)
    for D in DJ:
        cells = []
        for i in "0123":
            r = funnel(byid[(D, i)])
            cells.append(f"{pct(r['w50'], r['n'])} ／ {pct(r['o_USED'], r['n'])} ／ {pct(r['o_B'], r['n'])}")
        L.append(f"| {DJ[D]} | " + " | ".join(cells) + " |")
    return "\n".join(L), tot


if __name__ == "__main__":
    s, tot = build()
    print(s)
