"""Ver0.5 統制実験「同じ崩壊状態からの救出」（PA-47）

戦闘AIの判断を介さず、防御式だけで「順番の差」を測る。
  ・崩れた前衛1人（最大HP H、現在HP = r×H、EP 0）に、標準の一撃（期待値21、±10%）が毎手番1発ずつ来る
  ・味方は「行動①」→ 一撃 →「行動②」→ 以後は一撃のみ、の順で2回だけ手当てできる
  ・本人はEPがあれば必ず防御を展開する（完全防御優先、足りなければ部分防御）
比較: なし / 治療のみ / 補給のみ / 治療→補給 / 補給→治療（後の2つは治療量・補給量・行動回数・被弾タイミングが完全に同一）
測定: 手当て開始から死亡までに耐えた被弾数（＝救えた戦闘時間）、補給EPで防いだダメージ、再崩壊までの被弾数
"""
from __future__ import annotations

import random
from types import SimpleNamespace as NS

from ..config_loader import load_battle_config
from ..rules.combat_math import make_defense

HIT = 21.0          # 狼の爪の期待値
VAR = 0.10
MAX_HITS = 200


def _unit(H, r, ep_max=50):
    return NS(hp=max(1, int(round(H * r))), ep=0, d=NS(hp_max=H, ep_max=ep_max))


def simulate(defense, H, r, order, heal_ratio, supply, rng=None, std_hit=20.0):
    """order: none / heal / supply / heal_supply / supply_heal"""
    u = _unit(H, r)
    steps = {"none": [None, None], "heal": ["H", None], "supply": ["S", None],
             "heal_supply": ["H", "S"], "supply_heal": ["S", "H"]}[order]
    sup_blocked = 0.0
    sup_left = 0
    hits = 0
    recollapse = None
    recovered = False

    def act(kind):
        nonlocal sup_left
        if kind == "H":
            u.hp = min(H, u.hp + int(round(heal_ratio * H)))
        elif kind == "S":
            add = min(supply, u.d.ep_max - u.ep)
            u.ep += add
            sup_left += add

    def hit():
        nonlocal sup_blocked, sup_left
        raw = HIT * (rng.uniform(1 - VAR, 1 + VAR) if rng else 1.0)
        if u.ep > 0:
            hp_f, spent, blocked, _ = defense.resolve(u, raw)
            # 初期EPは0なので、消費EPはすべて補給分
            sup_blocked += blocked * min(spent, sup_left) / spent if spent else 0.0
            sup_left = max(0, sup_left - spent)
            u.ep -= spent
        else:
            hp_f = raw
        u.hp -= int(round(hp_f))

    def collapsed():
        return u.hp < 0.5 * H or u.ep < defense.required_ep(u, std_hit)

    def recovered_now():
        return u.hp >= 0.5 * H and u.ep >= 2 * defense.required_ep(u, std_hit)

    act(steps[0])
    if recovered_now():
        recovered = True
    while u.hp > 0 and hits < MAX_HITS:
        hit()
        hits += 1
        if u.hp <= 0:
            break
        if hits == 1 and steps[1]:
            act(steps[1])
        if recovered_now():
            recovered = True
        if recovered and recollapse is None and collapsed() and hits > 1:
            recollapse = hits
    return {"hits": hits, "sup_blocked": sup_blocked, "recovered": recovered,
            "recollapse": recollapse if recollapse is not None else hits}


def run(models=(("p=0（悪化なし）", "rules_v05_M_p0.yaml"), ("p=0.585", "rules_v05_M_p585.yaml"), ("p=1（主条件）", "rules_v05_M.yaml")),
        H=195, ratios=(0.8, 0.5, 0.35, 0.2), levels=(("S", 0.20, 15), ("M", 0.35, 30)), trials=2000, seed=7):
    out = []
    for mname, rfile in models:
      for hmax in ((H,) if isinstance(H, (int, float)) else H):
        cfg = load_battle_config(rules=rfile)
        d = make_defense(cfg.rules["aether_defense"])
        std = cfg.rules.get("v05", {}).get("standard_hit", 20)
        for lv, hr, sp in levels:
            for r in ratios:
                row = {"model": mname, "level": lv, "hp_ratio": r, "H": hmax}
                for order in ("none", "heal", "supply", "heal_supply", "supply_heal"):
                    det = simulate(d, hmax, r, order, hr, sp, None, std)
                    rng = random.Random(seed)
                    sims = [simulate(d, hmax, r, order, hr, sp, rng, std) for _ in range(trials)]
                    row[f"{order}_hits_det"] = det["hits"]
                    row[f"{order}_hits"] = sum(s["hits"] for s in sims) / trials
                    row[f"{order}_supblock"] = sum(s["sup_blocked"] for s in sims) / trials
                    row[f"{order}_recovered"] = sum(s["recovered"] for s in sims) / trials
                    row[f"{order}_recollapse"] = sum(s["recollapse"] for s in sims) / trials
                out.append(row)
    return out


def supply_value_table(H=195, supply=30, ratios=(1.0, 0.8, 0.5, 0.35, 0.2)):
    """⑭: 同じEPを健康な体／負傷した体に補給したとき、何ダメージ分防げるか（理論値 = EP ÷ cpd）。"""
    rows = []
    for mname, rfile in (("p=0（悪化なし）", "rules_v05_M_p0.yaml"), ("p=0.585", "rules_v05_M_p585.yaml"),
                         ("p=1（主条件）", "rules_v05_M.yaml")):
        d = make_defense(load_battle_config(rules=rfile).rules["aether_defense"])
        for r in ratios:
            u = _unit(H, r)
            rows.append({"model": mname, "hp_ratio": r, "blockable": supply / d.required_ep(u, 1.0)})
    return rows


def report(rows, sv) -> str:
    L = ["### 統制実験A: 同じEP30を補給したとき防げるダメージ（理論値、前衛HP195＝×1.5のアデル）",
         "| 補給時のHP | " + " | ".join(sorted({r['model'] for r in sv}, key=lambda m: m[0:3])) + " |", "|---|---|---|---|"]
    models = []
    for r in sv:
        if r["model"] not in models:
            models.append(r["model"])
    for hr in sorted({r["hp_ratio"] for r in sv}, reverse=True):
        cells = [f"{next(x for x in sv if x['model'] == m and x['hp_ratio'] == hr)['blockable']:.0f}" for m in models]
        L.append(f"| {hr:.0%} | " + " | ".join(cells) + " |")
    L[1] = "| 補給時のHP | " + " | ".join(models) + " |"
    L.append("")
    L.append("### 統制実験B: 崩壊した前衛（EP0）を2行動で救う。耐えた被弾数（2000試行平均、カッコ内は乱数なしの値）")
    L.append("| 式 | 最大HP | 量 | 崩壊時HP | 何もしない | 治療のみ | 補給のみ | **治療→補給** | **補給→治療** | 差（治療→補給 − 補給→治療） | 補給EPで防いだダメージ 治療→補給 / 補給→治療 |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        c = lambda o: f"{r[o + '_hits']:.2f}（{r[o + '_hits_det']}）"
        diff = r["heal_supply_hits"] - r["supply_heal_hits"]
        L.append(f"| {r['model']} | {r['H']} | {r['level']} | {r['hp_ratio']:.0%} | {c('none')} | {c('heal')} | {c('supply')} | "
                 f"{c('heal_supply')} | {c('supply_heal')} | {diff:+.2f} | {r['heal_supply_supblock']:.1f} / {r['supply_heal_supblock']:.1f} |")
    return "\n".join(L)


def per_action_table(rows) -> str:
    """⑮ 1行動あたり「救えた戦闘時間」（何もしない場合より余分に耐えた被弾数 ÷ 使った行動数）。"""
    L = ["### 統制実験C: 1行動あたり救えた被弾数（p=1・主条件。治療のみ/補給のみは1行動、両方は2行動）",
         "| 最大HP | 量 | 崩壊時HP | 治療のみ | 補給のみ | 治療→補給（2行動） | 補給→治療（2行動） |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        if not r["model"].startswith("p=1"):
            continue
        base = r["none_hits"]
        L.append(f"| {r['H']} | {r['level']} | {r['hp_ratio']:.0%} | {r['heal_hits'] - base:.2f} | {r['supply_hits'] - base:.2f} | "
                 f"{(r['heal_supply_hits'] - base) / 2:.2f} | {(r['supply_heal_hits'] - base) / 2:.2f} |")
    return "\n".join(L)


if __name__ == "__main__":
    rows = run(H=(195, 70))
    print(report(rows, supply_value_table()))
    print()
    print(per_action_table(rows))
