"""Ver0.15 の集計（表と図）。python -m tns.sim.v15_report"""
from __future__ import annotations

import json
import math
from pathlib import Path

OUT = Path("out/v15")
BLUE, ORANGE, GRAY = "#2a78d6", "#eb6834", "#8a8984"
SURF, INK, INK2 = "#fcfcfb", "#0b0b0b", "#52514e"


def load(name):
    p = OUT / name
    if not p.exists():
        return {}
    d = {}
    for line in p.read_text().splitlines():
        r = json.loads(line)
        d[r["name"]] = r
    return d


def paired(c, b):
    n = min(len(c["wins"]), len(b["wins"]))
    xs = [c["wins"][i] - b["wins"][i] for i in range(n)]
    m = sum(xs) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / max(n - 1, 1))
    return 100 * m, 100 * 1.96 * sd / math.sqrt(n), n


def ci(p, n):
    return 100 * 1.96 * math.sqrt(p * (1 - p) / n)


def setup_plt():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for f in font_manager.findSystemFonts():
        if "NotoSansCJK" in f:
            font_manager.fontManager.addfont(f)
    plt.rcParams["font.family"] = ["Noto Sans CJK JP", "sans-serif"]
    plt.rcParams.update({"axes.edgecolor": GRAY, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
                         "figure.facecolor": SURF, "axes.facecolor": SURF, "text.color": INK})
    return plt


ACTS = [("adel", "slash", "アデル 斬撃"), ("adel", "dive", "アデル 突撃"),
        ("vanguard", "slash", "前衛2 斬撃"), ("vanguard", "pin", "前衛2 牽制"),
        ("vanguard3", "slash", "前衛3 斬撃"), ("vanguard3", "hold", "前衛3 死守"), ("vanguard3", "push", "前衛3 押し返す"),
        ("celestia", "fire", "セレスティア 攻撃魔法"), ("celestia", "storm", "セレスティア 炎嵐"),
        ("celestia", "heal", "セレスティア 治療"), ("celestia", "wait", "セレスティア 待機"),
        ("toolsmith", "maintain", "学者 応急整備"), ("toolsmith", "observe", "学者 観測"), ("toolsmith", "wait", "学者 待機"),
        ("wolf_a", "claw", "狼A 爪撃"), ("wolf_a", "pin", "狼A 牽制"), ("wolf_c", "claw", "狼C 爪撃"), ("wolf_c", "pin", "狼C 牽制"),
        ("wolf_b", "claw", "狼B 爪撃"), ("wolf_b", "flank", "狼B 回り込み"),
        ("leader", "leap", "リーダー 跳躍襲撃"), ("leader", "howl", "リーダー 遠吠え"),
        ("shaman", "hex", "呪術師 呪雷"), ("shaman", "curse", "呪術師 大呪（詠唱開始）")]


def usage_table(S):
    rows = []
    for uid, aid, label in ACTS:
        used = S.get(f"act_{uid}_{aid}", 0.0)
        if aid == "curse":
            used = S.get("cast_start_shaman", 0.0)
        if aid == "storm":
            used = S.get("cast_start_celestia", 0.0)
        av = S.get(f"c_v15_avail_{aid}_{uid}")
        rate = f"{100 * used / av:.0f}%" if av else "—"
        rows.append(f"| {label} | {used:.2f} | {av:.2f} | {rate} |" if av else f"| {label} | {used:.2f} | — | — |")
    return "\n".join(["| 行動 | 1戦あたり使用 | 使える状態だった手番 | 使った割合 |", "|---|---|---|---|"] + rows)


def branch_stats(path, K=40):
    """分岐分析の集計。K回の計算でも出てしまう「偶然の差」（乱数だけの場合の最大−最小）も同時に見積もる。"""
    import random
    p = OUT / path
    if not p.exists():
        return None
    pts = [json.loads(l) for l in p.read_text().splitlines()]
    if not pts:
        return None
    rng = random.Random(1)
    rows = []
    for r in pts:
        ps = [x["p"] for x in r["res"]]
        if len(ps) < 2:
            continue
        sp = max(ps) - min(ps)
        m = sum(ps) / len(ps)
        sims = []
        for _ in range(300):
            q = [sum(1 for _ in range(K) if rng.random() < m) / K for _ in ps]
            sims.append(max(q) - min(q))
        null = sum(sims) / len(sims)
        pb, pw = max(ps), min(ps)
        pbar = (pb + pw) / 2
        se = math.sqrt(max(pbar * (1 - pbar), 1e-9) * 2 / K)
        z = (pb - pw) / se if se > 0 else 0.0
        ai = next((x["p"] for x in r["res"] if list(x["alt"]) == list(r["ai"])), None)
        rows.append(dict(kind=r["kind"], sp=sp, null=null, z=z, regret=(pb - ai) if ai is not None else None,
                         r=r, nalt=len(ps)))
    n = len(rows)
    def agg(sel):
        if not sel:
            return None
        return dict(n=len(sel), sp=sum(x["sp"] for x in sel) / len(sel), null=sum(x["null"] for x in sel) / len(sel),
                    sig=sum(1 for x in sel if x["z"] >= 3.0) / len(sel),
                    big=sum(1 for x in sel if x["z"] >= 3.0 and x["sp"] >= 0.25) / len(sel))
    regs = [x["regret"] for x in rows if x["regret"] is not None]
    sigs = sorted([x for x in rows if x["z"] >= 3.0], key=lambda x: -x["sp"])
    return dict(n=n, all=agg(rows), action=agg([x for x in rows if x["kind"] == "action"]),
                iv=agg([x for x in rows if x["kind"] == "intervention"]),
                regret=sum(regs) / max(len(regs), 1), sig_rows=sigs, rows=rows, K=K)


def main():
    E1 = load("E1.jsonl")
    E = load("E234.jsonl")
    lines = []
    plt = setup_plt()
    base = E1.get("E1_intel1")
    # ---------------- E1
    lines.append("## 知能別の勝率（各1,000戦）\n")
    lines.append("| 敵の知能 | 勝率 | 95%の幅 | 戦闘時間（T） | 1戦の行動数 |\n|---|---|---|---|---|")
    for i, nmj in enumerate(("低知能", "通常", "高知能", "戦術級")):
        r = E1.get(f"E1_intel{i}")
        if r:
            lines.append(f"| {nmj} | {100 * r['win']:.1f}% | ±{ci(r['win'], r['n']):.1f} | {r['S']['time']:.1f} | {r['S']['actions']:.0f} |")
    if base:
        S = base["S"]
        lines.append("\n## 行動の使用率（通常知能・1,000戦）\n")
        lines.append(usage_table(S))
        lines.append("\n## 大呪と突撃（通常知能・1戦あたり）\n")
        lines.append(f"- 大呪の詠唱開始 {S.get('cast_start_shaman', 0):.2f} 回／完成 {S.get('cast_done_shaman', 0):.2f}／"
                     f"中断（呪術師が倒れた）{S.get('cast_cancel_shaman', 0):.3f}")
        lines.append(f"- 大呪の与ダメ（HP）{S.get('curse_dmg', 0):.1f}・削ったEP {S.get('curse_ep', 0):.1f}")
        lines.append(f"- 突撃 {S.get('c_v15_dive_ally', 0):.2f} 回（薄い経路を通った {S.get('c_v15_dive_thin_ally', 0):.2f}・"
                     f"介入で止められた {S.get('c_v15_dive_intercepted_ally', 0):.2f}・詠唱中の相手へ {S.get('c_v15_dive_on_casting_ally', 0):.2f}）")
        lines.append(f"- 後衛への通常の近接（持ち場を離れる）味方 {S.get('c_v15_rear_melee_ally', 0):.2f}・敵 {S.get('c_v15_rear_melee_enemy', 0):.2f}")
        lines.append(f"- 回り込み {S.get('c_v15_flank_enemy', 0):.3f}（使える状態だった手番 {S.get('c_v15_avail_flank_wolf_b', 0):.2f}）")
        lines.append(f"- 観測 {S.get('act_toolsmith_observe', 0):.2f} 回 → 固定どおり実行 {S.get('fixed_exec', 0):.2f}・成立せず {S.get('fixed_broken', 0):.3f}")
        lines.append(f"- 遠吠え {S.get('act_leader_howl', 0):.2f} 回（指名された標的への群れの攻撃 {S.get('c_v15_howl_hit_enemy', 0):.2f} 回）")
        lines.append(f"- 介入 味方 {S.get('iv_ally', 0):.2f}・敵 {S.get('iv_enemy', 0):.2f}")
    # ---------------- E2
    if base and E:
        lines.append("\n## 能力値の効き（通常知能・各500戦・同じseedで比較）\n")
        lines.append("| 変えたもの | 勝率 | 基準との差（ポイント） | 95%の幅 |\n|---|---|---|---|")
        rows = []
        for side, sj in (("ally", "味方"), ("enemy", "敵")):
            for st, stj in (("power", "威力・魔法"), ("speed", "速度"), ("hp", "HP")):
                for f in (1.1, 0.9):
                    r = E.get(f"E2_{side}_{st}{f}")
                    if not r:
                        continue
                    d, w, n = paired(r, base)
                    rows.append((f"{sj}全員の{stj} {'+10%' if f > 1 else '−10%'}", d, w))
                    lines.append(f"| {sj}全員の{stj} {'+10%' if f > 1 else '−10%'} | {100 * r['win']:.1f}% | {d:+.1f} | ±{w:.1f} |")
        lb = E.get("E2_linear_base")
        if lb:
            lines.append(f"\n比較（ダメージを従来の比例式に戻した場合）: 基準 {100 * lb['win']:.1f}%\n")
            lines.append("| 変えたもの（比例式） | 勝率 | 比例式の基準との差 | 95%の幅 |\n|---|---|---|---|")
            for side, sj in (("ally", "味方"), ("enemy", "敵")):
                for f in (1.1, 0.9):
                    r = E.get(f"E2_linear_{side}_power{f}")
                    if r:
                        d, w, n = paired(r, lb)
                        lines.append(f"| {sj}全員の威力・魔法 {'+10%' if f > 1 else '−10%'} | {100 * r['win']:.1f}% | {d:+.1f} | ±{w:.1f} |")
        # 図
        if rows:
            fig, ax = plt.subplots(figsize=(7.2, 4.2))
            labels = [r[0] for r in rows][::-1]
            vals = [r[1] for r in rows][::-1]
            errs = [r[2] for r in rows][::-1]
            ax.barh(range(len(vals)), vals, xerr=errs, color=[BLUE if v >= 0 else ORANGE for v in vals],
                    error_kw={"ecolor": GRAY, "lw": 1}, height=0.6)
            ax.axvline(0, color=GRAY, lw=1)
            for x in (-10, 10):
                ax.axvline(x, color=GRAY, lw=0.8, ls="--")
            ax.set_yticks(range(len(vals)))
            ax.set_yticklabels(labels, fontsize=9)
            ax.set_xlabel("勝率の変化（ポイント）　点線＝目標の±10")
            ax.set_title("Ver0.15 能力値1割の効き（通常知能）", fontsize=11)
            for s in ("top", "right"):
                ax.spines[s].set_visible(False)
            fig.tight_layout()
            fig.savefig("RESULTS_v15_stat_sensitivity.png", dpi=150)
            plt.close(fig)
    # ---------------- E3
    if base and E:
        lines.append("\n## 行動を抜いたら弱くなるか（通常知能・各500戦）\n")
        lines.append("味方の行動を抜いて勝率が下がる＝その行動は役に立っている。敵の行動を抜いて味方の勝率が上がる＝敵にとって役に立っている。\n")
        lines.append("| 抜いた行動 | 味方の勝率 | 基準との差 | 95%の幅 |\n|---|---|---|---|")
        names = {"-dive": "味方: 突撃", "-pin": "味方: 牽制", "-push": "味方: 押し返す", "-hold": "味方: 死守",
                 "-observe": "味方: 観測", "-maintain": "味方: 応急整備", "E-pin": "敵: 牽制", "E-flank": "敵: 回り込み",
                 "E-howl": "敵: 遠吠え", "E-curse": "敵: 大呪", "E-hex": "敵: 呪雷"}
        for k, j in names.items():
            r = E.get("E3_" + k)
            if r:
                d, w, n = paired(r, base)
                lines.append(f"| {j} | {100 * r['win']:.1f}% | {d:+.1f} | ±{w:.1f} |")
    # ---------------- E4
    if E1 and E:
        lines.append("\n## 観測固定（各500戦）\n")
        lines.append("| 条件 | 勝率 | AI（観測あり・release）との差 | 95%の幅 |\n|---|---|---|---|")
        for i in (1, 3):
            b = E1.get(f"E1_intel{i}")
            for k, j in (("never", "観測しない"), ("lose", "観測あり・成立しなければ手番を失う（lose）")):
                r = E.get(f"E4_i{i}_{k}")
                if r and b:
                    d, w, n = paired(r, b)
                    lines.append(f"| 知能{i} {j} | {100 * r['win']:.1f}% | {d:+.1f} | ±{w:.1f} |")
    # ---------------- E5
    bs = branch_stats("E5c_branch.jsonl", K=40)
    if bs:
        a = bs["all"]
        lines.append("\n## 判断の効き（分岐分析・通常知能）\n")
        lines.append(f"- 判断点 {bs['n']} 個（行動 {bs['action']['n'] if bs['action'] else 0}・介入 {bs['iv']['n'] if bs['iv'] else 0}）。"
                     f"各判断点で、選択肢ごとに{bs['K']}回ずつ最後まで計算した（分岐した時点から乱数を振り直す）。")
        lines.append("- 「待機」は、AIが待機を選んだ場合を除いて選択肢から外した（明らかに悪い手で差を大きく見せないため）。")
        lines.append("- 注意: 選択肢ごとの勝率は有限回の計算なので、本当は差がなくても偶然の差が出る。その「偶然だけの場合の差」も並べた。")
        lines.append("\n| 判断の種類 | 判断点 | 最善と最悪の差（平均） | 偶然だけの場合の差 | はっきりした差がある判断点 | そのうち25ポイント以上 |\n|---|---|---|---|---|---|")
        for key, nmj in (("all", "全部"), ("iv", "庇うかどうか"), ("action", "行動")):
            g = bs[key]
            if g:
                lines.append(f"| {nmj} | {g['n']} | {100 * g['sp']:.1f} | {100 * g['null']:.1f} | {100 * g['sig']:.0f}% | {100 * g['big']:.0f}% |")
        lines.append("\n（はっきりした差 = 最善と最悪の差が、偶然のばらつきの3倍以上）")
        lines.append(f"\n- AIの後悔（最善 − AIの選択）: 平均 {100 * bs['regret']:.1f} ポイント（偶然の差を含む）")
        if bs["sig_rows"]:
            lines.append("\nはっきりした差が出た判断点の例:\n")
            NM = {"adel": "アデル", "vanguard": "前衛2", "vanguard3": "前衛3", "celestia": "セレスティア", "toolsmith": "学者",
                  "wolf_a": "狼A", "wolf_b": "狼B", "wolf_c": "狼C", "leader": "リーダー", "shaman": "呪術師", None: "庇わない"}
            AN = {"slash": "斬撃", "dive": "突撃", "pin": "牽制", "push": "押し返す", "hold": "死守", "fire": "攻撃魔法",
                  "storm": "炎嵐", "heal": "治療", "wait": "待機", "observe": "観測", "maintain": "応急整備"}
            def alt_txt(kind, alt):
                if kind == "intervention":
                    return f"{NM.get(alt[1], alt[1])}が庇う" if alt[1] else "庇わない"
                return f"{AN.get(alt[0], alt[0])}" + (f"→{NM.get(alt[1], alt[1])}" if alt[1] else "")
            for x in bs["sig_rows"][:6]:
                r = x["r"]
                who = NM.get(r["unit"], r["unit"])
                head = f"{who}への攻撃に介入するか" if r["kind"] == "intervention" else f"{who}の行動"
                opts = "／".join(f"{alt_txt(r['kind'], y['alt'])} {100 * y['p']:.0f}%" for y in r["res"])
                ai = alt_txt(r["kind"], r["ai"])
                lines.append(f"- 戦闘{r['seed']}・T{r['t']:.1f}・{head}: {opts}（AIの選択: {ai}）")
        cats = [(k, j) for k, j in (("iv", "庇うかどうか"), ("action", "行動"), ("all", "全部")) if bs[k]]
        fig, ax = plt.subplots(figsize=(7.2, 3.8))
        xs = range(len(cats))
        ob = [100 * bs[k]["sp"] for k, _ in cats]
        nu = [100 * bs[k]["null"] for k, _ in cats]
        ax.bar([x - 0.2 for x in xs], ob, width=0.38, color=BLUE, label="実際の差（最善−最悪）")
        ax.bar([x + 0.2 for x in xs], nu, width=0.38, color=GRAY, label="偶然だけでも出る差")
        for x, v in zip(xs, ob):
            ax.text(x - 0.2, v + 0.8, f"{v:.0f}", ha="center", fontsize=9, color=INK)
        for x, v in zip(xs, nu):
            ax.text(x + 0.2, v + 0.8, f"{v:.0f}", ha="center", fontsize=9, color=INK2)
        ax.set_xticks(list(xs))
        ax.set_xticklabels([j for _, j in cats])
        ax.set_ylabel("勝率の差（ポイント）")
        ax.set_title(f"Ver0.15 判断1つの効き（通常知能・{bs['n']}判断点・各{bs['K']}回）", fontsize=11)
        ax.legend(frameon=False, fontsize=9)
        for sp_ in ("top", "right"):
            ax.spines[sp_].set_visible(False)
        fig.tight_layout()
        fig.savefig("RESULTS_v15_decision_impact.png", dpi=150)
        plt.close(fig)
    Path("out/v15/report_tables.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
