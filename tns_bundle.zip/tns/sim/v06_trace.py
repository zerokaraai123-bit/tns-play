"""Ver0.6 追跡調査: 介入した前衛の「自己防御不能中の生身被弾」と、その後の防御復帰を1件ずつ追う。

既存のVer0.6の戦闘を、同じシード・同じ設定で再実行し（結果は完全に一致することを確認済み）、
エンジンのイベントを外から聞き取るだけで記録する。ルール・AI・数値は一切変更しない。

使い方: python -m tns.sim.v06_trace   → out/v06_trace_episodes.csv, out/v06_trace_hits.csv, out/v06_trace_tables.md
"""
from __future__ import annotations

import csv
import math
import os
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..config_loader import load_battle_config
from ..model.enums import Side
from .csv_export import write_csv
from .runner import make_engine

DS = ("D1", "D15", "D2", "D3")
PS = ("P0", "P1", "P2", "P3")
STD_RAW = 21.0          # 狼の爪の期待値（「次の攻撃」の想定）


class Tracer:
    """1戦ぶんのイベントを聞き取り、介入エピソードを組み立てる。"""

    def __init__(self, eng):
        self.eng = eng
        self.episodes = []          # 完了したエピソード
        self.open = {}              # unit_id -> 進行中エピソード
        self.post = {}              # unit_id -> 復帰後の観察中エピソード
        self.pending_iv = {}        # unit_id -> 介入直前の状態（次の damage がその介入の一撃）
        self.hits = []

    # ---------- helpers
    def W(self, u, hp=None):
        d = self.eng.defense
        hp = u.hp if hp is None else hp
        p = d._p(u)
        return (max(hp, 1) / u.d.hp_max) ** (-p)

    def need(self, u, hp, raw=STD_RAW):
        d = self.eng.defense
        save = u.hp
        try:
            u.hp = max(hp, 1)
            return math.ceil(d.required_ep(u, raw) - 1e-9)
        finally:
            u.hp = save

    # ---------- event handler
    def __call__(self, ev, eng):
        t = ev["t"]
        if t == "intervened":
            u = eng.u(ev["unit"])
            if u.side is not Side.ALLY or u.rank.value != "FRONT":
                return
            # 前のエピソードの復帰後観察が続いていれば、「次に受けた攻撃」はこの介入の一撃になる
            self.pending_iv[u.id] = {"pre_hp": u.hp, "pre_ep": u.ep}
            return
        if t == "damage":
            uid = ev["unit"]
            u = eng.u(uid)
            if u.side is not Side.ALLY or u.rank.value != "FRONT":
                return
            dmg, hp_after, ep_after, spent = ev["dmg"], ev["hp"], ev["ep"], ev.get("ep_spent", 0) or 0
            hp_before, ep_before = hp_after + dmg, ep_after + spent
            # 1) 復帰後の観察中なら、最初の被弾で結論を出す
            if uid in self.post:
                ep_ = self.post.pop(uid)
                ep_["post_hit"] = 1
                ep_["post_via_intervention"] = int(uid in self.pending_iv)   # 復帰後最初の被弾が、再び介入して受けた一撃だった
                ep_["post_defense"] = int(bool(ev["defense"]))
                ep_["post_mode"] = ev.get("mode", "")
                ep_["post_reason"] = ev.get("defense_reason", "")
                ep_["post_hp_before"], ep_["post_ep_before"] = hp_before, ep_before
                ep_["post_hp_ratio"] = round(hp_before / u.d.hp_max, 3)
                if ev["defense"]:
                    W = self.W(u, hp_before)
                    raw = ev["raw"]
                    need_p = self.need(u, hp_before, raw)
                    need_p0 = math.ceil(need_p / W - 1e-9) if W > 0 else need_p
                    ep_["post_W"] = round(W, 3)
                    ep_["post_need"] = need_p
                    ep_["post_need_p0"] = need_p0
                    ep_["post_ep_spent"] = spent
                    ep_["post_extra_ep_by_P"] = max(0, min(spent, need_p) - min(spent, need_p0))
                    # 補正がなければ完全防御できたのに、補正のせいで部分防御になった
                    ep_["post_pierce_by_P"] = int(ev.get("mode") == "partial" and ep_before >= need_p0)
                    ep_["post_dmg"] = dmg
                self._close(ep_)
            # 2) 介入の一撃
            if uid in self.pending_iv:
                pre = self.pending_iv.pop(uid)
                ep_ = {"unit": uid, "hp_max": u.d.hp_max, "ep_max": u.d.ep_max,
                       "pre_hp": pre["pre_hp"], "pre_ep": pre["pre_ep"],
                       "iv_defense": int(bool(ev["defense"])), "iv_mode": ev.get("mode", ""),
                       "iv_ep_used": spent, "iv_dmg": dmg, "post_iv_hp": hp_after, "post_iv_ep": ep_after,
                       "disp_hits": 0, "disp_dmg": 0, "returned": 0, "died_displaced": 0,
                       "w75": 0, "w50": 0, "w25": 0, "w75_n": 0, "w50_n": 0, "w25_n": 0,
                       "round": ev["round"]}
                self._mark_wounded(ep_, hp_after, ep_after)
                self.open[uid] = ep_
                if hp_after <= 0:
                    ep_["died_displaced"] = 1
                    ep_["outcome"] = "A"
                    self._finish_open(uid)
                return
            # 3) 自己防御不能中（介入後・復帰前）の被弾
            if uid in self.open:
                ep_ = self.open[uid]
                ep_["disp_hits"] += 1
                ep_["disp_dmg"] += dmg
                self.hits.append({"unit": uid, "round": ev["round"], "hit_no": ep_["disp_hits"],
                                  "hp_before": hp_before, "hp_after": hp_after, "hp_ratio_after": round(hp_after / u.d.hp_max, 3),
                                  "ep": ep_after, "dmg": dmg, "raw": round(ev["raw"], 1),
                                  "need_next_ep": self.need(u, hp_after) if hp_after > 0 else "",
                                  "need_next_ep_full_hp": self.need(u, u.d.hp_max),
                                  "W_after": round(self.W(u, hp_after), 3) if hp_after > 0 else "",
                                  "defense_reason": ev.get("defense_reason", ""), "died": int(hp_after <= 0)})
                self._mark_wounded(ep_, hp_after, ep_after)
                if hp_after <= 0:
                    ep_["died_displaced"] = 1
                    ep_["outcome"] = "A"
                    self._finish_open(uid)
            return
        if t == "stance":
            uid = ev["unit"]
            if uid in self.open and ev["new"] == "READY":
                u = eng.u(uid)
                ep_ = self.open.pop(uid)
                ep_["returned"] = 1
                ep_["ret_hp"], ep_["ret_ep"] = u.hp, u.ep
                ep_["ret_hp_ratio"] = round(u.hp / u.d.hp_max, 3)
                ep_["ret_need_next"] = self.need(u, u.hp)
                ep_["ret_W"] = round(self.W(u), 3)
                self._mark_wounded(ep_, u.hp, u.ep)
                if u.ep <= 0:
                    ep_["outcome"] = "B"
                    self._close(ep_)
                else:
                    self.post[uid] = ep_          # 次の被弾まで観察
            return
        if t == "battle_end":
            for uid in list(self.open):
                ep_ = self.open.pop(uid)
                ep_["outcome"] = "E"              # 復帰前に戦闘終了
                ep_["note"] = "復帰前に戦闘終了"
                self._close(ep_)
            for uid in list(self.post):
                ep_ = self.post.pop(uid)
                ep_["outcome"] = "C"              # 復帰しEPもあったが、以後攻撃されなかった
                self._close(ep_)

    def _mark_wounded(self, ep_, hp, ep):
        if ep <= 0 or hp <= 0:
            return
        r = hp / ep_["hp_max"]
        for th, k in ((0.75, "w75"), (0.5, "w50"), (0.25, "w25")):
            if r <= th:
                ep_[k] = 1
                ep_[k + "_n"] += 1

    def _finish_open(self, uid):
        ep_ = self.open.pop(uid)
        self._close(ep_)

    def _close(self, ep_):
        if "outcome" not in ep_:
            if ep_.get("post_defense"):
                ep_["outcome"] = "USED"
            else:
                reason = ep_.get("post_reason", "")
                ep_["outcome"] = "D" if reason else "E"
        self.episodes.append(ep_)


def _one(args):
    tag, rules, seed, policy, intel = args
    cfg = load_battle_config(party="party_v05_C0", rules=rules, ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    eng = make_engine(cfg, seed, policy, intel)
    tr = Tracer(eng)
    eng.listeners.append(tr)
    eng.run()
    D, P = tag.split("_")[:2]
    meta = {"D": D, "P": P, "enemy_intel": intel, "seed": seed, "winner": eng.stats.winner}
    return [dict(meta, **e) for e in tr.episodes], [dict(meta, **h) for h in tr.hits]


def run(out_dir="out", workers=None):
    jobs = []
    for D in DS:
        for P in PS:
            tag = f"{D}_{P}_x1.75"
            path = Path(out_dir) / f"wolves_5v5_v6s1_{tag}_battles.csv"
            with open(path, encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    jobs.append((tag, f"rules_v06_{D}_{P}.yaml", int(r["seed"]), r["policy"], int(r["enemy_intel"])))
    workers = workers or max(1, os.cpu_count() or 2)
    eps, hits = [], []
    with ProcessPoolExecutor(workers) as ex:
        for e, h in ex.map(_one, jobs, chunksize=50):
            eps += e
            hits += h
    write_csv(Path(out_dir) / "v06_trace_episodes.csv", eps)
    write_csv(Path(out_dir) / "v06_trace_hits.csv", hits)
    return eps, hits, len(jobs)


if __name__ == "__main__":
    eps, hits, n = run()
    print(n, "battles", len(eps), "episodes", len(hits), "displaced hits")
