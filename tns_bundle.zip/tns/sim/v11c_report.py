"""炎嵐・詠唱実験の集計。 python -m tns.sim.v11c_report > out/v11c/report.md"""
from __future__ import annotations

import json
import math
import random
import statistics as stt
from collections import Counter, defaultdict

from .v11c import OUT
from .v11_timeline import NAME

PN = {"v11": "Ver0.11介入AI", "v11c": "詠唱価値を認識する介入AI", "never": "Never"}
BN = ["0〜20%", "20〜40%", "40〜60%", "60〜80%", "80〜100%"]


def load(n, p):
    path = OUT / f"cast{n}_{p}.jsonl"
    return {(r["seed"], r["intel"]): r for r in map(json.loads, open(path, encoding="utf-8"))} if path.exists() else None


def mean(x):
    x = list(x)
    return sum(x) / len(x) if x else float("nan")


def pair(A, B):
    d = [A[k]["win"] - B[k]["win"] for k in A]
    n = len(d); m = sum(d) / n; sd = math.sqrt(sum((x - m) ** 2 for x in d) / (n - 1))
    return "%+.1f（z=%.1f）" % (m * 100, m / (sd / math.sqrt(n)) if sd else 0)


def binof(p):
    return min(4, int(p * 5))


def ev(r, kind):
    return [e for k, e in r["E"] if k == kind]


def ep_at(r, p):
    lim = p * r["N"]
    ep = 100
    for k, e in r["E"]:
        if k == "sample":
            if e["idx"] <= lim:
                ep = e["ep"]
            else:
                break
    return ep if p < 1 else r["end_ep"]


def cast_at(r, p):
    lim = p * r["N"]
    c = 0
    for k, e in r["E"]:
        if k == "sample":
            if e["idx"] <= lim:
                c = e["casting"]
            else:
                break
    return c


def summarize(R, n):
    N = len(R)
    s = {}
    s["win"] = mean(r["win"] for r in R.values()) * 100
    s["T"] = mean(r["rounds"] for r in R.values())
    s["N"] = mean(r["N"] for r in R.values())
    for k, d in (("dead_F", 2), ("incap_F", 2), ("dead_R", 3), ("incap_R", 3), ("cel_dead", 1), ("cel_incap", 1)):
        s[k] = mean(r[k] for r in R.values()) / d * 100
    starts = [e for r in R.values() for e in ev(r, "cast_start")]
    done = [e for r in R.values() for e in ev(r, "cast_complete")]
    canc = [e for r in R.values() for e in ev(r, "cast_cancel")]
    s["starts"], s["done"] = len(starts) / N, len(done) / N
    s["cancel_incap"] = sum(1 for e in canc if e["reason"] == "戦闘不能") / N
    s["cancel_dead"] = sum(1 for e in canc if e["reason"] == "死亡") / N
    s["fail_ep"] = sum(len(ev(r, "cast_fail")) for r in R.values()) / N
    s["unfinished"] = mean(r["unfinished"] for r in R.values())
    s["storms"] = sum(len(ev(r, "storm")) for r in R.values()) / N
    s["cast_actions"] = mean(e["actions"] - 1 for e in done) if done else 0.0
    s["cast_ext"] = (s["cast_actions"] - n) if done else 0.0
    # timings
    def first(kind, j, key="idx"):
        x = []
        for r in R.values():
            L = ev(r, kind)
            if len(L) > j:
                x.append((L[j]["idx"] / r["N"], L[j]["idx"]))
        return x
    for lab, kind, j in (("s1", "cast_start", 0), ("f1", "storm", 0), ("s2", "cast_start", 1), ("f2", "storm", 1)):
        x = first(kind, j)
        s[lab] = (len(x) / N, mean(v[0] for v in x) * 100 if x else float("nan"), mean(v[1] for v in x) if x else float("nan"))
    # spend
    sp = Counter()
    for r in R.values():
        for e in ev(r, "spend"):
            sp[e["cat"]] += e["ep"]
    for c in ("炎嵐", "攻撃魔法", "治療", "自衛"):
        s["ep_" + c] = sp[c] / N
    s["end_ep"] = mean(r["end_ep"] for r in R.values())
    def below(r, th):
        for k, e in r["E"]:
            if k == "sample" and e["ep"] < th:
                return e["idx"] / r["N"]
        return 1.0
    s["ep15"] = mean(below(r, 15) for r in R.values()) * 100
    # targeting during cast
    T = [e for r in R.values() for e in ev(r, "target")]
    TC = [e for e in T if e["casting"]]
    s["tg_cast"] = len(TC) / N
    s["tg_all"] = len(T) / N
    s["tg_cast_iv"] = sum(1 for e in TC if e["iv_by"]) / N
    s["tg_cast_noiv"] = sum(1 for e in TC if not e["iv_by"]) / N
    body = [e for e in TC if not e["iv_by"] and e["dmg"] > 0]
    s["tg_cast_body"] = len(body) / N
    s["body_dmg"] = mean(e["dmg"] for e in body) if body else 0.0
    s["body_hp_before"] = mean(e["hp"] for e in body) if body else 0.0
    s["body_hp_after"] = mean(e["hp_after"] if e["hp_after"] is not None else e["hp"] for e in body) if body else 0.0
    s["body_delay"] = mean(e["delay"] for e in body) if body else 0.0
    s["tg_cast_ivrate"] = (sum(1 for e in TC if e["iv_by"]) / len(TC) * 100) if TC else float("nan")
    s["tg_cast_window"] = (sum(1 for e in TC if e["window"]) / len(TC) * 100) if TC else float("nan")
    # ①〜⑥: per cast
    casts_with_iv = [e for e in done + canc if e.get("iv", 0) > 0]
    s["c_iv_total"] = len(casts_with_iv) / N
    s["c_iv_done_clean"] = sum(1 for e in done if e.get("iv", 0) > 0 and not e.get("hits")) / N
    s["c_iv_done"] = sum(1 for e in done if e.get("iv", 0) > 0) / N
    s["c_hit_done"] = sum(1 for e in done if e.get("hits")) / N
    s["c_hit_cancel"] = sum(1 for e in canc if e.get("hits") or e.get("tg", 0) > 0) / N
    s["cel_iv"] = sum(1 for e in T if e["iv_by"]) / N
    s["iv_rear"] = mean(r["iv_rear"] for r in R.values())
    return s


def timeline(R):
    pts = [0, .2, .4, .6, .8, 1.0]
    N = len(R)
    out = {"ep": [mean(ep_at(r, p) for r in R.values()) for p in pts],
           "cast": [mean(cast_at(r, p) for r in R.values()) * 100 for p in pts[:-1]]}
    for key, kind, cond in (("storm", "storm", None), ("tg", "target", None), ("iv", "target", "iv")):
        c = Counter()
        for r in R.values():
            for e in ev(r, kind):
                if cond == "iv" and not e["iv_by"]:
                    continue
                c[binof(e["idx"] / r["N"])] += 1
        out[key] = [c[b] / N for b in range(5)]
    return out


def main():
    D = {(n, p): load(n, p) for n in (0, 2, 4, 6) for p in PN}
    D = {k: v for k, v in D.items() if v}
    S = {k: summarize(v, k[0]) for k, v in D.items()}
    L = ["## 1. 勝率と戦闘全体（同一シード1,000戦）\n",
         "| 詠唱 | 方針 | 勝率 | Never比 | 詠唱0比 | 戦闘時間（巡） | 総行動数 | FRONT 死亡/戦闘不能 | REAR 死亡/戦闘不能 | セレスティア 死亡/戦闘不能 |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    for (n, p), s in sorted(S.items()):
        nv = pair(D[n, p], D[n, "never"]) if p != "never" else "–"
        z0 = pair(D[n, p], D[0, p if p != "v11c" else "v11"]) if n else "–"
        L.append(f"| {n}行動 | {PN[p]} | {s['win']:.1f}% | {nv} | {z0} | {s['T']:.1f} | {s['N']:.1f} | {s['dead_F']:.0f}% / {s['incap_F']:.0f}% | "
                 f"{s['dead_R']:.0f}% / {s['incap_R']:.0f}% | {s['cel_dead']:.0f}% / {s['cel_incap']:.0f}% |")
    L.append("\n## 2. 炎嵐（1戦あたり）\n")
    L.append("| 詠唱 | 方針 | 詠唱開始 | 発動成功 | キャンセル（戦闘不能/死亡） | EP不足で失敗 | 終了時に詠唱中 | 実際の詠唱（行動数） | 負傷による延長 | 1回目 開始→発動（進行度） | 2回目 開始→発動（進行度・発生率） |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for (n, p), s in sorted(S.items()):
        L.append(f"| {n}行動 | {PN[p]} | {s['starts']:.2f} | {s['storms']:.2f} | {s['cancel_incap']:.3f} / {s['cancel_dead']:.3f} | {s['fail_ep']:.3f} | "
                 f"{s['unfinished']*100:.1f}% | {s['cast_actions']:.2f} | +{s['cast_ext']:.2f} | "
                 f"{s['s1'][1]:.0f}%→{s['f1'][1]:.0f}%（行動{s['s1'][2]:.1f}→{s['f1'][2]:.1f}） | "
                 f"{s['s2'][1]:.0f}%→{s['f2'][1]:.0f}%（{s['f2'][0]*100:.0f}%の戦闘） |")
    L.append("\n## 3. 詠唱中の被弾（1戦あたり）\n")
    L.append("| 詠唱 | 方針 | 狙われた（全体） | うち詠唱中 | 詠唱中に介入できた | 詠唱中に介入した（割合） | 介入なし | 生身で被弾 | 被弾ダメ | HP 前→後 | 遅れ（行動数/回） |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for (n, p), s in sorted(S.items()):
        if n == 0:
            continue
        L.append(f"| {n}行動 | {PN[p]} | {s['tg_all']:.2f} | {s['tg_cast']:.2f} | {s['tg_cast_window']:.0f}% | {s['tg_cast_iv']:.2f}（{s['tg_cast_ivrate']:.0f}%） | "
                 f"{s['tg_cast_noiv']:.2f} | {s['tg_cast_body']:.2f} | {s['body_dmg']:.1f} | {s['body_hp_before']:.0f}→{s['body_hp_after']:.0f} | {s['body_delay']:.2f} |")
    L.append("\n**介入と詠唱の関係（①〜⑥、1戦あたり）**\n")
    L.append("| 詠唱 | 方針 | ①詠唱中に狙われた時の介入率 | ②介入され無傷のまま完成 | ③介入があった詠唱のうち発動成功 | ④介入なしで生身被弾 | ⑤その遅れ（行動数/回） | ⑥被弾後に戦闘不能・死亡でキャンセル |")
    L.append("|---|---|---|---|---|---|---|---|")
    for (n, p), s in sorted(S.items()):
        if n == 0:
            continue
        L.append(f"| {n}行動 | {PN[p]} | {s['tg_cast_ivrate']:.0f}% | {s['c_iv_done_clean']:.2f} | {s['c_iv_done']:.2f}/{s['c_iv_total']:.2f} | {s['tg_cast_body']:.2f} | "
                 f"{s['body_delay']:.2f} | {s['cancel_incap'] + s['cancel_dead']:.3f} |")
    L.append("\n## 4. EP（1戦あたり）\n")
    L.append("| 詠唱 | 方針 | 炎嵐 | 攻撃魔法 | 治療 | 自衛 | 終了時 | EP15未満になる平均進行度 | セレスティアへの介入 | REARへの介入 |\n|---|---|---|---|---|---|---|---|---|---|")
    for (n, p), s in sorted(S.items()):
        L.append(f"| {n}行動 | {PN[p]} | {s['ep_炎嵐']:.1f} | {s['ep_攻撃魔法']:.1f} | {s['ep_治療']:.1f} | {s['ep_自衛']:.1f} | {s['end_ep']:.1f} | {s['ep15']:.0f}% | {s['cel_iv']:.2f} | {s['iv_rear']:.2f} |")
    L.append("\n## 5. 時間軸（Ver0.11介入AI。進行度＝その戦闘の総行動数に対する割合）\n")
    for n in (0, 2, 4, 6):
        if (n, "v11") not in D:
            continue
        t = timeline(D[n, "v11"])
        L.append(f"**詠唱{n}行動**\n")
        L.append("| | 0% | 20% | 40% | 60% | 80% | 100% |\n|---|---|---|---|---|---|---|")
        L.append("| 平均EP | " + " | ".join(f"{v:.1f}" for v in t["ep"]) + " |")
        L.append("| 炎嵐詠唱中の戦闘の割合 | " + " | ".join(f"{v:.1f}%" for v in t["cast"]) + " | – |")
        L.append("\n| 区間 | " + " | ".join(BN) + " |\n|---|---|---|---|---|---|")
        L.append("| 炎嵐発動/戦 | " + " | ".join(f"{v:.2f}" for v in t["storm"]) + " |")
        L.append("| 狙われた/戦 | " + " | ".join(f"{v:.2f}" for v in t["tg"]) + " |")
        L.append("| セレスティアへの介入/戦 | " + " | ".join(f"{v:.2f}" for v in t["iv"]) + " |\n")
    L.append("## 6. 敵知能別の勝率（Ver0.11介入AI）\n")
    L.append("| 詠唱 | 低知能 | 通常 | 高知能 | 戦術級 |\n|---|---|---|---|---|")
    for n in (0, 2, 4, 6):
        R = D[n, "v11"]
        L.append(f"| {n}行動 | " + " | ".join(f"{mean(r['win'] for r in R.values() if r['intel'] == i)*100:.0f}%" for i in range(4)) + " |")
    print("\n".join(L))
    examples(D)


def render(r, title):
    out = [f"### {title}｜seed={r['seed']}・敵知能={['低知能','通常','高知能','戦術級'][r['intel']]}・{'勝ち' if r['win'] else '負け'}・総行動{r['N']}",
           "```"]
    ep = 100
    for k, e in r["E"]:
        if k == "spend" and e["cat"] in ("攻撃魔法", "治療"):
            out.append(f"行動{e['idx']:3d} セレスティア {e['cat']}  EP{ep}→{ep - e['ep']}")
            ep -= e["ep"]
        elif k == "cast_start":
            out.append(f"行動{e['idx']:3d} セレスティア 炎嵐の詠唱開始（HP{e['hp']}・EP{e['ep']}）")
        elif k == "storm":
            out.append(f"行動{e['idx']:3d} ★炎嵐発動  EP{ep}→{ep - 40}")
            ep -= 40
        elif k == "cast_cancel":
            out.append(f"行動{e['idx']:3d} ✕詠唱キャンセル（{e['reason']}）")
        elif k == "target":
            who = NAME.get(e["attacker"], e["attacker"])
            tag = "【詠唱中】" if e["casting"] else ""
            hpa = e["hp_after"] if e["hp_after"] is not None else e["hp"]
            body = (f"自衛EP{e['spent']}・" if e["spent"] else ("自衛不可・" if e["casting"] else "")) + f"生身{e['dmg']}（HP{e['hp']}→{hpa}）" \
                + (f"・詠唱{e['delay']:.2f}行動遅れ" if e["delay"] else "")
            if e["iv_by"]:
                res = f"→ {NAME[e['iv_by']]}が介入"
            elif not e["window"]:
                res = "→ 介入できる前衛なし。" + body
            else:
                res = f"→ 前衛は見送り（{e['ai_reason']}）。" + body
            out.append(f"行動{e['idx']:3d} {tag}{who}がセレスティアを狙う（HP{e['hp']}・EP{e['ep']}） {res}")
            ep -= e["spent"]
    out.append("```")
    return "\n".join(out)


def examples(D):
    rnd = random.Random(11)
    R4, R6, D0 = D[4, "v11"], D[6, "v11"], D[0, "v11"]
    A = [r for r in R4.values() if r["win"] and any(k == "cast_complete" and e["iv"] > 0 for k, e in r["E"])]
    B = [r for R in (R4, R6) for r in R.values() if any(k == "cast_complete" and any(h > 0 for h in e["hits"]) for k, e in r["E"])]
    C = [r for r in R6.values() if ev(r, "cast_cancel")]
    Dd = [k for k in R6 if D0[k]["win"] and not R6[k]["win"] and ev(R6[k], "cast_cancel")]
    print("\n## 7. 代表的な戦闘ログ（Ver0.11介入AI。行動＝累積行動数）\n")
    print(f"- 候補: A 詠唱4で介入→発動→勝ち {len(A)}戦／B 生身で被弾し詠唱が遅れても発動（詠唱4・6） {len(B)}戦／"
          f"C 詠唱6で戦闘不能→キャンセル {len(C)}戦／D 詠唱なしなら勝ち・詠唱6ではキャンセルして負け {len(Dd)}戦\n")
    for lab, pool, k in (("A｜詠唱4：詠唱開始→狙われる→前衛が介入→炎嵐成功", A, 2),
                         ("B｜介入なし→生身で被弾→詠唱が遅れる→それでも成功", B, 1),
                         ("C｜詠唱6：生身で削られて戦闘不能→詠唱キャンセル", C, 2)):
        for r in rnd.sample(pool, min(k, len(pool))):
            print(render(r, lab) + "\n")
    for key in rnd.sample(Dd, min(1, len(Dd))):
        print(render(D0[key], "D｜同じシード・詠唱なし（勝ち）") + "\n")
        print(render(R6[key], "D｜同じシード・詠唱6行動（負け）") + "\n")


if __name__ == "__main__":
    main()
