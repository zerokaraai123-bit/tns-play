"""3FRONT基本陣形・敵再調整・詠唱比較の集計。 python -m tns.sim.v11g_report wolves_X > out/v11g/report_X.md"""
from __future__ import annotations

import json
import math
import sys
from collections import Counter

from .v11f_report import S, pair, ev, mean, render
from .v11g import OUT

SIDE = {"adel": "左（アデル）", "vanguard3": "中央（前衛3）", "vanguard": "右（前衛2）"}


def load(tag):
    p = OUT / f"{tag}.jsonl"
    return {(r["seed"], r["intel"]): r for r in map(json.loads, open(p, encoding="utf-8"))} if p.exists() else None


def ep15(R):
    def below(r):
        for k, e in r["E"]:
            if k == "sample" and e["ep"] < 15:
                return e["idx"] / r["N"]
        return 1.0
    return mean(below(r) for r in R.values()) * 100


def main(enc):
    D = {(n, p): load(f"{enc}_cast{n}_{p}") for n in (0, 2, 4, 6) for p in ("v11", "never")}
    D = {k: v for k, v in D.items() if v}
    X = {k: S(v) for k, v in D.items()}
    L = [f"## 1. 詠唱0/2/4/6（敵: {enc}・3FRONT中央両対応・同一シード各1,000戦）\n",
         "| 詠唱 | 介入AI勝率 | Never勝率 | 差 | 詠唱開始/戦 | 炎嵐発動/戦 | キャンセル/戦 | セレスティア 死亡/戦闘不能 | FRONT 死亡/戦闘不能（1人あたり） | 戦闘時間（巡） | 総行動数 |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for n in (0, 2, 4, 6):
        if (n, "v11") not in X:
            continue
        a, b = X[n, "v11"], X[n, "never"]
        L.append(f"| {n} | {a['win']:.1f}% | {b['win']:.1f}% | {pair(D[n, 'v11'], D[n, 'never'])} | {a['starts']:.2f} | {a['storms']:.2f} | {a['cancel']:.3f} | "
                 f"{a['cel_dead']:.0f}% / {a['cel_incap']:.0f}% | {a['dead_F']:.0f}% / {a['incap_F']:.0f}% | {a['rounds']:.1f} | {a['N']:.1f} |")
    L.append("\n（Neverの炎嵐発動/キャンセル: " + "、".join(f"詠唱{n} {X[n,'never']['storms']:.2f}/{X[n,'never']['cancel']:.3f}" for n in (0, 2, 4, 6) if (n, 'never') in X) + "）")
    L.append("\n**詠唱0との差（介入AI）**: " + "、".join(f"詠唱{n} {pair(D[n, 'v11'], D[0, 'v11'])}" for n in (2, 4, 6) if (n, 'v11') in D))
    L.append("\n**敵知能別の勝率（介入AI / Never）**\n")
    L.append("| 詠唱 | 低知能 | 通常 | 高知能 | 戦術級 |\n|---|---|---|---|---|")
    for n in (0, 2, 4, 6):
        if (n, "v11") not in D:
            continue
        cells = [f"{mean(r['win'] for r in D[n, 'v11'].values() if r['intel'] == i)*100:.0f} / {mean(r['win'] for r in D[n, 'never'].values() if r['intel'] == i)*100:.0f}" for i in range(4)]
        L.append(f"| {n} | " + " | ".join(cells) + " |")
    # 介入構造
    L.append("\n## 2. 3FRONTの介入構造（介入AI、1戦あたり）\n")
    L.append("| 詠唱 | 詠唱中の介入 左/中央/右 | 1人だけ介入した詠唱 | 2人 | 3人 | 中央が守った相手（全期間）セレスティア/エーテル学者 | 中央の詠唱中の介入（セレスティア） | 左右が守った相手（全期間）左→セ/エ・右→セ/エ |")
    L.append("|---|---|---|---|---|---|---|---|")
    for n in (0, 2, 4, 6):
        if (n, "v11") not in D:
            continue
        R = D[n, "v11"]
        N = len(R)
        C = Counter()
        for r in R.values():
            C.update(r["C"])
        ends = [e for r in R.values() for e in ev(r, "cast_end")]
        cnt = Counter(len(e.get("iv_list", [])) for e in ends)
        side = Counter(f for e in ends for f in e.get("iv_list", []))
        g = lambda k: C[k] / N
        L.append(f"| {n} | {side['adel']/N:.2f} / {side['vanguard3']/N:.2f} / {side['vanguard']/N:.2f} | {cnt[1]/N:.2f} | {cnt[2]/N:.2f} | {cnt[3]/N:.2f} | "
                 f"{g('iv_vanguard3_celestia'):.2f} / {g('iv_vanguard3_toolsmith'):.2f} | {g('ivcast_vanguard3_celestia'):.2f} | "
                 f"{g('iv_adel_celestia'):.2f}/{g('iv_adel_toolsmith'):.2f}・{g('iv_vanguard_celestia'):.2f}/{g('iv_vanguard_toolsmith'):.2f} |")
    # 前線
    L.append("\n## 3. 前線状態と前線突破（介入AI、1戦あたり）\n")
    L.append("| 詠唱 | 詠唱中の持ち場の前衛 3人/2人/1人/0人 | 前線突破 | うち詠唱中 | うち介入で開いた経路から | セレスティアへの到達 | うち詠唱中 | Neverの前線突破 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for n in (0, 2, 4, 6):
        if (n, "v11") not in X:
            continue
        a = X[n, "v11"]
        h = a["hold"]
        hs = " / ".join(f"{h[k]:.0f}%" for k in (3, 2, 1, 0)) if n else "–"
        L.append(f"| {n} | {hs} | {a['intr']:.2f} | {a['intr_cast']:.2f} | {a['intr_by_iv']:.2f} | {a['intr_cel']:.2f} | {a['intr_cel_cast']:.2f} | {X[n,'never']['intr']:.2f} |")
    # セレスティア 詠唱中
    L.append("\n## 4. 詠唱中のセレスティア（1戦あたり。介入AI / Never）\n")
    L.append("| 詠唱 | 方針 | 狙われた | 介入された | 介入されなかった | 生身で被弾した攻撃 | 平均生身ダメ | 生身被弾した詠唱（1回/2回以上） | キャンセル 戦闘不能/死亡 |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for n in (2, 4, 6):
        for p in ("v11", "never"):
            if (n, p) not in D:
                continue
            R = D[n, p]; N = len(R)
            T = [e for r in R.values() for e in ev(r, "target") if e["casting"]]
            raw = [e for e in T if not e["iv_by"] and e["dmg"] > 0]
            a = X[n, p]
            L.append(f"| {n} | {'介入AI' if p == 'v11' else 'Never'} | {len(T)/N:.2f} | {sum(1 for e in T if e['iv_by'])/N:.2f} | {sum(1 for e in T if not e['iv_by'])/N:.2f} | "
                     f"{len(raw)/N:.2f} | {mean(e['dmg'] for e in raw) if raw else 0:.1f} | {a['cast_raw1']:.2f} / {a['cast_raw2']:.2f} | {a['cancel_incap']:.3f} / {a['cancel_dead']:.3f} |")
    # 守って完成
    L.append("\n## 5. 「守った結果、魔法が完成した」（介入AI）\n")
    L.append("| 詠唱 | 詠唱回数/戦 | 狙われた詠唱 | 介入→無傷→発動成功（1戦あたり） | 詠唱1回あたり | 狙われた詠唱のうち |\n|---|---|---|---|---|---|")
    for n in (2, 4, 6):
        if (n, "v11") not in D:
            continue
        R = D[n, "v11"]; N = len(R)
        ends = [e for r in R.values() for e in ev(r, "cast_end")]
        tgd = [e for e in ends if e["tg"] > 0]
        ok = [e for e in ends if e["n_iv_fronts"] >= 1 and e["raw_hits"] == 0 and e["kind"] == "cast_complete"]
        L.append(f"| {n} | {len(ends)/N:.2f} | {len(tgd)/N:.2f} | {len(ok)/N:.2f} | {len(ok)/max(1,len(ends))*100:.0f}% | {len(ok)/max(1,len(tgd))*100:.0f}% |")
    # EP
    L.append("\n## 6. セレスティアのEP（介入AI）\n")
    L.append("| 詠唱 | 0% | 20% | 40% | 60% | 80% | 100% | 炎嵐 | 攻撃魔法 | 治療 | 自衛 | 終了時 | EP15未満になる平均進行度 |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for n in (0, 2, 4, 6):
        if (n, "v11") not in X:
            continue
        a = X[n, "v11"]
        L.append(f"| {n} | " + " | ".join(f"{v:.0f}" for v in a["ept"]) + " | " + " | ".join(f"{a['ep_' + c]:.1f}" for c in ("炎嵐", "攻撃魔法", "治療", "自衛"))
                 + f" | {a['end_ep']:.1f} | {ep15(D[n, 'v11']):.0f}% |")
    # タイミング・EP剥がし
    L.append("\n## 7. 炎嵐のタイミングとEP剥がし（介入AI）\n")
    L.append("| 詠唱 | 1回目 開始 | 1回目 発動 | 2回目 開始 | 2回目 発動（発生率） | 序盤20行動の味方物理ダメ / 敵が防御に使ったEP | 炎嵐で敵が使ったEP / 炎嵐の生身ダメ |")
    L.append("|---|---|---|---|---|---|---|")
    for n in (0, 2, 4, 6):
        if (n, "v11") not in X:
            continue
        a = X[n, "v11"]
        f = lambda t: f"{t[2]:.0f}%（行動{t[1]:.1f}）" if t[0] else "–"
        L.append(f"| {n} | {f(a['s1'])} | {f(a['f1'])} | {f(a['s2'])} | {f(a['f2'])}（{a['f2'][0]:.0f}%） | {a['phys_dmg_early']:.0f} / {a['phys_enemy_ep_early']:.0f} | {a['mag_enemy_ep']:.0f} / {a['mag_dmg']:.0f} |")
    print("\n".join(L))
    # examples
    import random
    rnd = random.Random(3)
    print("\n## 8. 代表的な戦闘ログ（介入AI）\n")
    for n, lab, cond in ((4, "詠唱4：狙われる→介入→無傷で炎嵐成功", lambda e: e["n_iv_fronts"] >= 1 and e["raw_hits"] == 0 and e["kind"] == "cast_complete"),
                         (6, "詠唱6：2人以上が介入して炎嵐成功", lambda e: e["n_iv_fronts"] >= 2 and e["kind"] == "cast_complete"),
                         (6, "詠唱6：詠唱キャンセル", lambda e: e["kind"] == "cast_cancel"),
                         (4, "詠唱4：生身で被弾", lambda e: e["raw_hits"] >= 1)):
        if (n, "v11") not in D:
            continue
        pool = [r for r in D[n, "v11"].values() if any(cond(e) for e in ev(r, "cast_end"))]
        print(f"- {lab}: 候補 {len(pool)}戦\n")
        for r in rnd.sample(pool, min(1, len(pool))):
            print(render(r, lab) + "\n")


if __name__ == "__main__":
    main(*sys.argv[1:])
