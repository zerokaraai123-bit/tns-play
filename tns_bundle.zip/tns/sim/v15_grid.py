"""Ver0.15 の条件比較を順に実行して JSONL に追記する（長時間実行用）。
python -m tns.sim.v15_grid <conds.json> <out.jsonl> [N] [seed0]"""
import json
import sys
import time

from .v15 import run_batch, summarize


def main():
    conds = json.load(open(sys.argv[1]))
    out = sys.argv[2]
    N = int(sys.argv[3]) if len(sys.argv) > 3 else 300
    s0 = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    for c in conds:
        t = time.time()
        kw = {k: (tuple(v) if isinstance(v, list) else v) for k, v in c.get("kw", {}).items()}
        jobs = [dict(seed=s, intel=c.get("intel", 1), mods=c.get("mods"), **kw) for s in range(s0, s0 + N)]
        res = run_batch(jobs)
        n, S = summarize(res)
        rec = {"name": c["name"], "intel": c.get("intel", 1), "n": n, "win": S["win"], "S": S,
               "wins": [r["C"]["win"] for r in res], "sec": round(time.time() - t, 1)}
        with open(out, "a") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        print(c["name"], round(S["win"], 3), flush=True)


if __name__ == "__main__":
    main()
