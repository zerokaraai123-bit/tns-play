"""Ver0.11: 価値AIに ①離脱中の前衛が狙われる危険（実績ベース）②前衛が生きて前線に残る将来価値 を足す。
ルールは Ver0.10.2 の戦闘不能暫定仕様（incap4）。全方針を同じ仕様・同じシードで新たに実行する。
python -m tns.sim.v11
"""
from __future__ import annotations

import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..engine.battle_engine import BattleEngine
from ..model.enums import Side
from .csv_export import write_csv
from .v08 import summarize_records
from .v09 import rules_of, seeds
from .v10 import PRED_KEYS
from .v10s import SensTracer

OUT = Path("out/v11")
CONDS = ["q058_f85_incap4", "q058_f70_incap4", "q058_fP2_incap4"]
POLICIES = {"v9": (None, "v9"), "v10": (None, "v10"), "v11": (None, "v11"),
            "never": ("never_iv", "v9"), "always": ("always_iv", "v9"),
            "ivoff": ("iv_off", "v9")}   # 分解用: 介入しないが、REARは「守ってもらえる見込み」を通常どおり持つ（Neverとの差＝見込みの効果）
VALUE = ("v9", "v10", "v11")


def build(cond, policy, seed, intel, log=False, force=None):
    cfg = load_battle_config(party="party_v08", rules=rules_of(cond), ai_weights="ai_weights_v04.yaml",
                             ally_policies="ally_policies_v05_none.yaml", front_hp_mult=1.75)
    probe, hm = POLICIES[policy]
    ally = (ForcedAlly if force else ValueAllyController)(cfg.ally_policies, probe=probe, hole_model=hm)
    if force:
        ally.force = force
    eng = BattleEngine(cfg, {Side.ALLY: ally, Side.ENEMY: EnemyAIController(cfg.ai_weights)},
                       seed=seed, enemy_intel=intel, log_enabled=log)
    return eng, ally


class ForcedAlly(ValueAllyController):
    """反実仮想用: REARを狙う k 番目の介入判断だけ、指定した選択（介入する/しない）に固定する。"""
    force = None

    def decide_intervention(self, window):
        ch = super().decide_intervention(window)
        k, want = self.force
        ivs = [r for r in self.records if r["kind"] == "iv" and r["trank"] == "REAR"]
        if window.target.rank.value == "REAR" and ivs and len(ivs) == k + 1 and ivs[-1].get("_forced") is None:
            rec = ivs[-1]
            rec["_forced"] = want
            if want == "iv":
                f = rec["f"]
                from ..intervention.records import InterventionChoice
                return InterventionChoice(f, reasons=["反実仮想: 介入に固定"], mode="move")
            from ..intervention.records import InterventionChoice
            return InterventionChoice(None, reasons=["反実仮想: 見送りに固定"])
        return ch


def _one(job):
    cond, policy, seed, intel = job
    eng, ally = build(cond, policy, seed, intel)
    tr = SensTracer(eng, ally)
    eng.listeners.append(tr)
    eng.run()
    row = {"cond": cond, "policy": policy, "seed": seed, "enemy_intel": intel, "winner": eng.stats.winner,
           "rounds": eng.stats.rounds}
    row.update(tr.c)
    row.update(summarize_records(ally.records, tr))
    ivs = [r for r in ally.records if r["kind"] == "iv" and r["trank"] == "REAR"]
    prot = [r for r in ivs if r["choice"] != "self"]
    row["ivrec_n"] = len(ivs)
    row["ivrec_protect"] = len(prot)
    row["iv_f_hp_sum"] = sum(r["f_hp"] for r in prot)
    row["iv_f_ep_sum"] = sum(r["f_ep"] for r in prot)
    row["iv_f_ep0"] = sum(1 for r in prot if r["f_ep"] == 0)
    row["skip_f_ep0"] = sum(1 for r in ivs if r["choice"] == "self" and r["f_ep"] == 0)
    row["win_n"] = len(tr.closed)
    for k in PRED_KEYS + ("real_intr", "real_intr_hp", "real_intr_ep", "real_front_hits", "real_front_dmg",
                          "real_rear_hits", "real_rear_hp", "real_rear_ep"):
        row["sum_" + k] = sum(w[k] for w in tr.closed)
    fr = [u for u in eng.state.units.values() if u.side is Side.ALLY and u.rank.value == "FRONT"]
    row["n_interveners"] = len(tr.interveners)
    row["interveners_survived"] = sum(1 for u in fr if u.id in tr.interveners and u.alive)
    for u in eng.state.units.values():
        if u.side is Side.ALLY:
            r = u.rank.value
            row[f"end_dead_{r}"] = row.get(f"end_dead_{r}", 0) + int(u.hp <= 0)
            row[f"end_incap_{r}"] = row.get(f"end_incap_{r}", 0) + int(u.incapacitated)
            row[f"end_out_{r}"] = row.get(f"end_out_{r}", 0) + int(not u.alive)
    row["rear_ep_end"] = sum(u.ep for u in eng.state.units.values() if u.side is Side.ALLY and u.rank.value == "REAR")
    ivrows = [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k != "text"}
              | {"cond": cond, "policy": policy, "seed": seed, "enemy_intel": intel}
              for r in ivs] if policy in VALUE else []
    return row, ivrows


def run(conds=None, pols=None, workers=None):
    OUT.mkdir(parents=True, exist_ok=True)
    workers = workers or max(1, os.cpu_count() or 2)
    for cond in conds or CONDS:
        S = seeds("q058_" + cond.split("_")[1])
        for pol in pols or [p for p in POLICIES if p != "ivoff"]:
            tag = f"{cond}_{pol}"
            if (OUT / f"{tag}_battles.csv").exists():
                print("skip", tag, flush=True)
                continue
            B, IV = [], []
            with ProcessPoolExecutor(workers) as ex:
                for row, ivr in ex.map(_one, [(cond, pol, s, i) for s, i in S], chunksize=20):
                    B.append(row)
                    IV += ivr
            keys = sorted({k for b in B for k in b})
            write_csv(OUT / f"{tag}_battles.csv", [{k: b.get(k, 0) for k in keys} for b in B])
            if IV:
                ik = sorted({k for r in IV for k in r})
                write_csv(OUT / f"{tag}_ivdecisions.csv", [{k: r.get(k, "") for k in ik} for r in IV])
            print("done", tag, flush=True)


if __name__ == "__main__":
    run()
