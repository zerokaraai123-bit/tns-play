"""Ver0.5 解析: battles.csv から ①〜⑮ と敵AIログ指標を集計する。"""
from __future__ import annotations

import math
from collections import defaultdict
from pathlib import Path

from .v04_analysis import analyze as analyze_v04, load


def _g(r, k):
    v = r.get(k)
    return float(v) if v not in ("", None) else 0.0


def _ratio(a, b):
    return a / b if b else math.nan


def analyze(rows) -> dict:
    out = analyze_v04(rows)
    n = len(rows)
    S = lambda k: sum(_g(r, k) for r in rows)
    out["heals"] = S("v5_heal_n_ally") / n                                   # ⑧
    sup_n = sum(S(f"v5_sup_n_b{b}_ally") for b in range(4))
    out["supplies"] = sup_n / n                                               # ⑨
    out["heal_amt"] = S("v5_heal_amt_ally") / n
    out["sup_ep"] = sum(S(f"v5_sup_ep_b{b}_ally") for b in range(4)) / n
    out["heal_cpd_gain"] = 1 - _ratio(S("v5_heal_cpd_after_ally"), S("v5_heal_cpd_before_ally"))   # ⑩
    out["heal_on_collapsed"] = _ratio(S("v5_heal_on_collapsed_ally"), S("v5_heal_n_ally"))
    out["sup_on_collapsed"] = _ratio(S("v5_sup_on_collapsed_ally"), sup_n)
    tot_ep = tot_blk = tot_waste = 0
    for b in range(4):                                                         # ⑪ ⑭
        ep, blk, w = S(f"v5_sup_ep_b{b}_ally"), S(f"v5_sup_block_b{b}_ally"), S(f"v5_sup_waste_b{b}_ally")
        out[f"sup_share_b{b}"] = _ratio(S(f"v5_sup_n_b{b}_ally"), sup_n)
        out[f"sup_block_per_ep_b{b}"] = _ratio(blk, ep)
        out[f"sup_used_block_per_ep_b{b}"] = _ratio(blk, ep - w)
        out[f"sup_waste_b{b}"] = _ratio(w, ep)
        tot_ep += ep; tot_blk += blk; tot_waste += w
    out["sup_block_per_ep"] = _ratio(tot_blk, tot_ep)
    out["sup_blocked"] = tot_blk / n
    out["sup_waste"] = _ratio(tot_waste, tot_ep)
    for key in ("ally_front", "ally_rear"):                                   # ⑫ ⑬ ⑮
        col, rec = S(f"v5_collapse_{key}"), S(f"v5_recover_{key}")
        ended = S(f"v5_rec_end_recollapse_{key}") + S(f"v5_rec_end_death_{key}") + S(f"v5_rec_end_end_{key}")
        out[f"{key}_collapses"] = col / n
        out[f"{key}_recover_rate"] = _ratio(rec, col)
        out[f"{key}_recover_by_heal"] = _ratio(S(f"v5_recover_by_heal_{key}"), rec)
        out[f"{key}_rec_duration"] = _ratio(S(f"v5_rec_dur_sum_{key}"), ended)
        out[f"{key}_rec_recollapse"] = _ratio(S(f"v5_rec_end_recollapse_{key}"), ended)
        out[f"{key}_rec_death"] = _ratio(S(f"v5_rec_end_death_{key}"), ended)
        out[f"{key}_post_collapse"] = _ratio(S(f"v5_post_collapse_sum_{key}"), S(f"v5_collapsed_units_{key}"))
        out[f"{key}_collapsed_survived"] = _ratio(S(f"v5_collapsed_survived_{key}"), S(f"v5_collapsed_units_{key}"))
    out["post_collapse_total"] = (S("v5_post_collapse_sum_ally_front") + S("v5_post_collapse_sum_ally_rear")) / n
    col_all = S("v5_collapse_ally_front") + S("v5_collapse_ally_rear")
    out["recover_rate"] = _ratio(S("v5_recover_ally_front") + S("v5_recover_ally_rear"), col_all)
    out["gate_skip_heal"] = S("v5_gate_skip_heal") / n
    out["gate_skip_supply"] = S("v5_gate_skip_supply") / n
    # 敵AIログ（Q9）
    att = S("attacks_enemy")
    out["enemy_attacks"] = att / n
    out["enemy_dying_rate"] = _ratio(S("v5_att_dying_enemy"), att)
    out["enemy_abandon_rate"] = _ratio(S("v5_abandon_enemy"), att)
    out["enemy_rear_rate"] = _ratio(S("attacks_enemy_on_rear"), att)
    out["enemy_open_route"] = S("intrusion_ally") / n
    out["enemy_induced_iv"] = S("intervention_ally") / n
    out["enemy_focus_release"] = (S("focus_release_unreachable") + S("focus_release_hopeless") + S("focus_switch_better")) / n
    out["enemy_focus_keep"] = S("focus_keep") / n
    out["enemy_plans"] = S("plans") / n
    out["enemy_plan_success"] = _ratio(S("plans_success"), S("plans"))
    out["enemy_kills"] = S("ko_ally") / n
    out["enemy_self_iv"] = S("intervention_enemy") / n
    out["ally_kills"] = S("ko_enemy") / n
    fk = [_g(r, "first_ko_ally_attacks") for r in rows if r.get("first_ko_ally_attacks") not in ("", None)]
    out["enemy_attacks_to_first_kill"] = sum(fk) / len(fk) if fk else math.nan
    ld = [_g(r, "leader_down_round") for r in rows if r.get("leader_down_round") not in ("", None)]
    out["leader_down_rate"] = len(ld) / n
    out["leader_down_round"] = sum(ld) / len(ld) if ld else math.nan
    return out


def collect(out_dir, prefix, by=("enemy_intel",)):
    """prefix で始まる全条件を読み込み、条件タグ → {グループ: 指標} を返す。"""
    data = {}
    for p in sorted(Path(out_dir).glob(f"wolves_5v5_{prefix}_*_battles.csv")):
        tag = p.name[len(f"wolves_5v5_{prefix}_"):-len("_battles.csv")]
        rows = load(p)
        g = defaultdict(list)
        for r in rows:
            g["all"].append(r)
            for b in by:
                g[(b, r[b])].append(r)
        data[tag] = {k: analyze(v) for k, v in g.items()}
    return data
