"""Ver0.3 変更2: 高知能以上の「標的維持（集中攻撃）」。PROTOTYPE_ASSUMPTION PA-28

一度「高価値な標的を倒す」と判断したら、多少別の好機が出ても一定条件まで狙い続ける。
ただし次の場合は再評価して標的を変える:
  - 標的が死亡した                       → released: 標的撃破
  - 標的への攻撃経路が失われた             → released: 攻撃経路喪失
  - 明確に価値の高い緊急目標が発生した       → switched: 他の候補が 維持評価 + switch_margin を超えた
  - 狙い続けるのが著しく不利になった         → released: 撃破までの見込み手数が max_hits_to_kill を超えた
戦術的(3)は群れで標的を共有する（share_in_group_min_intel）。
"""
from __future__ import annotations

import math


class TargetLockManager:
    def __init__(self, cfg: dict):
        self.enabled_min = cfg.get("enabled_min_intel", 2)
        self.acquire_min = {int(k): v for k, v in cfg.get("acquire_min_score", {}).items()}
        self.keep_bonus = cfg.get("keep_bonus", 0.5)
        self.progress_bonus = cfg.get("progress_bonus", 0.6)
        self.switch_margin = cfg.get("switch_margin", 0.3)
        self.max_hits = cfg.get("max_hits_to_kill", 10)
        self.share_min = cfg.get("share_in_group_min_intel", 3)
        self.enabled = cfg.get("enabled", True)
        self.locks: dict[str, str] = {}   # key -> target_id

    def active_for(self, lvl: int) -> bool:
        return self.enabled and lvl >= self.enabled_min

    def key(self, actor, lvl):
        return f"group:{actor.d.group}" if (lvl >= self.share_min and actor.d.group) else f"unit:{actor.id}"

    def apply(self, eng, actor, lvl, items, scores, why):
        """items=(action, target, reach) の候補。戻り値: (選ぶindex or None, ログ文, 集計キー)"""
        k = self.key(actor, lvl)
        tid = self.locks.get(k)
        if tid is None:
            return None, None, None
        t = eng.u(tid)
        shared = k.startswith("group:")
        if not t.alive:
            del self.locks[k]
            return None, f"標的変更: {t.name}を撃破済み → 再評価", "focus_release_dead"
        lock_idx = [i for i, (a, tt, r) in enumerate(items) if tt.id == tid]
        if not lock_idx:
            if shared:
                return None, f"共有標的{t.name}へ届かない → 今回は個別判断（共有標的は維持）", "focus_shared_unreachable"
            del self.locks[k]
            return None, f"標的変更: {t.name}への攻撃経路を喪失 → 再評価", "focus_release_unreachable"
        bi = max(lock_idx, key=lambda i: scores[i])
        a = items[bi][0]
        exp = eng.estimate_damage(actor, a, t)
        hits = math.inf if exp <= 0 else t.hp / exp
        if hits > self.max_hits:
            del self.locks[k]
            return None, (f"標的変更: {t.name}は撃破まで約{hits:.0f}手（上限{self.max_hits}）→ 狙い続けるのは不利"), \
                "focus_release_hopeless"
        keep = scores[bi] + self.keep_bonus + self.progress_bonus * (1 - t.hp_ratio)
        others = [i for i in range(len(items)) if items[i][1].id != tid]
        if others:
            oi = max(others, key=lambda i: scores[i])
            if scores[oi] > keep + self.switch_margin:
                o = items[oi][1]
                self.locks[k] = o.id
                return oi, (f"標的変更: {o.name}（評価{scores[oi]:.2f}）が{t.name}の維持評価{keep:.2f}+{self.switch_margin}を超えた"
                            f"［{'、'.join(why[oi])}］"), "focus_switch_better"
            alt = f"、他の最高{items[oi][1].name}{scores[oi]:.2f}"
        else:
            alt = ""
        return bi, (f"標的維持: {t.name}を狙い続ける（維持評価{keep:.2f}=評価{scores[bi]:.2f}+維持{self.keep_bonus}"
                    f"+弱り{self.progress_bonus * (1 - t.hp_ratio):.2f}{alt}、撃破まで約{hits:.0f}手）"), "focus_keep"

    def maybe_acquire(self, actor, lvl, target, score):
        k = self.key(actor, lvl)
        if k in self.locks:
            return None
        if score >= self.acquire_min.get(lvl, math.inf):
            self.locks[k] = target.id
            return f"標的決定: {target.name}を集中攻撃の対象にする（評価{score:.2f}≥{self.acquire_min[lvl]}）"
        return None
