"""敵AIコントローラ（知能4段階）。標的選び・介入判断・防御判断。"""
from __future__ import annotations

from ...control.controller import Controller, Decision
from ...formation.route import holding_blockers
from ...intervention.records import InterventionChoice
from ...model.enums import ActionKind, INTEL_NAMES, Rank, Reach, Side
from .squad_planner import SquadPlanner
from .target_lock import TargetLockManager
from .target_scorer import features, score, softmax_pick


class EnemyAIController(Controller):
    name = "enemy_ai"

    def __init__(self, ai_cfg: dict):
        self.cfg = ai_cfg
        self.targeting = {int(k): v for k, v in ai_cfg["targeting"].items()}
        self.intervention = {int(k): v for k, v in ai_cfg["intervention"].items()}
        self.planner = SquadPlanner(ai_cfg.get("squad_planner", {}))
        self.lock = TargetLockManager(ai_cfg.get("focus", {"enabled": False}))
        self.always_defend = ai_cfg.get("defense", {}).get("always_if_able", True)

    def bind(self, engine, side):
        super().bind(engine, side)
        self.rng = engine.rng["enemy_ai"]
        self.rng_iv = engine.rng["enemy_intervene"]

    # -------------------------------------------------------------- 行動
    def decide_action(self, actor) -> Decision:
        eng = self.engine
        lvl = actor.intel_effective or 0
        W = self.targeting[lvl]
        attacks = [a for a in eng.available_actions(actor) if a.kind is ActionKind.ATTACK]
        if not attacks:
            return Decision("wait", reasons=["使える攻撃なし"])

        # 戦術的: 連携計画（囮）
        bait = self.planner.try_bait(eng, actor)
        if bait:
            a, t, plan = bait
            return Decision(a.id, t.id, reasons=[f"連携計画#{plan['id']}の囮"], tags={"plan_bait": plan["id"]})

        plan = self.planner.exploit_plan_for(actor)
        items, scores, why = [], [], []
        unreachable_best = None
        for a in attacks:
            for t in eng.state.target_candidates(actor.side.other, actor.side):
                r = eng.reach(actor, t, a)
                f = features(eng, actor, a, t, r if r.ok else None)
                s, parts = score(f, W["weights"])
                if plan and r.ok and r.via_route == plan["route"]:
                    s += self.planner.exploit_bonus
                    parts = ["連携計画の侵入"] + parts
                if not r.ok:
                    if unreachable_best is None or s > unreachable_best[0]:
                        unreachable_best = (s, a, t, r)
                    continue
                items.append((a, t, r))
                scores.append(s)
                why.append(parts)
        if not items:
            return Decision("wait", reasons=["到達できる標的なし"])
        if eng.incap_ai == "tiered":
            items, scores, why = self._incap_filter(eng, actor, lvl, items, scores, why)
        i = None
        focus_msg = None
        if self.lock.active_for(lvl):
            i, focus_msg, key = self.lock.apply(eng, actor, lvl, items, scores, why)
            if key:
                eng.stats.c[key] += 1
        if i is None:
            i = softmax_pick(list(range(len(items))), scores, W["temperature"], self.rng)
            if self.lock.active_for(lvl):
                a0, t0, _ = items[i]
                exp = eng.estimate_damage(actor, a0, t0)
                if exp > 0 and t0.hp / exp <= self.lock.max_hits:
                    m = self.lock.maybe_acquire(actor, lvl, t0, scores[i])
                    if m:
                        eng.stats.c["focus_acquire"] += 1
                        focus_msg = (focus_msg + " / " + m) if focus_msg else m
        a, t, r = items[i]
        best_reachable = max(scores)
        reasons = [f"{INTEL_NAMES[lvl]}: " + "、".join(why[i])]
        if focus_msg:
            reasons.append(focus_msg)
        if unreachable_best and unreachable_best[0] > best_reachable and unreachable_best[1].reach is Reach.MELEE:
            _, ua, ut, ur = unreachable_best
            eng.emit("ai_consider", unit=actor.id,
                     text=f"{ut.name}への近接攻撃を検討 → 経路判定: {ur.reason} → 直接接近不可 → {t.name}を標的")
        if r.via_route and lvl >= 2:
            eng.emit("ai_consider", unit=actor.id, text=f"OPEN経路{r.via_route}を認識 → {t.name}を標的")
        tags = {}
        if plan and r.via_route == plan["route"]:
            tags["plan_exploit"] = plan["id"]
            reasons.append(f"連携計画#{plan['id']}の侵入役")
        return Decision(a.id, t.id, reasons=reasons, tags=tags)

    def _incap_filter(self, eng, actor, lvl, items, scores, why):
        """Ver0.10.2 暫定（PA-111）: 戦闘不能者への対応を知能で分ける。
        低知能(0): 区別しない（従来の採点のまま。戦闘不能者への加点・減点なし）
        通常(1): 戦闘可能な相手に届く限りそちらだけ。戦闘不能者しか狙えないときだけ戦闘不能者を狙う
        高知能(2)・戦術級(3): 通常と同じ。ただし「トドメの価値」がある戦闘不能者だけは候補に残し、同じ採点で比べる
          トドメの価値 = ①この戦闘で治療するところを見た相手の回復役が、いま戦闘可能 ②この一手で倒せる
                       ③復帰されたときの脅威が大きい（威力・魔力が相手側で最大の半分以上）
          見ていない回復能力は使わない（神視点禁止）。戦術級の連携計画（囮）は既存のまま（戦闘不能者も囮になりうる）"""
        if lvl == 0:
            return items, scores, why
        cap = [k for k, (a, t, r) in enumerate(items) if t.alive]
        if not cap or len(cap) == len(items):
            return items, scores, why
        keep = set(cap)
        if lvl >= 2:
            healers = [eng.u(h) for h in eng.seen_healers[actor.side.other]]
            if any(h.alive for h in healers):
                foes = [u for u in eng.state.units.values() if u.side is actor.side.other and u.hp > 0]
                mx = max(max(f.d.power, f.d.magic) for f in foes) or 1
                for k, (a, t, r) in enumerate(items):
                    if t.incapacitated and eng.estimate_damage(actor, a, t) >= t.hp \
                            and max(t.d.power, t.d.magic) / mx >= 0.5:
                        keep.add(k)
                        why[k] = ["トドメの価値（回復役を目撃・一手で倒せる・復帰後の脅威大）"] + why[k]
                        eng.stats.c["v10_finish_cand"] += 1
        ks = sorted(keep)
        return [items[k] for k in ks], [scores[k] for k in ks], [why[k] for k in ks]

    # -------------------------------------------------------------- 介入（敵側が味方の攻撃からかばう）
    def decide_intervention(self, window) -> InterventionChoice:
        eng = self.engine
        t, atk, a = window.target, window.attacker, window.action
        foes = eng.state.side_units(t.side.other)
        max_threat = max((max(f.d.power, f.d.magic) for f in eng.state.side_units(t.side)), default=1) or 1
        est_t_true = eng.estimate_damage(atk, a, t)
        est_t_naive = eng.estimate_damage(atk, a, t, naive=True)
        best, best_score, best_why = None, -1e9, []
        for c in window.eligible:
            lvl = c.intel_effective or 0
            cfg = self.intervention[lvl]
            est_t = est_t_true if lvl >= 2 else est_t_naive   # PA-36
            W = cfg["weights"]
            protect = (W.get("protect_leader", 0) * (1.0 if t.d.is_leader else 0.0)
                       + W.get("protect_threat", 0) * max(t.d.power, t.d.magic) / max_threat
                       + W.get("protect_low_hp", 0) * (1 - t.hp_ratio)
                       + W.get("lethal", 0) * (1.0 if est_t >= t.hp else 0.0))
            est_c = eng.estimate_damage(atk, a, c, naive=lvl < 2)
            self_cost = W.get("self_hp", 0) * min(1.0, est_c / max(c.hp, 1))
            hole = 0.0
            hole_txt = ""
            for R in eng.state.routes_blocked_by(c.id):
                if holding_blockers(R, eng.state.units) != [c.id]:
                    continue
                rear = [eng.u(p) for p in R.protects if eng.u(p).alive]
                if not rear:
                    continue
                rv = max((1.0 if p.d.is_leader else 0.5 + 0.5 * (1 - p.hp_ratio)) for p in rear)
                hole += W.get("hole_risk", 0) * rv
                if W.get("hole_lookahead", 0):
                    before = eng.actors_before_next_turn_of(c.id)
                    threats = [eng.u(x) for x in dict.fromkeys(before)
                               if eng.u(x).side is t.side.other and eng.u(x).rank is Rank.FRONT
                               and any(aa.reach is Reach.MELEE for aa in eng.available_actions(eng.u(x)))]
                    if threats:
                        hole += W["hole_lookahead"] * rv
                        hole_txt = f"、{threats[0].name}が先に動き穴を突ける"
            noise = self.rng_iv.uniform(-cfg["noise"], cfg["noise"])
            s = protect - self_cost - hole + noise
            why = [f"{c.name}({INTEL_NAMES[lvl]}): 守る価値{protect:.2f} 自損{self_cost:.2f} 穴リスク{hole:.2f}{hole_txt} → {s:.2f} (閾値{cfg['threshold']})"]
            if s > cfg["threshold"] and s > best_score:
                best, best_score, best_why = c, s, why
            elif best is None:
                best_why = why
        if best:
            return InterventionChoice(best.id, reasons=best_why)
        return InterventionChoice(None, reasons=best_why)

    # -------------------------------------------------------------- 防御
    def decide_defense(self, defender, attacker, action, expected_raw):
        return (True, "敵: 展開可能なら展開 (PA-22)") if self.always_defend else (False, "設定により展開しない")
