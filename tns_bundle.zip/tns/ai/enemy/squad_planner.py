"""戦術的(知能3)の連携計画: 囮 → 前衛に介入させる → 穴 → 後続が侵入。

1. 味方側で「唯一の守り手 X」が塞いでいる経路 R を探す
2. X の次の手番より前に動く、近接可能な敵前衛（侵入役）がいるか確認
3. いれば、X が介入しそうな相手（R の先の後衛を遠距離で / X の隣の前衛を近接で）を囮として攻撃
   → 介入されれば R が開き侵入役が突く。介入されなければ囮の攻撃がそのまま通る。
すべて PROTOTYPE_ASSUMPTION（PA-23）。
"""
from __future__ import annotations

from ...model.enums import ActionKind, Rank, Reach, Side
from ...formation.route import holding_blockers


class SquadPlanner:
    def __init__(self, cfg: dict):
        self.min_intel = cfg.get("enabled_min_intel", 3)
        self.threshold = cfg.get("plan_score_threshold", 0.45)
        self.exploit_bonus = cfg.get("exploit_bonus", 1.5)
        self.active: dict[str, dict] = {}   # exploit_actor_id -> plan

    def _melee(self, engine, e):
        return [a for a in engine.available_actions(e) if a.kind is ActionKind.ATTACK and a.reach is Reach.MELEE]

    def try_bait(self, engine, actor):
        st = engine.state
        if (actor.intel_effective or 0) < self.min_intel:
            return None
        attacks = [a for a in engine.available_actions(actor) if a.kind is ActionKind.ATTACK]
        best = None
        for R in st.routes[Side.ALLY]:
            hb = holding_blockers(R, st.units)
            if len(hb) != 1:
                continue
            X = engine.u(hb[0])
            rear = [engine.u(p) for p in R.protects if engine.u(p).alive]
            if not rear:
                continue
            before_x = engine.actors_before_next_turn_of(X.id)
            exploiters = []
            for eid in dict.fromkeys(before_x):
                e = engine.u(eid)
                if e.side is Side.ENEMY and e.alive and e.rank is Rank.FRONT \
                        and (e.intel_effective or 0) >= 2 and self._melee(engine, e):
                    exploiters.append(e)
            if not exploiters:
                continue
            # 侵入の価値
            ex_val, ex_unit, ex_target = 0.0, None, None
            for e in exploiters:
                for a in self._melee(engine, e):
                    for p in rear:
                        d = engine.estimate_damage(e, a, p)
                        v = d / p.d.hp_max + (0.5 if d >= p.hp else 0.0)
                        if v > ex_val:
                            ex_val, ex_unit, ex_target = v, e, p
            # 囮の候補
            for a in attacks:
                for t in engine.valid_targets(actor, a):
                    if t.id == X.id:
                        continue
                    if t.rank is Rank.REAR and t.id not in R.protects:
                        continue
                    bait_val = engine.estimate_damage(actor, a, t) / t.d.hp_max
                    lure = 1.0 if t.id in R.protects else 0.6   # 守り手が反応しやすい相手ほど高い
                    val = 0.5 * bait_val + ex_val * lure
                    if best is None or val > best[0]:
                        best = (val, a, t, X, R, ex_unit, ex_target)
        if best is None or best[0] < self.threshold:
            return None
        val, a, t, X, R, e, p = best
        plan = {"id": len(engine.stats.plans) + 1, "round": st.round, "bait": actor.id, "bait_target": t.id,
                "blocker": X.id, "route": R.id, "exploit": e.id, "exploit_target": p.id, "success": False,
                "leader_down": engine.leader_down_for(actor)}
        engine.stats.plans.append(plan)
        self.active[e.id] = plan
        engine.emit("plan", text=f"{actor.name}が囮: {t.name}を攻撃し{X.name}の介入を誘う → "
                                 f"経路{R.id}が開けば{e.name}が{p.name}へ侵入（価値{val:.2f}）")
        return a, t, plan

    def exploit_plan_for(self, actor):
        return self.active.pop(actor.id, None)
