"""Ver0.15 敵AI（PA-211）。既存の EnemyAIController に、新しい行動（牽制・回り込み・遠吠え・大呪）の評価を足す。

方針:
  - 通常の攻撃は既存の特徴量 × 知能別ウェイトのまま（targeting）。
  - 新しい行動は、同じ尺度の点数を足して、知能別の温度で選ぶ（softmax）。
  - 遠吠えで指名された標的には、群れ全員が加点する（指名は公開情報）。
  - 介入・防御は既存のまま（牽制された者・死守中の者はエンジン側で介入候補から外れる）。
"""
from __future__ import annotations

from ...control.controller import Decision
from ...formation.route import holding_blockers
from ...model.enums import ActionKind, INTEL_NAMES, Rank, Reach, Side, Stance
from .enemy_controller import EnemyAIController
from .target_scorer import features, score, softmax_pick


class V15EnemyAI(EnemyAIController):
    name = "enemy_ai_v15"

    def __init__(self, ai_cfg: dict, disabled=()):
        super().__init__(ai_cfg)
        v = ai_cfg.get("v15", {}) or {}
        self.vw = {k: {int(i): float(x) for i, x in d.items()} for k, d in v.items()}
        self.disabled = set(disabled)      # 分析用: 使わせない行動ID（抜いたら弱くなるかの確認）

    def w(self, key, lvl):
        return self.vw.get(key, {}).get(lvl, 0.0)

    # -------------------------------------------------------------- 補助
    def _can_iv(self, eng, c):
        return c.alive and c.can_intervene and eng._iv_ok(c)

    def _acts_before(self, eng, uid):
        return list(eng.actors_before_next_turn_of(uid))

    def _pin_enable(self, eng, actor, t):
        """牽制で t の介入を封じると、群れの攻撃が後衛へ通りやすくなる見込み（0〜1）。"""
        if not self._can_iv(eng, t):
            return 0.0
        lanes = [r for r in eng.state.routes[t.side] if t.id in r.blockers]
        rears = {p for r in lanes for p in r.protects if eng.u(p).alive}
        if not rears:
            return 0.0
        before = self._acts_before(eng, t.id)
        n = 0
        for x in dict.fromkeys(before):
            e = eng.u(x)
            if e.side is not actor.side or e.id == actor.id or not e.alive:
                continue
            for a in eng.available_actions(e):
                if a.kind is not ActionKind.ATTACK:
                    continue
                if a.reach is Reach.RANGED or a.special == "flank":
                    if any(eng.u(p) in eng.valid_targets(e, a) for p in rears) or a.area == "all":
                        n += 1
                        break
        return min(1.0, n / 2.0)

    def _flank_risk(self, eng, actor):
        """自分が持ち場を離れると、自分たちの経路が薄くなって相手の突撃が通るか（0/1）。"""
        thin = []
        for r in eng.state.routes[actor.side]:
            if actor.id not in holding_blockers(r, eng.state.units):
                continue
            w_now = eng.route_weight(r)
            if w_now - 1 <= eng.thin_max:
                thin.append(r)
        if not thin:
            return 0.0
        foes = [f for f in eng.state.side_units(actor.side.other) if f.rank is Rank.FRONT and not f.displaced
                and any(eng.actions[x].special == "dive" for x in f.d.action_ids)]
        return 1.0 if foes else 0.3

    def _curse_risk(self, eng, actor):
        """詠唱中に潰される危険: 近接（通常・突撃）で自分に届く相手前衛がいるか（0/1）。"""
        for f in eng.state.side_units(actor.side.other):
            if f.rank is not Rank.FRONT or f.displaced or f.id in eng.pinned:
                continue
            for a in eng.available_actions(f):
                if a.kind is ActionKind.ATTACK and a.reach is Reach.MELEE and actor in eng.valid_targets(f, a):
                    return 1.0
            if any(eng.actions[x].special == "dive" for x in f.d.action_ids):
                if eng.breach_reach(f, actor).ok:
                    return 1.0
        return 0.0

    def _howl_value(self, eng, actor, t, W):
        """遠吠えの価値: 標的の価値（通常の評価）× リーダーの次の手番までに t を狙える群れの数/2。"""
        before = self._acts_before(eng, actor.id)
        cnt = 0
        vals = []
        for x in dict.fromkeys(before):
            e = eng.u(x)
            if e.side is not actor.side or e.id == actor.id or not e.alive or e.d.group != actor.d.group:
                continue
            for a in eng.available_actions(e):
                if a.kind is ActionKind.ATTACK and a.area != "all" and t in eng.valid_targets(e, a):
                    f = features(eng, e, a, t, eng.reach(e, t, a))
                    vals.append(score(f, W["weights"])[0])
                    cnt += 1
                    break
        if cnt == 0:
            return 0.0
        return (sum(vals) / len(vals)) * min(1.0, cnt / 2.0)

    def _break_charge(self, eng, lvl, chargers):
        """PA-268 魔法・遠隔で侍のためを崩す価値: 知能 × たまった分（倍率−1）。"""
        k = eng.charge_break.get(lvl, 0.0)
        if not k:
            return 0.0
        return k * sum(max(0.0, eng.charge_mult(c) - 1.0) for c in chargers)

    # -------------------------------------------------------------- Ver0.16 装置の温存（PA-232）
    def decide_defense(self, defender, attacker, action, expected_raw):
        eng = self.engine
        use, why = super().decide_defense(defender, attacker, action, expected_raw)
        if not use or not getattr(eng, "device_on", False):
            return use, why
        lvl = defender.intel_effective or 0
        r = self.w("device_save", lvl)
        if r <= 0:
            return use, why
        bf = eng.body_mult * eng._body_factor(defender, attacker, action)
        if defender.hp - expected_raw * bf <= defender.incap_ratio * defender.d.hp_max:
            return True, "装置: 生身では倒れる"
        before = [x for x in eng.actors_before_next_turn_of(defender.id) if x != attacker.id]
        big = 0.0
        for x in dict.fromkeys(before):
            f = eng.u(x)
            if f.side is defender.side or not f.alive:
                continue
            for a in eng.available_actions(f):
                if a.kind is ActionKind.ATTACK and defender in eng.valid_targets(f, a):
                    big = max(big, eng.damage.expected(f, a))
        if big > 0 and expected_raw < r * big:
            return False, f"装置を温存（この一撃{expected_raw:.0f} ＜ 次に来うる一撃{big:.0f}×{r}）"
        return use, why

    # -------------------------------------------------------------- Ver0.17 先に張る鎧（PA-244）
    def decide_clash(self, actor, foe):
        """PA-263 一騎打ちの構え（攻撃・パリィ・崩し）。知能ごとの確率で選ぶ（低知能の獣はほぼ攻撃）。"""
        eng = self.engine
        mix = eng.clash_mix.get(int(actor.intel_effective or 0)) or [1 / 3, 1 / 3, 1 / 3]
        r = eng.rng["clash"].random() * sum(mix)
        for st, w in zip(("attack", "parry", "break"), mix):
            if r < w:
                return st
            r -= w
        return "attack"

    def decide_preshield(self, actor):
        return self.decide_shield(actor, Decision("wait", None))

    def decide_shield(self, actor, dec):
        """敵の鎧（PA-253。知能で変わる）。
          低知能  : 自分に張るだけ。
          通常    : 自分。ただし、集中攻撃されて危ない仲間・狙われている詠唱者がいれば、そちらへ（見えている事実だけで判断）。
          高知能〜: 次の自分の手番までに来そうな攻撃を見積もり、鎧1枚で減らせる損失が一番大きい相手へ（詠唱者・瀕死の仲間を含む）。"""
        eng = self.engine
        a = eng.actions.get(dec.action_id)
        lvl = actor.intel_effective or 0
        if actor.ep <= 0:
            return None
        cast_start = a is not None and a.id in eng.cast_time
        default = None if cast_start else actor.id
        mates = [c for c in eng.state.side_units(actor.side) if c.id != actor.id and eng.can_shield(actor, c)]
        if lvl <= 0 or not mates:
            return default
        win = eng.interval(actor)
        if lvl == 1:
            danger = []
            for c in mates:
                h = eng.recent_hits(c.id, win)
                if (c.id in eng.casting and h >= 1) or h >= 2 or (h >= 1 and c.hp_ratio < 0.5):
                    danger.append((c.hp_ratio - (0.5 if c.id in eng.casting else 0.0), c))
            mine = eng.recent_hits(actor.id, win)
            if danger and (cast_start or mine < 2):
                danger.sort(key=lambda x: x[0])
                eng.stats.c["v17_enemy_shield_mate_i1"] += 1
                return danger[0][1].id
            return default
        best = (self._shield_gain(actor, actor, win) if not cast_start else -1.0, default)
        for c in mates:
            g = self._shield_gain(actor, c, win)
            if g > best[0] + 0.02:
                best = (g, c.id)
        sid = best[1] if best[0] > 0 or best[1] == default else default
        if sid not in (actor.id, None):
            eng.stats.c["v17_enemy_shield_mate_i2"] += 1
        return sid

    def _shield_gain(self, giver, x, win):
        """高知能: x に鎧を1枚足したときに減らせる損失の見込み（相手の行動予定と、見えている集中攻撃から）。"""
        import math
        eng = self.engine
        before = list(eng.actors_before_next_turn_of(giver.id))
        foes = eng.state.side_units(giver.side.other)
        mates_all = eng.state.side_units(giver.side)
        lam = rsum = 0.0
        seen_cast = set()
        for fid in before:
            f = eng.u(fid)
            if f.side is giver.side or not f.alive:
                continue
            if fid in eng.casting and fid not in seen_cast:
                seen_cast.add(fid)
                ca = eng.actions[eng.casting[fid]["dec"].action_id]
                if ca.area == "all" and x.alive:
                    lam += 1.0
                    rsum += eng.damage.expected(f, ca)
                    continue
            atk = [eng.actions[i] for i in f.d.action_ids
                   if eng.actions[i].kind is ActionKind.ATTACK and eng.actions[i].area != "all"]
            atk = [b for b in atk if x in eng.valid_targets(f, b)]
            if not atk:
                continue
            b = max(atk, key=lambda b: eng.damage.expected(f, b))
            tg = [t for t in mates_all if any(t in eng.valid_targets(f, bb) for bb in atk)] or [x]
            w = {t.id: 1.0 + 2.0 * eng.recent_hits(t.id, win) + (1.0 if t.id in eng.casting else 0.0) for t in tg}
            p = w.get(x.id, 0.0) / sum(w.values())
            lam += p
            rsum += p * eng.damage.expected(f, b)
        if lam <= 0:
            return 0.0
        R = rsum / lam
        m = len(eng.layers_on(x.id))
        term, cdf = math.exp(-lam), 0.0
        for i in range(m + 1):
            cdf += term
            term *= lam / (i + 1)
        p_reach = max(0.0, 1.0 - cdf)
        bf = eng.body_mult * eng._body_factor(x, None, None)
        imp = 1.5 if x.d.is_leader else (1.3 if x.id in eng.casting or (x.d.role or "") == "mage" else 1.0)
        inc = x.incap_ratio * x.d.hp_max

        def loss(d):
            d *= bf
            return imp * (min(1.0, d / x.d.hp_max) + (1.0 if x.hp - d <= inc else 0.0))
        if x.id == giver.id:
            cs = getattr(eng, "armor_cap_self", None)       # PA-270 自分の鎧の耐久
            part = R if cs is None else min(R, cs)
            need = eng.defense.required_ep(x, part)
            blocked = part if x.ep >= need else x.ep / max(eng.defense.required_ep(x, 1.0), 1e-9)
        else:
            cap = eng.cap_of(giver)
            part = R if cap is None else min(R, cap)
            need = eng.aegis_need(giver, part)
            blocked = part * (min(giver.ep, need) / need if need > 0 else 1.0)
        return p_reach * max(0.0, loss(R) - loss(R - blocked))

    # -------------------------------------------------------------- 行動
    def decide_action(self, actor) -> Decision:
        eng = self.engine
        lvl = actor.intel_effective or 0
        W = self.targeting[lvl]
        acts = [a for a in eng.available_actions(actor) if a.id not in self.disabled]
        if not acts:
            return Decision("wait", reasons=["使える行動なし"])
        # PA-260 ヘイト（本能）が判断（理性）を上回ったら、ヘイトの相手を狙う
        if getattr(eng, "hate_on", False):
            hv, htid = eng.hate_top(actor)
            J = eng.judgment_of(actor)
            if htid is not None and hv > J:
                ht = eng.u(htid)
                atks = [a for a in acts if a.kind is ActionKind.ATTACK and a.area not in ("all", "front")
                        and ht in eng.valid_targets(actor, a)]
                if atks:
                    a = max(atks, key=lambda b: (eng.damage.expected(actor, b), not b.special))
                    eng.stats.c["v17_hate_follow_enemy"] += 1
                    return Decision(a.id, htid, reasons=[f"ヘイト: {ht.name}へ{hv:.0f} ＞ 判断{J:.0f} → 本能で{ht.name}を狙う"],
                                    tags={"hate": True})
        bait = self.planner.try_bait(eng, actor)
        if bait and bait[0].id not in self.disabled:
            a, t, plan = bait
            return Decision(a.id, t.id, reasons=[f"連携計画#{plan['id']}の囮"], tags={"plan_bait": plan["id"]})
        plan = self.planner.exploit_plan_for(actor)
        g = actor.d.group or actor.id
        howl_t = eng.howl.get(g)
        items, scores, why = [], [], []          # items: (action, target, reach or None)
        for a in acts:
            sp = a.special
            if a.kind is ActionKind.ATTACK and a.area in ("all", "front"):
                # Ver0.19: 前列全員の攻撃（ゴーレムの薙ぎ払い）も、全体攻撃と同じ形でまとめて評価する（area_front / area_front_scale。無ければ大呪の値）
                tg = [t for t in eng.valid_targets(actor, a) if t.alive]
                if not tg:
                    continue
                # 1人ずつ撃った場合の評価（既存の特徴量×ウェイト）の平均 × 人数 × curse_scale
                sc1 = [score(features(eng, actor, a, t, None), W["weights"])[0] for t in tg]
                kw, ks = ("curse", "curse_scale") if a.area == "all" else ("area_front", "area_front_scale")
                wk = self.w(kw, lvl) if kw in self.vw else self.w("curse", lvl)
                ws = self.w(ks, lvl) if ks in self.vw else self.w("curse_scale", lvl)
                tot = sum(sc1) / len(sc1) * len(tg) * ws
                s = wk * tot
                parts = [f"{'全体' if a.area == 'all' else '前列'}{len(tg)}人（1人あたり評価{sum(sc1) / len(sc1):.2f}）→{tot:.2f}"]
                risk = self.w("curse_risk", lvl) * self._curse_risk(eng, actor) if (lvl >= 2 and a.id in eng.cast_time) else 0.0
                if risk:
                    s -= risk
                    parts.append(f"詠唱中に潰される危険−{risk:.2f}")
                br = self._break_charge(eng, lvl, [t for t in tg if t.id in eng.charging]) if getattr(eng, "charge_on", False) else 0.0
                if br:
                    s += br
                    parts.append(f"侍のためを崩す+{br:.2f}")
                items.append((a, tg[0], None))
                scores.append(s)
                why.append(parts)
                continue
            if a.kind is ActionKind.ATTACK:
                for t in eng.valid_targets(actor, a):
                    r = eng.reach(actor, t, a)
                    f = features(eng, actor, a, t, r if r.ok else None)
                    s, parts = score(f, W["weights"])
                    if plan and r.ok and r.via_route == plan["route"]:
                        s += self.planner.exploit_bonus
                        parts = ["連携計画の侵入"] + parts
                    if lvl >= 2 and hasattr(eng, "job_of") and eng.job_of(t).get("guard_rear"):
                        b = self.w("break_guard", lvl)          # PA-258 賢い敵ほど、先に重戦士（後衛の盾）を倒しに来る
                        if b:
                            s += b
                            parts = [f"後衛の盾を割る+{b:.2f}"] + parts
                    if getattr(eng, "charge_on", False) and eng.charging and t.id not in eng.charging \
                            and a.area not in ("all", "front") and eng.is_melee(a):
                        av = eng.charge_avoid.get(lvl, 0.0)        # PA-267 侍が構えている: そのそばで他人を近接で狙うと斬り込まれる
                        if av and any(eng.charge_counter_attack(c, actor) is not None for c in eng.state.side_units(actor.side.other)
                                      if c.id in eng.charging and c.alive and not c.incapacitated):
                            s -= av
                            parts = parts + [f"侍の構え（斬り込まれる）−{av:.2f}"]
                    if getattr(eng, "charge_on", False) and t.id in eng.charging and not eng.is_melee(a):
                        br = self._break_charge(eng, lvl, [t])
                        if br:
                            s += br
                            parts = [f"侍のためを崩す+{br:.2f}"] + parts
                    if howl_t == t.id:
                        b = self.w("howl_bonus", lvl)
                        if b:
                            s += b
                            parts = [f"遠吠えの指名+{b:.2f}"] + parts
                    if sp == "pin":
                        en = self._pin_enable(eng, actor, t)
                        b = self.w("pin", lvl) * en
                        s = s * 0.5 + b
                        parts = [f"牽制で介入を封じる{b:.2f}"] + parts
                    if sp == "flank" and lvl >= 2:
                        rk = self.w("flank_risk", lvl) * self._flank_risk(eng, actor)
                        if rk:
                            s -= rk
                            parts = parts + [f"持ち場を離れる危険−{rk:.2f}"]
                    items.append((a, t, r))
                    scores.append(s)
                    why.append(parts)
                continue
            if sp == "howl":
                if howl_t is not None:
                    continue
                best = None
                for t in eng.valid_targets(actor, a):
                    v = self._howl_value(eng, actor, t, W)
                    if best is None or v > best[0]:
                        best = (v, t)
                if best and best[0] > 0:
                    s = self.w("howl", lvl) * best[0]
                    items.append((a, best[1], None))
                    scores.append(s)
                    why.append([f"遠吠えで{best[1].name}を指名（群れの評価{best[0]:.2f}）"])
        if not items:
            return Decision("wait", reasons=["届く標的なし"])
        # 戦闘不能者の扱い（既存 PA-111）は単体攻撃だけに適用
        if eng.incap_ai == "tiered" and lvl >= 1:
            alive_att = [k for k, (a, t, r) in enumerate(items) if r is not None and t.alive]
            if alive_att:
                keep = [k for k, (a, t, r) in enumerate(items) if r is None or t.alive]
                items = [items[k] for k in keep]
                scores = [scores[k] for k in keep]
                why = [why[k] for k in keep]
        i = None
        focus_msg = None
        if self.lock.active_for(lvl):
            sub = [k for k, (a, t, r) in enumerate(items) if r is not None]
            if sub:
                si, focus_msg, key = self.lock.apply(eng, actor, lvl, [items[k] for k in sub],
                                                     [scores[k] for k in sub], [why[k] for k in sub])
                if key:
                    eng.stats.c[key] += 1
                if si is not None:
                    i = sub[si]
                    others = [k for k in range(len(items)) if items[k][2] is None]
                    if others:
                        o = max(others, key=lambda k: scores[k])
                        if scores[o] > scores[i] + self.lock.keep_bonus + self.lock.switch_margin:
                            i = o
                            focus_msg = (focus_msg or "") + " / 特殊行動を優先"
        if i is None:
            i = softmax_pick(list(range(len(items))), scores, W["temperature"], self.rng)
            a0, t0, r0 = items[i]
            if self.lock.active_for(lvl) and r0 is not None:
                exp = eng.estimate_damage(actor, a0, t0)
                if exp > 0 and t0.hp / exp <= self.lock.max_hits:
                    m = self.lock.maybe_acquire(actor, lvl, t0, scores[i])
                    if m:
                        eng.stats.c["focus_acquire"] += 1
                        focus_msg = (focus_msg + " / " + m) if focus_msg else m
        a, t, r = items[i]
        reasons = [f"{INTEL_NAMES[lvl]}: " + "、".join(why[i])]
        if focus_msg:
            reasons.append(focus_msg)
        tags = {}
        if plan and r is not None and r.via_route == plan["route"]:
            tags["plan_exploit"] = plan["id"]
        return Decision(a.id, t.id if t is not None else None, reasons=reasons, tags=tags)
