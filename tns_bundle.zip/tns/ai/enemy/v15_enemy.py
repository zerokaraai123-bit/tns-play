"""Ver0.15 敵AI（PA-211）。既存の EnemyAIController に、新しい行動（牽制・回り込み・遠吠え・大呪）の評価を足す。

方針:
  - 通常の攻撃は既存の特徴量 × 知能別ウェイトのまま（targeting）。
  - 新しい行動は、同じ尺度の点数を足して、知能別の温度で選ぶ（softmax）。
  - 遠吠えで指名された標的には、群れ全員が加点する（指名は公開情報）。
  - 介入・防御は既存のまま（牽制された者・死守中の者はエンジン側で介入候補から外れる）。
"""
from __future__ import annotations

from ...control.controller import Decision
from ...formation.route import holding_blockers
from ...model.enums import ActionKind, INTEL_NAMES, Rank, Reach, Side, Stance
from .enemy_controller import EnemyAIController
from .target_scorer import features, score, softmax_pick


class V15EnemyAI(EnemyAIController):
    name = "enemy_ai_v15"

    def __init__(self, ai_cfg: dict, disabled=()):
        super().__init__(ai_cfg)
        v = ai_cfg.get("v15", {}) or {}
        self.vw = {k: {int(i): float(x) for i, x in d.items()} for k, d in v.items()}
        self.disabled = set(disabled)      # 分析用: 使わせない行動ID（抜いたら弱くなるかの確認）

    def w(self, key, lvl):
        return self.vw.get(key, {}).get(lvl, 0.0)

    # -------------------------------------------------------------- 補助
    def _can_iv(self, eng, c):
        return c.alive and c.can_intervene and eng._iv_ok(c)

    def _acts_before(self, eng, uid):
        return list(eng.actors_before_next_turn_of(uid))

    def _pin_enable(self, eng, actor, t):
        """牽制で t の介入を封じると、群れの攻撃が後衛へ通りやすくなる見込み（0〜1）。"""
        if not self._can_iv(eng, t):
            return 0.0
        lanes = [r for r in eng.state.routes[t.side] if t.id in r.blockers]
        rears = {p for r in lanes for p in r.protects if eng.u(p).alive}
        if not rears:
            return 0.0
        before = self._acts_before(eng, t.id)
        n = 0
        for x in dict.fromkeys(before):
            e = eng.u(x)
            if e.side is not actor.side or e.id == actor.id or not e.alive:
                continue
            for a in eng.available_actions(e):
                if a.kind is not ActionKind.ATTACK:
                    continue
                if a.reach is Reach.RANGED or a.special == "flank":
                    if any(eng.u(p) in eng.valid_targets(e, a) for p in rears) or a.area == "all":
                        n += 1
                        break
        return min(1.0, n / 2.0)

    def _flank_risk(self, eng, actor):
        """自分が持ち場を離れると、自分たちの経路が薄くなって相手の突撃が通るか（0/1）。"""
        thin = []
        for r in eng.state.routes[actor.side]:
            if actor.id not in holding_blockers(r, eng.state.units):
                continue
            w_now = eng.route_weight(r)
            if w_now - 1 <= eng.thin_max:
                thin.append(r)
        if not thin:
            return 0.0
        foes = [f for f in eng.state.side_units(actor.side.other) if f.rank is Rank.FRONT and not f.displaced
                and any(eng.actions[x].special == "dive" for x in f.d.action_ids)]
        return 1.0 if foes else 0.3

    def _curse_risk(self, eng, actor):
        """詠唱中に潰される危険: 近接（通常・突撃）で自分に届く相手前衛がいるか（0/1）。"""
        for f in eng.state.side_units(actor.side.other):
            if f.rank is not Rank.FRONT or f.displaced or f.id in eng.pinned:
                continue
            for a in eng.available_actions(f):
                if a.kind is ActionKind.ATTACK and a.reach is Reach.MELEE and actor in eng.valid_targets(f, a):
                    return 1.0
            if any(eng.actions[x].special == "dive" for x in f.d.action_ids):
                if eng.breach_reach(f, actor).ok:
                    return 1.0
        return 0.0

    def _howl_value(self, eng, actor, t, W):
        """遠吠えの価値: 標的の価値（通常の評価）× リーダーの次の手番までに t を狙える群れの数/2。"""
        before = self._acts_before(eng, actor.id)
        cnt = 0
        vals = []
        for x in dict.fromkeys(before):
            e = eng.u(x)
            if e.side is not actor.side or e.id == actor.id or not e.alive or e.d.group != actor.d.group:
                continue
            for a in eng.available_actions(e):
                if a.kind is ActionKind.ATTACK and a.area != "all" and t in eng.valid_targets(e, a):
                    f = features(eng, e, a, t, eng.reach(e, t, a))
                    vals.append(score(f, W["weights"])[0])
                    cnt += 1
                    break
        if cnt == 0:
            return 0.0
        return (sum(vals) / len(vals)) * min(1.0, cnt / 2.0)

    # -------------------------------------------------------------- Ver0.16 装置の温存（PA-232）
    def decide_defense(self, defender, attacker, action, expected_raw):
        eng = self.engine
        use, why = super().decide_defense(defender, attacker, action, expected_raw)
        if not use or not getattr(eng, "device_on", False):
            return use, why
        lvl = defender.intel_effective or 0
        r = self.w("device_save", lvl)
        if r <= 0:
            return use, why
        bf = eng.body_mult * eng._body_factor(defender, attacker, action)
        if defender.hp - expected_raw * bf <= defender.incap_ratio * defender.d.hp_max:
            return True, "装置: 生身では倒れる"
        before = [x for x in eng.actors_before_next_turn_of(defender.id) if x != attacker.id]
        big = 0.0
        for x in dict.fromkeys(before):
            f = eng.u(x)
            if f.side is defender.side or not f.alive:
                continue
            for a in eng.available_actions(f):
                if a.kind is ActionKind.ATTACK and defender in eng.valid_targets(f, a):
                    big = max(big, eng.damage.expected(f, a))
        if big > 0 and expected_raw < r * big:
            return False, f"装置を温存（この一撃{expected_raw:.0f} ＜ 次に来うる一撃{big:.0f}×{r}）"
        return use, why

    # -------------------------------------------------------------- Ver0.17 先に張る鎧（PA-244）
    def decide_preshield(self, actor):
        return self.decide_shield(actor, Decision("wait", None))

    def decide_shield(self, actor, dec):
        """敵: EPがあれば基本は自分に張る。高知能以上の前衛は、詠唱する仲間（詠唱中・詠唱を始める）に鎧がなければそちらへ。"""
        eng = self.engine
        a = eng.actions.get(dec.action_id)
        lvl = actor.intel_effective or 0
        if actor.ep <= 0:
            return None
        cast_start = a is not None and a.id in eng.cast_time
        if lvl >= 2 and actor.rank is Rank.FRONT:
            for c in eng.state.side_units(actor.side):
                if c.id != actor.id and c.id in eng.casting and not eng.layers_on(c.id) and eng.can_shield(actor, c):
                    return c.id
        if cast_start:
            return None
        return actor.id

    # -------------------------------------------------------------- 行動
    def decide_action(self, actor) -> Decision:
        eng = self.engine
        lvl = actor.intel_effective or 0
        W = self.targeting[lvl]
        acts = [a for a in eng.available_actions(actor) if a.id not in self.disabled]
        if not acts:
            return Decision("wait", reasons=["使える行動なし"])
        bait = self.planner.try_bait(eng, actor)
        if bait and bait[0].id not in self.disabled:
            a, t, plan = bait
            return Decision(a.id, t.id, reasons=[f"連携計画#{plan['id']}の囮"], tags={"plan_bait": plan["id"]})
        plan = self.planner.exploit_plan_for(actor)
        g = actor.d.group or actor.id
        howl_t = eng.howl.get(g)
        items, scores, why = [], [], []          # items: (action, target, reach or None)
        for a in acts:
            sp = a.special
            if a.kind is ActionKind.ATTACK and a.area == "all":
                tg = [t for t in eng.valid_targets(actor, a) if t.alive]
                if not tg:
                    continue
                # 1人ずつ撃った場合の評価（既存の特徴量×ウェイト）の平均 × 人数 × curse_scale
                sc1 = [score(features(eng, actor, a, t, None), W["weights"])[0] for t in tg]
                tot = sum(sc1) / len(sc1) * len(tg) * self.w("curse_scale", lvl)
                s = self.w("curse", lvl) * tot
                parts = [f"全体{len(tg)}人（1人あたり評価{sum(sc1) / len(sc1):.2f}）→{tot:.2f}"]
                risk = self.w("curse_risk", lvl) * self._curse_risk(eng, actor) if lvl >= 2 else 0.0
                if risk:
                    s -= risk
                    parts.append(f"詠唱中に潰される危険−{risk:.2f}")
                items.append((a, tg[0], None))
                scores.append(s)
                why.append(parts)
                continue
            if a.kind is ActionKind.ATTACK:
                for t in eng.valid_targets(actor, a):
                    r = eng.reach(actor, t, a)
                    f = features(eng, actor, a, t, r if r.ok else None)
                    s, parts = score(f, W["weights"])
                    if plan and r.ok and r.via_route == plan["route"]:
                        s += self.planner.exploit_bonus
                        parts = ["連携計画の侵入"] + parts
                    if howl_t == t.id:
                        b = self.w("howl_bonus", lvl)
                        if b:
                            s += b
                            parts = [f"遠吠えの指名+{b:.2f}"] + parts
                    if sp == "pin":
                        en = self._pin_enable(eng, actor, t)
                        b = self.w("pin", lvl) * en
                        s = s * 0.5 + b
                        parts = [f"牽制で介入を封じる{b:.2f}"] + parts
                    if sp == "flank" and lvl >= 2:
                        rk = self.w("flank_risk", lvl) * self._flank_risk(eng, actor)
                        if rk:
                            s -= rk
                            parts = parts + [f"持ち場を離れる危険−{rk:.2f}"]
                    items.append((a, t, r))
                    scores.append(s)
                    why.append(parts)
                continue
            if sp == "howl":
                if howl_t is not None:
                    continue
                best = None
                for t in eng.valid_targets(actor, a):
                    v = self._howl_value(eng, actor, t, W)
                    if best is None or v > best[0]:
                        best = (v, t)
                if best and best[0] > 0:
                    s = self.w("howl", lvl) * best[0]
                    items.append((a, best[1], None))
                    scores.append(s)
                    why.append([f"遠吠えで{best[1].name}を指名（群れの評価{best[0]:.2f}）"])
        if not items:
            return Decision("wait", reasons=["届く標的なし"])
        # 戦闘不能者の扱い（既存 PA-111）は単体攻撃だけに適用
        if eng.incap_ai == "tiered" and lvl >= 1:
            alive_att = [k for k, (a, t, r) in enumerate(items) if r is not None and t.alive]
            if alive_att:
                keep = [k for k, (a, t, r) in enumerate(items) if r is None or t.alive]
                items = [items[k] for k in keep]
                scores = [scores[k] for k in keep]
                why = [why[k] for k in keep]
        i = None
        focus_msg = None
        if self.lock.active_for(lvl):
            sub = [k for k, (a, t, r) in enumerate(items) if r is not None]
            if sub:
                si, focus_msg, key = self.lock.apply(eng, actor, lvl, [items[k] for k in sub],
                                                     [scores[k] for k in sub], [why[k] for k in sub])
                if key:
                    eng.stats.c[key] += 1
                if si is not None:
                    i = sub[si]
                    others = [k for k in range(len(items)) if items[k][2] is None]
                    if others:
                        o = max(others, key=lambda k: scores[k])
                        if scores[o] > scores[i] + self.lock.keep_bonus + self.lock.switch_margin:
                            i = o
                            focus_msg = (focus_msg or "") + " / 特殊行動を優先"
        if i is None:
            i = softmax_pick(list(range(len(items))), scores, W["temperature"], self.rng)
            a0, t0, r0 = items[i]
            if self.lock.active_for(lvl) and r0 is not None:
                exp = eng.estimate_damage(actor, a0, t0)
                if exp > 0 and t0.hp / exp <= self.lock.max_hits:
                    m = self.lock.maybe_acquire(actor, lvl, t0, scores[i])
                    if m:
                        eng.stats.c["focus_acquire"] += 1
                        focus_msg = (focus_msg + " / " + m) if focus_msg else m
        a, t, r = items[i]
        reasons = [f"{INTEL_NAMES[lvl]}: " + "、".join(why[i])]
        if focus_msg:
            reasons.append(focus_msg)
        tags = {}
        if plan and r is not None and r.via_route == plan["route"]:
            tags["plan_exploit"] = plan["id"]
        return Decision(a.id, t.id if t is not None else None, reasons=reasons, tags=tags)
