"""標的の特徴量 × 知能別ウェイトで採点する（交換可能）。特徴量は 0..1。"""
from __future__ import annotations

import math

from ...model.enums import Rank

FEATURE_JA = {
    "proximity": "近さ", "threat": "脅威度", "expected_damage": "与ダメ見込み", "killable": "撃破可能",
    "rear": "後衛", "low_hp": "瀕死度", "ep_empty": "EP枯渇", "weak_body": "肉体が脆い",
    "open_route": "OPEN経路", "displaced": "持ち場離脱中", "is_leader_or_mage": "要の人物",
    "plan_exploit": "連携計画の侵入", "pierce": "肉体へ貫通見込み", "def_inefficiency": "防御効率の悪化",
}


def features(engine, actor, a, t, reach) -> dict:
    foes = engine.state.side_units(t.side)
    max_threat = max(max(f.d.power, f.d.magic) for f in foes) or 1
    max_body = max(f.d.body for f in foes) or 1
    # PA-36: 低知能(0)・通常(1)は「負傷で防御効率が落ちる」ことを理解しない見積もりを使う
    exp = engine.estimate_damage(actor, a, t, naive=(actor.intel_effective or 0) < 2)
    raw = engine.damage.expected(actor, a)
    max_frag = max(engine.defense.fragility(f) for f in foes) or 1
    return {
        "proximity": 1.0 if t.rank is Rank.FRONT else 0.3,
        "threat": max(t.d.power, t.d.magic) / max_threat,
        "expected_damage": min(1.0, exp / max(t.hp, 1)),
        "killable": 1.0 if exp >= t.hp else 0.0,
        "rear": 1.0 if t.rank is Rank.REAR else 0.0,
        "low_hp": 1.0 - t.hp_ratio,
        "ep_empty": 1.0 if engine.defense.exhausted(t) else 0.0,
        "weak_body": 1.0 - t.d.body / max_body,
        "open_route": 1.0 if reach is not None and reach.via_route else 0.0,
        "displaced": 1.0 if t.displaced else 0.0,
        "is_leader_or_mage": 1.0 if (t.d.is_leader or t.d.role == "mage") else 0.0,
        # Ver0.4: HP＝肉体強度モデル用（高知能以上のみウェイトを持つ）
        "pierce": min(1.0, exp / raw) if raw > 0 else 0.0,            # 防御を貫いて肉体へ通る割合の見込み
        "def_inefficiency": engine.defense.fragility(t) / max_frag,   # 防御効率の悪さ（負傷で悪化）
    }


def score(feats: dict, weights: dict) -> tuple[float, list]:
    parts = [(k, feats.get(k, 0.0) * w) for k, w in weights.items()]
    total = sum(v for _, v in parts)
    top = sorted((p for p in parts if p[1] > 0.05), key=lambda p: -p[1])[:3]
    return total, [f"{FEATURE_JA.get(k, k)}{v:+.2f}" for k, v in top]


def softmax_pick(items, scores, temperature, rng):
    if temperature <= 0:
        return items[max(range(len(items)), key=lambda i: scores[i])]
    m = max(scores)
    ws = [math.exp((s - m) / temperature) for s in scores]
    r = rng.random() * sum(ws)
    acc = 0.0
    for it, w in zip(items, ws):
        acc += w
        if r <= acc:
            return it
    return items[-1]
