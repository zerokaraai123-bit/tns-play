"""味方自動AI。行動・防御(base)は3方針共通、介入判断だけを差し替える（PA-16）。"""
from __future__ import annotations

from ...control.controller import Controller, Decision
from ...formation.route import holding_blockers
from ...intervention.records import InterventionChoice
from ...model.enums import ActionKind, Rank, Reach, Side


class AllyAutoController(Controller):
    name = "ally_auto"

    def __init__(self, pol_cfg: dict, policy: str = "situational"):
        self.base = pol_cfg["base"]
        self.policy_name = policy
        self.pcfg = pol_cfg["policies"].get(policy, {}) or {}
        if policy == "rear_ep_protect":
            # Ver0.7 比較実験専用（正式AIではない, PA-64）。REAR狙い以外は状況判断と同じ設定で判断する
            self.pcfg = pol_cfg["policies"].get("situational", {}) or {}
        # Ver0.5: 回復・補給の順番（none / heal_first / supply_first）PA-45
        self.order = (pol_cfg.get("recovery") or {}).get("order", "none")
        if policy not in ("always", "never", "situational", "rear_ep_protect"):
            raise ValueError(policy)

    # ------------------------------------------------------------------ 共通ヘルパ
    def importance(self, u) -> float:
        return self.base["importance"].get(u.d.role, 1.0)

    def loss(self, u, dmg) -> float:
        imp = self.importance(u)
        return imp * min(1.0, dmg / u.d.hp_max) + (self.base["ko_penalty"] * imp if dmg >= u.hp else 0.0)

    # ------------------------------------------------------------------ 行動 (base)
    def decide_action(self, actor) -> Decision:
        eng = self.engine
        acts = {a.id: a for a in eng.available_actions(actor)}
        kinds = {a.kind for a in acts.values()}
        if ActionKind.HEAL in kinds or any(a.kind is ActionKind.ATTACK and a.source == "magic" for a in acts.values()) \
                or "heal" in actor.d.action_ids:
            return self._mage(actor, acts)
        if ActionKind.EP_SUPPLY in kinds:
            return self._toolsmith(actor, acts)
        if "ep_supply" in actor.d.action_ids:
            return Decision("wait", reasons=["補給品切れ"])
        return self._attacker(actor, acts)

    def _attack_choice(self, actor, attacks):
        eng = self.engine
        W = self.base["attack_weights"]
        best = None
        for a in attacks:
            for t in eng.capable_first_targets(actor, a):
                r = eng.reach(actor, t, a)
                d = eng.estimate_damage(actor, a, t)
                f = {
                    "expected_damage": min(1.0, d / max(t.hp, 1)),
                    "killable": 1.0 if d >= t.hp else 0.0,
                    "low_hp": 1 - t.hp_ratio,
                    "leader": 1.0 if t.d.is_leader else 0.0,
                    "rear": 1.0 if t.rank is Rank.REAR else 0.0,
                    "open_route": 1.0 if r.via_route else 0.0,
                    "threat": min(1.0, max(t.d.power, t.d.magic) / 25),
                }
                s = sum(W.get(k, 0) * v for k, v in f.items())
                if best is None or s > best[0]:
                    top = sorted(((k, W.get(k, 0) * v) for k, v in f.items()), key=lambda x: -x[1])[:2]
                    best = (s, a, t, r, top)
        return best

    def _attacker(self, actor, acts):
        attacks = [a for a in acts.values() if a.kind is ActionKind.ATTACK]
        best = self._attack_choice(actor, attacks)
        if not best:
            return Decision("wait", reasons=["到達できる標的なし"])
        s, a, t, r, top = best
        why = [f"標的評価{s:.2f}（" + "、".join(f"{k}{v:+.2f}" for k, v in top) + "）"]
        if r.via_route:
            why.append(f"敵の経路{r.via_route}がOPEN → 後衛へ侵入")
        return Decision(a.id, t.id, reasons=why)

    def _mage(self, actor, acts):
        eng = self.engine
        m = self.base["mage"]
        heal = acts.get("heal") or next((a for a in acts.values() if a.kind is ActionKind.HEAL), None)
        if heal:
            hurt = [u for u in eng.state.side_units(actor.side) if u.hp_ratio < m["heal_threshold"]]
            if self.order == "supply_first" and self._supplier_available():
                # 補給→治療: EPが足りない相手は、先に補給を受けるまで治療しない（PA-45）
                gated = [u for u in hurt if self._needs_supply(u)]
                if gated:
                    eng.stats.c["v5_gate_skip_heal"] += len(gated)
                hurt = [u for u in hurt if not self._needs_supply(u)]
            if hurt:
                t = min(hurt, key=lambda u: u.hp_ratio - (m["heal_front_bonus"] if u.rank is Rank.FRONT else 0)
                        - 0.1 * (self.importance(u) - 1))
                return Decision(heal.id, t.id,
                                reasons=[f"{t.name}のHP{t.hp_ratio:.0%} < {m['heal_threshold']:.0%} → EPを治癒へ配分"])
        attacks = [a for a in acts.values() if a.kind is ActionKind.ATTACK]
        best = self._attack_choice(actor, attacks)
        if best:
            s, a, t, r, top = best
            kill = eng.estimate_damage(actor, a, t) >= t.hp
            if kill or actor.ep - a.ep_cost >= m["fire_ep_reserve"]:
                return Decision(a.id, t.id, reasons=[("とどめを優先" if kill else
                                                      f"EP残{actor.ep - a.ep_cost}≥温存ライン{m['fire_ep_reserve']} → 攻撃へ配分")])
        return Decision("wait", reasons=[f"EP{actor.ep}を治癒・防御用に温存"])

    def _toolsmith(self, actor, acts):
        eng = self.engine
        sup = next(a for a in acts.values() if a.kind is ActionKind.EP_SUPPLY)
        tc = self.base["toolsmith"]
        best = None
        healer_ok = self.order == "heal_first" and self._healer_available()
        for t in eng.valid_targets(actor, sup):
            deficit = t.d.ep_max - t.ep
            if deficit < sup.amount * tc["min_deficit_ratio"]:
                continue
            if healer_ok and t.hp_ratio < self.base["mage"]["heal_threshold"]:
                # 治療→補給: HPが減っている相手は、先に治療を受けるまで補給しない（PA-45）
                eng.stats.c["v5_gate_skip_supply"] += 1
                continue
            pr = deficit * (tc["mage_priority"] if "heal" in t.d.action_ids else 1.0)
            if eng.defense.exhausted(t):
                pr *= 1.3
            if tc.get("collapsed_first") and eng.cstate[t.id]["collapsed"] and self._needs_supply(t):
                # Ver0.5（PA-46）: 戦線崩壊中でEPが足りない味方を最優先（治療側の「HP50%未満を治療」と対になる基準）
                pr += 10_000 + (100 if t.rank is Rank.FRONT else 0)
            if best is None or pr > best[0]:
                best = (pr, t)
        if best:
            t = best[1]
            return Decision(sup.id, t.id, reasons=[f"{t.name}のEP{t.ep}/{t.d.ep_max}を補給"])
        return Decision("wait", reasons=["補給が必要な味方なし"])

    # ------------------------------------------------------------------ Ver0.5: 順番制御の判定（両方向で同じ閾値）
    def _needs_supply(self, u) -> bool:
        """EPが「標準の一撃2発を防ぎ切れる量」に満たない（＝戦線復旧のEP条件を満たさない）。"""
        eng = self.engine
        return u.ep < eng.recover_hits * eng._hit_cost(u)

    def _supplier_available(self) -> bool:
        eng = self.engine
        for u in eng.state.side_units(self.side):
            if "ep_supply" in u.d.action_ids and u.uses.get("ep_supply", 0) > 0:
                return True
        return False

    def _healer_available(self) -> bool:
        eng = self.engine
        heal = eng.actions.get("heal")
        for u in eng.state.side_units(self.side):
            if heal and "heal" in u.d.action_ids and u.ep >= heal.ep_cost:
                return True
        return False

    # ------------------------------------------------------------------ 防御 (base)
    def decide_defense(self, defender, attacker, action, expected_raw):
        d = self.base["defense"]
        if expected_raw >= defender.hp:
            return True, "致命傷を避けるため展開"
        if expected_raw < d["min_raw_to_defend"]:
            return False, "被弾見込みが小さくEP温存"
        if d.get("keep_ep_for_heal") and "heal" in defender.d.action_ids:
            heal_cost = self.engine.actions["heal"].ep_cost
            spend = self.engine.defense.preview(defender, expected_raw)[1]
            if defender.ep - spend < heal_cost:
                return False, "治癒1回分のEPを温存"
        return True, "展開"

    # ------------------------------------------------------------------ 介入（方針で差し替え）
    def decide_intervention(self, window) -> InterventionChoice:
        if self.policy_name == "never":
            return InterventionChoice(None, reasons=["方針never: 介入しない"])
        if self.policy_name == "always":
            # 肉体強度が最大の味方。Ver0.4 の hp_power モデルでは「肉体強度＝現在HP」（PA-30）
            strength = (lambda u: u.hp) if self.engine.defense.name == "hp_power" else (lambda u: u.d.body)
            c = max(window.eligible, key=lambda u: (strength(u), u.rank is Rank.FRONT))
            return InterventionChoice(c.id, reasons=["方針always: 肉体強度最大の味方が介入"])
        if self.policy_name == "rear_ep_protect":
            return self._rear_ep_protect(window)
        return self._situational(window)

    def _rear_ep_protect(self, window) -> InterventionChoice:
        """Ver0.7 比較実験用の介入方針 REAR EP Protection（PA-64）。正式AIではない。
        敵がREARを攻撃し、介入可能なFRONTがいれば、REAR自身がEPで防げる場合でもFRONTが介入する。
        どのFRONTが出るかは状況判断と同じ損失（被弾見込み＋穴リスク）が小さい方。REAR狙い以外は状況判断のまま。"""
        t = window.target
        fronts = [c for c in window.eligible if c.rank is Rank.FRONT]
        if t.rank is not Rank.REAR or not fronts:
            return self._situational(window)
        eng = self.engine
        best = None
        for c in fronts:
            take = self.loss(c, eng.estimate_damage(window.attacker, window.action, c))
            hole, _ = self._hole_risk(c)
            if best is None or take + hole < best[0]:
                best = (take + hole, c)
        return InterventionChoice(best[1].id, reasons=[f"REAR EP温存（比較実験）: {best[1].name}が{t.name}への攻撃に介入"])

    def _hole_risk(self, c):
        """c が持ち場を離れた場合に、穴を突かれる見込み損失（PA-18）。"""
        eng = self.engine
        p = self.pcfg.get("p_exploit", 0.6)
        risk, txt = 0.0, ""
        before = list(dict.fromkeys(eng.actors_before_next_turn_of(c.id)))
        for R in eng.state.routes_blocked_by(c.id):
            if holding_blockers(R, eng.state.units) != [c.id]:
                continue
            rear = [eng.u(x) for x in R.protects if eng.u(x).alive]
            threats = [eng.u(x) for x in before if eng.u(x).side is Side.ENEMY and eng.u(x).alive
                       and eng.u(x).rank is Rank.FRONT]
            worst = 0.0
            for e in threats:
                for a in eng.available_actions(e):
                    if a.kind is ActionKind.ATTACK and a.reach is Reach.MELEE:
                        for q in rear:
                            worst = max(worst, self.loss(q, eng.estimate_damage(e, a, q)))
            if threats and worst > 0:
                prob = 1 - (1 - p) ** len(threats)
                risk += prob * worst
                txt = f"穴リスク{prob * worst:.2f}（{threats[0].name}ほか{len(threats)}体が{c.name}の復帰前に行動）"
        return risk, txt

    def _situational(self, window) -> InterventionChoice:
        eng = self.engine
        t, atk, a = window.target, window.attacker, window.action
        loss_no = self.loss(t, eng.estimate_damage(atk, a, t))
        best = None
        notes = []
        for c in window.eligible:
            take = self.loss(c, eng.estimate_damage(atk, a, c))
            hole, txt = self._hole_risk(c)
            total = take + hole
            notes.append(f"{c.name}介入 {total:.2f}(被弾{take:.2f}{'+' + txt if txt else ''})")
            if best is None or total < best[0]:
                best = (total, c)
        head = f"介入しない損失{loss_no:.2f}"
        if best and best[0] + self.pcfg.get("margin", 0.02) < loss_no:
            return InterventionChoice(best[1].id, reasons=[f"状況判断: {head} > " + " / ".join(notes)])
        return InterventionChoice(None, reasons=[f"状況判断: {head} ≤ 介入案 " + " / ".join(notes)])
