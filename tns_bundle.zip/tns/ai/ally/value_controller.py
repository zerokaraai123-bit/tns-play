"""Ver0.8 自由設計実験: 価値で判断する味方AI（M1〜M5 共通）。

考え方（PA-80〜）:
  すべての判断を「戦力点」という1つの通貨で比べる。
    味方の損失   = 重要度 ×（失うHP / 最大HP）＋ 戦闘不能・死亡になるなら 重要度 × ko_penalty
    敵に与える価値 = （HPダメージ ＋ 削ったEPが防げたはずの威力）/ 敵の最大HP ＋ 倒せる（15%以下にできる）なら ko_penalty
  EPそのものには固定の値段を付けない。EPの価値は「そのEPで何ができるか」から毎回計算する（機会費用）:
    W_u(e) = max over 使える行動a [ 行動aの価値 ＋ 残りEPで自分を守れる価値 V_def(e − cost_a) ]
    EPを c 使う痛み = W_u(e) − W_u(e − c)
  → 治療魔法・大魔法の「使えるEPの線」をまたぐと、痛みが非線形に大きくなる。
  V_def（自衛用EPの価値）は「この先2巡で、守ってもらえずに自分に来そうな攻撃の数」で決まる。
    前衛が健在で構えていれば、REARに来る攻撃の一部は前衛が受けてくれる見込み → 自衛用EPの価値が下がる → 大胆に使える。
    前衛が倒れる・EPが尽きると見込みが消える → 自衛用EPの価値が上がる → 温存に切り替わる。

使う情報はキャラクターが知り得るものだけ（PA-81）:
  見えている行動順・敵味方のHP/EP・敵の攻撃の届き方・攻撃の期待威力。
  未来の乱数、敵AIの内部の重み、敵が誰を狙うかの答えは使わない（狙いは「届く相手から等確率」と見積もる）。
"""
from __future__ import annotations

import math

from ...control.controller import Decision
from ...formation.reach import check_reach
from ...formation.route import holding_blockers
from ...intervention.records import InterventionChoice
from ...model.enums import ActionKind, Rank, Reach, Side
from .ally_controller import AllyAutoController

HORIZON = 2.0          # PA-82: 自衛用EPの価値を見積もる先読み（巡）
ENEMY_W = 1.0          # PA-83: 敵の最大HP 1体分 = 味方（重要度1）の最大HP 1人分（対称）

def eff_strength(defense, u):
    """実効肉体強度（Ver0.9の記録用）。実効肉体強度モデルならその値、hp_power なら等価な値を逆算する。"""
    if hasattr(defense, "effective_strength"):
        return defense.effective_strength(u)
    q = defense.q if defense.q is not None else defense.p
    if not q:
        return float(u.hp)
    return defense.h_ref * (defense.k / defense.cpd(u)) ** (1.0 / q)


PROBES = ("always_iv", "never_iv", "iv_off", "always_storm", "fixed_reserve", "heal_only", "mage_only")


class ValueAllyController(AllyAutoController):
    name = "ally_value"

    cast_aware = False      # 詠唱実験: True のとき詠唱中の味方を守る価値（_cast_stake）を判断に入れる

    def __init__(self, pol_cfg: dict, probe: str | None = None, hole_model: str = "v9"):
        super().__init__(pol_cfg, "situational")
        self.probe = probe
        self.hole_model = hole_model          # Ver0.10: "v9"=従来の穴の見積もり / "v10"=離脱後の危険を敵の行動ごとに見積もる
        #                                        Ver0.11: "v11"= v10 ＋ ①離脱中に狙われる危険（実績）＋ ②前衛の将来価値
        #                                        Ver0.13: "v13"= v11 ＋ 時間認識（PA-190: 次の手番までの時間・敵の行動機会を新しい時間軸で数える）
        self.policy_name = ("value" if probe is None else f"value+{probe}") + ("" if hole_model == "v9" else f"+{hole_model}")
        self.last_pred = None
        self.records = []          # 判断記録（集計・ログ用）
        self._cache = {}
        self._sig = None

    def bind(self, engine, side):
        super().bind(engine, side)
        self._v11_by_f = {}
        self.obs = {"A": 0.0, "U": 0.0, "n": 0}        # Ver0.11 ①: 持ち場を離れた味方が狙われた実績（この戦闘で見えたもの）
        if self.hole_model in ("v11", "v13"):
            engine.listeners.append(self._observe)

    def _observe(self, ev, eng):
        """Ver0.11 ①（PA-120）: 敵の攻撃宣言を見て、「持ち場を離れた味方が候補にいたとき、実際にそこが狙われたか」を数える。
        候補＝その攻撃が届く戦闘可能な味方（キャラクターにも見える情報）。敵AIの内部の重みは使わない。"""
        if ev["t"] != "attack_declared":
            return
        a, tg = eng.u(ev["unit"]), eng.u(ev["target"])
        if a.side is not Side.ENEMY or tg.side is not Side.ALLY or not tg.alive:
            return
        act = eng.actions[ev["action"]]
        cand = [u for u in eng.state.side_units(Side.ALLY) if check_reach(a, u, act.reach, eng.state).ok]
        disp = [u for u in cand if u.displaced]
        if not disp or tg not in cand:
            return
        self.obs["A"] += 1.0 if tg.displaced else 0.0
        self.obs["U"] += len(disp) / len(cand)
        self.obs["n"] += 1

    def disp_mult(self):
        """離脱中の味方が、等確率の見込みより何倍狙われやすいか（実績ベース, 弱い事前分布つき）。"""
        k0 = self.pcfg.get("disp_prior", 1.0)       # PA-120: 事前は「等確率」を1回ぶん観測したのと同じ重み
        return (self.obs["A"] + k0) / (self.obs["U"] + k0)

    def _cached(self, key, fn):
        eng = self.engine
        sig = (eng.action_index, sum(u.hp * 131 + u.ep * 7 + (1 if u.displaced else 0) + len(u.stance.value)
                                     for u in eng.state.units.values()), tuple(sorted(eng.cover.items())),
               tuple(sorted(eng.aegis_used)))
        if sig != self._sig:
            self._sig = sig
            self._cache = {}
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    # ================================================================ 基本量
    def ko_pen(self):
        return self.base["ko_penalty"]

    def incap_hp(self, u):
        r = u.incap_ratio
        return r * u.d.hp_max if r > 0 else 0.0

    def body_loss(self, u, dmg, hp=None):
        """生身でdmgを受けたときの損失（戦闘不能・死亡ラインを知っている）。"""
        hp = u.hp if hp is None else hp
        if dmg <= 0:
            return 0.0
        imp = self.importance(u)
        inc = self.incap_hp(u)
        out = hp - dmg <= inc if inc > 0 else dmg >= hp
        v = imp * min(1.0, dmg / u.d.hp_max) + (self.ko_pen() * imp if out else 0.0)
        if not out:
            # 肉体が傷むと、この先「EPで防ぎきれない被弾」の損失が増える（PA-84 改訂）:
            #   負傷で防御の必要EPが増える（負傷補正P）＋ あと1発で倒れる範囲に入る、の両方を含む
            v += max(0.0, self.future_loss(u, hp - dmg, u.ep) - self.future_loss(u, hp, u.ep))
        return v

    def _at_hp(self, u, hp, fn):
        save = u.hp
        try:
            u.hp = max(1, int(round(hp)))
            return fn()
        finally:
            u.hp = save

    def ell0(self, u, hp):
        """平均的な一撃を生身で受けたときの、その場の損失（倒れるならKO込み）。"""
        x = self.avg_raw(u) * self.engine.body_mult
        if x <= 0:
            return 0.0
        imp = self.importance(u)
        inc = self.incap_hp(u)
        out = hp - x <= inc if inc > 0 else x >= hp
        return imp * min(1.0, x / u.d.hp_max) + (self.ko_pen() * imp if out else 0.0)

    def future_loss(self, u, hp, r, pi=None):
        """この先 HORIZON 巡で、守ってもらえず・EPでも防ぎきれない被弾の見込み損失。"""
        x = self.avg_raw(u)
        if x <= 0:
            return 0.0
        pi = self.protection(u) if pi is None else pi
        k = self.rate(u) * HORIZON * (1 - pi)
        c = max(self._at_hp(u, hp, lambda: self.engine.defense.required_ep(u, x)), 1e-6)
        return self.ell0(u, hp) * max(0.0, k - r / c)

    def enemy_attack(self, e):
        return next((self.engine.actions[a] for a in e.d.action_ids
                     if self.engine.actions[a].kind is ActionKind.ATTACK), None)

    def threats_to(self, u):
        return self._cached(("th", u.id), lambda: self._threats_to(u))

    def _threats_to(self, u):
        """u に届く敵と、その敵が u を狙う見込み（届く相手から等確率, PA-81）。"""
        eng = self.engine
        out = []
        for e in eng.state.side_units(Side.ENEMY):
            a = self.enemy_attack(e)
            if a is None:
                continue
            tg = [t for t in eng.state.side_units(Side.ALLY) if check_reach(e, t, a.reach, eng.state).ok]
            if u in tg:
                out.append((e, a, 1.0 / len(tg)))
        return out

    def rate(self, u):
        return sum(p for _, _, p in self.threats_to(u))

    # ---------------------------------------------------------------- Ver0.13（PA-190）: 時間認識
    def base_rate(self, u):
        eng = self.engine
        return eng.base_rate(u) if hasattr(eng, "base_rate") else 1.0

    def unit_rate(self, u, hp=None):
        """1Tあたりの行動回数（基礎速度 × HP速度倍率）。旧時間軸では HP倍率のみ。"""
        eng = self.engine
        m = eng.speed_mult(u) if hp is None else self._at_hp(u, hp, lambda: eng.speed_mult(u))
        return self.base_rate(u) * m

    def rate_T(self, u):
        """u が1Tあたりに受けそうな攻撃の数（敵ごとの行動頻度 × 狙う見込み）。"""
        return sum(p * self.unit_rate(e) for e, _, p in self.threats_to(u))

    def _leak_body(self, f, raw):
        eng = self.engine
        need = math.ceil(eng.defense.required_ep(f, raw) - 1e-9)
        spend = min(f.ep, need) if eng.defense.can_deploy(f) else 0
        blocked = spend / max(eng.defense.required_ep(f, 1.0), 1e-9)
        return max(0.0, raw - blocked) * eng.body_mult

    def window_actors(self, f, window, hp_after=None):
        """f が持ち場を離れてから次の自分の手番までに行動しそうな者（同じ敵の2回行動は2回）と、その時間。
        old    : 旧来どおり エンジンの「f の次の手番までの予定」をそのまま使う（時間の長さは記録用）
        next_hp: f の次の手番の予定時刻を、介入で受ける生身（hp_after）による速度低下で遅らせた時刻まで（PA-190）
        full   : 今から f の行動間隔1回分（持ち場を離れたときの標準の穴の時間。将来価値の計算用）
        予定は速度と現在のHPだけから計算する（乱数・敵AIの内部は使わない）。"""
        eng = self.engine
        now = getattr(eng, "cur_time", 0.0)
        nt = eng.next_time.get(f.id, now) if hasattr(eng, "next_time") else now
        if window == "old" or not hasattr(eng, "actions_before_time"):
            return eng.actors_before_next_turn_of(f.id), max(0.0, nt - now)
        if window == "full":
            end = now + eng.interval(f)
        else:
            m0 = eng.speed_mult(f)
            m1 = m0 if hp_after is None else self._at_hp(f, max(1.0, hp_after), lambda: eng.speed_mult(f))
            end = now + max(0.0, nt - now) * m0 / max(m1, 1e-9)
        return eng.actions_before_time(end, f), end - now

    def _time_preds(self, f, t, raw, mode):
        """記録用（判断には使わない）: 旧来の見積もり（o_）と時間認識版の見積もり（n_）を両方残す。"""
        if mode != "move":
            return {}
        hp_after = f.hp - self._leak_body(f, raw)
        save = self.hole_model
        out = {}
        try:
            for tag, win in (("o_", "old"), ("n_", "next_hp")):
                ids, wl = self.window_actors(f, win, hp_after)
                pr = self._after_risk(f, t, before_ids=ids)
                out.update({tag + "win": round(wl, 4), tag + "nact": pr["n_enemy_actions"],
                            tag + "fdmg": round(pr["pred_front_dmg"], 2), tag + "rhits": round(pr["pred_extra_rear_hits"], 3),
                            tag + "rhp": round(pr["pred_rear_hp"], 2),
                            tag + "acts": "・".join(x for x in ids if self.engine.u(x).side is Side.ENEMY)})
        finally:
            self.hole_model = save
        return out

    def avg_raw(self, u):
        th = self.threats_to(u)
        if not th:
            return 0.0
        w = sum(p for _, _, p in th)
        return sum(self.engine.damage.expected(e, a) * p for e, a, p in th) / w

    def protection(self, u):
        return self._cached(("pi", u.id), lambda: self._protection(u))

    def _protection(self, u):
        """REAR u に来る攻撃のうち、前衛が受けてくれる見込みの割合 π（0〜1）。"""
        eng = self.engine
        if u.rank is Rank.FRONT or self.probe == "never_iv":
            return 0.0
        for c, t in eng.cover.items():
            if t == u.id and eng.u(c).alive and not eng.u(c).displaced:
                return 1.0
        x = self.avg_raw(u)
        able = 0
        for f in eng.state.side_units(u.side):
            if f.rank is not Rank.FRONT or f.id == u.id:
                continue
            if f.displaced or f.id in eng.aegis_used:
                continue
            need = eng.aegis_need(f, x) if eng.aegis_on else eng.defense.required_ep(f, x)
            if f.ep >= need and f.hp_ratio > 0.4:
                able += 1
        if not able:
            return 0.0
        rear_rate = sum(self.rate(r) for r in eng.state.side_units(u.side) if r.rank is Rank.REAR)
        return min(1.0, able / max(rear_rate, 1e-6))

    def regen_next(self, u, e):
        eng = self.engine
        g = 0
        if eng.regen_ratio > 0:
            g = int(round(u.d.ep_max * eng.regen_ratio))
        elif eng.ward_ratio and eng.ward_regen_ratio > 0:
            g = int(round(eng.ward_max[u.id] * eng.ward_regen_ratio))
        return min(u.d.ep_max, e + g)

    def v_def(self, u, r, pi=None):
        """自衛用に r EP を持っている価値（この先 HORIZON 巡で守ってもらえない被弾を防げる分）。"""
        eng = self.engine
        x = self.avg_raw(u)
        if x <= 0 or r <= 0:
            return 0.0
        pi = self.protection(u) if pi is None else pi
        k = self.rate(u) * HORIZON * (1 - pi)
        c = max(eng.defense.required_ep(u, x), 1e-6)
        return self.ell0(u, u.hp) * min(k, r / c)

    def proj_heal_value(self, u):
        """次の機会に治療を使う価値の見込み（PA-87）。各味方の「この先、防ぎきれずに減りそうなHP」を引いた状態で評価する。"""
        def f():
            eng = self.engine
            a = next((eng.actions[x] for x in u.d.action_ids if eng.actions[x].kind is ActionKind.HEAL), None)
            if a is None:
                return 0.0, 0
            best = 0.0
            for x in eng.state.side_units(u.side):
                xr = self.avg_raw(x)
                if xr <= 0:
                    hp_p = x.hp
                else:
                    k = self.rate(x) * HORIZON * (1 - self.protection(x))
                    c = max(eng.defense.required_ep(x, xr), 1e-6)
                    hp_p = x.hp - eng.body_mult * xr * max(0.0, k - x.ep / c)
                hp_p = max(1.0, min(x.hp, hp_p))
                if hp_p <= self.incap_hp(x):
                    hp_p = self.incap_hp(x) + 1
                best = max(best, self._at_hp(x, hp_p, lambda: self.val_heal(u, a, x)))
            return best, a.ep_cost
        return self._cached(("ph", u.id), f)

    def v_rest(self, u, r, pi=None):
        """残りEP r の価値 = 自衛に取っておく価値 と「次の機会に魔法を使う」価値の大きい方（2手先まで, PA-87）。"""
        best = self.v_def(u, r, pi)
        eng = self.engine
        ward = min(u.ward, r) if eng.ward_ratio else 0
        # 攻撃魔法は「今撃っても次に撃っても同じ価値」なので先送りの理由にしない（先送りを無割引で数えると
        # 永遠に後回しにする判断になる: AI改訂v2で確認）。将来の価値が状態で変わる治療だけを数える（PA-87）
        heal = next((eng.actions[x] for x in u.d.action_ids if eng.actions[x].kind is ActionKind.HEAL), None)
        if heal is not None and heal.ep_cost <= r - ward:
            fut = self.proj_heal_value(u)[0]
            best = max(best, fut + self.v_def(u, r - heal.ep_cost, pi))
        return best

    def _now_actions(self, u):
        return self._cached(("na", u.id), lambda: self.best_actions(u, 10 ** 6))

    # ---------------------------------------------------------------- 行動の価値
    def val_attack(self, u, a, t):
        eng = self.engine
        exp = eng.damage.expected(u, a)
        d_hp = eng.estimate_damage(u, a, t)
        drained = 0.0
        if d_hp < exp - 1e-6:
            cpd = max(eng.defense.required_ep(t, 1.0), 1e-6)
            drained = min(t.ep, eng.defense.required_ep(t, exp)) / cpd
        v = ENEMY_W * (d_hp + drained) / t.d.hp_max
        if d_hp >= t.hp - self.incap_hp(t):
            v += self.ko_pen() * ENEMY_W
        return v

    def val_heal(self, u, a, t):
        eng = self.engine
        amt = int(round(a.heal_ratio * t.d.hp_max)) if a.heal_ratio else eng.heal.amount(u, a)
        amt = min(amt, t.d.hp_max - t.hp)
        if amt <= 0:
            return 0.0
        imp = self.importance(t)
        v = imp * amt / t.d.hp_max
        if t.incapacitated and t.hp + amt > self.incap_hp(t):
            # Ver0.10.2（PA-110）: 戦闘復帰させる価値 = 離脱の損失（body_loss の KO 分）の逆
            v += self.ko_pen() * imp
        # 肉体が戻ると、防御の必要EPも下がり、瀕死圏からも出る（同じ future_loss で評価, PA-86）
        v += max(0.0, self.future_loss(t, t.hp, t.ep) - self.future_loss(t, t.hp + amt, t.ep))
        return v

    def best_actions(self, u, e_spend):
        """(価値, 行動, 標的, コスト) の候補。e_spend = 行動に使えるEP。"""
        eng = self.engine
        out = [(0.0, "wait", None, 0)]
        for aid in u.d.action_ids:
            a = eng.actions[aid]
            if a.ep_cost > e_spend:
                continue
            if a.kind is ActionKind.ATTACK:
                tg = eng.capable_first_targets(u, a)
                if a.area == "all":
                    tg = [t for t in tg if t.alive]      # 範囲攻撃は戦闘不能者に当たらない（エンジンの現行処理）
                if not tg:
                    continue
                if a.area == "all":
                    out.append((sum(self.val_attack(u, a, t) for t in tg), a.id, tg[0].id, a.ep_cost))
                else:
                    t = max(tg, key=lambda t: self.val_attack(u, a, t))
                    out.append((self.val_attack(u, a, t), a.id, t.id, a.ep_cost))
            elif a.kind is ActionKind.HEAL:
                tg = eng.valid_targets(u, a)
                if tg:
                    t = max(tg, key=lambda t: self.val_heal(u, a, t))
                    out.append((self.val_heal(u, a, t), a.id, t.id, a.ep_cost))
        return out

    def W(self, u, e, pi=None, next_turn=True):
        return self._cached(("W", u.id, e, None if pi is None else round(pi, 4), next_turn),
                            lambda: self._W(u, e, pi, next_turn))

    def _W(self, u, e, pi=None, next_turn=True):
        """EP e を持っているときの、次の手番での最善（行動の価値＋残りEPの自衛価値）。"""
        eng = self.engine
        if next_turn:
            e = self.regen_next(u, e)
        ward = min(u.ward, e) if eng.ward_ratio else 0
        best = None
        for v, aid, tid, cost in self.best_actions(u, e - ward):
            tot = v + self.v_rest(u, e - cost, pi)
            if best is None or tot > best[0]:
                best = (tot, aid, tid, cost, v)
        return best

    def ep_pain(self, u, c, pi=None):
        """EP を c 使うことの機会費用（W の差）。"""
        if c <= 0:
            return 0.0, None, None
        hi = self.W(u, u.ep, pi)
        lo = self.W(u, max(0, u.ep - c), pi)
        return max(0.0, hi[0] - lo[0]), hi, lo

    # ================================================================ 行動
    def decide_action(self, actor) -> Decision:
        eng = self.engine
        if actor.rank is Rank.FRONT and eng.cover_on and self.probe not in ("never_iv",):
            d = self._consider_cover(actor)
            if d is not None:
                return d
        if "fire" in actor.d.action_ids or "heal" in actor.d.action_ids:
            return self._mage_value(actor)
        return super().decide_action(actor)

    def _mage_value(self, u):
        eng = self.engine
        spend = eng.spendable_ep(u)
        pi = self.protection(u)
        cands = []
        for v, aid, tid, cost in self.best_actions(u, spend):
            rest = self.regen_next(u, u.ep - cost)
            cands.append((v + self.v_rest(u, rest, pi), v, aid, tid, cost))
        cands.sort(key=lambda x: -x[0])
        tot, v, aid, tid, cost = cands[0]
        # 守ってもらえない場合（π=0）なら何を選んでいたか（判断の変化を数えるため）
        solo = max(((vv + self.v_rest(u, self.regen_next(u, u.ep - cc), 0.0)), aa, cc)
                   for vv, aa, tt, cc in [(c[1], c[2], c[3], c[4]) for c in cands])
        prot = max(((vv + self.v_rest(u, self.regen_next(u, u.ep - cc), 1.0)), aa, cc)
                   for vv, aa, tt, cc in [(c[1], c[2], c[3], c[4]) for c in cands])
        # 比較用の固定戦略（永久最適解の探索）
        if self.probe == "always_storm":
            pick = next((c for c in cands if c[2] == "storm"), None) or next((c for c in cands if c[2] == "fire"), None)
            if pick:
                tot, v, aid, tid, cost = pick
        elif self.probe == "fixed_reserve":
            d = super()._mage(u, {a.id: a for a in eng.available_actions(u)})
            self._rec("mage", u, choice=d.action_id, solo=solo[1], prot=prot[1], pi=pi, ep=u.ep, note="固定温存28")
            return d
        elif self.probe == "heal_only":
            pick = next((c for c in cands if c[2] == "heal"), None)
            tot, v, aid, tid, cost = pick if pick else (0, 0, "wait", None, 0)
        bold = aid != solo[1] and cost > solo[2]          # 守りの見込みがあるから、より多く使った
        cons = aid != prot[1] and cost < prot[2] and pi < 1.0   # 守りの見込みが足りないから、より温存した
        alts = "、".join(f"{c[2]}({c[1]:.2f}+残りEPの価値{c[0] - c[1]:.2f})" for c in cands[:4])
        why = (f"EP{u.ep}・守られる見込みπ={pi:.2f} → {aid}を選択。候補: {alts}"
               + (f"。守ってもらえないなら{solo[1]}だった（大胆な投入）" if bold else "")
               + (f"。十分に守られるなら{prot[1]}だった（温存へ切替）" if cons else ""))
        self._rec("mage", u, choice=aid, solo=solo[1], prot=prot[1], pi=pi, ep=u.ep, cost=cost,
                  bold=int(bold), cons=int(cons), rest=u.ep - cost, front_ok=int(self._front_alive_ok()))
        if aid == "wait" or tid is None:
            return Decision("wait", reasons=[why])
        return Decision(aid, tid, reasons=[why])

    def _front_alive_ok(self):
        return any(f.rank is Rank.FRONT and f.alive and f.ep > 0 for f in self.engine.state.side_units(self.side))

    # ---------------------------------------------------------------- M4: 庇護の構え
    def _consider_cover(self, f):
        eng = self.engine
        acts = {a.id: a for a in eng.available_actions(f)}
        if "cover" not in acts:
            return None
        atk = [a for a in acts.values() if a.kind is ActionKind.ATTACK]
        best_atk = 0.0
        for a in atk:
            for t in eng.capable_first_targets(f, a):
                best_atk = max(best_atk, self.val_attack(f, a, t))
        before = list(dict.fromkeys(eng.actors_before_next_turn_of(f.id)))
        best = None
        for x in eng.state.side_units(f.side):
            if x.rank is not Rank.REAR:
                continue
            hits = 0.0
            for eid in before:
                e = eng.u(eid)
                if e.side is not Side.ENEMY:
                    continue
                for ee, a, p in self.threats_to(x):
                    if ee is e:
                        hits += p
            if hits <= 0:
                continue
            raw = self.avg_raw(x)
            c_x = min(x.ep, math.ceil(eng.defense.required_ep(x, raw)))
            save = self.ep_pain(x, c_x, pi=0.0)[0] if c_x > 0 else self.body_loss(x, raw * eng.body_mult)
            c_f = math.ceil(eng.defense.required_ep(f, raw))
            cost_f = self.ep_pain(f, min(f.ep, c_f))[0] + (self.body_loss(f, raw * eng.body_mult) if f.ep < c_f else 0)
            gain = hits * (save - cost_f)
            if best is None or gain > best[0]:
                best = (gain, x, hits, save, cost_f)
        if self.probe == "always_iv" and best is not None:
            g, x, hits, save, cost_f = best
            self._rec("cover", f, choice="cover", target=x.id, gain=g, atk=best_atk, note="固定: 常に庇う")
            return Decision("cover", x.id, reasons=["固定戦略: 常に庇う"])
        if self.probe == "mage_only":
            x = eng.u("celestia")
            if x.alive:
                self._rec("cover", f, choice="cover", target=x.id, gain=0, atk=best_atk, note="固定: 魔導士だけ庇う")
                return Decision("cover", x.id, reasons=["固定戦略: 魔導士だけを庇う"])
            return None
        if best is None or best[0] <= best_atk + self.pcfg.get("margin", 0.02):
            if best is not None:
                self._rec("cover", f, choice="attack", target=best[1].id, gain=best[0], atk=best_atk)
            return None
        g, x, hits, save, cost_f = best
        why = (f"{x.name}を庇う: 自分の次の手番までに{x.name}へ来そうな攻撃{hits:.2f}回 ×（{x.name}が自衛した場合の痛み{save:.2f} − "
               f"自分が受ける痛み{cost_f:.2f}）= {g:.2f} ＞ 攻撃の価値{best_atk:.2f}")
        self._rec("cover", f, choice="cover", target=x.id, gain=g, atk=best_atk)
        return Decision("cover", x.id, reasons=[why])

    # ================================================================ 防御
    def predict_defense(self, u, attacker, action, expected_raw):
        return self._defense(u, attacker, action, expected_raw, record=False)

    def decide_defense(self, u, attacker, action, expected_raw):
        return self._defense(u, attacker, action, expected_raw, record=True)

    def _defense(self, u, attacker, action, expected_raw, record=True):
        eng = self.engine
        need = math.ceil(eng.defense.required_ep(u, expected_raw) - 1e-9)
        spend = min(u.ep, need)
        blocked = spend / max(eng.defense.required_ep(u, 1.0), 1e-9)
        body_if_def = self.body_loss(u, max(0.0, expected_raw - blocked) * eng.body_mult)
        body_if_not = self.body_loss(u, expected_raw * eng.body_mult)
        inc = self.incap_hp(u)
        x_body = expected_raw * eng.body_mult
        out_if_not = (u.hp - x_body <= inc) if inc > 0 else x_body >= u.hp
        if out_if_not:
            # 生身で受けると倒れる → 倒れたらEPは何の役にも立たないので必ず展開（PA-85）
            return True, f"自衛: 生身で受けると倒れる見込み（{x_body:.0f}ダメージ）"
        pain, hi, lo = self.ep_pain(u, spend)
        margin = self.pcfg.get("margin", 0.02)
        if pain + body_if_def <= body_if_not + margin:      # 同程度なら生身を避ける（生身被弾は危険）
            return True, f"自衛: EP{spend}の痛み{pain:.2f}＋残り被弾{body_if_def:.2f} ≤ 生身{body_if_not:.2f}"
        if record:
            self._rec("skip_def", u, pain=pain, body=body_if_not, ep=u.ep, frank=u.rank.value)
        return False, (f"生身で受ける: EP{spend}を使う痛み{pain:.2f}（次の手番の最善 {hi[1]}→{lo[1]}）＋防ぎきれない分{body_if_def:.2f}"
                       f" ＞ 生身の損失{body_if_not:.2f}")

    # ================================================================ 介入
    def decide_intervention(self, window) -> InterventionChoice:
        eng = self.engine
        t, atk, a = window.target, window.attacker, window.action
        fronts = [c for c in window.eligible if c.rank is Rank.FRONT]
        if self.probe in ("never_iv", "iv_off") or not fronts:
            # iv_off（Ver0.11 分解用）: 介入はしないが、REARの「守ってもらえる見込みπ」は通常どおり計算する
            return InterventionChoice(None, reasons=["介入可能な前衛なし" if not fronts else "固定: 介入しない"])
        raw = eng.damage.expected(atk, a)
        # --- 標的自身が対応した場合
        need_t = math.ceil(eng.defense.required_ep(t, raw) - 1e-9)
        can_def = eng.defense_allowed(t)
        spend_t = min(t.ep, need_t) if can_def else 0
        blocked = spend_t / max(eng.defense.required_ep(t, 1.0), 1e-9)
        pain_t, hi_t, lo_t = self.ep_pain(t, spend_t) if spend_t else (0.0, None, None)
        self_def = pain_t + self.body_loss(t, max(0.0, raw - blocked) * eng.body_mult)
        self_body = self.body_loss(t, raw * eng.body_mult)
        L_self = min(self_def, self_body) if can_def else self_body
        cast_stake = self._cast_stake(t, raw) if (self.cast_aware and t.id in getattr(eng, "casting", {})) else 0.0
        L_self += cast_stake
        lost_option = None
        if hi_t and lo_t and hi_t[1] != lo_t[1]:
            lost_option = (hi_t[1], lo_t[1])
        # --- 前衛が出る場合（移動して受ける／遠隔障壁）
        opts = []
        for f in fronts:
            for mode in (("move", "aegis") if eng.aegis_on else ("move",)):
                cost, parts = self._iv_cost(f, t, atk, a, raw, mode)
                opts.append((cost, f, mode, parts))
        opts.sort(key=lambda o: o[0])
        best = opts[0]
        margin = self.pcfg.get("margin", 0.02)
        forced = (self.probe == "always_iv" and t.rank is Rank.REAR) or \
                 (self.probe == "mage_only" and t.id == "celestia")
        if self.probe == "mage_only" and t.id != "celestia":
            return InterventionChoice(None, reasons=["固定: 魔導士以外は守らない"])
        go = forced or best[0] + margin < L_self
        cost, f, mode, parts = best
        lo_txt = f"（自衛すると{lost_option[0]}→{lost_option[1]}に落ちる）" if lost_option else ""
        why = (f"{atk.name}→{t.name}（期待威力{raw:.0f}）。{t.name}が自分で対応: EP{t.ep}から{spend_t}使う痛み{pain_t:.2f}{lo_txt}"
               f"・生身なら{self_body:.2f} → {L_self:.2f}。{f.name}（HP{f.hp_ratio:.0%}・EP{f.ep}）が"
               f"{'障壁' if mode == 'aegis' else '介入'}: " + "＋".join(f"{k}{v:.2f}" for k, v in parts.items()) + f" = {cost:.2f}")
        rec = dict(kind="iv", target=t.id, trank=t.rank.value, attacker=atk.id, f=f.id, mode=mode,
                   casting=int(t.id in getattr(eng, "casting", {})), cast_stake=round(cast_stake, 4),
                   L_self=L_self, L_iv=cost, t_ep=t.ep, t_need=need_t, f_ep=f.ep, f_hp=round(f.hp_ratio, 3),
                   lost_option=f"{lost_option[0]}>{lost_option[1]}" if lost_option else "",
                   threshold=int(lost_option is not None), forced=int(forced),
                   # Ver0.9 記録用（判断には使っていない値を含む）
                   raw=round(raw, 1), t_hp=t.hp, t_hpmax=t.d.hp_max, f_hpabs=f.hp, f_hpmax=f.d.hp_max,
                   t_S=round(eff_strength(eng.defense, t), 1), f_S=round(eff_strength(eng.defense, f), 1),
                   f_need=math.ceil(eng.defense.required_ep(f, raw) - 1e-9), pain_t=round(pain_t, 3),
                   self_body=round(self_body, 3), t_next=hi_t[1] if hi_t else "", t_next_after=lo_t[1] if lo_t else "",
                   parts="; ".join(f"{k}={v:.2f}" for k, v in parts.items()),
                   hole_model=self.hole_model)
        pred = self._after_risk(f, t, hp_after=f.hp - self._leak_body(f, raw)) if mode == "move" else {}
        rec.update({k: (round(v, 4) if isinstance(v, float) else v) for k, v in pred.items()})
        if self.hole_model in ("v11", "v13") and mode == "move":
            rec.update(self._time_preds(f, t, raw, mode))
            rec.update({k: round(v, 4) if isinstance(v, float) else v for k, v in self._v11_by_f.get(f.id, {}).items()})
        # 目の前の比較だけ（離脱後の危険を除く）なら守ったか
        now_only = cost - sum(v for k, v in parts.items() if k in ("自衛不能", "穴", "離脱中の被弾", "穴からの追加被弾",
                                                                    "前衛の将来価値"))
        rec["L_iv_now"] = round(now_only, 4)
        if go:
            rec["choice"] = mode
            rec["reason"] = ("固定戦略" if forced else
                             ("選択肢の維持" if lost_option else ("前衛の方が安い" if pain_t > 0 else "生身の危険")))
            self._rec2(rec, why + " → 前衛が受ける")
            return InterventionChoice(f.id, reasons=[why + " → 前衛が受ける"], mode=mode)
        rec["choice"] = "self"
        rec["reason"] = ("自衛の方が安い" if L_self <= cost else "差が小さい")
        self._rec2(rec, why + f" → {t.name}が自分で対応")
        return InterventionChoice(None, reasons=[why + f" → {t.name}が自分で対応"])

    def _iv_cost(self, f, t, atk, a, raw, mode):
        """前衛 f が出たときの損失。EPの痛み＋防ぎきれない分＋自衛不能時間の危険＋（移動なら）穴の危険。"""
        eng = self.engine
        parts = {}
        if mode == "aegis":
            need = eng.aegis_need(f, raw)
            spend = min(f.ep, need)
            pain = self.ep_pain(f, spend)[0]
            leak = raw * (1 - spend / need) if need > 0 else 0.0
            parts["EPの痛み"] = pain
            if leak > 0:
                parts["漏れ"] = self.body_loss(t, leak * eng.body_mult)
        else:
            need = math.ceil(eng.defense.required_ep(f, raw) - 1e-9)
            spend = min(f.ep, need) if eng.defense.can_deploy(f) else 0
            blocked = spend / max(eng.defense.required_ep(f, 1.0), 1e-9)
            parts["EPの痛み"] = self.ep_pain(f, spend)[0] if spend else 0.0
            leak = max(0.0, raw - blocked)
            if leak > 0:
                parts["自分の生身"] = self.body_loss(f, leak * eng.body_mult)
        now_cost = sum(parts.values())
        if self.hole_model in ("v11", "v13") and mode == "move":
            return self._iv_cost_v11(f, t, raw, parts, leak if mode == "move" else 0.0)
        if self.hole_model == "v10" and mode == "move":
            pred = self._after_risk(f, t)
            if pred["front_cost"] > 0:
                parts["離脱中の被弾"] = pred["front_cost"]
            if pred["rear_cost"] > 0:
                parts["穴からの追加被弾"] = pred["rear_cost"]
            return sum(parts.values()), parts
        # 自衛できない時間（次の自分の手番まで）
        exposed = 0.0
        before = list(dict.fromkeys(eng.actors_before_next_turn_of(f.id)))
        x_f = self.avg_raw(f)
        if x_f > 0:
            p_hits = 0.0
            for eid in before:
                for ee, aa, p in self.threats_to(f):
                    if ee.id == eid:
                        p_hits += p
            c_f = math.ceil(eng.defense.required_ep(f, x_f))
            normal = min(self.body_loss(f, x_f * eng.body_mult), self.ep_pain(f, min(f.ep, c_f))[0])
            exposed = p_hits * max(0.0, self.body_loss(f, x_f * eng.body_mult) - normal)
        if exposed > 0:
            parts["自衛不能"] = exposed
        if mode == "move":
            hole = self._hole_value(f, before)
            if hole > 0:
                parts["穴"] = hole
        return sum(parts.values()), parts

    def _after_risk(self, f, t, hp_after=None, window=None, before_ids=None):
        """Ver0.10（PA-100）: f が持ち場を離れてから戻るまでに起きそうなことを、見えている行動順から見積もる。
        ・f の次の手番までに行動する敵を、行動回数ぶん数える（同じ敵が2回動くなら2回）
        ・各敵について、f がいる場合と離れた場合で「届く相手」を比べる。新しく届くようになった後衛
          （f が塞いでいた経路の後ろ）を、その敵は p_exploit の見込みで狙う（既存の設定値）。残りは届く相手から等確率
        ・後衛に増える攻撃の見込みから、後衛が払うEP（足りなければ生身）と、その損失（戦闘不能・死亡ラインを含む）を計算
        ・f 自身は離脱中に自衛できないので、f に来る攻撃は全部生身。持ち場にいれば払っていたEPとの差を損失とする
        未来の乱数・敵AIの内部は使わない。"""
        eng = self.engine
        p_ex = self.pcfg.get("p_exploit", 0.6)
        if before_ids is None:
            if window is None:
                window = "next_hp" if self.hole_model == "v13" else "old"
            before_ids, win_len = self.window_actors(f, window, hp_after)
        else:
            win_len = None
        before = [eng.u(x) for x in before_ids]
        enemies = [e for e in before if e.side is Side.ENEMY and e.alive]
        allies = [u for u in eng.state.side_units(Side.ALLY)]
        save = (f.displaced, f.stance)
        reach_now, reach_hole = {}, {}
        for e in {e.id: e for e in enemies}.values():
            a = self.enemy_attack(e)
            if a is None:
                continue
            reach_now[e.id] = [u for u in allies if check_reach(e, u, a.reach, eng.state).ok]
        try:
            f.displaced = True
            for e in {e.id: e for e in enemies}.values():
                a = self.enemy_attack(e)
                if a is None:
                    continue
                reach_hole[e.id] = [u for u in allies if check_reach(e, u, a.reach, eng.state).ok]
        finally:
            f.displaced, f.stance = save
        m = self.disp_mult() if self.hole_model in ("v11", "v13") else 1.0     # Ver0.11 ①: 実績で補正（v9/v10は等確率=1）
        extra = {}          # 後衛ごとに増える攻撃の見込み（回数）と必要EP
        f_hits, f_raw = 0.0, 0.0
        hole_users = []
        for e in enemies:
            a = self.enemy_attack(e)
            if a is None or e.id not in reach_now:
                continue
            now, hole = reach_now[e.id], reach_hole[e.id]
            now_ids = {u.id for u in now}
            new = [u for u in hole if u.id not in now_ids and u.rank is Rank.REAR]
            raw = eng.damage.expected(e, a)
            if new:
                hole_users.append(e.name)
                for q in new:
                    pq = p_ex / len(new)
                    d = extra.setdefault(q.id, [0.0, 0.0, 0.0])
                    d[0] += pq
                    d[1] += pq * eng.defense.required_ep(q, raw)
                    d[2] += pq * raw
                p_f = (1 - p_ex) * m / max(len(now) - 1 + m, 1e-9) if f.id in now_ids else 0.0
            else:
                p_f = m / max(len(now) - 1 + m, 1e-9) if f.id in now_ids else 0.0
            f_hits += p_f
            f_raw += p_f * raw
        rear_cost = rear_hp = rear_ep = 0.0
        for qid, (h, need, raw_sum) in extra.items():
            q = eng.u(qid)
            spend = min(q.ep, need) if eng.defense.can_deploy(q) else 0.0
            covered = (spend / need) if need > 0 else 1.0
            unc_dmg = raw_sum * (1 - covered) * eng.body_mult
            pain = self.ep_pain(q, int(math.ceil(spend)))[0] if spend > 0 else 0.0
            body = self.body_loss(q, unc_dmg) if unc_dmg > 0 else 0.0
            rear_cost += min(pain + body, self.body_loss(q, raw_sum * eng.body_mult))
            rear_hp += unc_dmg
            rear_ep += spend
        front_cost = 0.0
        if f_raw > 0:
            body_f = self.body_loss(f, f_raw * eng.body_mult)
            need_f = eng.defense.required_ep(f, f_raw)
            normal = min(body_f, self.ep_pain(f, int(math.ceil(min(f.ep, need_f))))[0]
                         + self.body_loss(f, max(0.0, f_raw - min(f.ep, need_f) / max(eng.defense.required_ep(f, 1.0), 1e-9)) * eng.body_mult))
            front_cost = max(0.0, body_f - normal)
        return dict(pred_extra_rear_hits=sum(v[0] for v in extra.values()), pred_rear_hp=rear_hp, pred_rear_ep=rear_ep,
                    pred_front_hits=f_hits, pred_front_dmg=f_raw * eng.body_mult, n_enemy_actions=len(enemies),
                    pred_window=win_len if win_len is not None else -1.0,
                    hole_users="・".join(dict.fromkeys(hole_users)), rear_cost=rear_cost, front_cost=front_cost,
                    disp_mult=m)

    # ================================================================ Ver0.11 ②: 前衛が生きて前線に残る将来価値
    def front_future(self, f, hp=None):
        """前衛 f が、この先 HORIZON 巡のあいだ持ち場で戦い続ける価値（PA-121）。戦力点。
          V = (1 − P_out/2) × [ 攻撃の価値×手番数 ＋ 経路を塞ぐ価値 ＋ 狙いを引き受ける価値 ]
          ・攻撃の価値: いま届く敵への最善の一撃の価値（val_attack）× この先の手番数（HORIZON × 速度倍率）
          ・経路を塞ぐ価値: f が離れたら後衛に増える1巡あたりの損失（_after_risk の後衛分）× HORIZON
          ・狙いを引き受ける価値: f に来る攻撃（届く相手から等確率）が f 不在なら他の味方へ行ったときの損失 × HORIZON
          ・P_out: この先 HORIZON 巡で来そうな攻撃数 k（ポアソン）のうち、EPで防ぎきれない分で戦闘不能ラインを割る確率
          （1 − P_out/2 は「期間の平均で前線にいる割合」の近似）。HP以外（EP）は現在値のまま（EPの価値は EPの痛み 側で数える）"""
        hp = f.hp if hp is None else hp
        inc = self.incap_hp(f)
        if hp <= inc:
            return dict(V=0.0, pout=1.0, base=0.0)
        base = self._cached(("ffbase", f.id), lambda: self._front_base(f))
        eng = self.engine
        k = (self.rate_T(f) if self.hole_model == "v13" else self.rate(f)) * HORIZON
        x = self.avg_raw(f)
        if x <= 0 or k <= 0:
            pout = 0.0
        else:
            def calc():
                c = max(eng.defense.required_ep(f, x), 1e-9)
                covered = int(f.ep // c) if eng.defense.can_deploy(f) else 0
                need = covered + max(1, math.ceil((hp - inc) / max(x * eng.body_mult, 1e-9)))
                return need, eng.speed_mult(f)
            need, sm = self._at_hp(f, hp, calc)
            # P(N >= need), N ~ Poisson(k)
            cdf, term = 0.0, math.exp(-k)
            for i in range(need):
                cdf += term
                term *= k / (i + 1)
            pout = max(0.0, min(1.0, 1.0 - cdf))
        sm = self._at_hp(f, hp, lambda: eng.speed_mult(f))
        turns = HORIZON * sm * (self.base_rate(f) if self.hole_model == "v13" else 1.0)
        V = (1.0 - pout / 2.0) * (base["att"] * turns + base["block"] + base["absorb"])
        return dict(V=V, pout=pout, base=base["att"] * turns + base["block"] + base["absorb"],
                    att=base["att"] * turns, block=base["block"], absorb=base["absorb"])

    def _front_base(self, f):
        eng = self.engine
        att = 0.0
        for a in eng.available_actions(f):
            if a.kind is not ActionKind.ATTACK or a.area == "all" or a.ep_cost > f.ep:
                continue
            for t in eng.capable_first_targets(f, a):
                att = max(att, self.val_attack(f, a, t))
        # 経路を塞ぐ価値（f が離れたら後衛に増える損失。v10 と同じ見積もり、ただし狙われやすさは等確率）
        save = self.hole_model
        try:
            if save == "v13":
                # Ver0.13: 持ち場を1回離れると、次の自分の手番（満タンの行動間隔1回分）まで穴が開く。HORIZON の間にその回数は HORIZON×実効速度
                ids, _ = self.window_actors(f, "full")
                self.hole_model = "v10"
                block = self._after_risk(f, None, before_ids=ids)["rear_cost"] * HORIZON * self.unit_rate(f)
            else:
                self.hole_model = "v10"
                block = self._after_risk(f, None)["rear_cost"] * HORIZON
        finally:
            self.hole_model = save
        # 狙いを引き受ける価値
        absorb = 0.0
        for e, a, p in self.threats_to(f):
            others = [u for u in eng.state.side_units(Side.ALLY) if u.id != f.id
                      and check_reach(e, u, a.reach, eng.state).ok]
            if not others:
                continue
            raw = eng.damage.expected(e, a)
            ls = []
            for q in others:
                need = math.ceil(eng.defense.required_ep(q, raw) - 1e-9)
                sp = min(q.ep, need) if eng.defense.can_deploy(q) else 0
                blk = sp / max(eng.defense.required_ep(q, 1.0), 1e-9)
                ls.append(min(self.ep_pain(q, sp)[0] + self.body_loss(q, max(0.0, raw - blk) * eng.body_mult),
                              self.body_loss(q, raw * eng.body_mult)))
            absorb += p * HORIZON * (self.unit_rate(e) if save == "v13" else 1.0) * sum(ls) / len(ls)
        return dict(att=att, block=block, absorb=absorb)

    def _iv_cost_v11(self, f, t, raw, parts, leak):
        """Ver0.11: 介入の損失 = EPの痛み ＋ f のHPそのもの（戦闘不能の罰則は②で数える）
                                 ＋ ① 離脱中に狙われる被弾（実績で補正）＋ 穴からの追加被弾（v10と同じ）
                                 ＋ ② 前衛の将来価値の低下（介入で受ける生身＋離脱中の生身でHPが減った分）"""
        eng = self.engine
        imp = self.importance(f)
        out = {"EPの痛み": parts.get("EPの痛み", 0.0)}
        now_body = leak * eng.body_mult
        if now_body > 0:
            out["自分の生身"] = imp * min(1.0, now_body / f.d.hp_max)
        pred = self._after_risk(f, t, hp_after=f.hp - now_body)
        exp_body = pred["pred_front_dmg"]
        if exp_body > 0:
            out["離脱中の被弾"] = imp * min(1.0, exp_body / f.d.hp_max)
        if pred["rear_cost"] > 0:
            out["穴からの追加被弾"] = pred["rear_cost"]
        v_now = self.front_future(f)
        hp_after = f.hp - now_body - exp_body
        v_after = self.front_future(f, hp_after)
        dv = max(0.0, v_now["V"] - v_after["V"])
        if dv > 0:
            out["前衛の将来価値"] = dv
        self._v11_by_f[f.id] = dict(v11_V_now=v_now["V"], v11_V_after=v_after["V"], v11_pout_now=v_now["pout"],
                              v11_pout_after=v_after["pout"], v11_att=v_now.get("att", 0.0),
                              v11_block=v_now.get("block", 0.0), v11_absorb=v_now.get("absorb", 0.0),
                              v11_disp_mult=pred["disp_mult"], v11_obs_n=self.obs["n"])
        return sum(out.values()), out

    # ================================================================ 詠唱実験（PA-131）: 詠唱中の味方を守る価値
    def _cast_stake(self, t, raw):
        """詠唱中の t が生身で受けた場合に、詠唱そのものが失うもの（戦力点）。
        ・この一撃で戦闘不能・死亡になるなら、詠唱はキャンセル → 魔法の価値をまるごと失う
        ・ならない場合も、負傷で速度が落ちて完成が遅れる → 魔法の価値 ×（遅れ ÷ 先読み期間 HORIZON）を失う
        魔法の価値 = いま発動したときの価値（best_actions と同じ val_attack の合計）。固定の加点はない。"""
        eng = self.engine
        cs = eng.casting[t.id]
        a = eng.actions[cs["dec"].action_id]
        tg = [x for x in eng.valid_targets(t, a) if x.alive]
        v_spell = sum(self.val_attack(t, a, x) for x in tg) if a.area == "all" else \
            (max((self.val_attack(t, a, x) for x in tg), default=0.0))
        dmg = raw * eng.body_mult
        hp_after = t.hp - dmg
        inc = self.incap_hp(t)
        if (hp_after <= inc) if inc > 0 else hp_after <= 0:
            stake = v_spell
            kind = "詠唱キャンセル"
        else:
            m_now = eng.speed_mult(t)
            m_after = self._at_hp(t, hp_after, lambda: eng.speed_mult(t))
            if getattr(eng, "cast_unit", "time") == "actions":
                rem = max(0.0, cs["base"] - cs["progress"])
                delay = (rem / m_after - rem / m_now) / 10.0      # 行動数 → 巡（序盤の約10行動/巡で換算, PA-131）
            else:
                rem = max(0.0, cs["remaining"] - (eng.cur_time - (cs["last_t"] or eng.cur_time)) * (cs["speed"] or m_now))
                delay = rem / m_after - rem / m_now
            stake = v_spell * min(1.0, delay / HORIZON)
            kind = f"詠唱の遅れ{delay:.2f}巡"
        self._last_cast_stake = (stake, kind, v_spell)
        return stake

    def _hole_value(self, f, before):
        """f が持ち場を離れた場合、復帰前に近接の敵が後ろの味方を突く見込み損失（標的側の機会費用込み）。"""
        eng = self.engine
        p_ex = self.pcfg.get("p_exploit", 0.6)
        risk = 0.0
        for R in eng.state.routes_blocked_by(f.id):
            if holding_blockers(R, eng.state.units) != [f.id]:
                continue
            rear = [eng.u(x) for x in R.protects if eng.u(x).alive]
            threats = [eng.u(x) for x in before if eng.u(x).side is Side.ENEMY and eng.u(x).alive
                       and eng.u(x).rank is Rank.FRONT]
            worst = 0.0
            for e in threats:
                a = self.enemy_attack(e)
                if a is None or a.reach is not Reach.MELEE:
                    continue
                raw = eng.damage.expected(e, a)
                for q in rear:
                    need = math.ceil(eng.defense.required_ep(q, raw))
                    sp = min(q.ep, need)
                    blk = sp / max(eng.defense.required_ep(q, 1.0), 1e-9)
                    l = min(self.ep_pain(q, sp)[0] + self.body_loss(q, max(0, raw - blk) * eng.body_mult),
                            self.body_loss(q, raw * eng.body_mult))
                    worst = max(worst, l)
            if threats and worst > 0:
                risk += (1 - (1 - p_ex) ** len(threats)) * worst
        return risk

    # ================================================================ 記録
    def _rec(self, kind, u, **kw):
        self.records.append(dict(kind=kind, unit=u.id, round=self.engine.state.round,
                                 t=round(self.engine.cur_time, 3), **kw))

    def _rec2(self, rec, text):
        rec.update(round=self.engine.state.round, t=round(self.engine.cur_time, 3), text=text)
        self.records.append(rec)
