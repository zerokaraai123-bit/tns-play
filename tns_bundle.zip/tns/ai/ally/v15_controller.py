"""Ver0.15 味方AI（PA-210）。Ver0.13 の価値判断（ValueAllyController, hole_model v13）を土台に、
新しい行動（突撃・牽制・押し返す・死守・観測・応急整備）を、同じ「戦力点」で比べる。

使う情報はキャラクターが知り得るものだけ（PA-81）。観測で固定された敵の意思（PA-208）は公開情報なので使ってよい:
  ・固定された敵の狙いは「確定」として扱う（届く相手から等確率、の代わり）。
"""
from __future__ import annotations

import math

from ...control.controller import Decision
from ...formation.reach import check_reach
from ...model.enums import ActionKind, Rank, Reach, Side
from .value_controller import ValueAllyController


class V15AllyController(ValueAllyController):
    name = "ally_v15"

    def __init__(self, pol_cfg: dict, probe=None, disabled=(), observe_mode="ai"):
        super().__init__(pol_cfg, probe=probe, hole_model="v13")
        self.disabled = set(disabled)          # 分析用: 使わない行動ID
        self.observe_mode = observe_mode       # ai / always / never（分析用）
        self.policy_name = "v15" + (f"-{'-'.join(sorted(self.disabled))}" if self.disabled else "") + \
            ("" if observe_mode == "ai" else f"-obs_{observe_mode}")

    # ================================================================ 敵の脅威（固定された意思を反映）
    def _threats_to(self, u):
        """u に届く敵と、その敵が u を狙う見込み（先読み HORIZON の間の平均）。
        観測で意思が固定された敵は、次の1手だけ確定（PA-208）。その後の手は届く相手から等確率（PA-81）。
          k = この先 HORIZON の間の、その敵の行動回数の見込み（1以上）
          p(u) = (1[固定の標的がu] + (k−1)·p_等確率(u)) / k"""
        eng = self.engine
        out = []
        fixed = getattr(eng, "fixed_info", {}) if self.pcfg.get("use_fixed_info", True) else {}
        for e in eng.state.side_units(Side.ENEMY):
            a = self.enemy_attack(e)
            p_u = 0.0
            if a is not None:
                tg = [t for t in eng.state.side_units(Side.ALLY) if check_reach(e, t, a.reach, eng.state).ok]
                if u in tg:
                    p_u = 1.0 / len(tg)
            fx = fixed.get(e.id)
            if fx is None:
                if p_u > 0:
                    out.append((e, a, p_u))
                continue
            fa = eng.actions.get(fx.action_id)
            k = max(1.0, self.unit_rate(e) * 2.0)
            hit_fixed = fa is not None and fa.kind is ActionKind.ATTACK and (fa.area == "all" or fx.target_id == u.id)
            p = ((1.0 if hit_fixed else 0.0) + (k - 1.0) * p_u) / k
            if p > 0:
                out.append((e, fa if hit_fixed and fa.area != "all" else (a or fa), p))
        return out

    def enemy_attack(self, e):
        eng = self.engine
        return next((eng.actions[a] for a in e.d.action_ids
                     if eng.actions[a].kind is ActionKind.ATTACK and not eng.actions[a].special
                     and eng.actions[a].area != "all"), None)

    # ================================================================ 補助
    def loss_hit(self, x, raw):
        """x が威力 raw の一撃を受けたときの損失（EPで防ぐ・生身で受けるの安い方）。"""
        eng = self.engine
        if raw <= 0 or x.hp <= 0:
            return 0.0
        need = math.ceil(eng.defense.required_ep(x, raw) - 1e-9)
        sp = min(x.ep, need) if eng.defense_allowed(x) else 0
        blk = sp / max(eng.defense.required_ep(x, 1.0), 1e-9)
        a = (self.ep_pain(x, sp)[0] if sp else 0.0) + self.body_loss(x, max(0.0, raw - blk) * eng.body_mult)
        return min(a, self.body_loss(x, raw * eng.body_mult))

    def spell_loss(self, e, a):
        """全体魔法 a が発動したときの味方の損失の合計。"""
        eng = self.engine
        raw = eng.damage.expected(e, a)
        return sum(self.loss_hit(x, raw) for x in eng.state.side_units(Side.ALLY))

    def threat_value(self, e):
        """敵 e の次の1手で、こちらが失いそうな損失（固定された意思があればそれ）。"""
        eng = self.engine
        fx = getattr(eng, "fixed_info", {}).get(e.id)
        if e.id in eng.casting:
            a = eng.actions[eng.casting[e.id]["dec"].action_id]
            return self.spell_loss(e, a) if a.area == "all" else 0.0
        if fx is not None:
            a = eng.actions.get(fx.action_id)
            if a is None or a.kind is not ActionKind.ATTACK:
                return 0.0
            if a.area == "all":
                return self.spell_loss(e, a)
            if fx.target_id:
                return self.loss_hit(eng.u(fx.target_id), eng.damage.expected(e, a))
            return 0.0
        best = 0.0
        for a in eng.available_actions(e):
            if a.kind is not ActionKind.ATTACK:
                continue
            if a.area == "all":
                continue      # 詠唱が要る大魔法は「次の1手の脅威」ではなく詠唱開始の時点で数える
            tg = [t for t in eng.valid_targets(e, a) if t.alive]
            if not tg:
                continue
            raw = eng.damage.expected(e, a)
            best = max(best, sum(self.loss_hit(t, raw) for t in tg) / len(tg))
        return best

    def cast_bonus(self, t, dmg, actor=None):
        """詠唱中（または大魔法の意思が固定された）敵 t に dmg を与える価値。
        完成までに動ける味方の見込みダメージを足して倒し切れるなら、魔法の損失 × (この一撃の取り分)。
        倒し切れない見込みなら、負傷による遅れ分として小さく数える。"""
        eng = self.engine
        a = None
        end = None
        if t.id in eng.casting:
            a = eng.actions[eng.casting[t.id]["dec"].action_id]
            end = eng.next_time.get(t.id)
        else:
            fx = getattr(eng, "fixed_info", {}).get(t.id)
            if fx is not None and eng.actions.get(fx.action_id) is not None and fx.action_id in eng.cast_time:
                a = eng.actions[fx.action_id]
                dur = eng.cast_time[fx.action_id] * eng.cast_quantum / max(eng.eff_rate(t), 1e-9)
                end = eng.next_time.get(t.id, eng.cur_time) + dur
        if a is None or a.area != "all" or end is None:
            return 0.0
        prev = getattr(self, "_guard", False)
        self._guard = True
        try:
            loss = self.spell_loss(t, a)
        finally:
            self._guard = prev
        need = max(1.0, t.hp - self.incap_hp(t))
        follow = 0.0
        for x in dict.fromkeys(eng.actions_before_time(end, t)):
            ally = eng.u(x)
            if ally.side is not Side.ALLY or (actor is not None and ally.id == actor.id) or not ally.alive:
                continue
            best = 0.0
            for b in eng.available_actions(ally):
                if b.kind is ActionKind.ATTACK and b.area != "all" and t in eng.valid_targets(ally, b):
                    best = max(best, eng.estimate_damage(ally, b, t))
            follow += best
        if dmg + follow >= need:
            return loss * min(1.0, dmg / need)
        return loss * 0.1 * min(1.0, dmg / need)

    def can_iv_enemy(self, c):
        eng = self.engine
        return c.alive and c.can_intervene and eng._iv_ok(c)

    def _acts_first(self, a_id, b_id):
        eng = self.engine
        return eng.next_time.get(a_id, math.inf) < eng.next_time.get(b_id, math.inf)

    # ================================================================ 行動の価値
    def dive_value(self, u, a, t, assume_free=False):
        eng = self.engine
        p_int = self.pcfg.get("dive_p_int", 0.5)
        ivs = [c for c in eng.state.side_units(Side.ENEMY) if c.rank is Rank.FRONT and self.can_iv_enemy(c)]
        if assume_free or not ivs:
            p_int = 0.0
        dmg = eng.estimate_damage(u, a, t)
        v_hit = self.val_attack(u, a, t) + self.cast_bonus(t, dmg, u)
        v_int = max((self.val_attack(u, a, c) for c in ivs), default=0.0)
        hole, ivc = self.rear_costs(u)
        v = (1 - p_int) * v_hit + p_int * v_int - hole - ivc
        return v, {"一撃": (1 - p_int) * v_hit + p_int * v_int, "穴": -hole, "介入できない": -ivc}

    def lost_iv_cost(self, u, ids, k):
        """u が介入できなくなる間（ids の敵が動く間）に、u の担当の後衛が受けそうな攻撃を u が代われない損失。"""
        eng = self.engine
        enemies = [eng.u(x) for x in ids if eng.u(x).side is Side.ENEMY and eng.u(x).alive]
        cost = 0.0
        for r in eng.state.routes[Side.ALLY]:
            if u.id not in r.blockers:
                continue
            for q in r.protects:
                q = eng.u(q)
                if not q.alive:
                    continue
                hq = 0.0
                for e in enemies:
                    for ee, aa, p in self.threats_to(q):
                        if ee.id == e.id:
                            hq += p
                rq = self.avg_raw(q)
                if hq > 0 and rq > 0:
                    cost += k * hq * max(0.0, self.loss_hit(q, rq) - self.loss_hit(u, rq))
        return cost

    def pin_value(self, u, a, t):
        eng = self.engine
        v = self.val_attack(u, a, t)
        parts = {"一撃": v}
        # ① 介入を封じて、アデルの突撃を通す
        divers = [d for d in eng.state.side_units(Side.ALLY) if d.id != u.id and d.rank is Rank.FRONT
                  and not d.displaced and d.id not in eng.pinned
                  and any(eng.actions[x].special == "dive" for x in d.d.action_ids)]
        if self.can_iv_enemy(t) and divers:
            others = [c for c in eng.state.side_units(Side.ENEMY) if c.id != t.id and c.rank is Rank.FRONT
                      and self.can_iv_enemy(c)]
            if not others:
                best = 0.0
                for d in divers:
                    # 牽制は t の次の手番が終わるまで。d がそれより先に動ける場合だけ数える
                    if not self._acts_first(d.id, t.id):
                        continue
                    dv = next((eng.actions[x] for x in d.d.action_ids if eng.actions[x].special == "dive"), None)
                    for tt in eng.state.side_units(Side.ENEMY):
                        if tt.rank is not Rank.REAR or not eng.breach_reach(d, tt).ok:
                            continue
                        vf = self.dive_value(d, dv, tt, assume_free=True)[0]
                        vn = self.dive_value(d, dv, tt)[0]
                        best = max(best, vf - vn)
                if best > 0:
                    parts["突撃を通す"] = best * self.pcfg.get("pin_enable_k", 1.0)
        # ② 回り込みを止める
        fl = next((eng.actions[x] for x in t.d.action_ids if eng.actions[x].special == "flank"), None)
        if fl is not None:
            fx = getattr(eng, "fixed_info", {}).get(t.id)
            p = 1.0 if (fx is not None and fx.action_id == fl.id) else self.pcfg.get("pin_flank_p", 0.3)
            tg = [x for x in eng.valid_targets(t, fl) if x.alive] if fl in eng.available_actions(t) else []
            if tg:
                raw = eng.damage.expected(t, fl)
                parts["回り込みを止める"] = p * max(self.loss_hit(x, raw) for x in tg)
        return sum(parts.values()), parts

    def push_value(self, u, a, t):
        eng = self.engine
        v = self.val_attack(u, a, t)
        tempo = eng.push_delay / max(eng.interval(t), 1e-9) * self.threat_value(t)
        return v + tempo, {"一撃": v, "遅らせる": tempo}

    def hold_value(self, u):
        eng = self.engine
        parts = {}
        ids, _ = self.window_actors(u, "full")
        enemies = [eng.u(x) for x in ids if eng.u(x).side is Side.ENEMY and eng.u(x).alive]
        raw = self.avg_raw(u)
        hits = 0.0
        for e in enemies:
            for ee, aa, p in self.threats_to(u):
                if ee.id == e.id:
                    hits += p
        if raw > 0 and hits > 0:
            parts["被弾を減らす"] = hits * max(0.0, self.loss_hit(u, raw) - self.loss_hit(u, raw * eng.hold_mult))
        # 回り込みを止める: u が唯一の塞ぎ手の経路
        thin = [r for r in eng.state.routes[Side.ALLY] if u.id in r.blockers and eng.route_weight(r) <= eng.thin_max]
        if thin:
            rears = {p for r in thin for p in r.protects if eng.u(p).alive}
            stop = 0.0
            for e in {x.id: x for x in enemies}.values():
                fl = next((eng.actions[x] for x in e.d.action_ids if eng.actions[x].special == "flank"), None)
                if fl is None or e.id in eng.pinned:
                    continue
                fx = getattr(eng, "fixed_info", {}).get(e.id)
                p = 1.0 if (fx is not None and fx.action_id == fl.id) else self.pcfg.get("pin_flank_p", 0.3)
                raw_f = eng.damage.expected(e, fl)
                stop += p * max((self.loss_hit(eng.u(q), raw_f) for q in rears), default=0.0)
            if stop > 0:
                parts["回り込みを止める"] = stop
        # 介入できなくなる損失
        cost = self.lost_iv_cost(u, ids, self.pcfg.get("hold_iv_cost_k", 0.3))
        if cost > 0:
            parts["介入できない"] = -cost
        return sum(parts.values()), parts

    def observe_value(self, e):
        eng = self.engine
        if e.id in getattr(eng, "fixed_info", {}):
            return 0.0, {}
        th = self.threat_value(e)
        v = self.pcfg.get("observe_k", 0.5) * th
        parts = {"次の1手の脅威": v}
        # 大魔法を撃てる詠唱者: 詠唱を始める意思が固定されれば、突撃で先に潰せる
        big = next((eng.actions[x] for x in e.d.action_ids if x in eng.cast_time and eng.actions[x].area == "all"), None)
        if big is not None and e.id not in eng.casting and big.ep_cost <= e.ep:
            parts["大魔法の意思"] = self.pcfg.get("observe_k", 0.5) * self.spell_loss(e, big) * 0.5
        return sum(parts.values()), parts

    def best_actions(self, u, e_spend):
        out = super().best_actions(u, e_spend)
        if getattr(self, "_guard", False):
            return out                      # EPの価値（W）の計算の内側では、詠唱を潰す価値は数えない（再帰防止）
        eng = self.engine
        res = []
        for v, aid, tid, cost in out:
            a = eng.actions.get(aid)
            if a is not None and a.kind is ActionKind.ATTACK and a.area != "all" and tid:
                v = max(v, max((self.val_attack(u, a, t) + self.cast_bonus(t, eng.estimate_damage(u, a, t), u)
                                for t in eng.capable_first_targets(u, a)), default=v))
                bt = max(eng.capable_first_targets(u, a),
                         key=lambda t: self.val_attack(u, a, t) + self.cast_bonus(t, eng.estimate_damage(u, a, t), u))
                tid = bt.id
            res.append((v, aid, tid, cost))
        return res

    def _front_targets_left(self, u):
        return any(t.alive and t.rank is Rank.FRONT for t in self.engine.state.side_units(Side.ENEMY))

    def rear_costs(self, u):
        """u が持ち場を離れる行動（突撃・後衛への近接）の損失: 穴 ＋ 担当の後衛を庇えなくなる。"""
        ids, _ = self.window_actors(u, "full")
        save = self.hole_model
        try:
            self.hole_model = "v10"
            hole = self._after_risk(u, None, before_ids=ids)["rear_cost"]
        finally:
            self.hole_model = save
        return hole, self.lost_iv_cost(u, ids, self.pcfg.get("dive_iv_cost_k", 0.5))

    # ================================================================ 行動
    def decide_action(self, actor):
        if "fire" in actor.d.action_ids or "heal" in actor.d.action_ids:
            return self._mage_value(actor)
        if "observe" in actor.d.action_ids or "maintain" in actor.d.action_ids:
            return self._scholar(actor)
        if actor.rank is Rank.FRONT:
            return self._front(actor)
        return super().decide_action(actor)

    def _front(self, u):
        eng = self.engine
        acts = [a for a in eng.available_actions(u) if a.id not in self.disabled]
        cands = []
        for a in acts:
            sp = a.special
            if a.kind is ActionKind.ATTACK and not sp:
                for t in eng.capable_first_targets(u, a):
                    v = self.val_attack(u, a, t) + self.cast_bonus(t, eng.estimate_damage(u, a, t), u)
                    parts = {"一撃": v}
                    if t.rank is Rank.REAR and a.reach is Reach.MELEE and getattr(eng, "rear_melee_displaces", False):
                        if self.pcfg.get("dive_mode", "value") == "tactical" and self._front_targets_left(u):
                            dmg = eng.estimate_damage(u, a, t)
                            if self.cast_bonus(t, dmg, u) <= 0 and dmg < t.hp - self.incap_hp(t):
                                continue
                        hole, ivc = self.rear_costs(u)
                        parts.update({"穴": -hole, "介入できない": -ivc})
                        v -= hole + ivc
                    cands.append((v, a, t, parts))
            elif sp == "dive":
                for t in eng.capable_first_targets(u, a):
                    if self.pcfg.get("dive_mode", "value") == "tactical" and self._front_targets_left(u):
                        # 分析用（既定では使わない）: 突撃は「詠唱を潰せる」か「この一撃で倒せる」ときだけ
                        dmg = eng.estimate_damage(u, a, t)
                        if self.cast_bonus(t, dmg, u) <= 0 and dmg < t.hp - self.incap_hp(t):
                            continue
                    v, parts = self.dive_value(u, a, t)
                    cands.append((v, a, t, parts))
            elif sp == "pin":
                for t in [x for x in eng.valid_targets(u, a) if x.alive]:
                    v, parts = self.pin_value(u, a, t)
                    cands.append((v, a, t, parts))
            elif sp == "push":
                for t in [x for x in eng.valid_targets(u, a) if x.alive]:
                    v, parts = self.push_value(u, a, t)
                    cands.append((v, a, t, parts))
            elif sp == "hold":
                v, parts = self.hold_value(u)
                cands.append((v, a, u, parts))
        if not cands:
            return Decision("wait", reasons=["使える行動・届く相手なし"])
        cands.sort(key=lambda c: -c[0])
        v, a, t, parts = cands[0]
        alts = "、".join(f"{c[1].name}→{c[2].name}{c[0]:.2f}" for c in cands[1:4])
        why = f"{a.name}→{t.name}: " + "＋".join(f"{k}{x:.2f}" for k, x in parts.items()) + f" = {v:.2f}（他: {alts}）"
        self._rec("v15_front", u, choice=a.id, target=t.id, value=round(v, 4),
                  second=cands[1][1].id if len(cands) > 1 else "", second_v=round(cands[1][0], 4) if len(cands) > 1 else None)
        return Decision(a.id, t.id, reasons=[why])

    def _scholar(self, u):
        eng = self.engine
        acts = {a.id: a for a in eng.available_actions(u) if a.id not in self.disabled}
        cands = [(0.0, "wait", None, {})]
        if "maintain" in acts:
            a = acts["maintain"]
            for t in eng.valid_targets(u, a):
                if not t.alive:
                    continue
                gain = min(a.amount, t.d.ep_max - t.ep)
                if gain <= 0:
                    continue
                v = (self.W(t, t.ep + gain)[0] - self.W(t, t.ep)[0]) * self.pcfg.get("maintain_k", 1.0)
                cands.append((v, "maintain", t, {"EP+" + str(gain): v}))
        # 応急整備を優先（Ver0.15 の検証で、整備を遅らせると大きく負けることが分かった。PA-210）
        maint_now = [c for c in cands if c[1] == "maintain" and c[2] is not None
                     and min(acts["maintain"].amount, c[2].d.ep_max - c[2].ep) >= self.pcfg.get("maintain_min", 8)]
        if maint_now and self.observe_mode in ("ai", "after_maint"):
            cands = maint_now
        elif "observe" in acts and self.observe_mode != "never":
            a = acts["observe"]
            for e in eng.valid_targets(u, a):
                v, parts = self.observe_value(e)
                if v > 0:
                    cands.append((v, "observe", e, parts))
        if self.observe_mode == "always":
            obs = [c for c in cands if c[1] == "observe"]
            if obs:
                cands = obs
        cands.sort(key=lambda c: -c[0])
        v, aid, t, parts = cands[0]
        self._rec("v15_scholar", u, choice=aid, target=t.id if t else "", value=round(v, 4))
        if aid == "wait":
            return Decision("wait", reasons=["整備・観測の価値がない → 待機"])
        why = f"{eng.actions[aid].name}→{t.name}: " + "＋".join(f"{k}{x:.2f}" for k, x in parts.items())
        return Decision(aid, t.id, reasons=[why])
