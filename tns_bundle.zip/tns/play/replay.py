"""遊べる版の「記録をコピー」で書き出した文字列（TNS1:...）から、同じ戦闘を正確に再現して経過を表示する。
python -m tns.play.replay <記録の文字列 または 記録を保存したファイル>
"""
from __future__ import annotations

import sys
from pathlib import Path

from .session import GameSession


def main():
    arg = sys.argv[1]
    rec = Path(arg).read_text().strip() if Path(arg).exists() else arg
    g = GameSession.load(rec)
    v = g.view
    s = g.settings
    print(f"設定: ルール{s.get('ruleset')} seed {s['seed']} 知能{s['intel']} 敵×{s.get('enemy_power')} "
          f"奇襲{bool(s.get('ambush'))} 後衛への近接{s.get('rear_reach') or '既定'}")
    print(f"結果: {v.get('result', '途中')}  プレイヤーの指示 {v['n_player_decisions']}回")
    for f in v["frames"]:
        a = g.eng.u(f["actor"]).name
        print(f"[T{f['t']:.2f}] {a}")
        for e in f["events"]:
            print("   ", e["text"])


if __name__ == "__main__":
    main()
