"""JSON の窓口（ローカルサーバー版とブラウザ内Python版で共通）。1つのプロセスで1戦を保持する。"""
from __future__ import annotations

import json
import traceback

from .session import GameSession

_S = {"g": None}


def _slice(view, frm):
    if view is None:
        return None
    v = dict(view)
    frm = int(frm or 0)
    v["frames_from"] = frm if frm <= len(view["frames"]) else 0
    v["frames"] = view["frames"][v["frames_from"]:]
    v["frames_total"] = len(view["frames"])
    return v


def handle(req: dict) -> dict:
    try:
        cmd = req.get("cmd")
        frm = req.get("from", 0)
        if cmd == "new":
            _S["g"] = GameSession(req.get("settings") or {})
            return {"ok": True, "view": _slice(_S["g"].view, 0)}
        if cmd == "restart":                # 同じ戦闘（同じ seed・同じ設定）を最初から
            g = _S["g"]
            _S["g"] = GameSession(dict(g.settings))
            return {"ok": True, "view": _slice(_S["g"].view, 0)}
        g = _S["g"]
        if g is None:
            return {"ok": False, "error": "戦闘が始まっていません"}
        v = g.handle(req)
        return {"ok": True, "view": _slice(v, frm)}
    except Exception as e:      # 画面に理由を出す
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc()[-1500:]}


def handle_json(s: str) -> str:
    return json.dumps(handle(json.loads(s)), ensure_ascii=False)
