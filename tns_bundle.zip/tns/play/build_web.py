"""ブラウザ版（試験版）を作る: Python をブラウザの中で動かす Pyodide を使い、既存の戦闘エンジンをそのまま動かす。
python -m tns.play.build_web  → dist_web/index.html と dist_web/tns_bundle.zip
※ Pyodide 本体はインターネット上（cdn.jsdelivr.net）から読み込む。この作業環境からは取得できないため、動作は未確認。
"""
from __future__ import annotations

import zipfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "dist_web"
PYODIDE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js"

LOADER = """
<div id="bootMsg" style="position:fixed;left:0;right:0;bottom:0;background:#3b5b8c;color:#fff;padding:10px 14px;font-size:13px;z-index:20">
ブラウザの中で戦闘エンジン（Python）を準備しています…（初回は数十秒かかることがあります）</div>
<script src="%s"></script>
<script>
(async function(){
  const msg = document.getElementById("bootMsg");
  const btns = [document.getElementById("btnStart"), document.getElementById("btnWatch")];
  btns.forEach(b => b.disabled = true);
  try {
    const py = await loadPyodide();
    const buf = await (await fetch("tns_bundle.zip")).arrayBuffer();
    py.unpackArchive(buf, "zip", {extractDir: "/home/pyodide/tnsapp"});
    py.runPython("import sys, os\\nsys.path.insert(0, '/home/pyodide/tnsapp')\\nos.chdir('/home/pyodide/tnsapp')\\nfrom tns.play.api import handle_json");
    const h = py.globals.get("handle_json");
    window.TNS_PY = async (s) => h(s);
    msg.remove();
    btns.forEach(b => b.disabled = false);
  } catch (e) {
    msg.style.background = "#7a3434";
    msg.textContent = "ブラウザ版の準備に失敗しました: " + e + "（この環境ではブラウザ版が動かない可能性があります。パソコンでのローカル版をお使いください）";
  }
})();
</script>
""" % PYODIDE


def build():
    OUT.mkdir(exist_ok=True)
    html = (ROOT / "tns" / "play" / "web" / "index.html").read_text(encoding="utf-8")
    html = html.replace("</body>", LOADER + "\n</body>")
    (OUT / "index.html").write_text(html, encoding="utf-8")
    z = OUT / "tns_bundle.zip"
    ydir = Path(yaml.__file__).parent
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted((ROOT / "tns").rglob("*.py")):
            zf.write(p, p.relative_to(ROOT).as_posix())
        for p in sorted((ROOT / "config").rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(ROOT).as_posix())
        for p in sorted(ydir.glob("*.py")):         # PyYAML（純Python部分だけ）
            zf.write(p, "yaml/" + p.name)
    print("wrote", OUT / "index.html", z, z.stat().st_size // 1024, "KB")


if __name__ == "__main__":
    build()
