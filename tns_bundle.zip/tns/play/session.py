"""Ver0.14 プレイヤー操作の戦闘プロトタイプ（試作用。正式仕様ではない）。

しくみ（エンジンは変更しない）:
- 既存の TimelineEngine（Ver0.12/0.13）をそのまま使う。味方側の「判断の窓口」（Controller）だけを
  プレイヤー用に差し替える。窓口はエンジンが最初から用意しているもの（decide_action / decide_intervention）。
- プレイヤーの判断が必要になったら、そこで戦闘の計算を止める（NeedInput）。判断が届いたら、
  同じ seed・それまでの判断の記録で最初から計算し直し、止まった所の先へ進む（決定的な再計算）。
  → 判断している間、ゲーム内の時刻はまったく進まない。行動順・詠唱時間・攻撃処理はエンジンの計算そのまま。
- プレイヤーが操作しない判断（自動のユニット・自動の介入・「AIに任せる」）は既存の味方AI（Ver0.13 v13）が行う。
"""
from __future__ import annotations

import math
import random

from ..ai.ally.value_controller import ValueAllyController
from ..ai.enemy.enemy_controller import EnemyAIController
from ..config_loader import load_battle_config
from ..control.controller import Decision
from ..engine.timeline_engine import make_engine
from ..intervention.records import InterventionChoice
from ..model.enums import ActionKind, Rank, Side, Stance

DEFAULTS = {
    "method": "B",              # 速度方式 B（指数0.5）… 試作用の暫定
    "cast": 4,                  # 炎嵐の詠唱時間 4（0/2/4/6 の設定ファイルがある）
    "intel": 1,                 # 敵の知能 0=低 1=通常 2=高 3=戦術級
    "enemy_power": 0.954,       # Ver0.13 方式Bの難易度調整（試作の初期値）
    "seed": None,               # None なら毎回ランダム
    "ai": "v13",                # 味方AI: Ver0.13 の時間認識修正版
    "manual_units": ["adel", "vanguard3", "vanguard", "celestia"],   # プレイヤーが操作する味方
    "manual_intervention": "rear",  # 介入の判断: "rear"=後衛が狙われたときだけ / "all"=前衛どうしも / "none"=AIに任せる
    "ruleset": "v14",           # "v14"=Ver0.14 の戦闘 / "v15"=Ver0.15（役割・新しい行動・呪術師・観測固定）
}
INTEL_NAMES = {0: "低知能", 1: "通常", 2: "高知能", 3: "戦術級"}
POSITION = {"adel": "左FRONT", "vanguard3": "中央FRONT", "vanguard": "右FRONT", "celestia": "左REAR", "toolsmith": "右REAR"}


class NeedInput(Exception):
    def __init__(self, request):
        super().__init__("need input")
        self.request = request


class DecisionMismatch(RuntimeError):
    pass


def _scale_enemy(cfg, f, magic=False):
    """敵の威力（と魔法）に倍率を掛ける（試作の難易度設定）。ブラウザ版でも動くよう、ここでは sim を import しない。"""
    import copy
    cfg.encounter = copy.deepcopy(cfg.encounter)
    for u in cfg.encounter["units"]:
        u["power"] = u["power"] * f
        if magic:
            u["magic"] = u.get("magic", 0) * f
    return cfg


def make_battle(settings):
    s = settings
    f = float(s.get("enemy_power") or 1.0)
    if s.get("ruleset") == "v15":
        cfg = load_battle_config(party="party_v15", encounter="v15_caster5", rules="rules_v15.yaml",
                                 ai_weights="ai_weights_v15.yaml", ally_policies="ally_policies_v15.yaml",
                                 front_hp_mult=1.75)
        if abs(f - 1.0) > 1e-12:
            cfg = _scale_enemy(cfg, f, magic=True)
        return cfg
    rules = (f"rules_v12_{s['method']}_cast{s['cast']}.yaml")
    cfg = load_battle_config(party="party_v08_3f_center", encounter="wolves_6t", rules=rules,
                             ai_weights="ai_weights_v04.yaml", ally_policies="ally_policies_v05_none.yaml",
                             front_hp_mult=1.75)
    if abs(f - 1.0) > 1e-12:
        cfg = _scale_enemy(cfg, f)                 # tns.sim.v12.apply_mods の enemy_power と同じ計算
    return cfg


class PlayerController:
    """味方側の判断の窓口。プレイヤーが操作しない部分は、中に持っている既存の味方AIへそのまま渡す。"""
    name = "player"

    def __init__(self, ai, session):
        self.ai = ai
        self.session = session

    def bind(self, engine, side):
        self.engine = engine
        self.side = side
        self.ai.bind(engine, side)

    def __getattr__(self, k):          # policy_name / records / predict_defense / decide_defense など
        return getattr(self.ai, k)

    def decide_action(self, actor):
        return self.session._point("action", actor=actor)

    def decide_intervention(self, window):
        return self.session._point("intervene", window=window)

    def decide_defense(self, defender, attacker, action, expected_raw):
        return self.ai.decide_defense(defender, attacker, action, expected_raw)

    def predict_defense(self, defender, attacker, action, expected_raw):
        return self.ai.predict_defense(defender, attacker, action, expected_raw)


class GameSession:
    """1戦ぶんの状態。判断の記録 self.log_dec だけを持ち、表示はそのつど再計算する。"""

    def __init__(self, settings=None):
        s = dict(DEFAULTS)
        s.update(settings or {})
        if s.get("ruleset") == "v15" and "enemy_power" not in (settings or {}):
            s["enemy_power"] = 1.0          # Ver0.15 は難易度合わせ済みの数値（倍率なし）が初期値
        if s.get("seed") in (None, "", "random"):
            s["seed"] = random.randrange(0, 10 ** 6)
        s["seed"] = int(s["seed"])
        s["intel"] = int(s["intel"])
        s["cast"] = int(s["cast"])
        self.settings = s
        self.log_dec = []          # 判断点ごとの記録: {"sig":..., "by": "ai"|"player", "choice": {...}}
        self.view = None
        self.run()

    # ------------------------------------------------------------ 戦闘の計算（最初から, 決定的）
    def _build(self, listen=True):
        s = self.settings
        cfg = make_battle(s)
        if s.get("ruleset") == "v15":
            from ..ai.ally.v15_controller import V15AllyController
            from ..ai.enemy.v15_enemy import V15EnemyAI
            ai = V15AllyController(cfg.ally_policies)
            enemy = V15EnemyAI(cfg.ai_weights)
        else:
            ai = ValueAllyController(cfg.ally_policies, probe=None, hole_model=s["ai"])
            enemy = EnemyAIController(cfg.ai_weights)
        self._ctl = PlayerController(ai, self)
        eng = make_engine(cfg, {Side.ALLY: self._ctl, Side.ENEMY: enemy},
                          seed=s["seed"], enemy_intel=s["intel"])
        return eng

    def run(self):
        self._k = 0
        self._frames = []
        self._cur = None
        eng = self._build()
        self.eng = eng
        eng.listeners.append(self._listen)
        pending = None
        try:
            eng.run()
        except NeedInput as e:
            pending = e.request
        if pending is not None:
            # 途中の手番（例: 敵の攻撃宣言の最中）は「完了した手番」に入れず、判断画面に添える
            pending["partial"] = self._cur["events"] if self._cur else []
            pending["partial_actor"] = self._cur["actor"] if self._cur else None
            self._cur = None
        else:
            self._close_frame()
        self.view = self._make_view(pending)
        return self.view

    # ------------------------------------------------------------ 判断点
    def _sig(self, kind, actor=None, window=None):
        eng = self.eng
        if kind == "action":
            return f"action:{actor.id}:{eng.action_index}"
        return f"intervene:{window.attacker.id}>{window.target.id}:{eng.action_index}"

    def _manual(self, kind, actor=None, window=None):
        s = self.settings
        if kind == "action":
            return actor.id in s["manual_units"]
        m = s["manual_intervention"]
        if m in (True, "all"):
            return True
        if m == "rear":
            return window.target.rank is Rank.REAR
        return False

    def _point(self, kind, actor=None, window=None):
        k = self._k
        self._k += 1
        sig = self._sig(kind, actor, window)
        if k < len(self.log_dec):
            rec = self.log_dec[k]
            if rec["sig"] != sig:
                raise DecisionMismatch(f"判断点 {k} が一致しない: 記録 {rec['sig']} / 今回 {sig}")
            if rec["by"] == "player":
                return self._apply(kind, rec["choice"], actor, window)
            return self._ai(kind, actor, window)
        if not self._manual(kind, actor, window):
            self.log_dec.append({"sig": sig, "by": "ai"})
            return self._ai(kind, actor, window)
        # プレイヤーの判断が必要 → ここで止める（この判断点はまだ記録しない）
        req = self._request(kind, k, sig, actor, window)
        raise NeedInput(req)

    def _ai(self, kind, actor, window):
        if kind == "action":
            return self._ctl.ai.decide_action(actor)
        return self._ctl.ai.decide_intervention(window)

    def _apply(self, kind, ch, actor, window):
        if ch.get("ai"):
            return self._ai(kind, actor, window)
        if kind == "action":
            return Decision(ch["action"], ch.get("target"), reasons=["プレイヤーの指示"])
        if ch.get("interceptor"):
            return InterventionChoice(ch["interceptor"], reasons=["プレイヤーの指示: 庇う"])
        return InterventionChoice(None, reasons=["プレイヤーの指示: 庇わない"])

    # ------------------------------------------------------------ 選択肢と理由
    def _action_options(self, actor):
        eng = self.eng
        out = []
        avail = {a.id for a in eng.available_actions(actor)}
        for aid in actor.d.action_ids:
            a = eng.actions[aid]
            if a.kind is ActionKind.COVER and not eng.cover_on:
                continue                                  # このルールでは使えない行動は出さない
            o = {"id": a.id, "name": a.name, "ep": a.ep_cost, "kind": a.kind.value,
                 "area": getattr(a, "area", "single"), "ok": a.id in avail, "why": "", "targets": []}
            if a.uses is not None and actor.uses.get(a.id, 0) <= 0:
                o["why"] = f"使用回数を使い切った（1戦{a.uses}回まで）"
            elif a.ep_cost > eng.spendable_ep(actor, a):
                o["why"] = f"EP不足（必要{a.ep_cost} / 現在{actor.ep}）"
            elif a.kind is ActionKind.ATTACK and not o["ok"]:
                o["why"] = "近接攻撃ができない状態"
            if a.id in eng.cast_time:
                o["cast"] = round(eng.cast_time[a.id] * eng.cast_quantum / max(eng.eff_rate(actor), 1e-9), 3)
            if o["ok"] and a.kind is not ActionKind.WAIT:
                tg = eng.valid_targets(actor, a)
                if a.kind is ActionKind.ATTACK and getattr(a, "area", "single") == "all":
                    tg = [t for t in tg if t.alive]
                    if tg:
                        o["targets"] = [{"id": tg[0].id, "name": "敵全体", "info": f"戦闘可能な敵{len(tg)}体すべて"}]
                else:
                    for t in tg:
                        if a.kind is ActionKind.ATTACK:
                            d = eng.estimate_damage(actor, a, t)
                            r = eng.reach(actor, t, a)
                            exp = eng.damage.expected(actor, a)
                            drain = min(t.ep, eng.defense.required_ep(t, exp)) if d < exp - 1e-6 and eng.defense_allowed(t) else 0
                            info = f"HP−{d:.0f}の見込み" + (f"・EPを約{drain:.0f}削る" if drain >= 0.5 else "") + \
                                   (f"・{r.via_route}から突破" if r.via_route else "")
                            if t.incapacitated:
                                info += "・戦闘不能"
                        elif a.kind is ActionKind.HEAL:
                            amt = int(round(a.heal_ratio * t.d.hp_max)) if a.heal_ratio else eng.heal.amount(actor, a)
                            info = f"HP{t.hp}/{t.d.hp_max} → +{min(amt, t.d.hp_max - t.hp)}"
                        elif a.kind is ActionKind.EP_SUPPLY:
                            info = f"EP{t.ep}/{t.d.ep_max} → +{min(a.amount, t.d.ep_max - t.ep)}（残り{actor.uses.get(a.id, 0)}回）"
                        elif getattr(a, "special", "") == "observe":
                            info = "次の行動の意思を固定して見る" + ("（詠唱中: 完成を待つだけ）" if t.id in eng.casting else "")
                        elif getattr(a, "special", "") == "howl":
                            info = "群れに狙わせる"
                        elif getattr(a, "special", "") == "hold":
                            info = "次の手番まで: 受ける威力×0.6・介入しない・経路を2人分で塞ぐ"
                        else:
                            info = ""
                        sp = getattr(a, "special", "")
                        if sp == "pin":
                            info += "・相手は次の手番が終わるまで介入・突撃系が使えない"
                        elif sp == "push":
                            info += "・相手の次の行動を0.25T遅らせる"
                        elif sp == "dive":
                            info += "・行動後は持ち場を離れる（次の手番で戻る）"
                        elif a.kind is ActionKind.ATTACK and t.rank is Rank.REAR and a.reach is not None \
                                and a.reach.value == "MELEE" and getattr(eng, "rear_melee_displaces", False):
                            info += "・行動後は持ち場を離れる"
                        o["targets"].append({"id": t.id, "name": t.name, "info": info})
                if not o["targets"]:
                    o["ok"] = False
                    o["why"] = o["why"] or ("届く相手がいない" if a.kind is ActionKind.ATTACK else "対象がいない")
            out.append(o)
        return out

    def _request(self, kind, k, sig, actor, window):
        eng = self.eng
        if kind == "action":
            # 参考: AIならどうするか（判断には使わない。表示だけ）
            dec = self._ctl.ai.decide_action(actor)
            sug = {"action": dec.action_id, "target": dec.target_id,
                   "text": self._dec_text(dec), "reasons": [str(r) for r in (dec.reasons or [])][:3]}
            return {"kind": "action", "k": k, "sig": sig, "actor": actor.id, "options": self._action_options(actor),
                    "ai": sug, "snap": self._snapshot()}
        t, atk, a = window.target, window.attacker, window.action
        raw = eng.damage.expected(atk, a)
        opts = []
        for c in window.eligible:
            if c.rank is not Rank.FRONT:
                continue
            need = math.ceil(eng.defense.required_ep(c, raw) - 1e-9)
            before = [eng.u(x).name for x in eng.actors_before_next_turn_of(c.id) if eng.u(x).side is Side.ENEMY]
            opts.append({"id": c.id, "name": c.name, "pos": POSITION.get(c.id, ""), "hp": c.hp, "hp_max": c.d.hp_max,
                         "ep": c.ep, "need_ep": need, "next": round(eng.next_time[c.id] - eng.cur_time, 3),
                         "enemies_before": before, "est": round(eng.estimate_damage(atk, a, c), 1)})
        choice = self._ctl.ai.decide_intervention(window)
        sug = {"interceptor": choice.interceptor_id,
               "text": (f"{eng.u(choice.interceptor_id).name}が庇う" if choice.interceptor_id else "庇わない"),
               "reasons": [str(r) for r in (choice.reasons or [])][:2]}
        return {"kind": "intervene", "k": k, "sig": sig, "attacker": atk.id, "target": t.id, "action": a.name,
                "raw": round(raw, 1), "est_self": round(eng.estimate_damage(atk, a, t), 1),
                "target_casting": t.id in eng.casting, "options": opts, "ai": sug, "snap": self._snapshot()}

    def _dec_text(self, dec):
        eng = self.eng
        a = eng.actions[dec.action_id]
        if a.kind is ActionKind.WAIT or not dec.target_id:
            return a.name
        if getattr(a, "area", "single") == "all":
            return f"{a.name}（敵全体）"
        return f"{a.name} → {eng.u(dec.target_id).name}"

    # ------------------------------------------------------------ プレイヤーの入力
    def decide(self, k, choice):
        """choice: {"action","target"} / {"interceptor"} / {"interceptor": None} / {"ai": True}"""
        if self.view is None or self.view.get("pending") is None:
            raise ValueError("いまは判断を待っていない")
        p = self.view["pending"]
        if int(k) != p["k"]:
            raise ValueError("古い判断です（画面を更新してください）")
        if p["kind"] == "action" and not choice.get("ai"):
            ok = {(o["id"], t["id"]) for o in p["options"] if o["ok"] for t in o["targets"]} | \
                 {(o["id"], None) for o in p["options"] if o["ok"] and o["kind"] == "wait"}
            if (choice.get("action"), choice.get("target")) not in ok:
                raise ValueError("その行動・対象は選べません")
        if p["kind"] == "intervene" and not choice.get("ai") and choice.get("interceptor"):
            if choice["interceptor"] not in {o["id"] for o in p["options"]}:
                raise ValueError("その前衛は介入できません")
        self.log_dec.append({"sig": p["sig"], "by": "player", "choice": choice})
        return self.run()

    def undo(self):
        """直前のプレイヤーの判断を取り消す（その判断の場面に戻る）。"""
        idx = max((i for i, r in enumerate(self.log_dec) if r["by"] == "player"), default=None)
        if idx is None:
            return self.view
        del self.log_dec[idx:]
        return self.run()

    def update_settings(self, manual_units=None, manual_intervention=None):
        """操作の切り替え（この先の判断から有効）。"""
        if manual_units is not None:
            self.settings["manual_units"] = list(manual_units)
        if manual_intervention is not None:
            self.settings["manual_intervention"] = manual_intervention
        return self.run()

    # ------------------------------------------------------------ 表示用の記録
    def _snapshot(self):
        eng = self.eng
        now = eng.cur_time
        units = []
        for u in eng.state.units.values():
            cs = eng.casting.get(u.id)
            nt = eng.next_time.get(u.id, float("inf"))
            item = {"id": u.id, "hp": u.hp, "ep": u.ep, "alive": int(u.alive), "incap": int(u.incapacitated),
                    "dead": int(u.hp <= 0), "stance": u.stance.value, "displaced": int(u.displaced),
                    "next": round(nt - now, 3) if math.isfinite(nt) and u.alive else None}
            if cs is not None:
                item["cast"] = {"action": eng.actions[cs["dec"].action_id].name,
                                "left": round(max(0.0, nt - now), 3) if math.isfinite(nt) else None}
            fx = getattr(eng, "fixed_info", {}).get(u.id)
            if fx is not None:
                fa = eng.actions.get(fx.action_id)
                item["fixed"] = (fa.name if fa else fx.action_id) + (f"→{eng.u(fx.target_id).name}" if fx.target_id and not (fa and fa.area == "all") else "")
            if u.id in getattr(eng, "pinned", {}):
                item["pinned"] = 1
            if u.id in getattr(eng, "holding", set()):
                item["holding"] = 1
            if u.stance is Stance.DIVING if hasattr(Stance, "DIVING") else False:
                item["diving"] = 1
            units.append(item)
        routes = {}
        from ..formation.route import route_status_map
        rs = route_status_map(eng.state.all_routes(), eng.state.units)
        for r in eng.state.all_routes():
            routes[r.id] = rs[r.id]
        up = []
        try:
            if hasattr(eng, "_predicted"):
                cur = getattr(eng, "current_actor", None)
                seen = 0
                for sl in eng._predicted(now + 3.0):
                    up.append(sl.unit_id)
                    seen += 1
                    if seen >= 10:
                        break
        except Exception:
            up = []
        howl = {g: t for g, t in getattr(eng, "howl", {}).items()}
        route_w = {r.id: eng.route_weight(r) for r in eng.state.all_routes()} if hasattr(eng, "route_weight") else {}
        return {"t": round(now, 3), "round": eng.state.round, "units": units, "routes": routes, "upcoming": up, "howl": howl, "route_w": route_w,
                "actor": getattr(getattr(eng, "current_actor", None), "id", None)}

    def _close_frame(self):
        if self._cur is not None:
            self._cur["after"] = self._snapshot()
            self._frames.append(self._cur)
            self._cur = None

    def _listen(self, ev, eng):
        t = ev["t"]
        if t == "turn_start":
            self._close_frame()
            self._cur = {"actor": ev["unit"], "t": round(eng.cur_time, 3), "round": eng.state.round, "events": []}
            return
        if self._cur is None:
            return
        line = self._fmt(ev, eng)
        if line:
            self._cur["events"].append(line)

    def _fmt(self, ev, eng):
        t = ev["t"]
        n = lambda uid: eng.u(uid).name
        if t == "attack_declared":
            via = f"（{ev['via_route']}から前線を突破）" if ev.get("via_route") else ""
            return {"type": "attack", "a": ev["unit"], "t": ev["target"],
                    "text": f"{n(ev['unit'])}の{eng.actions[ev['action']].name} → {n(ev['target'])}{via}"}
        if t == "intervened":
            return {"type": "iv", "a": ev["unit"], "t": ev["target"],
                    "text": f"🛡 {n(ev['unit'])}が{n(ev['target'])}を庇った（持ち場を離れる）"}
        if t == "no_intervention":
            return {"type": "noiv", "t": ev["target"], "text": f"{n(ev['target'])}は庇われずに受ける"}
        if t == "damage":
            d, sp = ev.get("dmg", 0) or 0, ev.get("ep_spent", 0) or 0
            how = f"EP{sp}で防御し " if sp else "生身で "
            return {"type": "dmg", "t": ev["unit"], "dmg": d,
                    "text": f"{n(ev['unit'])}: {how}HP−{d}（残りHP{ev['hp']}）"}
        if t == "heal":
            return {"type": "heal", "a": ev["unit"], "t": ev["target"],
                    "text": f"✚ {n(ev['unit'])}が{n(ev['target'])}を治療 HP+{ev['amount']}"}
        if t == "area_attack":
            whom = "敵全体" if eng.u(ev["unit"]).side is Side.ALLY else "味方全体"
            return {"type": "storm", "a": ev["unit"], "text": f"🔥 {n(ev['unit'])}の{eng.actions[ev['action']].name}！ {whom}へ"}
        if t == "cast_start":
            left = eng.cast_time[ev["action"]] * eng.cast_quantum / max(eng.eff_rate(eng.u(ev["unit"])), 1e-9)
            return {"type": "cast", "a": ev["unit"],
                    "text": f"✦ {n(ev['unit'])}が{eng.actions[ev['action']].name}の詠唱を開始（完成まで約{left:.2f}T・その間は自己防御できない）"}
        if t == "cast_complete":
            return {"type": "cast", "a": ev["unit"], "text": f"✦ {n(ev['unit'])}の詠唱が完成"}
        if t == "cast_cancel":
            return {"type": "cast", "a": ev["unit"], "text": f"✖ {n(ev['unit'])}の詠唱が中断（{ev.get('reason', '')}）"}
        if t == "cast_fail":
            return {"type": "cast", "a": ev["unit"], "text": f"✖ {n(ev['unit'])}の詠唱は失敗（EP不足）"}
        if t == "ko":
            if ev.get("incap"):
                return {"type": "ko", "t": ev["unit"], "text": f"✖ {n(ev['unit'])}が戦闘不能"}
            return {"type": "dead", "t": ev["unit"], "text": f"☠ {n(ev['unit'])}が死亡"}
        if t == "revive":
            return {"type": "revive", "t": ev["unit"], "text": f"↺ {n(ev['unit'])}が戦闘に復帰"}
        if t == "intrusion":
            return {"type": "breach", "a": ev["unit"], "t": ev["target"],
                    "text": f"⚠ {n(ev['unit'])}が前線を突破して{n(ev['target'])}へ"}
        if t == "wait":
            return {"type": "wait", "a": ev["unit"], "text": f"{n(ev['unit'])}は待機"}
        if t == "stance" and ev.get("new") == "READY" and ev.get("old") in ("RECOVERING", "GUARDING", "INTERVENING"):
            return {"type": "return", "a": ev["unit"], "text": f"↩ {n(ev['unit'])}が持ち場へ戻った"}
        if t == "stance" and ev.get("new") == "DIVING":
            return {"type": "breach", "a": ev["unit"], "text": f"⇢ {n(ev['unit'])}が持ち場を離れて相手の後衛へ踏み込んだ"}
        if t == "dive_return":
            return {"type": "return", "a": ev["unit"], "text": f"↩ {n(ev['unit'])}が持ち場へ戻った"}
        if t == "hold":
            return {"type": "info", "a": ev["unit"], "text": f"⛨ {n(ev['unit'])}が死守の構え（次の手番まで）"}
        if t == "pinned":
            return {"type": "info", "t": ev["unit"], "text": f"⚓ {n(ev['by'])}が{n(ev['unit'])}を牽制（介入・突撃系を封じる）"}
        if t == "pushed":
            return {"type": "info", "t": ev["unit"], "text": f"⇠ {n(ev['by'])}が{n(ev['unit'])}を押し返した（次の行動 +0.25T）"}
        if t == "howl":
            return {"type": "info", "a": ev["unit"], "text": f"🐺 {n(ev['unit'])}の遠吠え: 群れが{n(ev['target'])}を狙う"}
        if t == "observe":
            a = eng.actions.get(ev.get("action") or "", None)
            what = a.name if a else str(ev.get("action"))
            tgt = f" → {n(ev['intent_target'])}" if ev.get("intent_target") else ""
            if ev.get("casting"):
                return {"type": "info", "a": ev["unit"], "text": f"👁 {n(ev['unit'])}が{n(ev['target'])}を観測: 詠唱中の{what}{tgt}"}
            return {"type": "info", "a": ev["unit"],
                    "text": f"👁 {n(ev['unit'])}が{n(ev['target'])}を観測: 次は「{what}{tgt}」に固定された"}
        if t == "fixed_execute":
            return {"type": "info", "a": ev["unit"], "text": f"👁 {n(ev['unit'])}は固定された意思のとおりに動く"}
        if t == "fixed_broken":
            return {"type": "info", "a": ev["unit"],
                    "text": f"👁 {n(ev['unit'])}の固定された意思が成立しない（{ev.get('why', '')}）"
                            + ("→ 手番を失う" if ev.get("mode") == "lose" else "→ 選び直す")}
        if t == "intel_down":
            return {"type": "info", "text": f"{n(ev['leader'])}が倒れ、{n(ev['unit'])}の統率が乱れた"}
        return None

    def _static(self):
        eng = self.eng
        units = []
        for u in eng.state.units.values():
            units.append({"id": u.id, "name": u.name, "side": u.side.value, "rank": u.rank.value, "hp_max": u.d.hp_max,
                          "ep_max": u.d.ep_max, "speed": u.d.speed, "pos": POSITION.get(u.id, ""),
                          "interval": round(1.0 / eng.base_rate(u), 3), "leader": int(u.d.is_leader)})
        return {"units": units, "settings": {k: v for k, v in self.settings.items()},
                "intel_name": INTEL_NAMES[self.settings["intel"]]}

    def _make_view(self, pending):
        eng = self.eng
        st = eng.state
        status = "decision" if pending else "end"
        res = {"status": status, "frames": self._frames, "pending": pending, "static": self._static(),
               "snap": pending["snap"] if pending else self._snapshot(),
               "n_player_decisions": sum(1 for r in self.log_dec if r["by"] == "player")}
        if not pending:
            res["winner"] = st.winner
            res["result"] = {"ally": "勝利", "enemy": "敗北", "draw": "時間切れ（引き分け）"}.get(st.winner, str(st.winner))
        return res

    # ------------------------------------------------------------ JSON の窓口（ローカルサーバーとブラウザ版の共通）
    def handle(self, req):
        cmd = req.get("cmd")
        if cmd == "state":
            return self.view
        if cmd == "decide":
            return self.decide(req["k"], req.get("choice") or {})
        if cmd == "undo":
            return self.undo()
        if cmd == "settings":
            return self.update_settings(req.get("manual_units"), req.get("manual_intervention"))
        raise ValueError(f"unknown cmd {cmd}")


def auto_result(settings):
    """完全自動（判断はすべて既存AI）で1戦。比較用。"""
    s = dict(settings)
    s["manual_units"] = []
    s["manual_intervention"] = "none"
    g = GameSession(s)
    return g
