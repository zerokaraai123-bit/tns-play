"""ローカルで遊ぶためのサーバー（Python標準ライブラリだけ。追加のインストールは PyYAML のみ）。
python -m tns.play            → http://127.0.0.1:8765 を開く
python -m tns.play --lan      → 同じWi-Fiの別の端末（スマホなど）からも開けるようにする（未検証）
"""
from __future__ import annotations

import argparse
import json
import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import api

WEB = Path(__file__).parent / "web"
LOCK = threading.Lock()
TYPES = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml"}


class H(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body: bytes, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", ""):
            path = "/index.html"
        f = (WEB / path.lstrip("/")).resolve()
        if not str(f).startswith(str(WEB.resolve())) or not f.is_file():
            return self._send(404, b"not found", "text/plain")
        self._send(200, f.read_bytes(), TYPES.get(f.suffix, "application/octet-stream"))

    def do_POST(self):
        if self.path.split("?")[0] != "/api":
            return self._send(404, b"not found", "text/plain")
        n = int(self.headers.get("Content-Length", 0))
        req = json.loads(self.rfile.read(n) or b"{}")
        with LOCK:
            res = api.handle(req)
        self._send(200, json.dumps(res, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")


def main(argv=None):
    ap = argparse.ArgumentParser(description="TNS 戦闘プロトタイプ（Ver0.14）")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--lan", action="store_true", help="同じネットワークの別の端末から開けるようにする")
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args(argv)
    host = "0.0.0.0" if a.lan else "127.0.0.1"
    srv = ThreadingHTTPServer((host, a.port), H)
    url = f"http://127.0.0.1:{a.port}/"
    print("TNS 戦闘プロトタイプを起動しました。")
    print(f"  このパソコンのブラウザで開く: {url}")
    if a.lan:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            print(f"  同じWi-Fiのスマホから開く（未検証）: http://{ip}:{a.port}/")
        except Exception:
            pass
    print("  終了するときは、この画面で Ctrl+C を押してください。")
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("終了しました。")


if __name__ == "__main__":
    main()
