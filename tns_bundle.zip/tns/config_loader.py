"""設定ファイル(YAML/JSON)の読み込み。コードに数値を書かないための入口。"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / "config"


def load_file(path) -> dict:
    p = Path(path)
    if not p.is_absolute() and not p.exists():
        p = CONFIG_DIR / p
    text = p.read_text(encoding="utf-8")
    data = json.loads(text) if p.suffix == ".json" else yaml.safe_load(text)
    if isinstance(data, dict) and "extends" in data:      # 差分だけ書いた設定ファイル
        base = load_file(p.parent / data.pop("extends"))
        data = _deep_merge(base, data)
    return data


def _deep_merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in over.items():
        out[k] = _deep_merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _resolve(name: str, sub: str) -> Path:
    p = Path(name)
    if p.exists():
        return p
    for ext in ("", ".yaml", ".yml", ".json"):
        q = CONFIG_DIR / sub / f"{name}{ext}"
        if q.exists():
            return q
    raise FileNotFoundError(f"{sub}/{name}")


@dataclass
class BattleConfig:
    rules: dict
    party: dict
    encounter: dict
    ai_weights: dict
    ally_policies: dict
    highlights: dict
    party_name: str
    encounter_name: str

    @property
    def hash(self) -> str:
        blob = json.dumps([self.rules, self.party, self.encounter, self.ai_weights, self.ally_policies],
                          sort_keys=True, ensure_ascii=False, default=str)
        return hashlib.sha1(blob.encode()).hexdigest()[:10]


def load_battle_config(party="party_default", encounter="wolves_5v5", rules="rules.yaml",
                       ai_weights="ai_weights.yaml", ally_policies="ally_policies.yaml",
                       highlights="highlights.yaml", front_hp_mult: float = 1.0) -> BattleConfig:
    party_cfg = load_file(_resolve(party, "parties"))
    if front_hp_mult != 1.0:
        # Ver0.4: 前衛キャラクター本人の基礎HPに倍率を掛ける（位置による補正ではない。PA-26）
        for u in party_cfg["units"]:
            if u["rank"] == "FRONT":
                u["hp"] = int(round(u["hp"] * front_hp_mult))
    return BattleConfig(
        rules=load_file(rules),
        party=party_cfg,
        encounter=load_file(_resolve(encounter, "encounters")),
        ai_weights=load_file(ai_weights),
        ally_policies=load_file(ally_policies),
        highlights=load_file(highlights),
        party_name=party, encounter_name=encounter,
    )
