"""ダメージ・エーテル防御・治癒・EP の計算。いずれも交換可能な Strategy。
数式はすべて PROTOTYPE_ASSUMPTION（PA-03 / PA-04 / PA-12 / PA-13）。
"""
from __future__ import annotations

import math


class DamageStrategy:
    def raw(self, attacker, action, rng=None) -> float:
        raise NotImplementedError

    def expected(self, attacker, action) -> float:
        return self.raw(attacker, action, None)


class LinearDamage(DamageStrategy):
    """PA-04: 能力値 * 係数 * (1±variance)"""

    def __init__(self, cfg):
        self.variance = float(cfg.get("variance", 0.1))

    def raw(self, attacker, action, rng=None):
        stat = getattr(attacker.d, action.source)
        v = 1.0 if rng is None else rng.uniform(1 - self.variance, 1 + self.variance)
        return stat * action.coef * v


class CurveDamage(DamageStrategy):
    """Ver0.15 検証用（PA-214）: 能力値の効きを緩める。実効値 = ref × (能力値/ref)^exponent。
    exponent=1 なら LinearDamage と同じ。0.5 なら能力値1割の差がダメージ約4.9%の差になる（速度の方式Bと同じ考え方）。"""

    def __init__(self, cfg):
        self.variance = float(cfg.get("variance", 0.1))
        self.p = float(cfg.get("exponent", 1.0))
        self.ref = float(cfg.get("ref", 20.0))

    def raw(self, attacker, action, rng=None):
        stat = float(getattr(attacker.d, action.source))
        eff = self.ref * (max(stat, 0.0) / self.ref) ** self.p if stat > 0 else 0.0
        v = 1.0 if rng is None else rng.uniform(1 - self.variance, 1 + self.variance)
        return eff * action.coef * v


class AetherDefenseStrategy:
    """エーテル防御装置。resolve() が「展開した場合の結果」を返す。
    戻り値: (HPへ通るダメージ(float), 消費EP(int), 防いだダメージ(float), 方式 'reduced'|'full'|'partial')"""
    name = "base"

    def can_deploy(self, c) -> bool:
        raise NotImplementedError

    def exhausted(self, c) -> bool:
        """EP枯渇（＝防御を展開できない）とみなすか。"""
        raise NotImplementedError

    def resolve(self, c, raw: float):
        raise NotImplementedError

    def preview(self, c, raw: float):
        """状態を変えずに resolve() の結果を見積もる。"""
        return self.resolve(c, raw)

    def fragility(self, c) -> float:
        """防御の効率の悪さ（大きいほど脆い）。AIの特徴量用。"""
        raise NotImplementedError

    def required_ep(self, c, raw: float) -> float:
        """この攻撃を（このモデルの意味で）防ぎ切るのに必要なEP。集計用。"""
        raise NotImplementedError


class BodyLinearDefense(AetherDefenseStrategy):
    """Ver0.2〜0.3: 軽減率 = min(max, flat + coef * 肉体強度)。展開ごとに固定EP消費（PA-03）。"""
    name = "body_linear"

    def __init__(self, cfg):
        self.ep_cost = int(cfg.get("ep_cost", 10))
        self.flat = float(cfg.get("flat", 0.1))
        self.coef = float(cfg.get("coef_per_body", 0.04))
        self.max = float(cfg.get("max_reduction", 0.8))

    def reduction(self, defender):
        return max(0.0, min(self.max, self.flat + self.coef * defender.d.body))

    def can_deploy(self, c):
        return c.ep >= self.ep_cost

    def exhausted(self, c):
        return c.ep < self.ep_cost

    def resolve(self, c, raw):
        red = self.reduction(c)
        return raw * (1 - red), self.ep_cost, raw * red, "reduced"

    def fragility(self, c):
        return 1 - self.reduction(c)

    def required_ep(self, c, raw):
        return self.ep_cost


class HPPowerDefense(AetherDefenseStrategy):
    """Ver0.4: HP＝現在の肉体強度。PROTOTYPE_ASSUMPTION PA-30〜PA-33

    1ダメージを防ぐのに必要なEP（EP単価）:
        cpd(HP) = k × (H_ref / HP)^p        … HPは「現在HP」（最大HPではない）
    ・HPが半分になると単価は 2^p 倍。HPの水準・キャラクターによらず常に同じ倍率（スケール不変）。
        A 弱い連鎖 p=0.32 → ×1.25 / B 中程度 p=0.585 → ×1.50 / C 強い連鎖 p=1.0 → ×2.00
    ・p=1 のとき 防げるダメージ = EP × HP / (k × H_ref) となり、「HP×EP」をそのまま式にした形になる。
    ・攻撃を完全に防ぐ必要EP = ceil(raw × cpd)。払えれば全量消費してHPダメージ0。
    ・払えなければ残りEPを全て使い、防げるのは EP / cpd 分だけ。残りがHPへ通る（部分防御 PA-32）。
    """
    name = "hp_power"

    def __init__(self, cfg):
        self.k = float(cfg.get("ep_per_damage_at_ref", 0.5))
        self.h_ref = float(cfg.get("hp_ref", 100))
        self.p = float(cfg.get("exponent", 1.0))
        self.min_hp = float(cfg.get("min_hp_for_cost", 1))
        # 体格の効き q（PA-37）: cpd = k × (H_ref/最大HP)^q × (最大HP/現在HP)^p
        #   q を省略すると q=p で、元の式 k × (H_ref/現在HP)^p と完全に同じ。
        #   q を固定して p だけ変えると「負傷による悪化（連鎖）」だけを比べられる。
        self.q = float(cfg["size_exponent"]) if "size_exponent" in cfg else None
        # Ver0.6 統制用（PA-53）: 陣営ごとに負傷補正 p を変える {ally: .., enemy: ..}。省略時は全員同じ p
        self.p_by_side = {k: float(v) for k, v in (cfg.get("exponent_by_side") or {}).items()}

    def _p(self, c):
        side = getattr(getattr(c, "d", None), "side", None)
        key = getattr(side, "value", side)
        return self.p_by_side.get(key, self.p)

    @staticmethod
    def apparent_hp(c):
        """Ver0.21 メンタリティ（PA-290）: 弱体化の計算に使う見かけのHP。
        見かけのHP割合 = 1 −（1 − HP割合）×（1 − メンタリティ/100）。メンタリティ0なら今のHPそのもの。"""
        m = getattr(getattr(c, "d", None), "mentality", 0) or 0
        if m <= 0:
            return c.hp
        r = c.hp / c.d.hp_max
        return c.d.hp_max * (1.0 - (1.0 - r) * (1.0 - min(100, m) / 100.0))

    def cpd(self, c) -> float:
        hp = max(self.apparent_hp(c), self.min_hp)
        p = self._p(c)
        if self.q is None:
            return self.k * (self.h_ref / hp) ** p
        return self.k * (self.h_ref / c.d.hp_max) ** self.q * (c.d.hp_max / hp) ** p

    def can_deploy(self, c):
        return c.ep > 0

    def exhausted(self, c):
        return c.ep <= 0

    def resolve(self, c, raw):
        if raw <= 0:
            return 0.0, 0, 0.0, "full"
        cpd = self.cpd(c)
        need = math.ceil(raw * cpd - 1e-9)
        if c.ep >= need:
            return 0.0, need, raw, "full"
        blocked = c.ep / cpd
        return raw - blocked, int(c.ep), blocked, "partial"

    def fragility(self, c):
        return self.cpd(c)

    def required_ep(self, c, raw):
        return raw * self.cpd(c)


class EffStrengthDefense(HPPowerDefense):
    """Ver0.9 実験: 実効肉体強度モデル（PA-90）。

    実効肉体強度 S = 現在HP × f(現在HP/最大HP)        … 残っている肉体 × 負傷による発揮効率
    1ダメージを防ぐ必要EP cpd = k × (H_ref / S)^q        … 実効肉体強度が高いほど少ないEPで防げる
      f(r) = r^α（連続のべき乗曲線。α=0 なら「現在HPそのものが肉体強度」、αが大きいほど負傷で発揮効率が落ちる）
      q   = 肉体強度がエーテル防御効率にどれだけ効くか（0 なら体格も負傷も無関係）

    注意（PA-91）: f がべき乗のとき、この式は Ver0.4〜0.8 の hp_power（size_exponent=q, exponent=p）で
    p = q × (1 + α) とした場合と数学的に同じになる。現行P2（q=0.585, p=1）は α = 1/0.585 − 1 ≒ 0.709、
    すなわち f(0.5) ≒ 0.61 の実効肉体強度モデルと等価。
    """
    name = "eff_strength"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.link = float(cfg.get("link_exponent", 0.584963))
        self.alpha = float(cfg.get("wound_alpha", 0.0))

    def wound_factor(self, c, hp=None):
        hp = self.apparent_hp(c) if hp is None else hp
        r = max(hp, self.min_hp) / c.d.hp_max
        return r ** self.alpha

    def effective_strength(self, c, hp=None):
        hp = self.apparent_hp(c) if hp is None else hp
        return max(hp, self.min_hp) * self.wound_factor(c, hp)

    def cpd(self, c) -> float:
        return self.k * (self.h_ref / self.effective_strength(c)) ** self.link


class HealStrategy:
    def amount(self, caster, action) -> int:
        raise NotImplementedError


class MagicLinearHeal(HealStrategy):
    def amount(self, caster, action):
        return int(round(caster.d.magic * action.coef))


class EPRegenStrategy:
    def __init__(self, cfg):
        self.per_round = int(cfg.get("regen_per_round", 0))

    def on_round_start(self, units):
        if self.per_round:
            for u in units:
                if u.alive:
                    u.ep = min(u.d.ep_max, u.ep + self.per_round)


def make_damage(cfg):
    if cfg.get("strategy", "linear") == "linear":
        return LinearDamage(cfg)
    if cfg.get("strategy") == "curve":
        return CurveDamage(cfg)
    raise ValueError(cfg)


def make_defense(cfg):
    s = cfg.get("strategy", "body_linear")
    if s == "body_linear":
        return BodyLinearDefense(cfg)
    if s == "eff_strength":
        return EffStrengthDefense(cfg)
    if s == "hp_power":
        return HPPowerDefense(cfg)
    raise ValueError(cfg)


def make_heal(cfg):
    return MagicLinearHeal()
