"""行動順。完成版の計算式は未決定 → 交換可能な TurnOrderStrategy。

PROTOTYPE_ASSUMPTION PA-01: 速度降順、同速は乱数。
PROTOTYPE_ASSUMPTION PA-02: actions_per_round>1 の追加枠はキュー内に均等配置。
  ※「素早さが高い＝複数回行動」は一般ルールにしない。actions_per_round は速度と独立。
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Slot:
    unit_id: str
    index_in_round: int   # そのユニットの何回目の行動か(0始まり)


class TurnOrderStrategy:
    def build_queue(self, units: list, rng) -> list[Slot]:
        raise NotImplementedError

    def predict_queue(self, units: list) -> list[Slot]:
        """乱数を使わない予測（AIの先読み・UI表示用）。"""
        raise NotImplementedError


class SpeedDescEven(TurnOrderStrategy):
    def _build(self, units, tiebreak):
        alive = [u for u in units if u.alive]
        base = sorted(alive, key=lambda u: (-u.d.speed, tiebreak(u)))
        queue = [Slot(u.id, 0) for u in base]
        L = len(queue)
        for u in base:
            n = u.d.actions_per_round
            if n <= 1:
                continue
            first = next(i for i, s in enumerate(queue) if s.unit_id == u.id and s.index_in_round == 0)
            for k in range(1, n):
                pos = first + round(k * (L + k) / n)
                queue.insert(min(pos, len(queue)), Slot(u.id, k))
        return queue

    def build_queue(self, units, rng):
        keys = {u.id: rng.random() for u in units}
        return self._build(units, lambda u: keys[u.id])

    def predict_queue(self, units):
        return self._build(units, lambda u: u.id)


def make_turn_order(cfg: dict) -> TurnOrderStrategy:
    s = cfg.get("strategy", "speed_desc")
    if s == "speed_desc":
        return SpeedDescEven()
    raise ValueError(f"unknown turn order strategy: {s}")
