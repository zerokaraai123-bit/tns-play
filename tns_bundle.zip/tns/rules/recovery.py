"""介入後の復帰ルール。PROTOTYPE_ASSUMPTION PA-07

own_turn_auto     : 自分の次の手番開始時に RECOVERING→READY、そのまま行動できる（第1試作の既定）
own_turn_consumes : 自分の次の手番を使って持ち場へ戻る（その手番は行動不可）
ticks             : 介入後、全体で N 回行動が進んだら READY
"""
from __future__ import annotations

from ..model.enums import Stance
from ..stance.stance_machine import transition


class RecoveryStrategy:
    name = "base"

    def on_intervened(self, c, engine):  # 介入確定時
        pass

    def on_own_turn_start(self, c, engine) -> bool:
        """自分の手番開始時。False を返すとこの手番は行動不可。"""
        return True

    def on_action_tick(self, engine):  # 誰かの行動が1つ終わるたび
        pass


def _return_to_post(c, engine, reason):
    if c.stance is Stance.GUARDING:
        transition(c, Stance.RECOVERING, engine.emit, reason)
    if c.stance is Stance.RECOVERING:
        transition(c, Stance.READY, engine.emit, reason)
    engine.on_unit_returned(c)


class OwnTurnAuto(RecoveryStrategy):
    name = "own_turn_auto"

    def on_own_turn_start(self, c, engine) -> bool:
        if c.displaced and c.alive:
            _return_to_post(c, engine, "自分の手番開始で持ち場へ復帰 (PA-07 own_turn_auto)")
        return True


class OwnTurnConsumes(RecoveryStrategy):
    name = "own_turn_consumes"

    def on_own_turn_start(self, c, engine) -> bool:
        if c.displaced and c.alive:
            _return_to_post(c, engine, "手番を使って持ち場へ復帰 (PA-07 own_turn_consumes)")
            return False
        return True


class Ticks(RecoveryStrategy):
    name = "ticks"

    def __init__(self, n: int):
        self.n = n

    def on_intervened(self, c, engine):
        c.recover_ticks = self.n

    def on_action_tick(self, engine):
        for c in engine.state.units.values():
            if c.alive and c.displaced:
                c.recover_ticks -= 1
                if c.recover_ticks <= 0:
                    _return_to_post(c, engine, f"{self.n}行動経過で復帰 (PA-07 ticks)")


def make_recovery(cfg: dict) -> RecoveryStrategy:
    s = cfg.get("strategy", "own_turn_auto")
    if s == "own_turn_auto":
        return OwnTurnAuto()
    if s == "own_turn_consumes":
        return OwnTurnConsumes()
    if s == "ticks":
        return Ticks(int(cfg.get("ticks", 3)))
    raise ValueError(f"unknown recovery strategy: {s}")
