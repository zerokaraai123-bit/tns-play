"""介入の記録と「穴」の追跡（BreachTracker）。

prevented_damage         : 元の標的が受けていたはずのダメージ（PA-19: 元の標的の防御判断で計算）
interceptor_damage_taken : 介入者が実際に受けたダメージ
breach_damage            : その介入で開いた経路を通ってきた近接攻撃で、後衛が受けたダメージ
net_value                : prevented - interceptor_taken - breach
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class InterventionRecord:
    id: int
    battle_round: int
    side: str
    interceptor: str
    original_target: str
    attacker: str
    action: str
    policy: str = ""
    routes_opened: list = field(default_factory=list)
    prevented_damage: float = 0.0
    interceptor_damage_taken: int = 0
    breach_damage: int = 0
    breach_attempts: int = 0        # 穴を通った侵入の回数（別の味方が介入して受けた場合も含む）
    breach_hits: int = 0
    breach_kos: int = 0
    interceptor_ko: bool = False
    closed: bool = False
    leader_down_at_time: bool = False

    @property
    def net_value(self) -> float:
        return self.prevented_damage - self.interceptor_damage_taken - self.breach_damage

    def row(self) -> dict:
        return {
            "id": self.id, "round": self.battle_round, "side": self.side, "policy": self.policy,
            "interceptor": self.interceptor, "original_target": self.original_target,
            "attacker": self.attacker, "action": self.action,
            "routes_opened": "|".join(self.routes_opened),
            "prevented_damage": round(self.prevented_damage, 1),
            "interceptor_damage_taken": self.interceptor_damage_taken,
            "breach_damage": self.breach_damage, "breach_attempts": self.breach_attempts, "breach_hits": self.breach_hits,
            "breach_kos": self.breach_kos, "interceptor_ko": int(self.interceptor_ko),
            "net_value": round(self.net_value, 1),
            "leader_down_at_time": int(self.leader_down_at_time),
        }


@dataclass
class InterventionWindow:
    attacker: object
    action: object
    target: object
    eligible: list
    reach: object


@dataclass
class InterventionChoice:
    interceptor_id: Optional[str] = None
    self_defense: Optional[bool] = None   # 本人対応: True=防御で受ける / False=何もしない / None=通常判断
    reasons: list = field(default_factory=list)
    mode: str = "move"                    # Ver0.8 実験: "move"=従来の介入 / "aegis"=持ち場から障壁（M5）


class BreachTracker:
    def __init__(self):
        self.records: list[InterventionRecord] = []
        self._open_by_route: dict[str, InterventionRecord] = {}

    def new(self, **kw) -> InterventionRecord:
        r = InterventionRecord(id=len(self.records) + 1, **kw)
        self.records.append(r)
        return r

    def open(self, rec: InterventionRecord, route_ids):
        rec.routes_opened = list(route_ids)
        for rid in route_ids:
            self._open_by_route[rid] = rec

    def record_for_route(self, route_id) -> Optional[InterventionRecord]:
        return self._open_by_route.get(route_id)

    def close_for_unit(self, unit_id) -> list[str]:
        closed = []
        for rid, rec in list(self._open_by_route.items()):
            if rec.interceptor == unit_id:
                del self._open_by_route[rid]
                closed.append(rid)
        for rec in self.records:
            if rec.interceptor == unit_id:
                rec.closed = True
        return closed
