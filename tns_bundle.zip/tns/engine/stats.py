"""1戦闘ぶんの集計値。"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class BattleStats:
    seed: int = 0
    ally_policy: str = ""
    enemy_intel: Optional[int] = None
    winner: str = ""
    rounds: int = 0
    c: Counter = field(default_factory=Counter)            # 汎用カウンタ
    targeted: Counter = field(default_factory=Counter)     # キャラ別の被標的回数
    ai_phase: dict = field(default_factory=lambda: {"pre": Counter(), "post": Counter()})
    leader_down_round: Optional[int] = None
    leader_down_ally_hp_ratio: Optional[float] = None
    leader_down_enemy_hp_ratio: Optional[float] = None
    final: dict = field(default_factory=dict)
    interventions: list = field(default_factory=list)
    plans: list = field(default_factory=list)              # 敵の連携計画
    # Ver0.3: 標的集中度など
    streaks: dict = field(default_factory=lambda: {"ally": [], "enemy": []})       # 攻撃者ごとの同一標的連続攻撃数
    team_streaks: dict = field(default_factory=lambda: {"ally": [], "enemy": []})  # 陣営全体での同一標的連続攻撃数
    ko_round: dict = field(default_factory=dict)           # unit_id -> 戦闘不能になった巡
    first_ko: dict = field(default_factory=dict)
    track: dict = field(default_factory=dict)              # Ver0.4: 個体ごとの崩壊トラッキング           # 被撃破側 -> {round, attacks}（相手陣営の攻撃回数）
