"""Ver0.12 検証用: イベント駆動の時間管理（PA-180〜。正式採用前の比較実装）。

rules.timeline:
  mode: event
  exponent: p          … A=1.0（比例型）, B=0.5（緩和型）, C=0.75（中間型）
  ref_speed: 10        … 基準速度。基準速度・HP満タンの行動間隔 = T（=1.0。旧来の1巡と同じ長さ）
  cast_quantum: 0.1    … 詠唱1単位 = 基準速度・HP満タンで 0.1T
  init_offset: w       … 分析専用（初回時刻に一様乱数[0,w)を足す）。既定0
  tie: random          … 分析専用: 同時刻・同速度の並べ方（random / ally_first / enemy_first）

時間の決まり（PA-180〜183）
- 実効速度 = (SPD / ref_speed)^p × HP速度倍率（既存の曲線をそのまま1回だけ掛ける）
- 行動間隔 = T / 実効速度
- 全員が時刻0から「1回目の待ち」を始める → 初回の行動時刻 = 自分の行動間隔
- 次行動可能時刻が最も早い者から行動。同時刻は (時刻, 速度の高い順, 乱数キー) で並べる。
  乱数キーは予約のたびに "order" ストリームから引く（同速の2人の順番は毎回ランダム）
- 行動後: 次行動可能時刻 = 行動した時刻 + 行動間隔（行動直後のHPで計算）
- 待機中・詠唱中にHPが変わったとき: 進んだ分はそのまま。残り時間 × (旧倍率 / 新倍率) に置き換える（PA-182）
- 詠唱（PA-183）: 詠唱N = 必要進行量 N×0.1T（基準速度・満タン）。所要時間 = N×0.1T / 実効速度。
  完成は自分の予約イベント。完成時刻に発動し、次の通常行動 = 完成時刻 + 行動間隔（払い戻しなし・二重加算なし）
- 戦闘不能→治療で復帰: 次の行動 = 治療した時刻 + 行動間隔
- 「巡」は時刻の区切りとしてだけ残す: 巡r = [(r−1)T, rT)。巡の始まりのEP回復・上限30巡（=時刻30T）は従来どおり
"""
from __future__ import annotations

import math

from ..model.enums import Side
from ..rules.turn_order import Slot
from .battle_engine import BattleEngine

INF = float("inf")


class TimelineEngine(BattleEngine):
    def __init__(self, cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
        super().__init__(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
        tl = cfg.rules.get("timeline", {}) or {}
        self.tl_p = float(tl.get("exponent", 0.75))
        self.tl_ref = float(tl.get("ref_speed", 10.0))
        self.T = 1.0
        self.cast_quantum = float(tl.get("cast_quantum", 0.1))
        self.cast_unit = "time"                  # 詠唱は時間で数える（AIの詠唱見積もりも時間の式を使う）
        self.hpm = {}                            # 現在の予約を計算したときのHP速度倍率
        self.tie = {}
        self.cur_time = 0.0
        self.time_log = []                       # 検証用: (unit, 行動した時刻)
        self.tie_rule = str(tl.get("tie", "random"))  # 分析用: random（既定）/ ally_first / enemy_first
        w = float(tl.get("init_offset", 0.0))
        r = self.rng["init_offset"]
        self.init_offset = {}
        for uid in sorted(self.state.units):
            u = self.state.units[uid]
            off = r.random() * w if w > 0 else 0.0
            self.init_offset[uid] = off
            self._set_next(u, self.interval(u) + off, now=0.0)
        self.lost_actions = {uid: 0.0 for uid in self.state.units}   # HP低下で失った行動機会（行動数換算）

    # ------------------------------------------------------------ 速度
    def base_rate(self, u) -> float:
        return (u.d.speed / self.tl_ref) ** self.tl_p

    def eff_rate(self, u) -> float:
        return self.base_rate(u) * self.speed_mult(u)

    def interval(self, u) -> float:
        return self.T / self.eff_rate(u)

    def _set_next(self, u, t, now):
        if t < now - 1e-12:
            raise AssertionError(f"行動可能時刻が過去へ戻る: {u.id} {t} < {now}")
        self.next_time[u.id] = t
        self.hpm[u.id] = self.speed_mult(u)
        self.tie[u.id] = self.rng["order"].random()

    def _key(self, u):
        side = 0
        if self.tie_rule == "ally_first":
            side = 0 if u.side is Side.ALLY else 1
        elif self.tie_rule == "enemy_first":
            side = 0 if u.side is Side.ENEMY else 1
        return (round(self.next_time[u.id], 9), -u.d.speed, side, self.tie[u.id])

    # ------------------------------------------------------------ 予約
    def _schedule_next(self, actor):
        t = self.cur_time
        if not actor.alive:
            self.next_time[actor.id] = INF
            return
        m = self.speed_mult(actor)
        b = self.base_rate(actor)
        cs = self.casting.get(actor.id)
        if cs is not None and cs["last_t"] is None:
            dur_ref = cs["base"] * self.cast_quantum           # 基準速度・満タンでの所要時間
            cs["remaining"] = dur_ref / b                      # 「HP倍率1で何T」かに直した残り
            cs["last_t"], cs["speed"] = t, m
            self._set_next(actor, t + cs["remaining"] / m, t)
            self.emit("schedule", unit=actor.id, time=round(t, 4), next=round(self.next_time[actor.id], 4),
                      mult=round(m, 4), hp_ratio=round(actor.hp / actor.d.hp_max, 4), casting=True)
            return
        full = self.T / b
        w = full / m
        self._set_next(actor, t + w, t)
        self.lost_actions[actor.id] += 1.0 / m - 1.0           # この待ちの間に、満タンならあと何行動できたか
        if m < 1.0:
            self.stats.c[f"v7_delay_{actor.side.value}"] += 1
        self.emit("schedule", unit=actor.id, time=round(t, 4), next=round(self.next_time[actor.id], 4),
                  mult=round(m, 4), hp_ratio=round(actor.hp / actor.d.hp_max, 4), wait=round(w, 4))

    def _rescale_all(self, skip=None):
        """HPが変わった者の残り時間を、新しい倍率で処理し直す（進んだ分はリセットしない, PA-182）。"""
        now = self.cur_time
        for u in self.state.units.values():
            if u is skip or not u.alive:
                continue
            nt = self.next_time[u.id]
            if not math.isfinite(nt):
                continue
            m_old, m_new = self.hpm[u.id], self.speed_mult(u)
            if abs(m_new - m_old) < 1e-12:
                continue
            rem = max(0.0, nt - now)
            new = now + rem * m_old / m_new
            self.next_time[u.id] = new
            self.hpm[u.id] = m_new
            cs = self.casting.get(u.id)
            if cs is not None and cs["last_t"] is not None:
                cs["remaining"] = (new - now) * m_new
                cs["last_t"], cs["speed"] = now, m_new
                if m_new < m_old:
                    cs["hits"] += 1
                self.emit("cast_delay", unit=u.id, old=round(nt, 4), new=round(new, 4), mult=round(m_new, 4), hp=u.hp)
            else:
                self.emit("wait_rescale", unit=u.id, old=round(nt, 4), new=round(new, 4), mult=round(m_new, 4))

    def _cast_rescale(self, u):
        pass                                      # _rescale_all がまとめて扱う

    def _requeue(self, u):
        pass

    def _cast_tick(self, actor):
        pass

    def _revive(self, u, by):
        from ..model.enums import Stance
        from ..stance.stance_machine import transition
        transition(u, Stance.READY, self.emit, "治療でHPが戦闘不能ラインを超えて戦闘復帰")
        now = self.cur_time
        self._set_next(u, now + self.interval(u), now)
        self.seen_revives[u.side] += 1
        self.stats.c[f"v10_revive_{u.side.value}"] += 1
        self.emit("revive", unit=u.id, by=by.id, hp=u.hp)

    # ------------------------------------------------------------ 予測（AI用。乱数を使わない）
    def _predicted(self, horizon_end):
        cur = getattr(self, "current_actor", None)
        now = self.cur_time
        out = []
        for u in self.state.units.values():
            if not u.alive:
                continue
            t = self.next_time[u.id]
            if not math.isfinite(t):
                continue
            if cur is not None and u is cur and t <= now + 1e-12:
                t = now + self.interval(u)          # いま手番中の者は、次の予定から
            w = self.interval(u)
            k = 0
            while t < horizon_end - 1e-9 and k < 64:
                out.append((round(t, 9), -u.d.speed, self._key(u)[2], self.tie[u.id] if k == 0 else 0.5, u.id))
                t += w
                k += 1
        out.sort()
        return [Slot(x[4], 0) for x in out]

    def actions_before_time(self, t_end, ref=None):
        """Ver0.13（AI用・乱数なし）: 時刻 t_end より前に予定されている行動（同じユニットが2回なら2回）。
        t_end ちょうどの予定は、ref より速度が高い者だけ「先」と数える（同時刻の並びの規則と同じ向き）。"""
        out = []
        horizon = t_end + 1e-9
        cur = getattr(self, "current_actor", None)
        now = self.cur_time
        for u in self.state.units.values():
            if not u.alive or (ref is not None and u is ref):
                continue
            t = self.next_time[u.id]
            if not math.isfinite(t):
                continue
            if cur is not None and u is cur and t <= now + 1e-12:
                t = now + self.interval(u)
            w = self.interval(u)
            k = 0
            while k < 64:
                if t < t_end - 1e-9 or (abs(t - t_end) <= 1e-9 and ref is not None and u.d.speed > ref.d.speed):
                    out.append(u.id)
                    t += w
                    k += 1
                else:
                    break
        return out

    def upcoming_slots(self, rounds_ahead: int = 1):
        end = (self.state.round + rounds_ahead) * self.T
        return self._predicted(end)

    def _predict_next_round(self):
        return self._predicted((self.state.round + 1) * self.T)

    # ------------------------------------------------------------ main loop
    def run(self):
        st = self.state
        self.emit("battle_start", routes=self.route_snapshot())
        st.round = 0
        while st.winner is None:
            alive = [u for u in st.units.values() if u.alive and math.isfinite(self.next_time[u.id])]
            if not alive:
                self._check_end()
                break
            actor = min(alive, key=self._key)
            t = self.next_time[actor.id]
            r = int(math.floor(t / self.T + 1e-9)) + 1
            stop = False
            while st.round < r:
                st.round += 1
                if st.round > self.max_rounds:
                    st.winner = "draw"
                    st.round -= 1
                    stop = True
                    break
                self.ep_regen.on_round_start(st.units.values())
                self.emit("round_start", queue=[s.unit_id for s in self._predicted(st.round * self.T)
                                                if True][:24], time=round(t, 4))
            if stop:
                break
            if t < self.cur_time - 1e-12:
                raise AssertionError("時刻が過去へ戻った")
            self.cur_time = t
            self.time_log.append((actor.id, t))
            self.current_actor = actor
            self._take_turn(actor)
            self._schedule_next(actor)
            self._rescale_all(skip=actor)
            self.recovery.on_action_tick(self)
            if self._check_end():
                break
        self.battle_time = self.cur_time
        self._finalize()
        self.emit("battle_end", winner=st.winner, rounds=st.round, time=round(self.cur_time, 4))
        return self.stats


def make_engine(cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
    if ((cfg.rules.get("v15", {}) or {}).get("enabled")):
        from .v15_engine import V15Engine          # Ver0.15 検証用（PA-200〜）
        return V15Engine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
    if ((cfg.rules.get("timeline", {}) or {}).get("mode")) == "event":
        return TimelineEngine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
    return BattleEngine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
