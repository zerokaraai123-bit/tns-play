"""用途別の乱数系列。片方の方針の判断が、別用途の乱数の流れを変えないようにする。
（方針比較を同じシードで公平に行うため）"""
import random
import zlib


class RngStreams:
    def __init__(self, seed: int):
        self.seed = seed
        self._streams = {}

    def __getitem__(self, name: str) -> random.Random:
        if name not in self._streams:
            self._streams[name] = random.Random(self.seed * 1_000_003 + zlib.crc32(name.encode()))
        return self._streams[name]
