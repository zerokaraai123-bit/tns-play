from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..formation.route import ApproachRoute
from ..model.combatant import Combatant, CombatantDef
from ..model.enums import Side


@dataclass
class BattleState:
    units: dict[str, Combatant]
    routes: dict[Side, list[ApproachRoute]]
    block_rule_sides: list[str]
    round: int = 0
    queue: list = field(default_factory=list)
    queue_pos: int = 0
    leader_down: dict = field(default_factory=dict)    # group -> bool
    winner: Optional[str] = None
    incap_targetable_by: tuple = ()    # 感度確認（Ver0.10.1）: この陣営からの攻撃は戦闘不能者も対象にできる。既定=空＝従来どおり

    def side_units(self, side: Side, alive_only=True):
        return [u for u in self.units.values() if u.side is side and (u.alive or not alive_only)]

    def target_candidates(self, side: Side, attacker_side: Side):
        """攻撃の対象候補。既定では戦闘に参加している者だけ。感度確認の設定時は戦闘不能者（HP>0）も含める。"""
        if attacker_side.value in self.incap_targetable_by:
            return [u for u in self.units.values() if u.side is side and u.hp > 0]
        return self.side_units(side)

    def all_routes(self):
        return self.routes[Side.ALLY] + self.routes[Side.ENEMY]

    def routes_blocked_by(self, unit_id: str):
        return [r for r in self.all_routes() if unit_id in r.blockers]

    @classmethod
    def build(cls, party_cfg: dict, enc_cfg: dict, rules: dict, enemy_intel: Optional[int] = None):
        units = {}
        for u in party_cfg["units"]:
            c = Combatant.spawn(CombatantDef.from_cfg(u, Side.ALLY))
            units[c.id] = c
        for u in enc_cfg["units"]:
            c = Combatant.spawn(CombatantDef.from_cfg(u, Side.ENEMY), intel_override=enemy_intel)
            units[c.id] = c
        routes = {
            Side.ALLY: [ApproachRoute.from_cfg(r, Side.ALLY) for r in party_cfg.get("routes", [])],
            Side.ENEMY: [ApproachRoute.from_cfg(r, Side.ENEMY) for r in enc_cfg.get("routes", [])],
        }
        sides = rules.get("battle", {}).get("block_rule_sides", ["ally", "enemy"])
        return cls(units=units, routes=routes, block_rule_sides=sides)
