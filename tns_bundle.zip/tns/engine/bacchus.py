"""Ver0.21 バッカス王（PA-290〜299）。正式仕様ではない。数値はすべて仮（PROTOTYPE_ASSUMPTION）。

王1人 対 イグニスの大軍。大軍は「横槍」と「兵の数」で表す（兵を1人ずつは作らない）。
- 王の手番: まず王踏（全員・弱い）→ 本命（振り下ろし・地割り・エーテル弾）。本命がアデル隊に向くのは 1/5、残りは兵へ。
- 王のHPが70%・40%・15%を切るたびに土五月雨（詠唱・全員に4発）。3回目のあとは本命が王の鉄槌（当たれば戦闘不能）。
- 王はHP1で止まり、それ以上ダメージを受けない。鉄槌を侍のため（死角斬り込み・一騎打ちのパリィ）で止めたときだけ倒れる。
- 横槍: 兵の数で決まる間隔で、王に攻撃が入る（弓・剣・魔導・槍）。角笛で兵が増える（無限）。
- 観測: 王の「アデル隊に向く次の手」を、何手先か選んで読める（兵への手番は飛ばして数える）。見えた手は必ずそのとおりに来る。
このファイルは V15Engine に混ぜて使う（V15Engine(BacchusMixin, TimelineEngine)）。
"""
from __future__ import annotations

import math
import random

from ..control.controller import Decision
from ..model.enums import Rank, Side


class BacchusMixin:
    # ------------------------------------------------------------ 準備
    def _bk_init(self, v, seed):
        bk = v.get("bacchus") or {}
        jobs = getattr(self, "jobs", {}) or {}
        self.bk_id = next((u.id for u in self.state.units.values()
                           if jobs.get(u.d.job, {}).get("bacchus")), None) if bk else None
        self.bk_on = self.bk_id is not None
        self.no_death = bool(v.get("no_death", False))          # PA-297 この戦闘では誰も死亡しない（味方はHP1で止まる）
        if not self.bk_on:
            return
        self.bk_cfg = bk
        self.rng_bk = random.Random(seed * 104_729 + 21)          # 既存の乱数系列を変えないよう別系列
        self.bk_plan = []                                         # これからの王の手番（本命の向き・技・相手の乱数）
        self.bk_obs_slot = None                                   # 観測された手番
        self.bk_rains_started = 0
        self.bk_rains_done = 0
        self.bk_fallen = False
        self._last_charge = None
        self._last_duel = None
        k = self.u(self.bk_id)
        k.incap_ratio = 0.0                                       # PA-294 王には戦闘不能がない
        ar = bk.get("army") or {}
        self.army = int(ar.get("start", 100))
        self.army_cap = int(ar.get("cap", 150))
        self.army_per_hit = float(ar.get("per_hit", 30))          # 兵○人につき毎T 1発
        self.army_horn_every = float(ar.get("horn_every", 2.0))
        self.army_horn_add = int(ar.get("horn_add", 15))
        self.army_hits = dict(ar.get("hits") or {})
        self.army_loss = {k2: tuple(x) for k2, x in (ar.get("loss") or {}).items()}
        self.army_next = self.army_per_hit / max(self.army, 1)
        self.horn_next = self.army_horn_every
        self.bk_rain_at = [float(x) for x in bk.get("rain_at", [0.70, 0.40, 0.15])]
        self.bk_stomp_until = float(bk.get("stomp_until", 0.15))
        self.bk_party_chance = float(bk.get("party_chance", 0.2))
        self.bk_weights = dict(bk.get("kind_weights") or {"bk_swing": 0.45, "bk_crack": 0.30, "bk_bolt": 0.25})
        self.bk_columns = dict(bk.get("columns") or {})          # 前衛 -> 真後ろの後衛（地割り）
        lh = bk.get("rain_last_hits")                             # PA-300 最後（3回目）の土五月雨は1人1〜2発
        self.bk_rain_last_hits = (int(lh[0]), int(lh[1])) if lh else None
        self.bk_hp1_all_party = bool(bk.get("hp1_all_party", False))   # PA-301 HP1になったら鉄槌は毎回アデル隊へ

    def _bk_floor(self, u) -> int:
        if self.no_death and u.side is Side.ALLY:
            return 1
        if self.bk_on and u.id == self.bk_id and not self.bk_fallen:
            return int(self.job_of(u).get("hp_floor", 1))
        return 0

    # ------------------------------------------------------------ 横槍（イグニス軍）
    def _bk_tick(self):
        """今の時刻までに起きた横槍と角笛を、起きた順に処理する。"""
        if not self.bk_on or self.bk_fallen:
            return
        now = self.cur_time
        changed = False
        for _ in range(500):
            nxt = min(self.army_next, self.horn_next)
            if nxt > now + 1e-9:
                break
            if self.horn_next <= self.army_next:
                old = self.army
                self.army = min(self.army_cap, self.army + self.army_horn_add)
                n = self.rng_bk.randint(1, 30)
                self.stats.c["v21_army_horn"] += 1
                self.emit("army_horn", add=self.army - old, army=self.army, squad=f"第{n}歩兵隊", at=round(self.horn_next, 3))
                if old <= 0 < self.army:
                    self.army_next = self.horn_next + self.army_per_hit / self.army
                self.horn_next += self.army_horn_every
            else:
                t = self.army_next
                if self.army > 0:
                    changed |= self._bk_army_hit(t)
                    self.army_next = t + self.army_per_hit / max(self.army, 1)
                else:
                    self.army_next = self.horn_next + 1e-6         # 兵がいない: 次の角笛まで横槍は止まる
        if changed:
            self._rescale_all()

    def _bk_army_hit(self, t) -> bool:
        k = self.u(self.bk_id)
        hits = self.army_hits
        kinds = list(hits.keys())
        ws = [float(hits[x].get("w", 1.0)) for x in kinds]
        r = self.rng_bk.random() * sum(ws)
        kind = kinds[-1]
        for x, w in zip(kinds, ws):
            if r < w:
                kind = x
                break
            r -= w
        h = hits[kind]
        raw = float(h.get("raw", 20)) * self.rng_bk.uniform(0.9, 1.1)
        squad = f"第{self.rng_bk.randint(1, 30)}{h.get('squad', '部隊')}"
        ls = self.layers.get(k.id, [])
        broke = False
        if h.get("pierce") or not ls:
            through = raw                                       # バックアタック: 鎧を無視して体へ／鎧がない
        else:
            ds = self.layer_dur.get(k.id, [])
            dur = ds.pop() if len(ds) == len(ls) else None
            gid = ls.pop()
            if k.id in self.shield_of.get(gid, []):
                self.shield_of[gid].remove(k.id)
            broke = True
            through = 0.0 if h.get("break_only") else max(0.0, raw - float(dur or 0.0))
        if not h.get("magic") and self.body_phys_on:
            through *= (self.body_phys_ref / max(1.0, float(k.d.body))) ** self.body_phys_p   # 物理は王の肉体で減る
        dmg = max(0, int(round(through)))
        floor = self._hp_floor(k)
        new = max(min(k.hp, floor), k.hp - dmg) if floor > 0 else max(0, k.hp - dmg)
        dmg = k.hp - new
        k.hp = new
        self.stats.c[f"v21_army_hit_{kind}"] += 1
        self.stats.c["v21_army_dmg"] += dmg
        self.emit("army_hit", kind=kind, name=h.get("name", kind), squad=squad, raw=round(raw, 1), broke=broke,
                  layers=len(ls), dmg=dmg, hp=k.hp, at=round(t, 3))
        return dmg > 0

    def _bk_army_loss(self, key, why):
        lo, hi = self.army_loss.get(key, (0, 0))
        n = min(self.army, self.rng_bk.randint(int(lo), int(hi))) if hi > 0 else 0
        old = self.army
        self.army -= n
        if old > 0 and self.army <= 0:
            self.army_next = self.horn_next + 1e-6
        squad = f"第{self.rng_bk.randint(1, 30)}{self.rng_bk.choice(['槍隊', '剣隊', '弓隊', '歩兵隊', '魔導隊'])}"
        self.stats.c["v21_army_lost"] += n
        self.emit("army_loss", n=n, army=self.army, why=why, squad=squad)

    # ------------------------------------------------------------ 王の手番を決める
    def _bk_new_slot(self):
        r = self.rng_bk
        return {"party": r.random() < self.bk_party_chance, "kr": r.random(), "tr": r.random(), "lock": None}

    def _bk_slot_at(self, i):
        while len(self.bk_plan) <= i:
            self.bk_plan.append(self._bk_new_slot())
        return self.bk_plan[i]

    def _bk_phase(self, k):
        r = k.hp / k.d.hp_max
        due = sum(1 for x in self.bk_rain_at if r < x - 1e-12)
        if self.bk_rains_started < due:
            return "rain"
        if self.bk_rains_done >= len(self.bk_rain_at) and r < self.bk_stomp_until:
            return "mallet"
        return "normal"

    def _bk_kind(self, slot, phase):
        if phase == "mallet":
            return "bk_mallet"
        ks = list(self.bk_weights.keys())
        tot = sum(float(self.bk_weights[x]) for x in ks)
        r = slot["kr"] * tot
        for x in ks:
            if r < float(self.bk_weights[x]):
                return x
            r -= float(self.bk_weights[x])
        return ks[-1]

    def _bk_targets(self, k, kind):
        a = self.actions[kind]
        alive = [t for t in self.state.side_units(Side.ALLY) if t.alive]
        if kind == "bk_bolt":
            rear = [t for t in alive if t.rank is Rank.REAR]
            return rear or alive
        if kind == "bk_crack":
            front = [t for t in alive if t.rank is Rank.FRONT]
            return front or alive
        vt = [t for t in self.valid_targets(k, a) if t.alive]
        return vt or alive

    def _bk_party(self, k, slot, phase=None):
        """この手番の本命がアデル隊に向くか。PA-301: HP1（最後の局面）なら必ず向く。"""
        if slot["party"]:
            return True
        phase = phase or self._bk_phase(k)
        return bool(self.bk_hp1_all_party and phase == "mallet" and k.hp <= self._hp_floor(k))

    def _bk_interpret(self, k, slot, phase):
        if slot.get("lock"):
            kind, tid = slot["lock"]
            t = self.state.units.get(tid) if tid else None
            if t is None or t.alive:
                return kind, tid
        kind = self._bk_kind(slot, phase)
        if not self._bk_party(k, slot, phase):
            return kind, None
        ts = self._bk_targets(k, kind)
        if not ts:
            return kind, None
        return kind, ts[min(len(ts) - 1, int(slot["tr"] * len(ts)))].id

    def _bk_decide(self, k):
        phase = self._bk_phase(k)
        r = k.hp / k.d.hp_max
        if phase == "rain":
            self.bk_rains_started += 1
            alive = [t for t in self.state.side_units(Side.ALLY) if t.alive]
            dec = Decision("bk_rain", alive[0].id if alive else None,
                           reasons=[f"HPが{int(self.bk_rain_at[self.bk_rains_started - 1] * 100)}%を切った → 土五月雨（{self.bk_rains_started}回目）"],
                           tags={"bk": "rain"})
            self.stats.c["v21_rain"] += 1
            self.emit("bk_rain_due", unit=k.id, n=self.bk_rains_started)
            if self.precommit and k.alive:
                self._choose_shield(k, dec)
            return dec
        slot = self.bk_plan.pop(0) if self.bk_plan else self._bk_new_slot()
        kind, tid = self._bk_interpret(k, slot, phase)
        if self.bk_obs_slot is slot:
            self.bk_obs_slot = None
            self.fixed_info.pop(k.id, None)
            self.emit("fixed_execute", unit=k.id, action=kind, target=tid)
        elif self.bk_obs_slot is not None and self.bk_obs_slot in self.bk_plan:
            fx = self.fixed_info.get(k.id)
            if fx is not None:
                fx.tags["obs_left"] = self.bk_plan.index(self.bk_obs_slot) + 1
        stomp = r >= self.bk_stomp_until and kind in ("bk_swing", "bk_crack")   # 踏み込む技の前に王踏（魔法・鉄槌はなし）
        if tid is None:
            dec = Decision("bk_army", k.id, reasons=["本命は周りのイグニス兵へ"],
                           tags={"bk": "army", "kind": kind, "stomp": stomp})
        else:
            dec = Decision(kind, tid, reasons=["本命はアデル隊へ（1/5）"], tags={"bk": "party", "stomp": stomp})
        self.stats.c[f"v21_turn_{'party' if tid else 'army'}"] += 1
        if self.precommit and k.alive:
            self._choose_shield(k, dec)
        return dec

    # ------------------------------------------------------------ 観測（PA-296）
    def _bk_observe(self, actor, k, depth):
        n = self.observe_depth_for(actor, k, depth)
        phase = self._bk_phase(k)
        cnt, i = 0, 0
        while True:
            s = self._bk_slot_at(i)
            if self._bk_party(k, s, phase):
                cnt += 1
                if cnt >= n:
                    break
            i += 1
        kind, tid = self._bk_interpret(k, s, "mallet" if phase == "mallet" else "normal")
        s["lock"] = (kind, tid)                                   # 見えた手は必ずそのとおりに来る
        self.bk_obs_slot = s
        self.fixed_info[k.id] = Decision(kind, tid, reasons=["観測で見えた王の手"],
                                         tags={"obs_left": i + 1, "obs_depth": n, "bk_obs": True})
        self.stats.c[f"v21_observe_depth_{n}"] += 1
        self.emit("observe", unit=actor.id, target=k.id, action=kind, intent_target=tid, casting=False, depth=n,
                  shield="-", bk_turns=i + 1)

    # ------------------------------------------------------------ 王の行動
    def _bk_pre(self, k, dec) -> bool:
        """True ならこの行動はここで終わり（ふつうの処理に渡さない）。"""
        tags = dec.tags if dec.tags is not None else {}
        cc = tags.get("cast_complete")
        aid = dec.action_id
        if self.bk_fallen:
            return True
        if tags.get("stomp") and not cc and not tags.get("stomp_done"):
            tags["stomp_done"] = True
            self._bk_stomp(k)
            if self._check_end():
                return True
        if aid == "bk_army":
            self._bk_army_main(k, tags.get("kind"))
            return True
        if aid in ("bk_rain", "bk_crack", "bk_mallet") and not cc:
            return False                                          # 詠唱（振りかぶり）を始める: ふつうの処理
        if aid == "bk_rain":
            self._bk_rain(k, dec)
            return True
        if aid == "bk_crack":
            self._bk_crack(k, dec)
            return True
        if aid == "bk_mallet":
            self._bk_mallet(k, dec)
            return True
        return False

    def _bk_stomp(self, k):
        a = self.actions["bk_stomp"]
        self.stats.c["v21_stomp"] += 1
        self.emit("area_attack", unit=k.id, action=a.id, reasons=["王踏（踏み込み）"])
        for t in list(self.state.side_units(Side.ALLY)):
            if t.alive and k.alive:
                self._resolve_attack(k, a, t, Decision(a.id, t.id, reasons=["王踏"]), no_iv=True)
                if self._check_end():
                    return
        self._bk_army_loss("bk_stomp", "王踏")

    def _bk_army_main(self, k, kind):
        a = self.actions.get(kind)
        self.stats.c[f"v21_army_main_{kind}"] += 1
        self.emit("bk_army", unit=k.id, action=kind, name=a.name if a else kind)
        self._bk_army_loss(kind, a.name if a else kind)

    def _bk_rain(self, k, dec):
        a = self.actions["bk_rain"]
        self.emit("area_attack", unit=k.id, action=a.id, reasons=dec.reasons)
        last = self.bk_rains_done + 1 >= len(self.bk_rain_at)
        for t in list(self.state.side_units(Side.ALLY)):
            n = max(1, a.hits)
            if last and self.bk_rain_last_hits:
                n = self.rng_bk.randint(*self.bk_rain_last_hits)   # PA-300 最後の土五月雨は1人ごとに1発か2発（平均1.5発）
                self.emit("bk_rain_hits", unit=k.id, target=t.id, n=n)
            for i in range(n):
                if not t.alive or self._check_end():
                    break
                if i > 0:
                    self.emit("multi_hit", unit=k.id, target=t.id, action=a.id, n=i + 1, of=n)
                self._resolve_attack(k, a, t, Decision(a.id, t.id, reasons=["土五月雨"]), no_iv=True)
        self._bk_army_loss("bk_rain", a.name)
        self.bk_rains_done += 1
        self.emit("bk_rain_done", unit=k.id, n=self.bk_rains_done, last=self.bk_rains_done >= len(self.bk_rain_at))

    def _bk_crack(self, k, dec):
        a = self.actions["bk_crack"]
        t = self.state.units.get(dec.target_id) if dec.target_id else None
        if t is None or not t.alive:
            ts = self._bk_targets(k, "bk_crack")
            t = ts[0] if ts else None
        if t is None:
            return
        line = [t]
        rid = self.bk_columns.get(t.id)
        r = self.state.units.get(rid) if rid else None
        if r is not None and r.alive:
            line.append(r)
        self.emit("bk_crack", unit=k.id, targets=[x.id for x in line])
        for x in line:
            if x.alive and not self._check_end():
                self._resolve_attack(k, a, x, Decision(a.id, x.id, reasons=["地割り"]), no_iv=True)

    def _bk_mallet(self, k, dec):
        self._last_charge = None
        self._last_duel = None
        done = self._charge_hooks(k, dec)
        if done:
            lc = self._last_charge
            if lc and lc[0] == "strike":
                self._bk_fall(lc[1], "strike")
                return
            if lc and lc[0] == "duel":
                kind, win = self._last_duel or (None, None)
                if kind == "parry" and win == lc[1]:
                    self._bk_fall(lc[1], "parry")
                elif kind == "break" and win == k.id:
                    self._bk_mallet_land(k, self.u(lc[1]))      # パリィの構えを崩された → 鉄槌がそのまま入る
            return
        t = self.state.units.get(dec.target_id) if dec.target_id else None
        if t is None or not t.alive:
            ts = self._bk_targets(k, "bk_mallet")
            t = ts[0] if ts else None
        if t is not None:
            self._bk_mallet_land(k, t)

    def _bk_mallet_land(self, k, t):
        before = self.route_snapshot()
        cap = max(1, int(math.floor(t.incap_ratio * t.d.hp_max))) if t.incap_ratio > 0 else 1
        hp0 = t.hp
        t.hp = min(t.hp, cap)
        self.stats.c["v21_mallet_hit"] += 1
        self.emit("mallet_hit", unit=k.id, target=t.id, hp=t.hp, dmg=hp0 - t.hp)
        if not t.alive:
            self._on_ko(t, before)

    def _bk_fall(self, by, how):
        k = self.u(self.bk_id)
        before = self.route_snapshot()
        self.bk_fallen = True
        k.hp = 0
        self.casting.pop(k.id, None)
        self.stats.c[f"v21_fall_{how}"] += 1
        self.emit("bacchus_fall", unit=k.id, by=by, how=how)
        self._on_ko(k, before)

    def _bk_clash(self, u):
        """鉄槌の一騎打ちで王が出す手: 攻撃か崩しを半々（振り下ろしている最中なのでパリィはしない）。"""
        return "attack" if self.rng_bk.random() < 0.5 else "break"

    def _bk_speed(self, u):
        """王の速さ: メンタリティ100なので傷ついても落ちない。HP15%を切ったら徐々に落ちる（PA-295）。"""
        curve = sorted((float(a), float(b)) for a, b in self.job_of(u).get("low_hp_speed", []))
        if not curve:
            return 1.0
        r = max(0.0, u.hp / u.d.hp_max)
        if r >= curve[-1][0]:
            return curve[-1][1]
        if r <= curve[0][0]:
            return curve[0][1]
        for (x0, y0), (x1, y1) in zip(curve, curve[1:]):
            if r <= x1:
                return y0 + (y1 - y0) * (r - x0) / (x1 - x0)
        return 1.0
