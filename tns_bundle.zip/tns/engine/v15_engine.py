"""Ver0.15 検証用エンジン（PA-200〜209）。正式仕様ではない。

TimelineEngine（Ver0.12 のイベント方式・方式B）を継承し、Ver0.15 の新しい行動だけを足す。
既存の処理（ダメージ・エーテル防御・介入・持ち場離脱・前線突破・戦闘不能・速度・詠唱）はそのまま使う。

新しい行動（rules.actions の special）:
  dive / flank : 薄い経路（塞ぎ手が thin_route_max 人以下。死守中は hold_blocker_weight 人分）を通って相手のREARを近接攻撃。
                 行動後は DIVING（持ち場を離れる）。次の自分の手番の始めに戻る。防御は可・介入は不可。
  pin          : 相手FRONTを近接攻撃。相手は自分の次の手番が終わるまで、介入・dive/flank/pin/push が使えない。
  push         : 相手FRONTを近接攻撃。相手の次の行動を push_delay T 遅らせる。
  hold         : 自分の次の手番の始めまで、受ける威力×hold_raw_mult・介入不可・塞ぎ手2人分。
  howl         : 群れに標的を指名（リーダーの次の手番の始めまで）。公開情報。
  observe      : 敵1体の「次の行動の意思」をその瞬間に敵AIに決めさせ、固定する（可能性の観測固定）。
                 次の手番で成立すればそのとおりに行動。成立しなければ release（選び直し）/ lose（待機）。

Ver0.16 の追加（PA-230〜236。すべて設定で有効化。無効なら Ver0.15 と同じ動作）:
  device       : エーテル防御装置は「自分の手番から次の自分の手番まで」に1回だけ（自分を守る・介入、どちらでも）。
                 使ったら次の自分の手番まで生身（自衛・介入とも不可）。
  介入（鎧）   : 介入者は持ち場を離れ、装置の鎧を守られる側にまとわせる。鎧は上限（armor_cap）まで防ぐ。
                 上限を超えた分（余波）は、守られた側の肉体へ直接入る（守られた側のエーテル防御は効かない）。
                 範囲攻撃は介入できない（従来どおり）。
  観測の深さ   : 固定する意思は「何手先か」がランダム（observe_depth）。公開情報。固定された敵は、その手番まで
                 自分で未来を壊す行動を選べない（EP・使用回数の確保、詠唱の開始禁止）。成立しなければ手番を失う。
  前借り       : 指定ユニットは、EPが足りない分をHPで払って行動できる（戦闘不能にならない範囲）。
  集中         : EPを回復する。その手番から次の自分の手番まで、装置は使えない。

Ver0.17 の追加（PA-240〜245。device.mode: precommit のときだけ）:
  先に張る鎧   : 装置は攻撃を受けてから使うのではなく、自分の手番に「自分／仲間1人／張らない」を選んで先に張る。
                 鎧は次の自分の手番まで残り、最初の1発（大小・単体/全体を問わず）で1枚消える。重ねがけ可。
                 外側（あとから張った方）から割れる。全体攻撃は1人につき1枚。敵からは見えない。
                 割り込む介入はない（持ち場も離れない）。仲間に張ると、次の自分の手番が ally_shield_delay T 遅れる。

Ver0.19 の追加（PA-270〜273。設定があるときだけ。なければ Ver0.18 と同じ）:
  鎧の耐久30   : 自分に張った鎧も armor_cap_self まで（超えた分は貫通）。
  構え         : EPを先払いして「構えの鎧」（耐久は体の状態で変わる）。割れずに耐久から引き、次の自分の手番まで残る。
  観測の深さ   : observe_depth_mode: choose なら、何手先かを観測する側が選ぶ（技はそのあと敵AIが決める）。
  ゴーレム     : ジョブ golem。毎手番 自分に3枚（EPなし）・詠唱を始める手番は張れない・ヘイトなし。
"""
from __future__ import annotations

import math
import random

from ..control.controller import Decision
from ..formation.reach import ReachResult, can_use_melee
from ..formation.route import holding_blockers, route_blocked
from ..model.enums import ActionKind, Rank, Side, Stance
from ..stance.stance_machine import transition
from .timeline_engine import TimelineEngine
from .bacchus import BacchusMixin                                    # Ver0.21 バッカス王（PA-290〜）

BREACH = ("dive", "flank")
PIN_BLOCKED = ("dive", "flank", "pin", "push")


CLASH_STANCES = ("attack", "parry", "break")
CLASH_NAMES = {"attack": "攻撃", "parry": "パリィ", "break": "崩し"}


class V15Engine(BacchusMixin, TimelineEngine):
    def __init__(self, cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
        super().__init__(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
        v = cfg.rules.get("v15", {}) or {}
        self.hold_mult = float(v.get("hold_raw_mult", 0.6))
        self.hold_w = int(v.get("hold_blocker_weight", 2))
        self.thin_max = int(v.get("thin_route_max", 1))
        self.push_delay = float(v.get("push_delay", 0.25))
        self.observe_fail = str(v.get("observe_fail", "release"))
        self.howl_power = float(v.get("howl_power", 0.2))
        self.rear_phys_mult = float(v.get("rear_physical_mult", 1.0))               # PA-215
        self.rear_phys_sides = set(v.get("rear_physical_sides", ["ally", "enemy"]))
        self._cur_action = None
        bp = v.get("body_physical") or {}
        self.body_phys_on = bool(bp.get("enabled", False))                  # PA-216
        self.body_phys_ref = float(bp.get("ref", 10.0))
        self.body_phys_p = float(bp.get("exponent", 0.5))
        self.rear_melee_displaces = bool(v.get("rear_melee_displaces", True))   # PA-201b
        self.pinned = {}          # uid -> 牽制した者のID（自分の次の手番が終わるまで）
        self._pin_clear = set()
        self.holding = set()      # 死守中
        self.howl = {}            # group -> 指名された標的ID
        self.howl_by = {}         # group -> 遠吠えしたリーダーID
        self.fixed = {}           # 観測で固定された意思: uid -> Decision
        self.fixed_info = {}      # 公開情報としての固定（詠唱中の詠唱者を観測した場合も含む）
        self._last_final = None
        # ---- Ver0.16（PA-230〜236）
        dv = v.get("device") or {}
        self.device_on = bool(dv.get("enabled", False))
        self.armor_cap = dv.get("armor_cap", None)          # 数値 or {unit_id: 数値}。None=上限なし
        if self.device_on:
            self.aegis_on = True                             # 介入は「鎧を飛ばす」形だけ
            self.aegis_mult = float(dv.get("armor_cost_mult", 1.0))
        od = v.get("observe_depth", [1, 1])
        self.obs_depth = (int(od[0]), int(od[1])) if isinstance(od, (list, tuple)) else (int(od), int(od))
        self.rng_obs = random.Random(seed * 7_919 + 16)     # 既存の乱数系列を変えないよう別系列
        self.reserve = {}         # 固定された意思のために確保するもの: uid -> {"ep": n, "uses": aid or None}
        self._exec_fixed = False
        self.precommit = self.device_on and dv.get("mode") == "precommit"     # Ver0.17（PA-240）
        self.ally_shield_delay = float(dv.get("ally_shield_delay", 0.0))
        self.shield_range = str(dv.get("shield_range", "any"))                # PA-248
        self.shield_min_ep = int(dv.get("min_ep", 0))                        # PA-266 鎧を張るのに残っていなければならないEP
        self.prebattle = bool(dv.get("prebattle", True))                     # PA-249/250 False=奇襲（準備なし）
        self.ambush_first_strike = bool(v.get("ambush_first_strike", False))  # PA-254 奇襲: 敵が必ず先に動く
        self.layers = {}          # 鎧を着ている者 -> [張った者のID,...]（末尾が外側）
        self.shield_of = {}       # 張った者 -> [張った相手, ...]（1枚ごと。重戦士は2枚まで）
        self.jobs = v.get("jobs") or {}                                       # PA-258 ジョブ
        self._delay_count = {}
        self._delay_next = set()
        self._layer_self = False
        # ---- PA-259 知能の個体値（＋難易度のずらし＋リーダーがいる間は群れの仲間が1段階上）
        self.base_intel = {}
        if v.get("intel_model") == "base":
            off = (int(enemy_intel) - 1) if enemy_intel is not None else 0
            for u in self.state.side_units(Side.ENEMY, alive_only=False):
                b = int(u.d.intelligence if u.d.intelligence is not None else 1)
                self.base_intel[u.id] = max(0, min(3, b + off))
            leaders = {u.d.group for u in self.state.side_units(Side.ENEMY) if u.d.is_leader and u.d.group}
            for u in self.state.side_units(Side.ENEMY, alive_only=False):
                boost = 1 if (u.d.group in leaders and not u.d.is_leader) else 0
                u.intel_effective = max(0, min(3, self.base_intel[u.id] + boost))
        # ---- PA-260 ヘイト（本能）と判断（理性）
        hc = v.get("hate") or {}
        self.hate_on = bool(hc.get("enabled", False))
        self.hate_judgment = float(hc.get("judgment", 50))
        self.hate_bonus = {int(k): float(x) for k, x in (hc.get("bonus") or {0: 0, 1: 10, 2: 25, 3: 40}).items()}
        self.hate_instinct = {int(k): float(x) for k, x in (hc.get("instinct") or {0: 1.0, 1: 0.5, 2: 0.3, 3: 0.2}).items()}
        self.hate_body_hit = float(hc.get("body_hit", 15))
        self.hate_actions = dict(hc.get("actions") or {})
        self.hate_decay = float(hc.get("decay", 0.5))
        self.hate = {}            # 敵ID -> {味方ID: ヘイト}
        self.hate_cap = float(hc["cap"]) if hc.get("cap") is not None else None     # PA-265 上限
        # ---- PA-262〜264 同時行動（一騎打ち・死角攻撃）
        cc = v.get("clash") or {}
        self.clash_on = bool(cc.get("enabled", False))
        self.clash_window = float(cc.get("window", 0.05))
        self.clash_stagger = float(cc.get("stagger", 0.5))
        self.blind_mult = float(cc.get("blind_mult", 1.5))
        self.clash_mix = {int(k): list(x) for k, x in (cc.get("enemy_mix") or {}).items()}
        self.clash_random = bool(cc.get("random_simul", True))   # PA-262 偶然の同時行動（Ver0.18改で無効）
        ch = v.get("charge") or {}
        self.charge_on = bool(ch.get("enabled", False))           # PA-267 侍の「ため斬り」
        self.charge_per_T = float(ch.get("per_T", 1.0))
        self.charge_max = float(ch.get("max_mult", 2.0))
        self.charge_strip = bool(ch.get("strip_armor", False))     # PA-302 ために入ったら着ている鎧は全部消える
        self.charge_hold = bool(ch.get("can_hold", False))         # PA-303 ため中に手番が来たら「ためを続ける」も選べる
        self._charge_t0 = {}
        self.charge_avoid = {int(k): float(x) for k, x in (ch.get("enemy_avoid") or {}).items()}
        self.charge_break = {int(k): float(x) for k, x in (ch.get("enemy_break") or {}).items()}
        self.charging = {}        # ため中: uid -> ためを始めた時刻
        self.charge_ready = {}    # 次の手番でためを放つ: uid -> 倍率
        self._clash_mult = 1.0
        self.duel_raw = {}
        self._stagger = set()
        self.simul_with = {}      # 同時行動の相手（表示用）: uid -> 相手ID
        self._fs_until = None     # 奇襲で敵が先に動き終わる時刻（その間は同時行動にしない）
        sb = v.get("skill_ep_body") or {}                                  # PA-257 技のEPを実効肉体強度で補正
        self.skill_body_actions = set(sb.get("actions", []) or [])
        self.skill_body_p = float(sb.get("exponent", 1.0))
        ref = sb.get("ref_unit")
        self.skill_body_ref = (self.defense.required_ep(self.u(ref), 1.0)
                               if ref and ref in self.state.units else None)
        bl = v.get("blood") or {}
        self.blood_on = bool(bl.get("enabled", False))
        self.blood_units = set(bl.get("units", []) or [])
        self.blood_rate = float(bl.get("hp_per_ep", 1.0))
        # ---- Ver0.19（PA-270〜273）
        cs = dv.get("armor_cap_self", None)
        self.armor_cap_self = None if cs is None else float(cs)          # PA-270 自分に張った鎧の耐久（None=上限なし）
        kc = v.get("kamae") or {}
        self.kamae_on = bool(kc.get("enabled", False))                    # PA-271 構え
        self.kamae_base = float(kc.get("base", 100))
        kref = kc.get("ref_unit")
        self.kamae_ref = (self.defense.required_ep(self.u(kref), 1.0)
                          if kref and kref in self.state.units else None)
        self.kamae_left = {}      # 構えの鎧: uid -> 残りの耐久
        self._kamae_hit = None
        pp = dv.get("prepay") or {}
        self.prepay_on = bool(pp.get("enabled", False))                    # PA-281 先払いの鎧
        self.prepay_cost = int(pp.get("cost", 10))
        self.prepay_base = float(pp.get("base", 30))
        pref = pp.get("ref_unit")
        self.prepay_ref = (self.defense.required_ep(self.u(pref), 1.0)
                           if pref and pref in self.state.units else None)
        self.layer_dur = {}       # 鎧を着ている者 -> [耐久 or None, ...]（layers と同じ並び）
        self._cur_layer_dur = None
        self.obs_mode = str(v.get("observe_depth_mode", "random"))        # PA-272 random / choose
        sm = v.get("summon") or {}
        self.summon_on = bool(sm.get("enabled", False)) and any(           # PA-284 狼リーダーの「仲間を呼ぶ」
            "summon" in u.d.action_ids for u in self.state.units.values())  # 呼べる者がいない戦闘（ゴーレム戦）では何もしない
        self.summon_delay = float(sm.get("delay", 1.0))
        self.summon_trigger = int(sm.get("trigger_empty", 2))
        self.summon_template = dict(sm.get("template") or {})
        self.summon_names = list(sm.get("names") or [])
        self._forced_done = set() # PA-286 強制の技を使い終えた者
        self.arriving = {}        # 駆けつけ中: uid -> 入る前列の場所（番号）
        self.removed = set()      # 戦場から退場した者（呼ばれた狼に場所をゆずった戦闘不能の狼）
        self._summon_n = 0
        self.front_slots = [u.id for u in self.state.side_units(Side.ENEMY, alive_only=False)
                            if u.rank is Rank.FRONT] if self.summon_on else []
        oa = v.get("observe_depth_ai") or {}
        self.obs_ai = {"caster": int(oa.get("caster", 3)), "other": int(oa.get("other", 1))}
        self._bk_init(v, seed)                                             # Ver0.21 バッカス王（ない戦闘では何もしない）

    # ------------------------------------------------------------ Ver0.21 メンタリティ・HPの下限（PA-290/294/297）
    def _hp_floor(self, u) -> int:
        if getattr(self, "bk_on", False) or getattr(self, "no_death", False):
            return self._bk_floor(u)
        return 0

    def speed_mult(self, u) -> float:
        if getattr(self, "bk_on", False) and u.id == self.bk_id and self.speed_on:
            return self._bk_speed(u)                       # PA-295 王: HP15%までは落ちない・そこから徐々に
        m = getattr(u.d, "mentality", 0) or 0
        if m <= 0 or not self.speed_on or u.side.value not in self.hp_body_sides:
            return super().speed_mult(u)
        r = max(0.0, u.hp / u.d.hp_max)
        r = 1.0 - (1.0 - r) * (1.0 - min(100, m) / 100.0)  # PA-290 見かけのHP割合
        c = self.speed_curve
        if r <= c[0][0]:
            return c[0][1]
        for (x0, y0), (x1, y1) in zip(c, c[1:]):
            if r <= x1:
                return y0 + (y1 - y0) * (r - x0) / (x1 - x0)
        return c[-1][1]

    # ------------------------------------------------------------ 経路の薄さ
    def route_weight(self, r) -> int:
        return sum(self.hold_w if b in self.holding else 1 for b in holding_blockers(r, self.state.units))

    def breach_reach(self, attacker, target) -> ReachResult:
        if not can_use_melee(attacker):
            return ReachResult(False, reason="後衛は近接攻撃不可")
        if target.rank is not Rank.REAR:
            return ReachResult(False, reason="突撃・回り込みは後衛だけを狙う")
        routes = [r for r in self.state.routes[target.side] if target.id in r.protects]
        if not routes:
            return ReachResult(True, reason="この後衛を守る経路なし")
        best = min(routes, key=self.route_weight)
        w = self.route_weight(best)
        if w <= self.thin_max:
            hb = holding_blockers(best, self.state.units)
            return ReachResult(True, via_route=best.id, reason=f"経路{best.id}が薄い（塞ぎ手{w}）",
                               blocked_by=hb)
        return ReachResult(False, reason=f"経路{best.id}の塞ぎ手が厚い（{w}）")

    def reach(self, attacker, target, action):
        if action.special in BREACH:
            return self.breach_reach(attacker, target)
        if action.basic and target.rank is Rank.REAR and self.jobs and self.guard_active(target.side):
            return ReachResult(False, reason="重戦士が立っていて、後衛には通常攻撃が届かない (PA-258)")
        return super().reach(attacker, target, action)

    # ------------------------------------------------------------ 行動の候補
    def available_actions(self, u):
        out = []
        for a in super().available_actions(u):
            sp = a.special
            if sp in PIN_BLOCKED and (u.id in self.pinned or u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp and sp != "hold" and not self.valid_targets(u, a):
                continue
            if sp == "hold" and (u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp == "focus" and (u.ep >= u.d.ep_max or (self.device_on and not self.device_ready(u))):
                continue
            if sp == "summon":
                continue                                   # PA-284 仲間を呼ぶは、条件がそろったときに強制で使う（自分では選ばない）
            if sp == "kamae" and (not self.kamae_on or u.ep < self.ep_cost(u, a) or u.id in self.casting):
                continue                                   # PA-271 構え: EPは先払い（前借りは使えない）
            if a.id in self.skill_body_actions and self.ep_cost(u, a) > self.spendable_ep(u, a):
                continue                                   # PA-257 補正後のEPが足りない
            rs = self.reserve.get(u.id)
            if rs and not self._exec_fixed:
                if a.id in self.cast_time:
                    continue                    # 固定された未来の手番より前に、詠唱を始めない（PA-233）
                if rs["uses"] == a.id and u.uses.get(a.id, 0) <= 1:
                    continue
            out.append(a)
        return out

    def valid_targets(self, u, a):
        sp = a.special
        st = self.state
        if sp in BREACH:
            return [t for t in st.target_candidates(u.side.other, u.side)
                    if t.rank is Rank.REAR and self.breach_reach(u, t).ok]
        if sp in ("pin", "push"):
            return [t for t in st.side_units(u.side.other) if t.rank is Rank.FRONT and can_use_melee(u)]
        if sp == "hold":
            return [u]
        if sp == "howl":
            return st.side_units(u.side.other)
        if sp == "observe":
            return st.side_units(u.side.other)
        if sp in ("focus", "kamae", "summon"):
            return [u]
        if sp == "charge":
            if self.charge_hold and u.id in self.charge_ready:
                return [u]                                 # PA-303 ためを続ける
            return [] if u.id in self.charge_ready or u.id in self.charging else [u]
        if a.kind is ActionKind.ATTACK and a.area == "front":
            return [t for t in super().valid_targets(u, a) if t.rank is Rank.FRONT]      # PA-256 相手の前列全員
        out = super().valid_targets(u, a)
        if a.kind is ActionKind.ATTACK and getattr(a, "front_only", False):
            out = [t for t in out if t.rank is Rank.FRONT]     # PA-280 前衛だけが射程（ダブルアタック）
        if a.kind is ActionKind.ATTACK and a.basic and out and self.guard_active(u.side.other):
            out = [t for t in out if t.rank is not Rank.REAR]   # PA-258 重戦士が立っている間、後衛は通常攻撃で狙えない
        return out

    # ------------------------------------------------------------ フック
    def _iv_ok(self, c) -> bool:
        if getattr(self, "precommit", False):
            return False                              # Ver0.17: 割り込む介入はない
        return c.id not in self.pinned and c.id not in self.holding

    # ------------------------------------------------------------ Ver0.16 エーテル防御装置（PA-230/231）
    def defense_allowed(self, c) -> bool:
        if getattr(self, "precommit", False):
            return False                              # Ver0.17: 受ける瞬間の防御はない（先に張った鎧だけ）
        return super().defense_allowed(c)

    def device_ready(self, c) -> bool:
        """装置をいま使えるか（自分の手番から次の自分の手番までに1回）。"""
        return c.id not in self.aegis_used

    def cap_of(self, c):
        cap = self.armor_cap
        if isinstance(cap, dict):
            cap = cap.get(c.id, cap.get("default"))
        return None if cap is None else float(cap)

    def _on_self_defense(self, u):
        if self.device_on:
            self.aegis_used.add(u.id)
            self.stats.c[f"v16_device_self_{u.side.value}"] += 1

    def _adjust_iv_choice(self, choice):
        if self.device_on and choice is not None and choice.interceptor_id:
            choice.mode = "aegis"
        return choice

    def _on_aegis(self, aegis, target, attacker, action, choice):
        """介入者は持ち場を離れる（PA-231）。鎧は守られる側がまとう。"""
        if not self.device_on:
            return
        st = self.state
        side = target.side.value
        before = self.route_snapshot()
        transition(aegis, Stance.INTERVENING, self.emit, f"{target.name}へ装置の鎧を飛ばした（持ち場を離れる）")
        self.recovery.on_intervened(aegis, self)
        transition(aegis, Stance.GUARDING, self.emit, "鎧を飛ばした（次の自分の手番まで持ち場の外・生身）")
        opened = [r.id for r in st.routes_blocked_by(aegis.id)
                  if before[r.id] == "BLOCK" and not route_blocked(r, st.units)]
        self.stats.c[f"intervention_{side}"] += 1
        self.stats.c[f"front_open_{side}"] += len(opened)
        self.stats.c[f"front_open_by_intervention_{side}"] += len(opened)
        for rid in opened:
            self.emit("route_change", route=rid, status="OPEN", cause=f"{aegis.name}が持ち場を離れた")

    def _aegis_block(self, c, raw):
        """介入の鎧（PA-231）: 上限まで、介入者のEPで防ぐ。上限を超えた分は余波として通る。"""
        if not self.device_on:
            return super()._aegis_block(c, raw)
        if self._kamae_hit is not None:
            return self._kamae_block(raw)                         # PA-271 構えの鎧
        if self.prepay_on and self._cur_layer_dur is not None:
            return self._prepaid_block(c, raw)                    # PA-281 先払いの鎧
        cap = self.armor_cap_self if self._layer_self else self.cap_of(c)   # 自分の鎧: Ver0.18まではなし・Ver0.19は30（PA-270）
        self._layer_self = False
        part = raw if cap is None else min(raw, cap)
        over = raw - part
        if self.job_of(c).get("shield_free"):
            leak, spent, mode = 0.0, 0, "aegis_free"             # shield_free: true のときだけ（受けてもEPを使わない）。Ver0.19 の既定は false
        else:
            leak, spent, mode = super()._aegis_block(c, part)
        side = c.side.value
        if over > 0:
            self.stats.c[f"v16_armor_pierce_{side}"] += 1
            self.stats.c[f"v16_armor_over_{side}"] += over
            self.emit("armor_pierce", unit=c.id, raw=round(raw, 1), cap=cap, over=round(over, 1))
            mode = "armor_pierce"
        return leak + over, spent, mode

    # ------------------------------------------------------------ Ver0.19 先払いの鎧（PA-281）
    def shield_durability(self, g) -> float:
        """鎧1枚の耐久 = 基準30 ×（基準キャラ満タン時の「1ダメージを防ぐEP」÷ 張る者の今のそれ）。体の状態で変わる（案1）。"""
        if not self.prepay_ref:
            return self.prepay_base
        return self.prepay_base * self.prepay_ref / max(self.defense.required_ep(g, 1.0), 1e-9)

    def _prepaid_block(self, c, raw):
        dur = float(self._cur_layer_dur)
        self._cur_layer_dur = None
        self._layer_self = False
        part = min(raw, dur)
        over = raw - part
        side = c.side.value
        self.stats.c[f"v19_prepaid_hit_{side}"] += 1
        if over > 0:
            self.stats.c[f"v16_armor_pierce_{side}"] += 1
            self.stats.c[f"v16_armor_over_{side}"] += over
            self.emit("armor_pierce", unit=c.id, raw=round(raw, 1), cap=round(dur, 1), over=round(over, 1))
            return over, 0, "armor_pierce"
        return 0.0, 0, "aegis_prepaid"

    def _place_shield(self, giver, sid):
        """先払い: EPを払って鎧を1枚張る（耐久は張った瞬間の体で決まる）。払えなければ False。"""
        if self.prepay_on and not self.job_of(giver).get("shield_free"):
            if giver.ep < self.prepay_cost:
                return False
            giver.ep -= self.prepay_cost
            self._consume_packets(giver, self.prepay_cost, 0.0)
            self._check_ep(giver)
            self._update_collapse(giver, cause="spend")
            self.stats.c[f"v19_prepay_ep_{giver.side.value}"] += self.prepay_cost
        self._add_layer(giver, sid)
        return True

    # ------------------------------------------------------------ Ver0.19 構え（PA-271）
    def kamae_durability(self, u) -> float:
        """構えの鎧の耐久 = 基準 ×（基準キャラ満タン時の「1ダメージを防ぐEP」÷ u の今のそれ）。体の状態で変わる（案Y）。"""
        if not self.kamae_ref:
            return self.kamae_base
        return self.kamae_base * self.kamae_ref / max(self.defense.required_ep(u, 1.0), 1e-9)

    def _kamae_block(self, raw):
        uid = self._kamae_hit
        self._kamae_hit = None
        left = self.kamae_left.get(uid, 0.0)
        part = min(raw, left)
        over = raw - part
        left -= part
        side = self.u(uid).side.value
        broken = left <= 1e-6
        if broken:
            self.kamae_left.pop(uid, None)
            self._del_layer(uid, uid)
            if uid in self.shield_of.get(uid, []):
                self.shield_of[uid].remove(uid)
            self.stats.c[f"v19_kamae_broken_{side}"] += 1
        else:
            self.kamae_left[uid] = left
        self.stats.c[f"v19_kamae_hit_{side}"] += 1
        self.stats.c[f"v19_kamae_blocked_{side}"] += part
        self.emit("kamae_hit", unit=uid, raw=round(raw, 1), blocked=round(part, 1), left=round(max(0.0, left), 1),
                  over=round(over, 1), broken=broken)
        if over > 0:
            self.stats.c[f"v19_kamae_pierce_{side}"] += 1
        return over, 0, "kamae"

    # ------------------------------------------------------------ Ver0.20 仲間を呼ぶ（PA-284）
    def empty_front_slots(self):
        """前列の空いた場所の番号（そこにいた狼が死亡・戦闘不能で、まだ誰も呼ばれていない場所）。"""
        taken = set(self.arriving.values())
        out = []
        for i, uid in enumerate(self.front_slots):
            u = self.state.units.get(uid)
            if i in taken or uid in self.arriving:
                continue
            if u is None or not u.alive:
                out.append(i)
        return out

    def summon_due(self, u) -> bool:
        if not u.alive or "summon" not in u.d.action_ids:
            return False
        return len(self.empty_front_slots()) >= self.summon_trigger

    def _summon(self, leader):
        from ..model.combatant import Combatant, CombatantDef
        slots = self.empty_front_slots()
        arrive = self.cur_time + self.summon_delay
        ids = []
        for i in slots:
            k = self._summon_n
            self._summon_n += 1
            name = self.summon_names[k] if k < len(self.summon_names) else f"狼{k + 4}"
            uid = f"wolf_s{k + 1}"
            d = dict(self.summon_template)
            d.update({"id": uid, "name": name, "rank": "FRONT", "group": leader.d.group})
            u = Combatant.spawn(CombatantDef.from_cfg(d, Side.ENEMY))
            u.arriving = True
            self._register_unit(u, arrive)
            self.arriving[uid] = i
            ids.append(uid)
        self.stats.c[f"v20_summon_{leader.side.value}"] += 1
        self.stats.c[f"v20_summoned_{leader.side.value}"] += len(ids)
        self.emit("summon", unit=leader.id, summoned=ids, names=[self.u(x).name for x in ids], arrive=round(arrive, 4))

    def _register_unit(self, u, t_first):
        """戦闘の途中で加わる者を、エンジンの全ての帳簿に登録する（行動順・記録・知能など）。"""
        st = self.state
        st.units[u.id] = u
        for aid in u.d.action_ids:
            if self.actions[aid].uses is not None:
                u.uses[aid] = int(self.actions[aid].uses)
        if u.side.value in self.hp_body_sides:
            u.incap_ratio = next((x.incap_ratio for x in st.units.values() if x is not u and x.side is u.side), 0.0)
        self.track[u.id] = {"first_hp": None, "first_hp_round": None, "half": None, "ep_out": None,
                            "ep_out_round": None, "death": None, "att_before": 0, "opp_before": 0,
                            "att_after": 0, "opp_after": 0, "hits_after": 0,
                            "v6_first_dmg": None, "v6_body_hits": 0, "v6_body_dmg": 0, "v6_full_blocks": 0,
                            "v6_full_after_hit": 0, "v6_side_at_hit": None, "v6_self_at_hit": None,
                            "v6_turns": 0, "v6_rw_side": None, "v6_rw_self": None,
                            "v6_disp_hits": 0, "v6_disp_dmg": 0, "v6_disp_ko": 0}
        self.cstate[u.id] = {"collapsed": False, "first": None, "rec_at": None, "n_col": 0}
        self.packets[u.id] = [[u.ep, -1, 0.0]]
        self.lost_actions[u.id] = 0.0
        self.ward_max[u.id] = u.ward
        if self.defense.exhausted(u):
            self._ep_low.add(u.id)
        if self.base_intel or u.side is Side.ENEMY:
            b = int(u.d.intelligence if u.d.intelligence is not None else 0)
            ref = next((x for x in st.units.values() if x.side is u.side and x.d.group == u.d.group
                        and not x.d.is_leader and x.id in self.base_intel and x is not u), None)
            off = (self.base_intel[ref.id] - int(ref.d.intelligence or 0)) if ref is not None else 0
            self.base_intel[u.id] = max(0, min(3, b + off))
            boost = 1 if any(x.d.is_leader and x.alive and x.d.group == u.d.group for x in st.units.values()) else 0
            u.intel_effective = max(0, min(3, self.base_intel[u.id] + boost))
        self._set_next(u, max(t_first, self.cur_time), self.cur_time)

    def _arrive(self, u):
        """駆けつけた狼が前列に入る。その場所にいた戦闘不能の狼は退場する（消える）。"""
        i = self.arriving.pop(u.id)
        u.arriving = False
        old_id = self.front_slots[i]
        old = self.state.units.get(old_id)
        if old is not None and old.hp > 0 and not old.alive:
            old.removed = True
            self.removed.add(old.id)
            self.next_time[old.id] = math.inf
            self._remove_layers(old.id)
            self.layers.pop(old.id, None)
            self.layer_dur.pop(old.id, None)
            self.emit("removed", unit=old.id, by=u.id)
        import dataclasses
        rs = self.state.routes[u.side]
        for k, r in enumerate(rs):
            if old_id in r.blockers:                       # 経路の塞ぎ手を入れかえる（経路は書きかえ不可なので作り直す）
                nb = type(r.blockers)(u.id if x == old_id else x for x in r.blockers)
                rs[k] = dataclasses.replace(r, blockers=nb)
        self.front_slots[i] = u.id
        self.stats.c[f"v20_arrive_{u.side.value}"] += 1
        self.emit("arrive", unit=u.id, slot=i, replaced=old_id)

    def _take_turn(self, actor):
        if getattr(self, "bk_on", False):
            self._bk_tick()                                # Ver0.21 横槍・角笛（今の時刻までの分）
        if getattr(actor, "arriving", False):
            self._arrive(actor)                            # 1T後に到着し、そのまま最初の行動をする
        return self._take_turn_v18(actor)

    def _check_end(self) -> bool:
        st = self.state
        if self.arriving and st.side_units(Side.ALLY) and not st.side_units(Side.ENEMY):
            return False                                   # 駆けつけ中の狼がいる間は終わらない
        return super()._check_end()

    def _raw_mult(self, final, attacker=None, target=None) -> float:
        self._last_final = final
        m = self.hold_mult if final.id in self.holding else 1.0
        a = self._cur_action
        if (self.rear_phys_mult != 1.0 and a is not None and a.source == "power" and final.rank is Rank.REAR
                and final.side.value in self.rear_phys_sides):
            m *= self.rear_phys_mult        # PA-215: 後衛は物理攻撃に脆い（庇われた場合は受けた前衛に掛からない）
            self.stats.c[f"v15_rear_phys_hit_{final.side.value}"] += 1
        if attacker is not None and target is not None and attacker.d.group:
            if self.howl.get(attacker.d.group) == target.id and self.howl_by.get(attacker.d.group) != attacker.id:
                m *= 1.0 + self.howl_power          # PA-206: 遠吠えで指名された標的への群れの攻撃は威力+20%
                self.stats.c[f"v15_howl_hit_{attacker.side.value}"] += 1
        if self._clash_mult != 1.0:
            m *= self._clash_mult           # PA-263/264 一騎打ちの力比べ・死角攻撃（鎧に通す前に掛ける）
        return m

    # ------------------------------------------------------------ 手番の始まり・終わり
    def _v08_turn_start(self, actor):
        super()._v08_turn_start(actor)
        if getattr(self, "precommit", False) and self.shield_of.get(actor.id):
            for t in self._remove_layers(actor.id):        # 前の手番で張った鎧は、次の自分の手番で消える
                self.stats.c[f"v17_layer_expired_{actor.side.value}"] += 1
                self.emit("armor_expire", unit=actor.id, target=t)
        if self.kamae_left.pop(actor.id, None) is not None:
            self.emit("kamae_end", unit=actor.id)          # PA-271 構えは次の自分の手番まで
        if actor.stance is Stance.DIVING and actor.alive:
            before = self.route_snapshot()
            transition(actor, Stance.READY, self.emit, "突撃・回り込みから持ち場へ戻った (PA-201)")
            self.emit("dive_return", unit=actor.id)
            after = self.route_snapshot()
            for rid, s in after.items():
                if before.get(rid) == "OPEN" and s == "BLOCK":
                    self.emit("route_change", route=rid, status="BLOCK", cause=f"{actor.name}が持ち場へ戻った")
        if actor.id in self.holding:
            self.holding.discard(actor.id)
            self.emit("hold_end", unit=actor.id)
        for g, lid in list(self.howl_by.items()):
            if lid == actor.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)
                self.emit("howl_end", unit=actor.id)
        if actor.id in self.pinned:
            self._pin_clear.add(actor.id)
        if actor.id in self.casting and actor.id in self.fixed_info:
            self.fixed_info.pop(actor.id, None)
        self.charge_ready.pop(actor.id, None)
        if actor.id in self.charging:                      # PA-267 誰も来なかった: この手番で、ためた威力を放てる
            m = self.charge_mult(actor)
            self._charge_t0[actor.id] = self.charging.pop(actor.id, None)
            self.charge_ready[actor.id] = m
            self.emit("charge_ready", unit=actor.id, mult=round(m, 3))

    def _schedule_next(self, actor):
        super()._schedule_next(actor)
        if self.hate_on and actor.id in self.hate:
            # PA-260 ヘイトは自分の手番が終わるごとに冷める（判断に使ってから半分に）
            h = {k: x * self.hate_decay for k, x in self.hate[actor.id].items()}
            self.hate[actor.id] = {k: x for k, x in h.items() if x >= 1.0}
        if actor.id in self._delay_next:
            self._delay_next.discard(actor.id)
            nt = self.next_time.get(actor.id)
            if nt is not None and math.isfinite(nt):
                k = max(1, self._delay_count.pop(actor.id, 1))
                self.next_time[actor.id] = nt + self.ally_shield_delay * k  # 仲間に張った代償（PA-242。枚数ぶん）
        if actor.id in self._stagger:
            self._stagger.discard(actor.id)
            nt = self.next_time.get(actor.id)
            if nt is not None and math.isfinite(nt):
                self.next_time[actor.id] = nt + self.clash_stagger     # PA-263 弾かれた・崩された
        if actor.id in self._pin_clear:
            self._pin_clear.discard(actor.id)
            if self.pinned.pop(actor.id, None) is not None:
                self.emit("pin_end", unit=actor.id)

    # ------------------------------------------------------------ Ver0.17 先に張る鎧（PA-240〜245）
    def layers_on(self, uid):
        return self.layers.get(uid, [])

    def can_shield(self, giver, target) -> bool:
        """PA-248 鎧を張れる範囲。lanes: 自分／前衛どうし／担当の後衛（経路の塞ぎ手＝介入担当範囲）／後衛どうし（PA-248b）。"""
        if target.side is not giver.side or target.hp <= 0:
            return False                                   # 戦闘不能者（HP>0）には張れる。死亡者には張れない
        if target.id in getattr(self, "charging", {}) and giver.id != target.id:
            return False                                   # PA-267 ため中の者には、仲間も鎧を張れない
        if giver.id == target.id or self.shield_range != "lanes":
            return True
        if giver.rank is not Rank.FRONT:
            return target.rank is not Rank.FRONT          # PA-248b 後衛は後衛どうしで張り合える（前衛には張れない）
        if target.rank is Rank.FRONT:
            return True
        return any(giver.id in r.blockers for r in self.state.routes[target.side] if target.id in r.protects)

    # ------------------------------------------------------------ PA-258 ジョブ
    def job_of(self, u) -> dict:
        return self.jobs.get(u.d.job, {}) if u.d.job else {}

    def shields_per_turn(self, u) -> int:
        return int(self.job_of(u).get("shields_per_turn", 1))

    def push_delay_for(self, t) -> float:
        """押し返すで t の次の行動が遅れる時間。巨体（ジョブの push_reduce）はその分だけ短い（PA-274）。"""
        return max(0.0, self.push_delay - float(self.job_of(t).get("push_reduce", 0.0)))

    def guard_active(self, side) -> bool:
        """side に「後衛への通常攻撃を防ぐ」者（重戦士）が戦闘可能で立っているか。"""
        return any(self.job_of(u).get("guard_rear") for u in self.state.side_units(side))

    def _remove_layers(self, giver_id):
        out = []
        for t in self.shield_of.pop(giver_id, []):
            if self._del_layer(t, giver_id):                          # 外側から1枚ずつ
                out.append(t)
        return out

    def _del_layer(self, target_id, giver_id) -> bool:
        """target が着ている giver の鎧を、外側から1枚外す（耐久の並びもそろえて外す）。"""
        ls = self.layers.get(target_id, [])
        if giver_id not in ls:
            return False
        i = len(ls) - 1 - ls[::-1].index(giver_id)
        del ls[i]
        ds = self.layer_dur.get(target_id)
        if ds is not None and i < len(ds):
            del ds[i]
        return True

    def _remove_layer(self, giver_id):
        ts = self._remove_layers(giver_id)
        return ts[0] if ts else None

    def _add_layer(self, giver, sid, dur=None):
        self.layers.setdefault(sid, []).append(giver.id)
        self.shield_of.setdefault(giver.id, []).append(sid)
        if self.prepay_on and dur is None:
            dur = self.shield_durability(giver)            # PA-281 耐久は張った瞬間の、張った者の体で決まる
        ds = self.layer_dur.setdefault(sid, [])
        while len(ds) < len(self.layers[sid]) - 1:
            ds.append(None)
        ds.append(dur)

    def layer_durs(self, uid):
        ls, ds = self.layers.get(uid, []), self.layer_dur.get(uid, [])
        return [ds[i] if i < len(ds) else None for i in range(len(ls))]

    def _forced_aegis(self, target, attacker, action):
        if not self.precommit:
            return None
        if action is not None and action.special == "shock":
            return None                                    # PA-261 エーテル無視の衝撃波: 鎧を素通りする（鎧は割れない）
        ls = self.layers.get(target.id)
        if not ls:
            self.stats.c[f"v17_hit_bare_{target.side.value}"] += 1
            return None
        if ls[-1] == target.id and target.id in self.kamae_left:
            self._kamae_hit = target.id                    # PA-271 構えの鎧: 1発では割れず、耐久から引く
            self._layer_self = False
            return target
        ds = self.layer_dur.get(target.id, [])
        self._cur_layer_dur = ds.pop() if len(ds) == len(ls) else None
        gid = ls.pop()                                    # 外側から割れる
        if target.id in self.shield_of.get(gid, []):
            self.shield_of[gid].remove(target.id)
        g = self.u(gid)
        self._layer_self = gid == target.id
        side = target.side.value
        self.stats.c[f"v17_layer_used_{'self' if self._layer_self else 'other'}_{side}"] += 1
        self.emit("armor_hit", unit=gid, target=target.id, self_layer=self._layer_self, left=len(ls),
                  area=action.area == "all")
        return g

    def run(self):
        if self.precommit and self.prebattle and not getattr(self, "_prebattle_done", False):
            self._prebattle_done = True
            self._pre_battle()
        if self.ambush_first_strike and not getattr(self, "_ambush_done", False):
            self._ambush_done = True
            self._first_strike(Side.ENEMY)
        return super().run()

    def _first_strike(self, side):
        """PA-254 奇襲: side の全員の最初の行動が終わるまで、相手側は動けない。相手側どうしの順番（速さの差）は保つ。"""
        st = self.state
        first = [self.next_time[u.id] for u in st.side_units(side) if math.isfinite(self.next_time.get(u.id, math.inf))]
        others = [u for u in st.side_units(side.other) if math.isfinite(self.next_time.get(u.id, math.inf))]
        if not first or not others:
            return
        t_last = max(first)
        self._fs_until = t_last
        t0 = min(self.next_time[u.id] for u in others)
        for u in others:
            self.next_time[u.id] = t_last + 0.01 + (self.next_time[u.id] - t0)
        self.stats.c[f"v17_first_strike_{side.value}"] += 1
        self.emit("first_strike", side=side.value, until=round(t_last, 4))

    def _pre_battle(self):
        """PA-249 戦闘前の準備: 各自が、最初の自分の手番まで張っておく鎧を決める（プレイヤー・AI）。"""
        for side in (Side.ALLY, Side.ENEMY):
            ctl = self.controllers[side]
            for u in list(self.state.side_units(side)):
                if not u.alive:
                    continue
                free = bool(self.job_of(u).get("shield_free")) or self.prepay_on       # 先払いは張るときに払えるかで決まる
                if self.job_of(u).get("no_device"):
                    got = None                                       # PA-283 獣は装置なし
                elif self.job_of(u).get("shield_auto_self"):
                    got = [u.id] * self.shields_per_turn(u)          # PA-273 ゴーレム: いつも自分に
                elif hasattr(ctl, "decide_preshield"):
                    got = ctl.decide_preshield(u)
                else:
                    got = u.id if u.ep > 0 else None
                sids = list(got) if isinstance(got, (list, tuple)) else [got]
                sids = sids[:self.shields_per_turn(u)]
                placed = 0
                for sid in sids:
                    t = self.state.units.get(sid) if sid else None
                    if t is None or not self.can_shield(u, t) or u.id in self.casting or (u.ep < self.shield_min_ep and not free):
                        sid = None
                    self.stats.c[f"v17_pre_{'none' if sid is None else ('self' if sid == u.id else 'other')}_{side.value}"] += 1
                    if sid is None:
                        continue
                    if not self._place_shield(u, sid):
                        self.stats.c[f"v19_prepay_no_ep_{side.value}"] += 1
                        self.emit("shield_no_ep", unit=u.id, target=sid, ep=u.ep, prebattle=True)
                        continue
                    placed += 1
                    self.emit("shield", unit=u.id, target=sid, layers=len(self.layers[sid]), prebattle=True,
                              durability=round(self.layer_durs(sid)[-1] or 0, 1) if self.prepay_on else None)
                if placed:
                    self._check_exposed(u)
                if not placed:
                    self.emit("shield", unit=u.id, target=None, prebattle=True)

    def _choose_shield(self, actor, dec):
        """手番の行動と一緒に、鎧を張る先を決める（PA-241）。重戦士は2枚まで（PA-258）。"""
        n = self.shields_per_turn(actor)
        tags = dec.tags or {}
        if self.job_of(actor).get("no_device"):
            self.emit("shield", unit=actor.id, target=None)  # PA-283 獣はエーテル防御装置を持たない
            return
        if self.job_of(actor).get("shield_auto_self"):
            # PA-273 ゴーレム: 行動とは別に、毎手番 自分に n 枚（EPを使わない）。詠唱を始める手番は張れない（中核が開く）
            a = self.actions.get(dec.action_id)
            cast_start = a is not None and a.id in self.cast_time and not tags.get("cast_complete")
            side = actor.side.value
            skip_only = self.job_of(actor).get("shield_skip_casts")
            if cast_start and (skip_only is None or a.id in skip_only):     # Ver0.21 王: 土五月雨の詠唱だけ張らない
                self.stats.c[f"v19_auto_shield_skip_cast_{side}"] += 1
                self.emit("shield", unit=actor.id, target=None)
                return
            if self.prepay_on and not self.job_of(actor).get("shield_free"):
                # PA-281 先払い: 1枚10EP。行動のEPを払ったあとに払える枚数だけ（強制で張る）
                n = min(n, max(0, self.shield_ep_left(actor, dec, tags)) // self.prepay_cost)
                if n <= 0:
                    self.stats.c[f"v19_prepay_no_ep_{side}"] += 1
                    self.emit("shield_no_ep", unit=actor.id, target=actor.id, ep=self.shield_ep_left(actor, dec, tags))
                    return
            elif not self.job_of(actor).get("shield_free") and self.shield_min_ep > 0 \
                    and self.shield_ep_left(actor, dec, tags) < self.shield_min_ep:
                self.stats.c[f"v18_shield_no_ep_{side}"] += 1                  # PA-266 EPが残らないなら張れない
                self.emit("shield_no_ep", unit=actor.id, target=actor.id, ep=self.shield_ep_left(actor, dec, tags))
                return
            for _ in range(n):
                self._place_shield(actor, actor.id)
            self.stats.c[f"v19_auto_shield_{side}"] += n
            self.emit("shield", unit=actor.id, target=actor.id, layers=len(self.layers[actor.id]))
            self._check_exposed(actor)
            return
        if n > 1 or "shields" in tags:
            if "shields" in tags:
                sids = list(tags["shields"])
            elif "shield" in tags:
                sids = [tags["shield"]] + ([tags["shield2"]] if "shield2" in tags else [])
            else:
                ctl = self.controllers[actor.side]
                if hasattr(ctl, "decide_shields"):
                    sids = list(ctl.decide_shields(actor, dec, n))
                else:
                    sids = [ctl.decide_shield(actor, dec)] if hasattr(ctl, "decide_shield") else [actor.id]
            sids = [x for x in sids[:n]]
            if not any(sids):
                sids = [None]
            self._delay_count[actor.id] = 0
            for sid in sids:
                self._choose_shield_one(actor, dec, sid, {k: v for k, v in tags.items() if k != "fixed_shield"})
            return
        if "shield" in tags:
            sid = tags["shield"]
        else:
            ctl = self.controllers[actor.side]
            sid = ctl.decide_shield(actor, dec) if hasattr(ctl, "decide_shield") else (actor.id if actor.ep > 0 else None)
        self._delay_count[actor.id] = 0
        self._choose_shield_one(actor, dec, sid, tags)

    def _choose_shield_one(self, actor, dec, sid, tags):
        a = self.actions.get(dec.action_id)
        cast_start = a is not None and a.id in self.cast_time and not tags.get("cast_complete")
        if a is not None and a.special in ("focus", "charge", "kamae"):
            sid = None                                     # 集中した手番は装置を使えない（PA-235）・ためる手番も張れない（PA-267）・構えの手番はほかに張らない（PA-271）
        fixed_sid = sid if tags.get("fixed_shield") else None
        if sid is not None:
            t = self.state.units.get(sid)
            if t is None or t.side is not actor.side or t.hp <= 0 or (cast_start and sid == actor.id) \
                    or not self.can_shield(actor, t):
                sid = None                                 # 詠唱を始めた者は自分には張れない（PA-130）・範囲外（PA-248）
        need = self.prepay_cost if self.prepay_on else self.shield_min_ep      # PA-281 先払いなら1枚分のEPが要る
        if sid is not None and need > 0 and self.shield_ep_left(actor, dec, tags) < need:
            self.stats.c[f"v18_shield_no_ep_{actor.side.value}"] += 1
            self.emit("shield_no_ep", unit=actor.id, target=sid, ep=self.shield_ep_left(actor, dec, tags))
            sid = None                                     # PA-266 EPが残らない者は鎧を張れない（空の鎧が先に割れるのを防ぐ）
        side = actor.side.value
        if fixed_sid is not None and sid is None:
            # 固定された鎧が成り立たない（相手が死亡・範囲外など）→ 鎧は張れずに終わる。行動はそのまま（PA-255 a）
            self.stats.c[f"v17_fixed_shield_broken_{side}"] += 1
            self.emit("fixed_shield_broken", unit=actor.id, target=fixed_sid)
        elif tags.get("fixed_shield"):
            self.stats.c[f"v17_fixed_shield_{side}"] += 1
        if sid is None:
            self.stats.c[f"v17_shield_none_{side}"] += 1
            self.emit("shield", unit=actor.id, target=None,
                      kamae=bool(a is not None and a.special == "kamae"))     # 構えの手番（表示用）
            return
        self._place_shield(actor, sid)
        self.stats.c[f"v17_shield_{'self' if sid == actor.id else 'other'}_{side}"] += 1
        if sid != actor.id and self.ally_shield_delay > 0:
            self._delay_next.add(actor.id)
            self._delay_count[actor.id] = self._delay_count.get(actor.id, 0) + 1     # 仲間に張った枚数ぶん遅れる
        self.emit("shield", unit=actor.id, target=sid, layers=len(self.layers[sid]),
                  durability=round(self.layer_durs(sid)[-1] or 0, 1) if self.prepay_on else None, ep=actor.ep)

    def shield_ep_left(self, actor, dec, tags=None):
        """PA-266 この手番の行動でEPを払ったあとに残るEP（鎧はこのEPで受ける）。詠唱を始める手番は発動時に払うので引かない。"""
        a = self.actions.get(dec.action_id) if dec is not None else None
        tags = tags if tags is not None else (dec.tags or {} if dec is not None else {})
        if a is None or a.kind is ActionKind.WAIT or (a.id in self.cast_time and not tags.get("cast_complete")):
            return actor.ep
        return actor.ep - self.ep_cost(actor, a)

    # ------------------------------------------------------------ Ver0.16 前借り（PA-234）・確保（PA-233）
    def ep_cost(self, u, a) -> int:
        """PA-257 行動のEP。指定の技は、防御装置と同じ「実効肉体強度（今のHP×負傷）」で増減する。
        消費 = 基本 ×（u の 1ダメージあたりの防御EP ÷ 基準キャラの満タン時のそれ）^exponent。"""
        if a.id in self.skill_body_actions and self.skill_body_ref and a.ep_cost > 0:
            r = self.defense.required_ep(u, 1.0) / max(self.skill_body_ref, 1e-9)
            return max(1, int(round(a.ep_cost * r ** self.skill_body_p)))
        return a.ep_cost

    def blood_capacity(self, u) -> int:
        """HPで払えるEPの量（戦闘不能ラインより上に残る範囲）。"""
        if not (self.blood_on and u.id in self.blood_units) or not u.alive:
            return 0
        floor = math.floor(u.incap_ratio * u.d.hp_max) + 1 if u.incap_ratio > 0 else 1
        return max(0, int((u.hp - floor) / self.blood_rate))

    def spendable_ep(self, u, a=None) -> int:
        e = super().spendable_ep(u, a)
        rs = self.reserve.get(u.id)
        if rs and not self._exec_fixed:
            e -= rs["ep"]
        if a is not None and a.ep_cost > 0:
            e += self.blood_capacity(u)
        return e

    def _can_pay(self, actor, a) -> bool:
        return actor.ep + self.blood_capacity(actor) >= self.ep_cost(actor, a)

    def _pay(self, actor, a) -> int:
        cost = self.ep_cost(actor, a)
        if actor.ep >= cost:
            actor.ep -= cost
            return cost
        paid = int(actor.ep)
        short = cost - paid
        hp = int(math.ceil(short * self.blood_rate - 1e-9))
        actor.ep = 0
        actor.hp = max(1, actor.hp - hp)
        self.stats.c[f"v16_blood_{actor.side.value}"] += 1
        self.stats.c[f"v16_blood_hp_{actor.side.value}"] += hp
        self.emit("blood_pay", unit=actor.id, action=a.id, ep=paid, hp=hp, hp_left=actor.hp)
        return paid

    # ------------------------------------------------------------ 観測固定（PA-208）
    def _feasible(self, actor, dec) -> tuple[bool, str]:
        a = self.actions.get(dec.action_id)
        if a is None:
            return False, "不明な行動"
        if a.kind is ActionKind.WAIT:
            return True, ""
        if a.id not in {x.id for x in self.available_actions(actor)}:
            if a.special in PIN_BLOCKED and actor.id in self.pinned:
                return False, "牽制されて使えない"
            if self.ep_cost(actor, a) > self.spendable_ep(actor, a):
                return False, "EP不足"
            return False, "その行動が使えない"
        if dec.target_id is None:
            return True, ""
        t = self.u(dec.target_id)
        if a.kind is ActionKind.ATTACK and a.area in ("all", "front"):
            return (bool([x for x in self.valid_targets(actor, a) if x.alive]), "届く相手がいない")
        if t not in self.valid_targets(actor, a):
            return False, f"{t.name}に届かない／対象にできない"
        if a.kind is ActionKind.ATTACK and not t.alive and not t.incapacitated:
            return False, f"{t.name}がいない"
        return True, ""

    def force_cast_due(self, u):
        """PA-286 EPが決まった値を下回ったら、次の手番は必ずその技（1戦に1回）。使えないときは None。"""
        fc = self.job_of(u).get("force_cast") if hasattr(self, "job_of") else None
        if not fc or u.id in self._forced_done or not u.alive:
            return None
        if u.ep >= float(fc.get("below_ep", 0)):
            return None
        a = self.actions.get(fc.get("action"))
        if a is None or a.id not in u.d.action_ids or u.ep < self.ep_cost(u, a):
            return None
        ts = self.valid_targets(u, a)
        return (a, ts[0]) if ts else None

    def _decide(self, actor):
        if getattr(self, "bk_on", False) and actor.id == self.bk_id:
            return self._bk_decide(actor)                  # Ver0.21 バッカス王の手番
        fc = self.force_cast_due(actor) if actor.id not in self.fixed else None
        if fc is not None:
            # PA-286 EP91未満 → 次の行動は必ず地面への打撃（観測で固定された手番があれば、その次）
            a, t = fc
            self._forced_done.add(actor.id)
            self.stats.c[f"v20_force_cast_{actor.side.value}"] += 1
            self.emit("force_cast", unit=actor.id, action=a.id, ep=actor.ep,
                      below=self.job_of(actor)["force_cast"]["below_ep"])
            dec = Decision(a.id, t.id, reasons=[f"EP{actor.ep:.0f}が{self.job_of(actor)['force_cast']['below_ep']}未満 → {a.name}（強制）"])
            if self.precommit and actor.alive:
                self._choose_shield(actor, dec)
            return dec
        if self.summon_on and actor.id not in self.fixed and self.summon_due(actor):
            # PA-284 前列に空きが2つ以上 → 次の行動は必ず「仲間を呼ぶ」（観測で固定された手番があれば、その次）
            n = len(self.empty_front_slots())
            dec = Decision("summon", actor.id, reasons=[f"前列の空き{n}つ → 仲間を呼ぶ（強制）"])
            if self.precommit and actor.alive:
                self._choose_shield(actor, dec)
            return dec
        dec = self._decide_v15(actor)
        if self.precommit and actor.alive:
            self._choose_shield(actor, dec)
        return dec

    def _decide_v15(self, actor):
        for a in self.available_actions(actor):          # 記録用: 使える状態だった回数（使用率の分母）
            if a.special or a.id in ("maintain", "curse", "storm", "focus"):
                self.stats.c[f"v15_avail_{a.id}_{actor.id}"] += 1
        fx = self.fixed.get(actor.id)
        if fx is not None:
            left = int((fx.tags or {}).get("obs_left", 1))
            if left > 1:
                # まだその手番ではない（PA-233）: 自由に動くが、固定された未来を自分で壊す行動は選べない
                fx.tags["obs_left"] = left - 1
                self.stats.c[f"v16_fixed_wait_{actor.side.value}"] += 1
                self.emit("fixed_pending", unit=actor.id, action=fx.action_id, target=fx.target_id, left=left - 1)
                return super()._decide(actor)
            self.fixed.pop(actor.id, None)
        self.fixed_info.pop(actor.id, None)
        if fx is not None:
            self._exec_fixed = True
            try:
                ok, why = self._feasible(actor, fx)
            finally:
                self._exec_fixed = False
                self.reserve.pop(actor.id, None)
            if ok:
                self.stats.c[f"v15_fixed_exec_{actor.side.value}"] += 1
                self.emit("fixed_execute", unit=actor.id, action=fx.action_id, target=fx.target_id)
                return Decision(fx.action_id, fx.target_id, reasons=["観測で固定された意思（心変わりできない）"] + list(fx.reasons),
                                tags={**(fx.tags or {}), "fixed": True})
            self.stats.c[f"v15_fixed_broken_{actor.side.value}"] += 1
            self.emit("fixed_broken", unit=actor.id, action=fx.action_id, target=fx.target_id, why=why,
                      mode=self.observe_fail)
            if self.observe_fail == "lose":
                self.stats.c[f"v15_fixed_lost_turn_{actor.side.value}"] += 1
                keep = {"shield": fx.tags["shield"], "fixed_shield": True} if "shield" in (fx.tags or {}) else {}
                return Decision("wait", reasons=[f"固定された意思が成立しない（{why}）→ 迷って手番を失う"], tags=keep)
        return super()._decide(actor)

    def observe_depth_for(self, actor, t, depth=None) -> int:
        """PA-272 観測の深さ。choose: 選んだ手（なければ観測する側のAIに聞く）。random: 今までどおり乱数（PA-233）。"""
        lo, hi = self.obs_depth
        if self.obs_mode == "choose":
            if depth is None:
                ctl = self.controllers[actor.side]
                depth = ctl.decide_observe_depth(actor, t) if hasattr(ctl, "decide_observe_depth") else lo
            return max(lo, min(hi, int(depth)))
        return lo if hi <= lo else self.rng_obs.randint(lo, hi)

    def _observe(self, actor, t, depth=None):
        if getattr(self, "bk_on", False) and t.id == self.bk_id and t.id not in self.casting:
            return self._bk_observe(actor, t, depth)       # PA-296 王の「アデル隊に向く次の手」を読む
        if t.id in self.casting:
            d = self.casting[t.id]["dec"]
            self.fixed_info[t.id] = d
            self.stats.c["v15_observe_casting"] += 1
            self.emit("observe", unit=actor.id, target=t.id, action=d.action_id, intent_target=d.target_id, casting=True)
            return
        n = self.observe_depth_for(actor, t, depth)       # 先に「何手先か」を決める（技はそのあと敵AIが決める）
        dec = self.controllers[t.side].decide_action(t)
        dec.tags = {**(dec.tags or {}), "obs_left": n, "obs_depth": n}
        if self.precommit:
            # PA-255 その手番で張る鎧の相手も一緒に固定する（観測した瞬間の状況で決めさせる・公開）
            ctl = self.controllers[t.side]
            sid = ctl.decide_shield(t, dec) if hasattr(ctl, "decide_shield") else (t.id if t.ep > 0 else None)
            dec.tags["shield"] = sid
            dec.tags["fixed_shield"] = True
        self.fixed[t.id] = dec
        self.fixed_info[t.id] = dec
        a = self.actions.get(dec.action_id)
        if n > 1 and a is not None:
            self.reserve[t.id] = {"ep": a.ep_cost, "uses": a.id if a.uses is not None else None}
        self.stats.c[f"v16_observe_depth_{n}"] += 1
        self.emit("observe", unit=actor.id, target=t.id, action=dec.action_id, intent_target=dec.target_id,
                  casting=False, depth=n, shield=(dec.tags or {}).get("shield", "-"))

    # ------------------------------------------------------------ 実行
    def _execute(self, actor, dec):
        if getattr(self, "bk_on", False) and actor.id == self.bk_id and self._bk_pre(actor, dec):
            return                                         # Ver0.21 王踏・兵への本命・土五月雨・地割り・鉄槌
        if self.charge_on:
            done = self._charge_hooks(actor, dec)
            if done:
                return
        a = self.actions[dec.action_id]
        sp = a.special
        side = actor.side.value
        if a.kind is ActionKind.SPECIAL:
            t = self.u(dec.target_id) if dec.target_id else None
            self.stats.c[f"v15_{sp}_{side}"] += 1
            if sp == "hold":
                self.holding.add(actor.id)
                self.emit("hold", unit=actor.id, reasons=dec.reasons)
            elif sp == "howl" and t is not None:
                g = actor.d.group or actor.id
                self.howl[g] = t.id
                self.howl_by[g] = actor.id
                self.emit("howl", unit=actor.id, target=t.id, reasons=dec.reasons)
            elif sp == "observe" and t is not None:
                self._observe(actor, t, depth=(dec.tags or {}).get("obs_depth"))
            elif sp == "summon":
                self._summon(actor)
            elif sp == "kamae":
                cost = self.ep_cost(actor, a)                  # PA-271 EPは先払い（殴られなくても払う）
                actor.ep -= cost
                self._consume_packets(actor, cost, 0.0)
                self._check_ep(actor)
                self._update_collapse(actor, cause="spend")
                dur = self.kamae_durability(actor)
                self._add_layer(actor, actor.id)
                self.kamae_left[actor.id] = dur
                self.stats.c[f"v19_kamae_{side}"] += 1
                self.stats.c[f"v19_kamae_dur_{side}"] += dur
                self.emit("kamae", unit=actor.id, durability=round(dur, 1), ep=actor.ep, cost=cost,
                          layers=len(self.layers[actor.id]), reasons=dec.reasons)
            elif sp == "charge":
                if self.charge_strip and self.precommit:
                    gone = list(self.layers.get(actor.id, []))
                    for gid in gone:                       # PA-302 ため＝鎧なしで集中する（張った人のEPは戻らない）
                        if actor.id in self.shield_of.get(gid, []):
                            self.shield_of[gid].remove(actor.id)
                    self.layers.pop(actor.id, None)
                    self.layer_dur.pop(actor.id, None)
                    self.kamae_left.pop(actor.id, None)
                    if gone:
                        self.stats.c[f"v21_charge_strip_{side}"] += len(gone)
                        self.emit("charge_strip", unit=actor.id, n=len(gone))
                self.charging[actor.id] = self.cur_time
                self.stats.c[f"v18_charge_{side}"] += 1
                self.emit("charge_start", unit=actor.id, reasons=dec.reasons)
            elif sp == "focus":
                g = min(a.amount, actor.d.ep_max - actor.ep)
                actor.ep += g
                if self.device_on:
                    self.aegis_used.add(actor.id)        # 集中している間は装置を使えない（PA-235）
                self._check_ep(actor)
                self._update_collapse(actor, cause="supply")
                self.emit("focus", unit=actor.id, amount=g, ep=actor.ep, reasons=dec.reasons)
            else:
                self.emit("wait", unit=actor.id, reasons=dec.reasons)
            return
        if sp and not (a.id in self.cast_time and not dec.tags.get("cast_complete")):
            self.stats.c[f"v15_{sp}_{side}"] += 1
        rear_melee = (self.rear_melee_displaces and not sp and a.kind is ActionKind.ATTACK and a.area not in ("all", "front")
                      and a.reach is not None and a.reach.value == "MELEE" and dec.target_id
                      and self.u(dec.target_id).rank is Rank.REAR and not (a.id in self.cast_time and not dec.tags.get("cast_complete")))
        if sp in BREACH or rear_melee:
            target = self.u(dec.target_id)
            r = self.reach(actor, target, a)
            if not sp:
                sp = "rear_melee"
                self.stats.c[f"v15_rear_melee_{side}"] += 1
            if r.via_route and holding_blockers(next(x for x in self.state.all_routes() if x.id == r.via_route),
                                                self.state.units):
                self.stats.c[f"v15_{sp}_thin_{side}"] += 1
            if target.id in self.casting:
                self.stats.c[f"v15_{sp}_on_casting_{side}"] += 1
            before = self.route_snapshot()
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is not None and fin.id != target.id:
                self.stats.c[f"v15_{sp}_intercepted_{side}"] += 1
            if actor.alive and actor.stance is Stance.READY and r.ok:
                transition(actor, Stance.DIVING, self.emit, f"{a.name}で{target.name}へ踏み込んだ（持ち場を離れる）")
                after = self.route_snapshot()
                for rid, s in after.items():
                    if before.get(rid) == "BLOCK" and s == "OPEN":
                        self.stats.c[f"front_open_{side}"] += 1
                        self.stats.c[f"v15_open_by_{sp}_{side}"] += 1
                        self.emit("route_change", route=rid, status="OPEN", cause=f"{actor.name}が{a.name}で持ち場を離れた")
            return
        if sp in ("pin", "push"):
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is None or fin.side is actor.side or not fin.alive:
                return
            if sp == "pin":
                self.pinned[fin.id] = actor.id
                self._pin_clear.discard(fin.id)
                self.emit("pinned", unit=fin.id, by=actor.id)
            else:
                nt = self.next_time.get(fin.id)
                if nt is not None and math.isfinite(nt):
                    pd = self.push_delay_for(fin)
                    self.next_time[fin.id] = nt + pd
                    self.stats.c[f"v15_push_delay_{side}"] += pd
                    self.emit("pushed", unit=fin.id, by=actor.id, old=round(nt, 4), new=round(nt + pd, 4), delay=round(pd, 4),
                              giant=bool(self.job_of(fin).get("push_reduce")))
            return
        super()._execute(actor, dec)
        self._extra_hits(actor, a, dec)
        self._check_exposed(actor)

    def _extra_hits(self, actor, a, dec):
        """PA-278 ダブルアタック: 同じ相手に続けて当てる（2発目以降。1発ずつ鎧に通す・スタンも1発ずつ）。"""
        if a.kind is not ActionKind.ATTACK or a.hits <= 1 or a.area in ("all", "front") or not dec.target_id:
            return
        if a.id in self.cast_time and not (dec.tags or {}).get("cast_complete"):
            return
        for i in range(1, a.hits):
            t = self.u(dec.target_id)
            if not actor.alive or not t.alive or self._check_end():
                return
            self.stats.c[f"v19_multi_hit_{actor.side.value}"] += 1
            self.emit("multi_hit", unit=actor.id, target=t.id, action=a.id, n=i + 1, of=a.hits)
            self._resolve_attack(actor, a, t, dec)

    def estimate_damage(self, attacker, action, target, defend=None, naive=False) -> float:
        e = super().estimate_damage(attacker, action, target, defend=defend, naive=naive)
        return e * max(1, int(getattr(action, "hits", 1)))       # PA-278 ダブルアタックは2発ぶん（見積もり）

    # ------------------------------------------------------------ PA-276/277 中核の露出（ゴーレム）
    def exposed_why(self, u):
        """肉体が下がっている理由（なければ None）: casting = 詠唱中 / ep0 = EPが尽きた。"""
        job = self.job_of(u) if hasattr(self, "jobs") else {}
        if job.get("cast_body") is None:
            return None
        if u.id in self.casting:
            return "casting"
        if job.get("exposed_at_ep0") and u.ep <= 0:
            return "ep0"
        return None

    def _check_exposed(self, u):
        if getattr(self, "_ep0_seen", None) is None:
            self._ep0_seen = set()
        if u.id not in self._ep0_seen and self.exposed_why(u) == "ep0" and u.alive:
            self._ep0_seen.add(u.id)
            self.stats.c[f"v19_core_exposed_{u.side.value}"] += 1
            self.emit("core_exposed", unit=u.id, body=float(self.job_of(u)["cast_body"]))

    def _body_factor(self, final, attacker, action) -> float:
        """PA-216: 物理攻撃（威力が元）が生身に通る分は、受ける側の「肉体」で増減する。
        倍率 = (ref / 肉体)^exponent。肉体が弱いほど深く傷つく。魔法には掛からない（肉体では防げない）。"""
        jm = float(self.job_of(final).get("damage_taken", 1.0)) if hasattr(self, "jobs") else 1.0   # PA-268 侍は脆い
        if not self.body_phys_on or action is None or action.source != "power":
            return jm
        body = final.d.body
        cb = self.job_of(final).get("cast_body") if hasattr(self, "jobs") else None
        if cb is not None and self.exposed_why(final):
            body = float(cb)                               # PA-276 詠唱中・PA-277 EP0 は肉体が下がる（ゴーレム 25→5）
        b = max(1.0, float(body))
        return jm * (self.body_phys_ref / b) ** self.body_phys_p

    def recent_hits(self, uid, window):
        """直近 window T の間に、uid が攻撃の対象になった回数（戦場で見えている公開情報）。"""
        t0 = self.cur_time - window
        return sum(1 for t in getattr(self, "hit_log", {}).get(uid, ()) if t >= t0 - 1e-9)

    def _resolve_attack(self, attacker, a, target, dec, no_iv=False):
        if not hasattr(self, "hit_log"):
            self.hit_log = {}
        self.hit_log.setdefault(target.id, []).append(self.cur_time)
        self._cur_action = a
        hp0 = target.hp
        try:
            return super()._resolve_attack(attacker, a, target, dec, no_iv=no_iv)
        finally:
            self._cur_action = None
            if target.id in self.charging and attacker.side is not target.side and target.alive \
                    and (not self.is_melee(a) or a.area in ("all", "front")):
                old = self.charge_mult(target)
                self.charging[target.id] = self.cur_time          # PA-268 魔法・遠隔・範囲で集中が途切れる → 1.0倍からため直し
                self.stats.c[f"v18_charge_reset_{target.side.value}"] += 1
                self.emit("charge_reset", unit=target.id, by=attacker.id, old=round(old, 3))
            if self.hate_on and attacker.side is not target.side and target.side is Side.ENEMY:
                self._gain_hate(target, attacker, a, hp0 - target.hp)
            self._check_exposed(target)
            st = float(self.job_of(attacker).get("stun_on_body", 0.0)) if attacker.side is not target.side else 0.0
            if st > 0 and hp0 - target.hp > 0 and target.alive:
                self._stun(target, attacker, st)

    def _stun(self, u, by, d):
        """PA-275 スタン: 生身まで届いた攻撃で、次の手番（詠唱中なら完成）が d T 遅れる。重なる。"""
        nt = self.next_time.get(u.id)
        if nt is None or not math.isfinite(nt):
            return
        self.next_time[u.id] = nt + d
        self.stats.c[f"v19_stun_{u.side.value}"] += 1
        self.emit("stunned", unit=u.id, by=by.id, delay=d, casting=u.id in self.casting,
                  old=round(nt, 4), new=round(nt + d, 4))

    # ------------------------------------------------------------ PA-262〜264 同時行動（一騎打ち・死角攻撃）
    def _simul_partner(self, actor):
        """actor とほぼ同時（window T 以内）に動く、相手側の1人（いちばん近い者）。詠唱中の者は除く。"""
        if not self.clash_on or not self.clash_random or actor.id in self.casting:
            return None
        t = self.cur_time
        if self._fs_until is not None and t <= self._fs_until + 1e-9:
            return None                                    # 奇襲で敵が先に動いている間は同時にしない
        best = None
        for u in self.state.side_units(actor.side.other):
            nt = self.next_time.get(u.id, math.inf)
            if not u.alive or not math.isfinite(nt) or u.id in self.casting:
                continue
            d = nt - t
            if -1e-9 <= d <= self.clash_window + 1e-9 and (best is None or d < best[0]):
                best = (d, u)
        return best[1] if best else None

    def _turn_open(self, actor, simul_with=None):
        """手番の始まり（基本エンジンの _take_turn の前半と同じ）。False なら行動できない。"""
        self.current_actor = actor
        self.action_index += 1
        self.side_turns[actor.side.value] += 1
        self.track[actor.id]["v6_turns"] += 1
        nxt = [s.unit_id for s in self.upcoming_slots(0)][:6]
        self.emit("turn_start", unit=actor.id, upcoming=nxt, snap=actor.short(), intel=actor.intel_effective,
                  routes=self.route_snapshot(), simul=simul_with)
        self._v08_turn_start(actor)
        if not self.recovery.on_own_turn_start(actor, self):
            self.emit("turn_skipped", unit=actor.id, reason="持ち場への復帰に手番を使用")
            return False
        return True

    @staticmethod
    def is_melee(a) -> bool:
        """近接攻撃か（PA-269: 跳躍襲撃のように、遠くから届いても体ごとぶつかる攻撃は近接扱い）。"""
        return (a.reach is not None and a.reach.value == "MELEE") or bool(getattr(a, "contact", False))

    def melee_single(self, u, dec):
        """単体を狙う近接攻撃なら、その標的を返す（一騎打ち・死角攻撃の対象になる行動）。"""
        if dec is None or not dec.target_id:
            return None
        a = self.actions.get(dec.action_id)
        if a is None or a.kind is not ActionKind.ATTACK or a.area in ("all", "front"):
            return None
        if not self.is_melee(a):
            return None
        if a.id in self.cast_time and not (dec.tags or {}).get("cast_complete"):
            return None
        t = self.state.units.get(dec.target_id)
        if t is None or t.side is u.side:
            return None
        return t

    def _take_turn_v18(self, actor):
        b = self._simul_partner(actor)
        if b is None:
            return super()._take_turn(actor)
        a = actor
        self.simul_with = {a.id: b.id, b.id: a.id}
        self._pair_ids = (a.id, b.id)
        gap = self.next_time[b.id] - self.cur_time
        self.stats.c["v18_simul"] += 1
        try:
            da = self._decide(a) if self._turn_open(a) else None
            self.time_log.append((b.id, self.cur_time))
            self.emit("simul", unit=a.id, other=b.id, gap=round(gap, 4))
            db = self._decide(b) if (b.alive and self._turn_open(b, simul_with=a.id)) else None
        finally:
            self.simul_with = {}
        tb = self.cur_time + gap
        self._resolve_pair(a, da, b, db)
        self._pair_ids = ()
        # b の次の手番は、本来の自分の時刻から数える（同時になったことで得も損もしない）
        t0 = self.cur_time
        self.current_actor = b
        self.cur_time = max(t0, tb)
        try:
            self._schedule_next(b)
        finally:
            self.cur_time = t0
        self._rescale_all(skip=b)
        self.current_actor = a

    def _run_dec(self, u, d, check=False):
        """決めておいた行動を実行する（同時に動いた相手のせいで成り立たなくなっていたら手番を失う）。"""
        if d is None or not u.alive:
            return
        self.current_actor = u
        if check:
            ok, why = self._feasible(u, d)
            if not ok:
                self.stats.c[f"v18_simul_void_{u.side.value}"] += 1
                self.emit("simul_void", unit=u.id, action=d.action_id, why=why)
                return
        self._execute(u, d)

    def _spend_only(self, u, d):
        """攻撃はしたが当たらなかった: EP（と使用回数）だけ払う。"""
        a = self.actions[d.action_id]
        if a.ep_cost:
            paid = self._pay(u, a)
            self._consume_packets(u, paid, 0.0)
            self._check_ep(u)
            self._update_collapse(u, cause="spend")
        if a.uses is not None:
            u.uses[a.id] -= 1

    def _exec_mult(self, u, d, mult):
        self.current_actor = u
        self._clash_mult = mult
        try:
            self._execute(u, d)
        finally:
            self._clash_mult = 1.0

    def _resolve_pair(self, a, da, b, db):
        ta, tb = self.melee_single(a, da), self.melee_single(b, db)
        if ta is not None and tb is not None and ta.id == b.id and tb.id == a.id:
            return self._duel(a, da, b, db)
        if ta is not None and ta.id == b.id and tb is not None:
            return self._blindside(a, da, b, db)
        if tb is not None and tb.id == a.id and ta is not None:
            return self._blindside(b, db, a, da)
        self._run_dec(a, da)
        if self._check_end():
            return
        self._run_dec(b, db, check=True)

    def _blindside(self, x, dx, y, dy):
        """PA-264 x が、よそ（z）を殴ろうとしている y の死角を突く。y の攻撃は中断。"""
        z = self.u(dy.target_id)
        self.stats.c[f"v18_blind_{x.side.value}"] += 1
        self.emit("blindside", unit=x.id, target=y.id, victim_target=z.id, mult=self.blind_mult)
        self._exec_mult(x, dx, self.blind_mult)
        self.stats.c[f"v18_blind_interrupted_{y.side.value}"] += 1
        self.emit("blind_interrupted", unit=y.id, action=dy.action_id, target=z.id)

    def _duel(self, a, da, b, db, boost=None):
        prev = self.current_actor
        busy = getattr(self, "_charge_busy", False)
        self._charge_busy = True
        try:
            return self._duel_inner(a, da, b, db, boost)
        finally:
            self._charge_busy = busy
            self.current_actor = prev

    def _duel_inner(self, a, da, b, db, boost=None):
        """PA-263 一騎打ち: 攻撃・パリィ・崩しの三すくみ。boost: ため斬りの倍率（PA-267）。"""
        boost = boost or {}
        aa, ab = self.actions[da.action_id], self.actions[db.action_id]
        ba, bb = boost.get(a.id, 1.0), boost.get(b.id, 1.0)
        ra, rb = self.damage.expected(a, aa) * ba, self.damage.expected(b, ab) * bb
        self.duel_raw = {a.id: ra, b.id: rb}
        if getattr(self, "bk_on", False) and a.id == self.bk_id:
            sa = self._bk_clash(a)                         # PA-298 鉄槌の一騎打ち: 王は攻撃か崩しを半々
        else:
            sa = self.controllers[a.side].decide_clash(a, b) if hasattr(self.controllers[a.side], "decide_clash") else "attack"
        if getattr(self, "bk_on", False) and b.id == self.bk_id:
            sb = self._bk_clash(b)
        else:
            sb = self.controllers[b.side].decide_clash(b, a) if hasattr(self.controllers[b.side], "decide_clash") else "attack"
        sa = sa if sa in CLASH_STANCES else "attack"
        sb = sb if sb in CLASH_STANCES else "attack"
        self.stats.c["v18_duel"] += 1
        self.stats.c[f"v18_duel_{a.side.value}_{sa}"] += 1
        self.stats.c[f"v18_duel_{b.side.value}_{sb}"] += 1
        self.emit("duel", unit=a.id, other=b.id, stance=sa, other_stance=sb, raw=round(ra, 1), other_raw=round(rb, 1))
        beats = {"parry": "attack", "break": "parry", "attack": "break"}     # 左が右に勝つ
        if sa == sb == "attack":
            if abs(ra - rb) < 1e-9:
                self._spend_only(a, da)
                self._spend_only(b, db)
                self.stats.c["v18_duel_even"] += 1
                self.emit("duel_result", kind="even", unit=a.id, other=b.id)
                return
            w, dw, lo, dl, rw, rl = (a, da, b, db, ra, rb) if ra > rb else (b, db, a, da, rb, ra)
            self._last_duel = ("power", w.id)
            bw = boost.get(w.id, 1.0)
            self._spend_only(lo, dl)
            self.stats.c[f"v18_duel_power_win_{w.side.value}"] += 1
            self.emit("duel_result", kind="power", unit=w.id, other=lo.id, raw=round(rw, 1), other_raw=round(rl, 1),
                      through=round(rw - rl, 1))
            self._exec_mult(w, dw, bw * (rw - rl) / rw)
            return
        if sa == sb:
            self.stats.c[f"v18_duel_same_{sa}"] += 1
            self.emit("duel_result", kind="same", unit=a.id, other=b.id, stance=sa)
            return
        w, dw, sw, lo, dl, sl = (a, da, sa, b, db, sb) if beats[sa] == sb else (b, db, sb, a, da, sa)
        self._last_duel = (sw, w.id)
        self.stats.c[f"v18_duel_win_{w.side.value}_{sw}"] += 1
        self.emit("duel_result", kind=sw, unit=w.id, other=lo.id)
        if sw == "parry":                      # 攻撃を弾いた: 攻撃した側はEPだけ払って崩れる
            self._spend_only(lo, dl)
            self._apply_stagger(lo)
        elif sw == "break":                    # パリィの構えを崩した
            self._apply_stagger(lo)
        else:                                  # 崩しに来たところを斬った: 攻撃がそのまま通る
            if boost.get(w.id, 1.0) != 1.0:
                self._exec_mult(w, dw, boost[w.id])
            else:
                self._run_dec(w, dw)

    def _apply_stagger(self, u):
        """崩れ: いま手番中（このあと次の手番を決める）の者は予約に、それ以外は今の予約に直接足す。"""
        if u is self.current_actor or u.id in getattr(self, "_pair_ids", ()):
            self._stagger.add(u.id)
            return
        nt = self.next_time.get(u.id)
        if nt is not None and math.isfinite(nt):
            self.next_time[u.id] = nt + self.clash_stagger
        self.emit("staggered", unit=u.id, delay=self.clash_stagger)

    # ------------------------------------------------------------ PA-267 侍の「ため斬り」
    def charge_mult(self, u) -> float:
        t0 = self.charging.get(u.id)
        if t0 is None:
            return 1.0
        return min(self.charge_max, 1.0 + self.charge_per_T * max(0.0, self.cur_time - t0))

    def charge_counter_attack(self, c, foe):
        """ため中の c が foe へ斬り込むときに使う攻撃（単体の近接攻撃で届くもの。一番強いもの）。"""
        best = None
        for a in self.available_actions(c):
            if a.kind is ActionKind.ATTACK and a.area not in ("all", "front") and a.reach is not None \
                    and a.reach.value == "MELEE" and not a.special and foe in self.valid_targets(c, a):
                if best is None or self.damage.expected(c, a) > self.damage.expected(c, best):
                    best = a
        return best

    def _charge_hooks(self, actor, dec):
        """True を返したら、この行動はここで終わり（斬り込まれて中断・一騎打ちで決着）。"""
        if getattr(self, "_charge_busy", False):
            return False
        a0 = self.actions.get(dec.action_id)
        if self.charge_hold and a0 is not None and a0.special == "charge" and actor.id in self.charge_ready:
            # PA-303 ためを続ける: 放たずに構えたまま。倍率はそのまま伸びる（上限まで）
            self.charge_ready.pop(actor.id, None)
            t0 = self._charge_t0.pop(actor.id, None)
            self.charging[actor.id] = self.cur_time if t0 is None else t0
            self.stats.c[f"v21_charge_hold_{actor.side.value}"] += 1
            self.emit("charge_continue", unit=actor.id, mult=round(self.charge_mult(actor), 3))
            return True
        # ① ためを放つ手番: 単体の近接攻撃に倍率が乗る
        m = self.charge_ready.pop(actor.id, None)
        if m is not None:
            if self.melee_single(actor, dec) is not None:
                self.stats.c[f"v18_charge_release_{actor.side.value}"] += 1
                self.emit("charge_release", unit=actor.id, target=dec.target_id, mult=round(m, 3))
                self._exec_mult(actor, dec, m)
                return True
            self.emit("charge_lost", unit=actor.id, why="ためを放たなかった")
            return False
        t = self.melee_single(actor, dec)
        if t is None:
            return False
        foes = [c for c in self.state.side_units(actor.side.other) if c.id in self.charging and c.alive and not c.incapacitated]
        if not foes:
            return False
        # ② ため中の本人を近接で狙った → 一騎打ち（パリィタイム）
        if t.id in self.charging:
            c = t
            ca = self.charge_counter_attack(c, actor)
            if ca is not None:
                m = self.charge_mult(c)
                self.charging.pop(c.id, None)
                self._last_charge = ("duel", c.id)
                self.stats.c[f"v18_charge_duel_{c.side.value}"] += 1
                self.emit("charge_duel", unit=c.id, other=actor.id, mult=round(m, 3))
                self._duel(actor, dec, c, Decision(ca.id, actor.id, reasons=["ため斬り"]), boost={c.id: m})
                return True
            return False
        # ③ ほかの者を近接で狙った → ため中の者が死角から斬り込めるか（選べる）
        for c in sorted(foes, key=lambda x: -self.charge_mult(x)):
            ca = self.charge_counter_attack(c, actor)
            if ca is None:
                continue
            m = self.charge_mult(c)
            ctl = self.controllers[c.side]
            go = ctl.decide_charge_strike(c, actor, t, m) if hasattr(ctl, "decide_charge_strike") else True
            if not go:
                self.emit("charge_hold", unit=c.id, attacker=actor.id, target=t.id, mult=round(m, 3))
                continue
            self.charging.pop(c.id, None)
            self._last_charge = ("strike", c.id)
            self.stats.c[f"v18_charge_strike_{c.side.value}"] += 1
            self.emit("charge_strike", unit=c.id, target=actor.id, victim_target=t.id, mult=round(m, 3))
            prev = self.current_actor
            self._charge_busy = True
            try:
                self._exec_mult(c, Decision(ca.id, actor.id, reasons=["ため斬り（死角から斬り込む）"]), m)
            finally:
                self._charge_busy = False
                self.current_actor = prev
            self.stats.c[f"v18_blind_interrupted_{actor.side.value}"] += 1
            self.emit("blind_interrupted", unit=actor.id, action=dec.action_id, target=t.id)
            return True
        return False

    # ------------------------------------------------------------ PA-260 ヘイト
    def judgment_of(self, e) -> float:
        return self.hate_judgment + self.hate_bonus.get(int(e.intel_effective or 0), 0.0)

    def instinct_of(self, e) -> float:
        if self.job_of(e).get("no_hate"):
            return 0.0                                     # PA-273 ゴーレム: 本能がない（ヘイトが溜まらない）
        b = self.base_intel.get(e.id, int(e.intel_effective or 0))
        return self.hate_instinct.get(int(b), 1.0)

    def hate_top(self, e):
        """e のヘイトが一番高い相手（戦闘可能な者だけ）: (値, ID) or (0, None)"""
        best = (0.0, None)
        for tid, x in self.hate.get(e.id, {}).items():
            t = self.state.units.get(tid)
            if t is not None and t.alive and x > best[0]:
                best = (x, tid)
        return best

    def _gain_hate(self, e, attacker, a, dmg):
        """生身にダメージが通ったときだけヘイトが増える（鎧で全部防いだら増えない）。衝撃波は鎧を無視して必ず届く。"""
        key = a.special or a.id
        if key not in self.hate_actions and dmg <= 0:
            return
        base = float(self.hate_actions.get(key, self.hate_body_hit))
        amt = base * self.instinct_of(e)
        if amt <= 0 or e.hp <= 0:
            return
        h = self.hate.setdefault(e.id, {})
        old_top = self.hate_top(e)
        h[attacker.id] = h.get(attacker.id, 0.0) + amt
        if self.hate_cap is not None:
            h[attacker.id] = min(self.hate_cap, h[attacker.id])     # PA-265
        self.stats.c[f"v17_hate_gain_{key}"] += 1
        new_top = self.hate_top(e)
        hooked = new_top[0] > self.judgment_of(e)
        self.emit("hate", unit=e.id, toward=attacker.id, amount=round(amt, 1), value=round(h[attacker.id], 1),
                  judgment=round(self.judgment_of(e), 1), hooked=hooked and new_top[1] == attacker.id,
                  was=old_top[1])

    # ------------------------------------------------------------ 戦闘不能
    def _on_ko(self, u, routes_before):
        super()._on_ko(u, routes_before)
        self.fixed.pop(u.id, None)
        self.fixed_info.pop(u.id, None)
        self.reserve.pop(u.id, None)
        if self.charging.pop(u.id, None) is not None:
            self.emit("charge_lost", unit=u.id, why="倒れた")
        self.charge_ready.pop(u.id, None)
        self.pinned.pop(u.id, None)
        self.kamae_left.pop(u.id, None)                    # 倒れたら構えは解ける
        if self.precommit:
            self._remove_layers(u.id)                      # 倒れた者が張った鎧は消える（維持できない）
            if u.hp <= 0:
                self.layer_dur.pop(u.id, None)
                for gid in self.layers.pop(u.id, []):      # 死亡した者が着ていた鎧は消える（戦闘不能者は着たまま）
                    if u.id in self.shield_of.get(gid, []):
                        self.shield_of[gid].remove(u.id)
        self.holding.discard(u.id)
        for g, lid in list(self.howl_by.items()):
            if lid == u.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)


def make_v15_engine(cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
    return V15Engine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
