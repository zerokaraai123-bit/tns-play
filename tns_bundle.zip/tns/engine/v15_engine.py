"""Ver0.15 検証用エンジン（PA-200〜209）。正式仕様ではない。

TimelineEngine（Ver0.12 のイベント方式・方式B）を継承し、Ver0.15 の新しい行動だけを足す。
既存の処理（ダメージ・エーテル防御・介入・持ち場離脱・前線突破・戦闘不能・速度・詠唱）はそのまま使う。

新しい行動（rules.actions の special）:
  dive / flank : 薄い経路（塞ぎ手が thin_route_max 人以下。死守中は hold_blocker_weight 人分）を通って相手のREARを近接攻撃。
                 行動後は DIVING（持ち場を離れる）。次の自分の手番の始めに戻る。防御は可・介入は不可。
  pin          : 相手FRONTを近接攻撃。相手は自分の次の手番が終わるまで、介入・dive/flank/pin/push が使えない。
  push         : 相手FRONTを近接攻撃。相手の次の行動を push_delay T 遅らせる。
  hold         : 自分の次の手番の始めまで、受ける威力×hold_raw_mult・介入不可・塞ぎ手2人分。
  howl         : 群れに標的を指名（リーダーの次の手番の始めまで）。公開情報。
  observe      : 敵1体の「次の行動の意思」をその瞬間に敵AIに決めさせ、固定する（可能性の観測固定）。
                 次の手番で成立すればそのとおりに行動。成立しなければ release（選び直し）/ lose（待機）。

Ver0.16 の追加（PA-230〜236。すべて設定で有効化。無効なら Ver0.15 と同じ動作）:
  device       : エーテル防御装置は「自分の手番から次の自分の手番まで」に1回だけ（自分を守る・介入、どちらでも）。
                 使ったら次の自分の手番まで生身（自衛・介入とも不可）。
  介入（鎧）   : 介入者は持ち場を離れ、装置の鎧を守られる側にまとわせる。鎧は上限（armor_cap）まで防ぐ。
                 上限を超えた分（余波）は、守られた側の肉体へ直接入る（守られた側のエーテル防御は効かない）。
                 範囲攻撃は介入できない（従来どおり）。
  観測の深さ   : 固定する意思は「何手先か」がランダム（observe_depth）。公開情報。固定された敵は、その手番まで
                 自分で未来を壊す行動を選べない（EP・使用回数の確保、詠唱の開始禁止）。成立しなければ手番を失う。
  前借り       : 指定ユニットは、EPが足りない分をHPで払って行動できる（戦闘不能にならない範囲）。
  集中         : EPを回復する。その手番から次の自分の手番まで、装置は使えない。

Ver0.17 の追加（PA-240〜245。device.mode: precommit のときだけ）:
  先に張る鎧   : 装置は攻撃を受けてから使うのではなく、自分の手番に「自分／仲間1人／張らない」を選んで先に張る。
                 鎧は次の自分の手番まで残り、最初の1発（大小・単体/全体を問わず）で1枚消える。重ねがけ可。
                 外側（あとから張った方）から割れる。全体攻撃は1人につき1枚。敵からは見えない。
                 割り込む介入はない（持ち場も離れない）。仲間に張ると、次の自分の手番が ally_shield_delay T 遅れる。
"""
from __future__ import annotations

import math
import random

from ..control.controller import Decision
from ..formation.reach import ReachResult, can_use_melee
from ..formation.route import holding_blockers, route_blocked
from ..model.enums import ActionKind, Rank, Side, Stance
from ..stance.stance_machine import transition
from .timeline_engine import TimelineEngine

BREACH = ("dive", "flank")
PIN_BLOCKED = ("dive", "flank", "pin", "push")


CLASH_STANCES = ("attack", "parry", "break")
CLASH_NAMES = {"attack": "攻撃", "parry": "パリィ", "break": "崩し"}


class V15Engine(TimelineEngine):
    def __init__(self, cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
        super().__init__(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
        v = cfg.rules.get("v15", {}) or {}
        self.hold_mult = float(v.get("hold_raw_mult", 0.6))
        self.hold_w = int(v.get("hold_blocker_weight", 2))
        self.thin_max = int(v.get("thin_route_max", 1))
        self.push_delay = float(v.get("push_delay", 0.25))
        self.observe_fail = str(v.get("observe_fail", "release"))
        self.howl_power = float(v.get("howl_power", 0.2))
        self.rear_phys_mult = float(v.get("rear_physical_mult", 1.0))               # PA-215
        self.rear_phys_sides = set(v.get("rear_physical_sides", ["ally", "enemy"]))
        self._cur_action = None
        bp = v.get("body_physical") or {}
        self.body_phys_on = bool(bp.get("enabled", False))                  # PA-216
        self.body_phys_ref = float(bp.get("ref", 10.0))
        self.body_phys_p = float(bp.get("exponent", 0.5))
        self.rear_melee_displaces = bool(v.get("rear_melee_displaces", True))   # PA-201b
        self.pinned = {}          # uid -> 牽制した者のID（自分の次の手番が終わるまで）
        self._pin_clear = set()
        self.holding = set()      # 死守中
        self.howl = {}            # group -> 指名された標的ID
        self.howl_by = {}         # group -> 遠吠えしたリーダーID
        self.fixed = {}           # 観測で固定された意思: uid -> Decision
        self.fixed_info = {}      # 公開情報としての固定（詠唱中の詠唱者を観測した場合も含む）
        self._last_final = None
        # ---- Ver0.16（PA-230〜236）
        dv = v.get("device") or {}
        self.device_on = bool(dv.get("enabled", False))
        self.armor_cap = dv.get("armor_cap", None)          # 数値 or {unit_id: 数値}。None=上限なし
        if self.device_on:
            self.aegis_on = True                             # 介入は「鎧を飛ばす」形だけ
            self.aegis_mult = float(dv.get("armor_cost_mult", 1.0))
        od = v.get("observe_depth", [1, 1])
        self.obs_depth = (int(od[0]), int(od[1])) if isinstance(od, (list, tuple)) else (int(od), int(od))
        self.rng_obs = random.Random(seed * 7_919 + 16)     # 既存の乱数系列を変えないよう別系列
        self.reserve = {}         # 固定された意思のために確保するもの: uid -> {"ep": n, "uses": aid or None}
        self._exec_fixed = False
        self.precommit = self.device_on and dv.get("mode") == "precommit"     # Ver0.17（PA-240）
        self.ally_shield_delay = float(dv.get("ally_shield_delay", 0.0))
        self.shield_range = str(dv.get("shield_range", "any"))                # PA-248
        self.shield_min_ep = int(dv.get("min_ep", 0))                        # PA-266 鎧を張るのに残っていなければならないEP
        self.prebattle = bool(dv.get("prebattle", True))                     # PA-249/250 False=奇襲（準備なし）
        self.ambush_first_strike = bool(v.get("ambush_first_strike", False))  # PA-254 奇襲: 敵が必ず先に動く
        self.layers = {}          # 鎧を着ている者 -> [張った者のID,...]（末尾が外側）
        self.shield_of = {}       # 張った者 -> [張った相手, ...]（1枚ごと。重戦士は2枚まで）
        self.jobs = v.get("jobs") or {}                                       # PA-258 ジョブ
        self._delay_count = {}
        self._delay_next = set()
        self._layer_self = False
        # ---- PA-259 知能の個体値（＋難易度のずらし＋リーダーがいる間は群れの仲間が1段階上）
        self.base_intel = {}
        if v.get("intel_model") == "base":
            off = (int(enemy_intel) - 1) if enemy_intel is not None else 0
            for u in self.state.side_units(Side.ENEMY, alive_only=False):
                b = int(u.d.intelligence if u.d.intelligence is not None else 1)
                self.base_intel[u.id] = max(0, min(3, b + off))
            leaders = {u.d.group for u in self.state.side_units(Side.ENEMY) if u.d.is_leader and u.d.group}
            for u in self.state.side_units(Side.ENEMY, alive_only=False):
                boost = 1 if (u.d.group in leaders and not u.d.is_leader) else 0
                u.intel_effective = max(0, min(3, self.base_intel[u.id] + boost))
        # ---- PA-260 ヘイト（本能）と判断（理性）
        hc = v.get("hate") or {}
        self.hate_on = bool(hc.get("enabled", False))
        self.hate_judgment = float(hc.get("judgment", 50))
        self.hate_bonus = {int(k): float(x) for k, x in (hc.get("bonus") or {0: 0, 1: 10, 2: 25, 3: 40}).items()}
        self.hate_instinct = {int(k): float(x) for k, x in (hc.get("instinct") or {0: 1.0, 1: 0.5, 2: 0.3, 3: 0.2}).items()}
        self.hate_body_hit = float(hc.get("body_hit", 15))
        self.hate_actions = dict(hc.get("actions") or {})
        self.hate_decay = float(hc.get("decay", 0.5))
        self.hate = {}            # 敵ID -> {味方ID: ヘイト}
        self.hate_cap = float(hc["cap"]) if hc.get("cap") is not None else None     # PA-265 上限
        # ---- PA-262〜264 同時行動（一騎打ち・死角攻撃）
        cc = v.get("clash") or {}
        self.clash_on = bool(cc.get("enabled", False))
        self.clash_window = float(cc.get("window", 0.05))
        self.clash_stagger = float(cc.get("stagger", 0.5))
        self.blind_mult = float(cc.get("blind_mult", 1.5))
        self.clash_mix = {int(k): list(x) for k, x in (cc.get("enemy_mix") or {}).items()}
        self.clash_random = bool(cc.get("random_simul", True))   # PA-262 偶然の同時行動（Ver0.18改で無効）
        ch = v.get("charge") or {}
        self.charge_on = bool(ch.get("enabled", False))           # PA-267 侍の「ため斬り」
        self.charge_per_T = float(ch.get("per_T", 1.0))
        self.charge_max = float(ch.get("max_mult", 2.0))
        self.charge_avoid = {int(k): float(x) for k, x in (ch.get("enemy_avoid") or {}).items()}
        self.charge_break = {int(k): float(x) for k, x in (ch.get("enemy_break") or {}).items()}
        self.charging = {}        # ため中: uid -> ためを始めた時刻
        self.charge_ready = {}    # 次の手番でためを放つ: uid -> 倍率
        self._clash_mult = 1.0
        self.duel_raw = {}
        self._stagger = set()
        self.simul_with = {}      # 同時行動の相手（表示用）: uid -> 相手ID
        self._fs_until = None     # 奇襲で敵が先に動き終わる時刻（その間は同時行動にしない）
        sb = v.get("skill_ep_body") or {}                                  # PA-257 技のEPを実効肉体強度で補正
        self.skill_body_actions = set(sb.get("actions", []) or [])
        self.skill_body_p = float(sb.get("exponent", 1.0))
        ref = sb.get("ref_unit")
        self.skill_body_ref = (self.defense.required_ep(self.u(ref), 1.0)
                               if ref and ref in self.state.units else None)
        bl = v.get("blood") or {}
        self.blood_on = bool(bl.get("enabled", False))
        self.blood_units = set(bl.get("units", []) or [])
        self.blood_rate = float(bl.get("hp_per_ep", 1.0))

    # ------------------------------------------------------------ 経路の薄さ
    def route_weight(self, r) -> int:
        return sum(self.hold_w if b in self.holding else 1 for b in holding_blockers(r, self.state.units))

    def breach_reach(self, attacker, target) -> ReachResult:
        if not can_use_melee(attacker):
            return ReachResult(False, reason="後衛は近接攻撃不可")
        if target.rank is not Rank.REAR:
            return ReachResult(False, reason="突撃・回り込みは後衛だけを狙う")
        routes = [r for r in self.state.routes[target.side] if target.id in r.protects]
        if not routes:
            return ReachResult(True, reason="この後衛を守る経路なし")
        best = min(routes, key=self.route_weight)
        w = self.route_weight(best)
        if w <= self.thin_max:
            hb = holding_blockers(best, self.state.units)
            return ReachResult(True, via_route=best.id, reason=f"経路{best.id}が薄い（塞ぎ手{w}）",
                               blocked_by=hb)
        return ReachResult(False, reason=f"経路{best.id}の塞ぎ手が厚い（{w}）")

    def reach(self, attacker, target, action):
        if action.special in BREACH:
            return self.breach_reach(attacker, target)
        if action.basic and target.rank is Rank.REAR and self.jobs and self.guard_active(target.side):
            return ReachResult(False, reason="重戦士が立っていて、後衛には通常攻撃が届かない (PA-258)")
        return super().reach(attacker, target, action)

    # ------------------------------------------------------------ 行動の候補
    def available_actions(self, u):
        out = []
        for a in super().available_actions(u):
            sp = a.special
            if sp in PIN_BLOCKED and (u.id in self.pinned or u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp and sp != "hold" and not self.valid_targets(u, a):
                continue
            if sp == "hold" and (u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp == "focus" and (u.ep >= u.d.ep_max or (self.device_on and not self.device_ready(u))):
                continue
            if a.id in self.skill_body_actions and self.ep_cost(u, a) > self.spendable_ep(u, a):
                continue                                   # PA-257 補正後のEPが足りない
            rs = self.reserve.get(u.id)
            if rs and not self._exec_fixed:
                if a.id in self.cast_time:
                    continue                    # 固定された未来の手番より前に、詠唱を始めない（PA-233）
                if rs["uses"] == a.id and u.uses.get(a.id, 0) <= 1:
                    continue
            out.append(a)
        return out

    def valid_targets(self, u, a):
        sp = a.special
        st = self.state
        if sp in BREACH:
            return [t for t in st.target_candidates(u.side.other, u.side)
                    if t.rank is Rank.REAR and self.breach_reach(u, t).ok]
        if sp in ("pin", "push"):
            return [t for t in st.side_units(u.side.other) if t.rank is Rank.FRONT and can_use_melee(u)]
        if sp == "hold":
            return [u]
        if sp == "howl":
            return st.side_units(u.side.other)
        if sp == "observe":
            return st.side_units(u.side.other)
        if sp == "focus":
            return [u]
        if sp == "charge":
            return [] if u.id in self.charge_ready or u.id in self.charging else [u]
        if a.kind is ActionKind.ATTACK and a.area == "front":
            return [t for t in super().valid_targets(u, a) if t.rank is Rank.FRONT]      # PA-256 相手の前列全員
        out = super().valid_targets(u, a)
        if a.kind is ActionKind.ATTACK and a.basic and out and self.guard_active(u.side.other):
            out = [t for t in out if t.rank is not Rank.REAR]   # PA-258 重戦士が立っている間、後衛は通常攻撃で狙えない
        return out

    # ------------------------------------------------------------ フック
    def _iv_ok(self, c) -> bool:
        if getattr(self, "precommit", False):
            return False                              # Ver0.17: 割り込む介入はない
        return c.id not in self.pinned and c.id not in self.holding

    # ------------------------------------------------------------ Ver0.16 エーテル防御装置（PA-230/231）
    def defense_allowed(self, c) -> bool:
        if getattr(self, "precommit", False):
            return False                              # Ver0.17: 受ける瞬間の防御はない（先に張った鎧だけ）
        return super().defense_allowed(c)

    def device_ready(self, c) -> bool:
        """装置をいま使えるか（自分の手番から次の自分の手番までに1回）。"""
        return c.id not in self.aegis_used

    def cap_of(self, c):
        cap = self.armor_cap
        if isinstance(cap, dict):
            cap = cap.get(c.id, cap.get("default"))
        return None if cap is None else float(cap)

    def _on_self_defense(self, u):
        if self.device_on:
            self.aegis_used.add(u.id)
            self.stats.c[f"v16_device_self_{u.side.value}"] += 1

    def _adjust_iv_choice(self, choice):
        if self.device_on and choice is not None and choice.interceptor_id:
            choice.mode = "aegis"
        return choice

    def _on_aegis(self, aegis, target, attacker, action, choice):
        """介入者は持ち場を離れる（PA-231）。鎧は守られる側がまとう。"""
        if not self.device_on:
            return
        st = self.state
        side = target.side.value
        before = self.route_snapshot()
        transition(aegis, Stance.INTERVENING, self.emit, f"{target.name}へ装置の鎧を飛ばした（持ち場を離れる）")
        self.recovery.on_intervened(aegis, self)
        transition(aegis, Stance.GUARDING, self.emit, "鎧を飛ばした（次の自分の手番まで持ち場の外・生身）")
        opened = [r.id for r in st.routes_blocked_by(aegis.id)
                  if before[r.id] == "BLOCK" and not route_blocked(r, st.units)]
        self.stats.c[f"intervention_{side}"] += 1
        self.stats.c[f"front_open_{side}"] += len(opened)
        self.stats.c[f"front_open_by_intervention_{side}"] += len(opened)
        for rid in opened:
            self.emit("route_change", route=rid, status="OPEN", cause=f"{aegis.name}が持ち場を離れた")

    def _aegis_block(self, c, raw):
        """介入の鎧（PA-231）: 上限まで、介入者のEPで防ぐ。上限を超えた分は余波として通る。"""
        if not self.device_on:
            return super()._aegis_block(c, raw)
        cap = None if self._layer_self else self.cap_of(c)     # 自分の鎧には上限なし
        self._layer_self = False
        part = raw if cap is None else min(raw, cap)
        over = raw - part
        leak, spent, mode = super()._aegis_block(c, part)
        side = c.side.value
        if over > 0:
            self.stats.c[f"v16_armor_pierce_{side}"] += 1
            self.stats.c[f"v16_armor_over_{side}"] += over
            self.emit("armor_pierce", unit=c.id, raw=round(raw, 1), cap=cap, over=round(over, 1))
            mode = "armor_pierce"
        return leak + over, spent, mode

    def _raw_mult(self, final, attacker=None, target=None) -> float:
        self._last_final = final
        m = self.hold_mult if final.id in self.holding else 1.0
        a = self._cur_action
        if (self.rear_phys_mult != 1.0 and a is not None and a.source == "power" and final.rank is Rank.REAR
                and final.side.value in self.rear_phys_sides):
            m *= self.rear_phys_mult        # PA-215: 後衛は物理攻撃に脆い（庇われた場合は受けた前衛に掛からない）
            self.stats.c[f"v15_rear_phys_hit_{final.side.value}"] += 1
        if attacker is not None and target is not None and attacker.d.group:
            if self.howl.get(attacker.d.group) == target.id and self.howl_by.get(attacker.d.group) != attacker.id:
                m *= 1.0 + self.howl_power          # PA-206: 遠吠えで指名された標的への群れの攻撃は威力+20%
                self.stats.c[f"v15_howl_hit_{attacker.side.value}"] += 1
        if self._clash_mult != 1.0:
            m *= self._clash_mult           # PA-263/264 一騎打ちの力比べ・死角攻撃（鎧に通す前に掛ける）
        return m

    # ------------------------------------------------------------ 手番の始まり・終わり
    def _v08_turn_start(self, actor):
        super()._v08_turn_start(actor)
        if getattr(self, "precommit", False) and self.shield_of.get(actor.id):
            for t in self._remove_layers(actor.id):        # 前の手番で張った鎧は、次の自分の手番で消える
                self.stats.c[f"v17_layer_expired_{actor.side.value}"] += 1
                self.emit("armor_expire", unit=actor.id, target=t)
        if actor.stance is Stance.DIVING and actor.alive:
            before = self.route_snapshot()
            transition(actor, Stance.READY, self.emit, "突撃・回り込みから持ち場へ戻った (PA-201)")
            self.emit("dive_return", unit=actor.id)
            after = self.route_snapshot()
            for rid, s in after.items():
                if before.get(rid) == "OPEN" and s == "BLOCK":
                    self.emit("route_change", route=rid, status="BLOCK", cause=f"{actor.name}が持ち場へ戻った")
        if actor.id in self.holding:
            self.holding.discard(actor.id)
            self.emit("hold_end", unit=actor.id)
        for g, lid in list(self.howl_by.items()):
            if lid == actor.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)
                self.emit("howl_end", unit=actor.id)
        if actor.id in self.pinned:
            self._pin_clear.add(actor.id)
        if actor.id in self.casting and actor.id in self.fixed_info:
            self.fixed_info.pop(actor.id, None)
        self.charge_ready.pop(actor.id, None)
        if actor.id in self.charging:                      # PA-267 誰も来なかった: この手番で、ためた威力を放てる
            m = self.charge_mult(actor)
            self.charging.pop(actor.id, None)
            self.charge_ready[actor.id] = m
            self.emit("charge_ready", unit=actor.id, mult=round(m, 3))

    def _schedule_next(self, actor):
        super()._schedule_next(actor)
        if self.hate_on and actor.id in self.hate:
            # PA-260 ヘイトは自分の手番が終わるごとに冷める（判断に使ってから半分に）
            h = {k: x * self.hate_decay for k, x in self.hate[actor.id].items()}
            self.hate[actor.id] = {k: x for k, x in h.items() if x >= 1.0}
        if actor.id in self._delay_next:
            self._delay_next.discard(actor.id)
            nt = self.next_time.get(actor.id)
            if nt is not None and math.isfinite(nt):
                k = max(1, self._delay_count.pop(actor.id, 1))
                self.next_time[actor.id] = nt + self.ally_shield_delay * k  # 仲間に張った代償（PA-242。枚数ぶん）
        if actor.id in self._stagger:
            self._stagger.discard(actor.id)
            nt = self.next_time.get(actor.id)
            if nt is not None and math.isfinite(nt):
                self.next_time[actor.id] = nt + self.clash_stagger     # PA-263 弾かれた・崩された
        if actor.id in self._pin_clear:
            self._pin_clear.discard(actor.id)
            if self.pinned.pop(actor.id, None) is not None:
                self.emit("pin_end", unit=actor.id)

    # ------------------------------------------------------------ Ver0.17 先に張る鎧（PA-240〜245）
    def layers_on(self, uid):
        return self.layers.get(uid, [])

    def can_shield(self, giver, target) -> bool:
        """PA-248 鎧を張れる範囲。lanes: 自分／前衛どうし／担当の後衛（経路の塞ぎ手＝介入担当範囲）／後衛どうし（PA-248b）。"""
        if target.side is not giver.side or target.hp <= 0:
            return False                                   # 戦闘不能者（HP>0）には張れる。死亡者には張れない
        if target.id in getattr(self, "charging", {}) and giver.id != target.id:
            return False                                   # PA-267 ため中の者には、仲間も鎧を張れない
        if giver.id == target.id or self.shield_range != "lanes":
            return True
        if giver.rank is not Rank.FRONT:
            return target.rank is not Rank.FRONT          # PA-248b 後衛は後衛どうしで張り合える（前衛には張れない）
        if target.rank is Rank.FRONT:
            return True
        return any(giver.id in r.blockers for r in self.state.routes[target.side] if target.id in r.protects)

    # ------------------------------------------------------------ PA-258 ジョブ
    def job_of(self, u) -> dict:
        return self.jobs.get(u.d.job, {}) if u.d.job else {}

    def shields_per_turn(self, u) -> int:
        return int(self.job_of(u).get("shields_per_turn", 1))

    def guard_active(self, side) -> bool:
        """side に「後衛への通常攻撃を防ぐ」者（重戦士）が戦闘可能で立っているか。"""
        return any(self.job_of(u).get("guard_rear") for u in self.state.side_units(side))

    def _remove_layers(self, giver_id):
        out = []
        for t in self.shield_of.pop(giver_id, []):
            ls = self.layers.get(t, [])
            if giver_id in ls:
                ls.reverse(); ls.remove(giver_id); ls.reverse()          # 外側から1枚ずつ
                out.append(t)
        return out

    def _remove_layer(self, giver_id):
        ts = self._remove_layers(giver_id)
        return ts[0] if ts else None

    def _add_layer(self, giver, sid):
        self.layers.setdefault(sid, []).append(giver.id)
        self.shield_of.setdefault(giver.id, []).append(sid)

    def _forced_aegis(self, target, attacker, action):
        if not self.precommit:
            return None
        if action is not None and action.special == "shock":
            return None                                    # PA-261 エーテル無視の衝撃波: 鎧を素通りする（鎧は割れない）
        ls = self.layers.get(target.id)
        if not ls:
            self.stats.c[f"v17_hit_bare_{target.side.value}"] += 1
            return None
        gid = ls.pop()                                    # 外側から割れる
        if target.id in self.shield_of.get(gid, []):
            self.shield_of[gid].remove(target.id)
        g = self.u(gid)
        self._layer_self = gid == target.id
        side = target.side.value
        self.stats.c[f"v17_layer_used_{'self' if self._layer_self else 'other'}_{side}"] += 1
        self.emit("armor_hit", unit=gid, target=target.id, self_layer=self._layer_self, left=len(ls),
                  area=action.area == "all")
        return g

    def run(self):
        if self.precommit and self.prebattle and not getattr(self, "_prebattle_done", False):
            self._prebattle_done = True
            self._pre_battle()
        if self.ambush_first_strike and not getattr(self, "_ambush_done", False):
            self._ambush_done = True
            self._first_strike(Side.ENEMY)
        return super().run()

    def _first_strike(self, side):
        """PA-254 奇襲: side の全員の最初の行動が終わるまで、相手側は動けない。相手側どうしの順番（速さの差）は保つ。"""
        st = self.state
        first = [self.next_time[u.id] for u in st.side_units(side) if math.isfinite(self.next_time.get(u.id, math.inf))]
        others = [u for u in st.side_units(side.other) if math.isfinite(self.next_time.get(u.id, math.inf))]
        if not first or not others:
            return
        t_last = max(first)
        self._fs_until = t_last
        t0 = min(self.next_time[u.id] for u in others)
        for u in others:
            self.next_time[u.id] = t_last + 0.01 + (self.next_time[u.id] - t0)
        self.stats.c[f"v17_first_strike_{side.value}"] += 1
        self.emit("first_strike", side=side.value, until=round(t_last, 4))

    def _pre_battle(self):
        """PA-249 戦闘前の準備: 各自が、最初の自分の手番まで張っておく鎧を決める（プレイヤー・AI）。"""
        for side in (Side.ALLY, Side.ENEMY):
            ctl = self.controllers[side]
            for u in list(self.state.side_units(side)):
                if not u.alive:
                    continue
                if hasattr(ctl, "decide_preshield"):
                    got = ctl.decide_preshield(u)
                else:
                    got = u.id if u.ep > 0 else None
                sids = list(got) if isinstance(got, (list, tuple)) else [got]
                sids = sids[:self.shields_per_turn(u)]
                placed = 0
                for sid in sids:
                    t = self.state.units.get(sid) if sid else None
                    if t is None or not self.can_shield(u, t) or u.id in self.casting or u.ep < self.shield_min_ep:
                        sid = None
                    self.stats.c[f"v17_pre_{'none' if sid is None else ('self' if sid == u.id else 'other')}_{side.value}"] += 1
                    if sid is None:
                        continue
                    self._add_layer(u, sid)
                    placed += 1
                    self.emit("shield", unit=u.id, target=sid, layers=len(self.layers[sid]), prebattle=True)
                if not placed:
                    self.emit("shield", unit=u.id, target=None, prebattle=True)

    def _choose_shield(self, actor, dec):
        """手番の行動と一緒に、鎧を張る先を決める（PA-241）。重戦士は2枚まで（PA-258）。"""
        n = self.shields_per_turn(actor)
        tags = dec.tags or {}
        if n > 1 or "shields" in tags:
            if "shields" in tags:
                sids = list(tags["shields"])
            elif "shield" in tags:
                sids = [tags["shield"]] + ([tags["shield2"]] if "shield2" in tags else [])
            else:
                ctl = self.controllers[actor.side]
                if hasattr(ctl, "decide_shields"):
                    sids = list(ctl.decide_shields(actor, dec, n))
                else:
                    sids = [ctl.decide_shield(actor, dec)] if hasattr(ctl, "decide_shield") else [actor.id]
            sids = [x for x in sids[:n]]
            if not any(sids):
                sids = [None]
            self._delay_count[actor.id] = 0
            for sid in sids:
                self._choose_shield_one(actor, dec, sid, {k: v for k, v in tags.items() if k != "fixed_shield"})
            return
        if "shield" in tags:
            sid = tags["shield"]
        else:
            ctl = self.controllers[actor.side]
            sid = ctl.decide_shield(actor, dec) if hasattr(ctl, "decide_shield") else (actor.id if actor.ep > 0 else None)
        self._delay_count[actor.id] = 0
        self._choose_shield_one(actor, dec, sid, tags)

    def _choose_shield_one(self, actor, dec, sid, tags):
        a = self.actions.get(dec.action_id)
        cast_start = a is not None and a.id in self.cast_time and not tags.get("cast_complete")
        if a is not None and a.special in ("focus", "charge"):
            sid = None                                     # 集中した手番は装置を使えない（PA-235）・ためる手番も張れない（PA-267）
        fixed_sid = sid if tags.get("fixed_shield") else None
        if sid is not None:
            t = self.state.units.get(sid)
            if t is None or t.side is not actor.side or t.hp <= 0 or (cast_start and sid == actor.id) \
                    or not self.can_shield(actor, t):
                sid = None                                 # 詠唱を始めた者は自分には張れない（PA-130）・範囲外（PA-248）
        if sid is not None and self.shield_min_ep > 0 and self.shield_ep_left(actor, dec, tags) < self.shield_min_ep:
            self.stats.c[f"v18_shield_no_ep_{actor.side.value}"] += 1
            self.emit("shield_no_ep", unit=actor.id, target=sid, ep=self.shield_ep_left(actor, dec, tags))
            sid = None                                     # PA-266 EPが残らない者は鎧を張れない（空の鎧が先に割れるのを防ぐ）
        side = actor.side.value
        if fixed_sid is not None and sid is None:
            # 固定された鎧が成り立たない（相手が死亡・範囲外など）→ 鎧は張れずに終わる。行動はそのまま（PA-255 a）
            self.stats.c[f"v17_fixed_shield_broken_{side}"] += 1
            self.emit("fixed_shield_broken", unit=actor.id, target=fixed_sid)
        elif tags.get("fixed_shield"):
            self.stats.c[f"v17_fixed_shield_{side}"] += 1
        if sid is None:
            self.stats.c[f"v17_shield_none_{side}"] += 1
            self.emit("shield", unit=actor.id, target=None)
            return
        self._add_layer(actor, sid)
        self.stats.c[f"v17_shield_{'self' if sid == actor.id else 'other'}_{side}"] += 1
        if sid != actor.id and self.ally_shield_delay > 0:
            self._delay_next.add(actor.id)
            self._delay_count[actor.id] = self._delay_count.get(actor.id, 0) + 1     # 仲間に張った枚数ぶん遅れる
        self.emit("shield", unit=actor.id, target=sid, layers=len(self.layers[sid]))

    def shield_ep_left(self, actor, dec, tags=None):
        """PA-266 この手番の行動でEPを払ったあとに残るEP（鎧はこのEPで受ける）。詠唱を始める手番は発動時に払うので引かない。"""
        a = self.actions.get(dec.action_id) if dec is not None else None
        tags = tags if tags is not None else (dec.tags or {} if dec is not None else {})
        if a is None or a.kind is ActionKind.WAIT or (a.id in self.cast_time and not tags.get("cast_complete")):
            return actor.ep
        return actor.ep - self.ep_cost(actor, a)

    # ------------------------------------------------------------ Ver0.16 前借り（PA-234）・確保（PA-233）
    def ep_cost(self, u, a) -> int:
        """PA-257 行動のEP。指定の技は、防御装置と同じ「実効肉体強度（今のHP×負傷）」で増減する。
        消費 = 基本 ×（u の 1ダメージあたりの防御EP ÷ 基準キャラの満タン時のそれ）^exponent。"""
        if a.id in self.skill_body_actions and self.skill_body_ref and a.ep_cost > 0:
            r = self.defense.required_ep(u, 1.0) / max(self.skill_body_ref, 1e-9)
            return max(1, int(round(a.ep_cost * r ** self.skill_body_p)))
        return a.ep_cost

    def blood_capacity(self, u) -> int:
        """HPで払えるEPの量（戦闘不能ラインより上に残る範囲）。"""
        if not (self.blood_on and u.id in self.blood_units) or not u.alive:
            return 0
        floor = math.floor(u.incap_ratio * u.d.hp_max) + 1 if u.incap_ratio > 0 else 1
        return max(0, int((u.hp - floor) / self.blood_rate))

    def spendable_ep(self, u, a=None) -> int:
        e = super().spendable_ep(u, a)
        rs = self.reserve.get(u.id)
        if rs and not self._exec_fixed:
            e -= rs["ep"]
        if a is not None and a.ep_cost > 0:
            e += self.blood_capacity(u)
        return e

    def _can_pay(self, actor, a) -> bool:
        return actor.ep + self.blood_capacity(actor) >= self.ep_cost(actor, a)

    def _pay(self, actor, a) -> int:
        cost = self.ep_cost(actor, a)
        if actor.ep >= cost:
            actor.ep -= cost
            return cost
        paid = int(actor.ep)
        short = cost - paid
        hp = int(math.ceil(short * self.blood_rate - 1e-9))
        actor.ep = 0
        actor.hp = max(1, actor.hp - hp)
        self.stats.c[f"v16_blood_{actor.side.value}"] += 1
        self.stats.c[f"v16_blood_hp_{actor.side.value}"] += hp
        self.emit("blood_pay", unit=actor.id, action=a.id, ep=paid, hp=hp, hp_left=actor.hp)
        return paid

    # ------------------------------------------------------------ 観測固定（PA-208）
    def _feasible(self, actor, dec) -> tuple[bool, str]:
        a = self.actions.get(dec.action_id)
        if a is None:
            return False, "不明な行動"
        if a.kind is ActionKind.WAIT:
            return True, ""
        if a.id not in {x.id for x in self.available_actions(actor)}:
            if a.special in PIN_BLOCKED and actor.id in self.pinned:
                return False, "牽制されて使えない"
            if self.ep_cost(actor, a) > self.spendable_ep(actor, a):
                return False, "EP不足"
            return False, "その行動が使えない"
        if dec.target_id is None:
            return True, ""
        t = self.u(dec.target_id)
        if a.kind is ActionKind.ATTACK and a.area in ("all", "front"):
            return (bool([x for x in self.valid_targets(actor, a) if x.alive]), "届く相手がいない")
        if t not in self.valid_targets(actor, a):
            return False, f"{t.name}に届かない／対象にできない"
        if a.kind is ActionKind.ATTACK and not t.alive and not t.incapacitated:
            return False, f"{t.name}がいない"
        return True, ""

    def _decide(self, actor):
        dec = self._decide_v15(actor)
        if self.precommit and actor.alive:
            self._choose_shield(actor, dec)
        return dec

    def _decide_v15(self, actor):
        for a in self.available_actions(actor):          # 記録用: 使える状態だった回数（使用率の分母）
            if a.special or a.id in ("maintain", "curse", "storm", "focus"):
                self.stats.c[f"v15_avail_{a.id}_{actor.id}"] += 1
        fx = self.fixed.get(actor.id)
        if fx is not None:
            left = int((fx.tags or {}).get("obs_left", 1))
            if left > 1:
                # まだその手番ではない（PA-233）: 自由に動くが、固定された未来を自分で壊す行動は選べない
                fx.tags["obs_left"] = left - 1
                self.stats.c[f"v16_fixed_wait_{actor.side.value}"] += 1
                self.emit("fixed_pending", unit=actor.id, action=fx.action_id, target=fx.target_id, left=left - 1)
                return super()._decide(actor)
            self.fixed.pop(actor.id, None)
        self.fixed_info.pop(actor.id, None)
        if fx is not None:
            self._exec_fixed = True
            try:
                ok, why = self._feasible(actor, fx)
            finally:
                self._exec_fixed = False
                self.reserve.pop(actor.id, None)
            if ok:
                self.stats.c[f"v15_fixed_exec_{actor.side.value}"] += 1
                self.emit("fixed_execute", unit=actor.id, action=fx.action_id, target=fx.target_id)
                return Decision(fx.action_id, fx.target_id, reasons=["観測で固定された意思（心変わりできない）"] + list(fx.reasons),
                                tags={**(fx.tags or {}), "fixed": True})
            self.stats.c[f"v15_fixed_broken_{actor.side.value}"] += 1
            self.emit("fixed_broken", unit=actor.id, action=fx.action_id, target=fx.target_id, why=why,
                      mode=self.observe_fail)
            if self.observe_fail == "lose":
                self.stats.c[f"v15_fixed_lost_turn_{actor.side.value}"] += 1
                keep = {"shield": fx.tags["shield"], "fixed_shield": True} if "shield" in (fx.tags or {}) else {}
                return Decision("wait", reasons=[f"固定された意思が成立しない（{why}）→ 迷って手番を失う"], tags=keep)
        return super()._decide(actor)

    def _observe(self, actor, t):
        if t.id in self.casting:
            d = self.casting[t.id]["dec"]
            self.fixed_info[t.id] = d
            self.stats.c["v15_observe_casting"] += 1
            self.emit("observe", unit=actor.id, target=t.id, action=d.action_id, intent_target=d.target_id, casting=True)
            return
        dec = self.controllers[t.side].decide_action(t)
        lo, hi = self.obs_depth
        n = lo if hi <= lo else self.rng_obs.randint(lo, hi)
        dec.tags = {**(dec.tags or {}), "obs_left": n, "obs_depth": n}
        if self.precommit:
            # PA-255 その手番で張る鎧の相手も一緒に固定する（観測した瞬間の状況で決めさせる・公開）
            ctl = self.controllers[t.side]
            sid = ctl.decide_shield(t, dec) if hasattr(ctl, "decide_shield") else (t.id if t.ep > 0 else None)
            dec.tags["shield"] = sid
            dec.tags["fixed_shield"] = True
        self.fixed[t.id] = dec
        self.fixed_info[t.id] = dec
        a = self.actions.get(dec.action_id)
        if n > 1 and a is not None:
            self.reserve[t.id] = {"ep": a.ep_cost, "uses": a.id if a.uses is not None else None}
        self.stats.c[f"v16_observe_depth_{n}"] += 1
        self.emit("observe", unit=actor.id, target=t.id, action=dec.action_id, intent_target=dec.target_id,
                  casting=False, depth=n, shield=(dec.tags or {}).get("shield", "-"))

    # ------------------------------------------------------------ 実行
    def _execute(self, actor, dec):
        if self.charge_on:
            done = self._charge_hooks(actor, dec)
            if done:
                return
        a = self.actions[dec.action_id]
        sp = a.special
        side = actor.side.value
        if a.kind is ActionKind.SPECIAL:
            t = self.u(dec.target_id) if dec.target_id else None
            self.stats.c[f"v15_{sp}_{side}"] += 1
            if sp == "hold":
                self.holding.add(actor.id)
                self.emit("hold", unit=actor.id, reasons=dec.reasons)
            elif sp == "howl" and t is not None:
                g = actor.d.group or actor.id
                self.howl[g] = t.id
                self.howl_by[g] = actor.id
                self.emit("howl", unit=actor.id, target=t.id, reasons=dec.reasons)
            elif sp == "observe" and t is not None:
                self._observe(actor, t)
            elif sp == "charge":
                self.charging[actor.id] = self.cur_time
                self.stats.c[f"v18_charge_{side}"] += 1
                self.emit("charge_start", unit=actor.id, reasons=dec.reasons)
            elif sp == "focus":
                g = min(a.amount, actor.d.ep_max - actor.ep)
                actor.ep += g
                if self.device_on:
                    self.aegis_used.add(actor.id)        # 集中している間は装置を使えない（PA-235）
                self._check_ep(actor)
                self._update_collapse(actor, cause="supply")
                self.emit("focus", unit=actor.id, amount=g, ep=actor.ep, reasons=dec.reasons)
            else:
                self.emit("wait", unit=actor.id, reasons=dec.reasons)
            return
        if sp and not (a.id in self.cast_time and not dec.tags.get("cast_complete")):
            self.stats.c[f"v15_{sp}_{side}"] += 1
        rear_melee = (self.rear_melee_displaces and not sp and a.kind is ActionKind.ATTACK and a.area not in ("all", "front")
                      and a.reach is not None and a.reach.value == "MELEE" and dec.target_id
                      and self.u(dec.target_id).rank is Rank.REAR and not (a.id in self.cast_time and not dec.tags.get("cast_complete")))
        if sp in BREACH or rear_melee:
            target = self.u(dec.target_id)
            r = self.reach(actor, target, a)
            if not sp:
                sp = "rear_melee"
                self.stats.c[f"v15_rear_melee_{side}"] += 1
            if r.via_route and holding_blockers(next(x for x in self.state.all_routes() if x.id == r.via_route),
                                                self.state.units):
                self.stats.c[f"v15_{sp}_thin_{side}"] += 1
            if target.id in self.casting:
                self.stats.c[f"v15_{sp}_on_casting_{side}"] += 1
            before = self.route_snapshot()
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is not None and fin.id != target.id:
                self.stats.c[f"v15_{sp}_intercepted_{side}"] += 1
            if actor.alive and actor.stance is Stance.READY and r.ok:
                transition(actor, Stance.DIVING, self.emit, f"{a.name}で{target.name}へ踏み込んだ（持ち場を離れる）")
                after = self.route_snapshot()
                for rid, s in after.items():
                    if before.get(rid) == "BLOCK" and s == "OPEN":
                        self.stats.c[f"front_open_{side}"] += 1
                        self.stats.c[f"v15_open_by_{sp}_{side}"] += 1
                        self.emit("route_change", route=rid, status="OPEN", cause=f"{actor.name}が{a.name}で持ち場を離れた")
            return
        if sp in ("pin", "push"):
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is None or fin.side is actor.side or not fin.alive:
                return
            if sp == "pin":
                self.pinned[fin.id] = actor.id
                self._pin_clear.discard(fin.id)
                self.emit("pinned", unit=fin.id, by=actor.id)
            else:
                nt = self.next_time.get(fin.id)
                if nt is not None and math.isfinite(nt):
                    self.next_time[fin.id] = nt + self.push_delay
                    self.stats.c[f"v15_push_delay_{side}"] += self.push_delay
                    self.emit("pushed", unit=fin.id, by=actor.id, old=round(nt, 4), new=round(nt + self.push_delay, 4))
            return
        super()._execute(actor, dec)

    def _body_factor(self, final, attacker, action) -> float:
        """PA-216: 物理攻撃（威力が元）が生身に通る分は、受ける側の「肉体」で増減する。
        倍率 = (ref / 肉体)^exponent。肉体が弱いほど深く傷つく。魔法には掛からない（肉体では防げない）。"""
        jm = float(self.job_of(final).get("damage_taken", 1.0)) if hasattr(self, "jobs") else 1.0   # PA-268 侍は脆い
        if not self.body_phys_on or action is None or action.source != "power":
            return jm
        b = max(1.0, float(final.d.body))
        return jm * (self.body_phys_ref / b) ** self.body_phys_p

    def recent_hits(self, uid, window):
        """直近 window T の間に、uid が攻撃の対象になった回数（戦場で見えている公開情報）。"""
        t0 = self.cur_time - window
        return sum(1 for t in getattr(self, "hit_log", {}).get(uid, ()) if t >= t0 - 1e-9)

    def _resolve_attack(self, attacker, a, target, dec, no_iv=False):
        if not hasattr(self, "hit_log"):
            self.hit_log = {}
        self.hit_log.setdefault(target.id, []).append(self.cur_time)
        self._cur_action = a
        hp0 = target.hp
        try:
            return super()._resolve_attack(attacker, a, target, dec, no_iv=no_iv)
        finally:
            self._cur_action = None
            if target.id in self.charging and attacker.side is not target.side and target.alive \
                    and (not self.is_melee(a) or a.area in ("all", "front")):
                old = self.charge_mult(target)
                self.charging[target.id] = self.cur_time          # PA-268 魔法・遠隔・範囲で集中が途切れる → 1.0倍からため直し
                self.stats.c[f"v18_charge_reset_{target.side.value}"] += 1
                self.emit("charge_reset", unit=target.id, by=attacker.id, old=round(old, 3))
            if self.hate_on and attacker.side is not target.side and target.side is Side.ENEMY:
                self._gain_hate(target, attacker, a, hp0 - target.hp)

    # ------------------------------------------------------------ PA-262〜264 同時行動（一騎打ち・死角攻撃）
    def _simul_partner(self, actor):
        """actor とほぼ同時（window T 以内）に動く、相手側の1人（いちばん近い者）。詠唱中の者は除く。"""
        if not self.clash_on or not self.clash_random or actor.id in self.casting:
            return None
        t = self.cur_time
        if self._fs_until is not None and t <= self._fs_until + 1e-9:
            return None                                    # 奇襲で敵が先に動いている間は同時にしない
        best = None
        for u in self.state.side_units(actor.side.other):
            nt = self.next_time.get(u.id, math.inf)
            if not u.alive or not math.isfinite(nt) or u.id in self.casting:
                continue
            d = nt - t
            if -1e-9 <= d <= self.clash_window + 1e-9 and (best is None or d < best[0]):
                best = (d, u)
        return best[1] if best else None

    def _turn_open(self, actor, simul_with=None):
        """手番の始まり（基本エンジンの _take_turn の前半と同じ）。False なら行動できない。"""
        self.current_actor = actor
        self.action_index += 1
        self.side_turns[actor.side.value] += 1
        self.track[actor.id]["v6_turns"] += 1
        nxt = [s.unit_id for s in self.upcoming_slots(0)][:6]
        self.emit("turn_start", unit=actor.id, upcoming=nxt, snap=actor.short(), intel=actor.intel_effective,
                  routes=self.route_snapshot(), simul=simul_with)
        self._v08_turn_start(actor)
        if not self.recovery.on_own_turn_start(actor, self):
            self.emit("turn_skipped", unit=actor.id, reason="持ち場への復帰に手番を使用")
            return False
        return True

    @staticmethod
    def is_melee(a) -> bool:
        """近接攻撃か（PA-269: 跳躍襲撃のように、遠くから届いても体ごとぶつかる攻撃は近接扱い）。"""
        return (a.reach is not None and a.reach.value == "MELEE") or bool(getattr(a, "contact", False))

    def melee_single(self, u, dec):
        """単体を狙う近接攻撃なら、その標的を返す（一騎打ち・死角攻撃の対象になる行動）。"""
        if dec is None or not dec.target_id:
            return None
        a = self.actions.get(dec.action_id)
        if a is None or a.kind is not ActionKind.ATTACK or a.area in ("all", "front"):
            return None
        if not self.is_melee(a):
            return None
        if a.id in self.cast_time and not (dec.tags or {}).get("cast_complete"):
            return None
        t = self.state.units.get(dec.target_id)
        if t is None or t.side is u.side:
            return None
        return t

    def _take_turn(self, actor):
        b = self._simul_partner(actor)
        if b is None:
            return super()._take_turn(actor)
        a = actor
        self.simul_with = {a.id: b.id, b.id: a.id}
        self._pair_ids = (a.id, b.id)
        gap = self.next_time[b.id] - self.cur_time
        self.stats.c["v18_simul"] += 1
        try:
            da = self._decide(a) if self._turn_open(a) else None
            self.time_log.append((b.id, self.cur_time))
            self.emit("simul", unit=a.id, other=b.id, gap=round(gap, 4))
            db = self._decide(b) if (b.alive and self._turn_open(b, simul_with=a.id)) else None
        finally:
            self.simul_with = {}
        tb = self.cur_time + gap
        self._resolve_pair(a, da, b, db)
        self._pair_ids = ()
        # b の次の手番は、本来の自分の時刻から数える（同時になったことで得も損もしない）
        t0 = self.cur_time
        self.current_actor = b
        self.cur_time = max(t0, tb)
        try:
            self._schedule_next(b)
        finally:
            self.cur_time = t0
        self._rescale_all(skip=b)
        self.current_actor = a

    def _run_dec(self, u, d, check=False):
        """決めておいた行動を実行する（同時に動いた相手のせいで成り立たなくなっていたら手番を失う）。"""
        if d is None or not u.alive:
            return
        self.current_actor = u
        if check:
            ok, why = self._feasible(u, d)
            if not ok:
                self.stats.c[f"v18_simul_void_{u.side.value}"] += 1
                self.emit("simul_void", unit=u.id, action=d.action_id, why=why)
                return
        self._execute(u, d)

    def _spend_only(self, u, d):
        """攻撃はしたが当たらなかった: EP（と使用回数）だけ払う。"""
        a = self.actions[d.action_id]
        if a.ep_cost:
            paid = self._pay(u, a)
            self._consume_packets(u, paid, 0.0)
            self._check_ep(u)
            self._update_collapse(u, cause="spend")
        if a.uses is not None:
            u.uses[a.id] -= 1

    def _exec_mult(self, u, d, mult):
        self.current_actor = u
        self._clash_mult = mult
        try:
            self._execute(u, d)
        finally:
            self._clash_mult = 1.0

    def _resolve_pair(self, a, da, b, db):
        ta, tb = self.melee_single(a, da), self.melee_single(b, db)
        if ta is not None and tb is not None and ta.id == b.id and tb.id == a.id:
            return self._duel(a, da, b, db)
        if ta is not None and ta.id == b.id and tb is not None:
            return self._blindside(a, da, b, db)
        if tb is not None and tb.id == a.id and ta is not None:
            return self._blindside(b, db, a, da)
        self._run_dec(a, da)
        if self._check_end():
            return
        self._run_dec(b, db, check=True)

    def _blindside(self, x, dx, y, dy):
        """PA-264 x が、よそ（z）を殴ろうとしている y の死角を突く。y の攻撃は中断。"""
        z = self.u(dy.target_id)
        self.stats.c[f"v18_blind_{x.side.value}"] += 1
        self.emit("blindside", unit=x.id, target=y.id, victim_target=z.id, mult=self.blind_mult)
        self._exec_mult(x, dx, self.blind_mult)
        self.stats.c[f"v18_blind_interrupted_{y.side.value}"] += 1
        self.emit("blind_interrupted", unit=y.id, action=dy.action_id, target=z.id)

    def _duel(self, a, da, b, db, boost=None):
        prev = self.current_actor
        busy = getattr(self, "_charge_busy", False)
        self._charge_busy = True
        try:
            return self._duel_inner(a, da, b, db, boost)
        finally:
            self._charge_busy = busy
            self.current_actor = prev

    def _duel_inner(self, a, da, b, db, boost=None):
        """PA-263 一騎打ち: 攻撃・パリィ・崩しの三すくみ。boost: ため斬りの倍率（PA-267）。"""
        boost = boost or {}
        aa, ab = self.actions[da.action_id], self.actions[db.action_id]
        ba, bb = boost.get(a.id, 1.0), boost.get(b.id, 1.0)
        ra, rb = self.damage.expected(a, aa) * ba, self.damage.expected(b, ab) * bb
        self.duel_raw = {a.id: ra, b.id: rb}
        sa = self.controllers[a.side].decide_clash(a, b) if hasattr(self.controllers[a.side], "decide_clash") else "attack"
        sb = self.controllers[b.side].decide_clash(b, a) if hasattr(self.controllers[b.side], "decide_clash") else "attack"
        sa = sa if sa in CLASH_STANCES else "attack"
        sb = sb if sb in CLASH_STANCES else "attack"
        self.stats.c["v18_duel"] += 1
        self.stats.c[f"v18_duel_{a.side.value}_{sa}"] += 1
        self.stats.c[f"v18_duel_{b.side.value}_{sb}"] += 1
        self.emit("duel", unit=a.id, other=b.id, stance=sa, other_stance=sb, raw=round(ra, 1), other_raw=round(rb, 1))
        beats = {"parry": "attack", "break": "parry", "attack": "break"}     # 左が右に勝つ
        if sa == sb == "attack":
            if abs(ra - rb) < 1e-9:
                self._spend_only(a, da)
                self._spend_only(b, db)
                self.stats.c["v18_duel_even"] += 1
                self.emit("duel_result", kind="even", unit=a.id, other=b.id)
                return
            w, dw, lo, dl, rw, rl = (a, da, b, db, ra, rb) if ra > rb else (b, db, a, da, rb, ra)
            bw = boost.get(w.id, 1.0)
            self._spend_only(lo, dl)
            self.stats.c[f"v18_duel_power_win_{w.side.value}"] += 1
            self.emit("duel_result", kind="power", unit=w.id, other=lo.id, raw=round(rw, 1), other_raw=round(rl, 1),
                      through=round(rw - rl, 1))
            self._exec_mult(w, dw, bw * (rw - rl) / rw)
            return
        if sa == sb:
            self.stats.c[f"v18_duel_same_{sa}"] += 1
            self.emit("duel_result", kind="same", unit=a.id, other=b.id, stance=sa)
            return
        w, dw, sw, lo, dl, sl = (a, da, sa, b, db, sb) if beats[sa] == sb else (b, db, sb, a, da, sa)
        self.stats.c[f"v18_duel_win_{w.side.value}_{sw}"] += 1
        self.emit("duel_result", kind=sw, unit=w.id, other=lo.id)
        if sw == "parry":                      # 攻撃を弾いた: 攻撃した側はEPだけ払って崩れる
            self._spend_only(lo, dl)
            self._apply_stagger(lo)
        elif sw == "break":                    # パリィの構えを崩した
            self._apply_stagger(lo)
        else:                                  # 崩しに来たところを斬った: 攻撃がそのまま通る
            if boost.get(w.id, 1.0) != 1.0:
                self._exec_mult(w, dw, boost[w.id])
            else:
                self._run_dec(w, dw)

    def _apply_stagger(self, u):
        """崩れ: いま手番中（このあと次の手番を決める）の者は予約に、それ以外は今の予約に直接足す。"""
        if u is self.current_actor or u.id in getattr(self, "_pair_ids", ()):
            self._stagger.add(u.id)
            return
        nt = self.next_time.get(u.id)
        if nt is not None and math.isfinite(nt):
            self.next_time[u.id] = nt + self.clash_stagger
        self.emit("staggered", unit=u.id, delay=self.clash_stagger)

    # ------------------------------------------------------------ PA-267 侍の「ため斬り」
    def charge_mult(self, u) -> float:
        t0 = self.charging.get(u.id)
        if t0 is None:
            return 1.0
        return min(self.charge_max, 1.0 + self.charge_per_T * max(0.0, self.cur_time - t0))

    def charge_counter_attack(self, c, foe):
        """ため中の c が foe へ斬り込むときに使う攻撃（単体の近接攻撃で届くもの。一番強いもの）。"""
        best = None
        for a in self.available_actions(c):
            if a.kind is ActionKind.ATTACK and a.area not in ("all", "front") and a.reach is not None \
                    and a.reach.value == "MELEE" and not a.special and foe in self.valid_targets(c, a):
                if best is None or self.damage.expected(c, a) > self.damage.expected(c, best):
                    best = a
        return best

    def _charge_hooks(self, actor, dec):
        """True を返したら、この行動はここで終わり（斬り込まれて中断・一騎打ちで決着）。"""
        if getattr(self, "_charge_busy", False):
            return False
        # ① ためを放つ手番: 単体の近接攻撃に倍率が乗る
        m = self.charge_ready.pop(actor.id, None)
        if m is not None:
            if self.melee_single(actor, dec) is not None:
                self.stats.c[f"v18_charge_release_{actor.side.value}"] += 1
                self.emit("charge_release", unit=actor.id, target=dec.target_id, mult=round(m, 3))
                self._exec_mult(actor, dec, m)
                return True
            self.emit("charge_lost", unit=actor.id, why="ためを放たなかった")
            return False
        t = self.melee_single(actor, dec)
        if t is None:
            return False
        foes = [c for c in self.state.side_units(actor.side.other) if c.id in self.charging and c.alive and not c.incapacitated]
        if not foes:
            return False
        # ② ため中の本人を近接で狙った → 一騎打ち（パリィタイム）
        if t.id in self.charging:
            c = t
            ca = self.charge_counter_attack(c, actor)
            if ca is not None:
                m = self.charge_mult(c)
                self.charging.pop(c.id, None)
                self.stats.c[f"v18_charge_duel_{c.side.value}"] += 1
                self.emit("charge_duel", unit=c.id, other=actor.id, mult=round(m, 3))
                self._duel(actor, dec, c, Decision(ca.id, actor.id, reasons=["ため斬り"]), boost={c.id: m})
                return True
            return False
        # ③ ほかの者を近接で狙った → ため中の者が死角から斬り込めるか（選べる）
        for c in sorted(foes, key=lambda x: -self.charge_mult(x)):
            ca = self.charge_counter_attack(c, actor)
            if ca is None:
                continue
            m = self.charge_mult(c)
            ctl = self.controllers[c.side]
            go = ctl.decide_charge_strike(c, actor, t, m) if hasattr(ctl, "decide_charge_strike") else True
            if not go:
                self.emit("charge_hold", unit=c.id, attacker=actor.id, target=t.id, mult=round(m, 3))
                continue
            self.charging.pop(c.id, None)
            self.stats.c[f"v18_charge_strike_{c.side.value}"] += 1
            self.emit("charge_strike", unit=c.id, target=actor.id, victim_target=t.id, mult=round(m, 3))
            prev = self.current_actor
            self._charge_busy = True
            try:
                self._exec_mult(c, Decision(ca.id, actor.id, reasons=["ため斬り（死角から斬り込む）"]), m)
            finally:
                self._charge_busy = False
                self.current_actor = prev
            self.stats.c[f"v18_blind_interrupted_{actor.side.value}"] += 1
            self.emit("blind_interrupted", unit=actor.id, action=dec.action_id, target=t.id)
            return True
        return False

    # ------------------------------------------------------------ PA-260 ヘイト
    def judgment_of(self, e) -> float:
        return self.hate_judgment + self.hate_bonus.get(int(e.intel_effective or 0), 0.0)

    def instinct_of(self, e) -> float:
        b = self.base_intel.get(e.id, int(e.intel_effective or 0))
        return self.hate_instinct.get(int(b), 1.0)

    def hate_top(self, e):
        """e のヘイトが一番高い相手（戦闘可能な者だけ）: (値, ID) or (0, None)"""
        best = (0.0, None)
        for tid, x in self.hate.get(e.id, {}).items():
            t = self.state.units.get(tid)
            if t is not None and t.alive and x > best[0]:
                best = (x, tid)
        return best

    def _gain_hate(self, e, attacker, a, dmg):
        """生身にダメージが通ったときだけヘイトが増える（鎧で全部防いだら増えない）。衝撃波は鎧を無視して必ず届く。"""
        key = a.special or a.id
        if key not in self.hate_actions and dmg <= 0:
            return
        base = float(self.hate_actions.get(key, self.hate_body_hit))
        amt = base * self.instinct_of(e)
        if amt <= 0 or e.hp <= 0:
            return
        h = self.hate.setdefault(e.id, {})
        old_top = self.hate_top(e)
        h[attacker.id] = h.get(attacker.id, 0.0) + amt
        if self.hate_cap is not None:
            h[attacker.id] = min(self.hate_cap, h[attacker.id])     # PA-265
        self.stats.c[f"v17_hate_gain_{key}"] += 1
        new_top = self.hate_top(e)
        hooked = new_top[0] > self.judgment_of(e)
        self.emit("hate", unit=e.id, toward=attacker.id, amount=round(amt, 1), value=round(h[attacker.id], 1),
                  judgment=round(self.judgment_of(e), 1), hooked=hooked and new_top[1] == attacker.id,
                  was=old_top[1])

    # ------------------------------------------------------------ 戦闘不能
    def _on_ko(self, u, routes_before):
        super()._on_ko(u, routes_before)
        self.fixed.pop(u.id, None)
        self.fixed_info.pop(u.id, None)
        self.reserve.pop(u.id, None)
        if self.charging.pop(u.id, None) is not None:
            self.emit("charge_lost", unit=u.id, why="倒れた")
        self.charge_ready.pop(u.id, None)
        self.pinned.pop(u.id, None)
        if self.precommit:
            self._remove_layers(u.id)                      # 倒れた者が張った鎧は消える（維持できない）
            if u.hp <= 0:
                for gid in self.layers.pop(u.id, []):      # 死亡した者が着ていた鎧は消える（戦闘不能者は着たまま）
                    if u.id in self.shield_of.get(gid, []):
                        self.shield_of[gid].remove(u.id)
        self.holding.discard(u.id)
        for g, lid in list(self.howl_by.items()):
            if lid == u.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)


def make_v15_engine(cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
    return V15Engine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
