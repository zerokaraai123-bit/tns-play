"""Ver0.15 検証用エンジン（PA-200〜209）。正式仕様ではない。

TimelineEngine（Ver0.12 のイベント方式・方式B）を継承し、Ver0.15 の新しい行動だけを足す。
既存の処理（ダメージ・エーテル防御・介入・持ち場離脱・前線突破・戦闘不能・速度・詠唱）はそのまま使う。

新しい行動（rules.actions の special）:
  dive / flank : 薄い経路（塞ぎ手が thin_route_max 人以下。死守中は hold_blocker_weight 人分）を通って相手のREARを近接攻撃。
                 行動後は DIVING（持ち場を離れる）。次の自分の手番の始めに戻る。防御は可・介入は不可。
  pin          : 相手FRONTを近接攻撃。相手は自分の次の手番が終わるまで、介入・dive/flank/pin/push が使えない。
  push         : 相手FRONTを近接攻撃。相手の次の行動を push_delay T 遅らせる。
  hold         : 自分の次の手番の始めまで、受ける威力×hold_raw_mult・介入不可・塞ぎ手2人分。
  howl         : 群れに標的を指名（リーダーの次の手番の始めまで）。公開情報。
  observe      : 敵1体の「次の行動の意思」をその瞬間に敵AIに決めさせ、固定する（可能性の観測固定）。
                 次の手番で成立すればそのとおりに行動。成立しなければ release（選び直し）/ lose（待機）。

Ver0.16 の追加（PA-230〜236。すべて設定で有効化。無効なら Ver0.15 と同じ動作）:
  device       : エーテル防御装置は「自分の手番から次の自分の手番まで」に1回だけ（自分を守る・介入、どちらでも）。
                 使ったら次の自分の手番まで生身（自衛・介入とも不可）。
  介入（鎧）   : 介入者は持ち場を離れ、装置の鎧を守られる側にまとわせる。鎧は上限（armor_cap）まで防ぐ。
                 上限を超えた分（余波）は、守られた側の肉体へ直接入る（守られた側のエーテル防御は効かない）。
                 範囲攻撃は介入できない（従来どおり）。
  観測の深さ   : 固定する意思は「何手先か」がランダム（observe_depth）。公開情報。固定された敵は、その手番まで
                 自分で未来を壊す行動を選べない（EP・使用回数の確保、詠唱の開始禁止）。成立しなければ手番を失う。
  前借り       : 指定ユニットは、EPが足りない分をHPで払って行動できる（戦闘不能にならない範囲）。
  集中         : EPを回復する。その手番から次の自分の手番まで、装置は使えない。

Ver0.17 の追加（PA-240〜245。device.mode: precommit のときだけ）:
  先に張る鎧   : 装置は攻撃を受けてから使うのではなく、自分の手番に「自分／仲間1人／張らない」を選んで先に張る。
                 鎧は次の自分の手番まで残り、最初の1発（大小・単体/全体を問わず）で1枚消える。重ねがけ可。
                 外側（あとから張った方）から割れる。全体攻撃は1人につき1枚。敵からは見えない。
                 割り込む介入はない（持ち場も離れない）。仲間に張ると、次の自分の手番が ally_shield_delay T 遅れる。
"""
from __future__ import annotations

import math
import random

from ..control.controller import Decision
from ..formation.reach import ReachResult, can_use_melee
from ..formation.route import holding_blockers, route_blocked
from ..model.enums import ActionKind, Rank, Side, Stance
from ..stance.stance_machine import transition
from .timeline_engine import TimelineEngine

BREACH = ("dive", "flank")
PIN_BLOCKED = ("dive", "flank", "pin", "push")


class V15Engine(TimelineEngine):
    def __init__(self, cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
        super().__init__(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
        v = cfg.rules.get("v15", {}) or {}
        self.hold_mult = float(v.get("hold_raw_mult", 0.6))
        self.hold_w = int(v.get("hold_blocker_weight", 2))
        self.thin_max = int(v.get("thin_route_max", 1))
        self.push_delay = float(v.get("push_delay", 0.25))
        self.observe_fail = str(v.get("observe_fail", "release"))
        self.howl_power = float(v.get("howl_power", 0.2))
        self.rear_phys_mult = float(v.get("rear_physical_mult", 1.0))               # PA-215
        self.rear_phys_sides = set(v.get("rear_physical_sides", ["ally", "enemy"]))
        self._cur_action = None
        bp = v.get("body_physical") or {}
        self.body_phys_on = bool(bp.get("enabled", False))                  # PA-216
        self.body_phys_ref = float(bp.get("ref", 10.0))
        self.body_phys_p = float(bp.get("exponent", 0.5))
        self.rear_melee_displaces = bool(v.get("rear_melee_displaces", True))   # PA-201b
        self.pinned = {}          # uid -> 牽制した者のID（自分の次の手番が終わるまで）
        self._pin_clear = set()
        self.holding = set()      # 死守中
        self.howl = {}            # group -> 指名された標的ID
        self.howl_by = {}         # group -> 遠吠えしたリーダーID
        self.fixed = {}           # 観測で固定された意思: uid -> Decision
        self.fixed_info = {}      # 公開情報としての固定（詠唱中の詠唱者を観測した場合も含む）
        self._last_final = None
        # ---- Ver0.16（PA-230〜236）
        dv = v.get("device") or {}
        self.device_on = bool(dv.get("enabled", False))
        self.armor_cap = dv.get("armor_cap", None)          # 数値 or {unit_id: 数値}。None=上限なし
        if self.device_on:
            self.aegis_on = True                             # 介入は「鎧を飛ばす」形だけ
            self.aegis_mult = float(dv.get("armor_cost_mult", 1.0))
        od = v.get("observe_depth", [1, 1])
        self.obs_depth = (int(od[0]), int(od[1])) if isinstance(od, (list, tuple)) else (int(od), int(od))
        self.rng_obs = random.Random(seed * 7_919 + 16)     # 既存の乱数系列を変えないよう別系列
        self.reserve = {}         # 固定された意思のために確保するもの: uid -> {"ep": n, "uses": aid or None}
        self._exec_fixed = False
        self.precommit = self.device_on and dv.get("mode") == "precommit"     # Ver0.17（PA-240）
        self.ally_shield_delay = float(dv.get("ally_shield_delay", 0.0))
        self.shield_range = str(dv.get("shield_range", "any"))                # PA-248
        self.prebattle = bool(dv.get("prebattle", True))                     # PA-249/250 False=奇襲（準備なし）
        self.ambush_first_strike = bool(v.get("ambush_first_strike", False))  # PA-254 奇襲: 敵が必ず先に動く
        self.layers = {}          # 鎧を着ている者 -> [張った者のID,...]（末尾が外側）
        self.shield_of = {}       # 張った者 -> 張った相手
        self._delay_next = set()
        self._layer_self = False
        bl = v.get("blood") or {}
        self.blood_on = bool(bl.get("enabled", False))
        self.blood_units = set(bl.get("units", []) or [])
        self.blood_rate = float(bl.get("hp_per_ep", 1.0))

    # ------------------------------------------------------------ 経路の薄さ
    def route_weight(self, r) -> int:
        return sum(self.hold_w if b in self.holding else 1 for b in holding_blockers(r, self.state.units))

    def breach_reach(self, attacker, target) -> ReachResult:
        if not can_use_melee(attacker):
            return ReachResult(False, reason="後衛は近接攻撃不可")
        if target.rank is not Rank.REAR:
            return ReachResult(False, reason="突撃・回り込みは後衛だけを狙う")
        routes = [r for r in self.state.routes[target.side] if target.id in r.protects]
        if not routes:
            return ReachResult(True, reason="この後衛を守る経路なし")
        best = min(routes, key=self.route_weight)
        w = self.route_weight(best)
        if w <= self.thin_max:
            hb = holding_blockers(best, self.state.units)
            return ReachResult(True, via_route=best.id, reason=f"経路{best.id}が薄い（塞ぎ手{w}）",
                               blocked_by=hb)
        return ReachResult(False, reason=f"経路{best.id}の塞ぎ手が厚い（{w}）")

    def reach(self, attacker, target, action):
        if action.special in BREACH:
            return self.breach_reach(attacker, target)
        return super().reach(attacker, target, action)

    # ------------------------------------------------------------ 行動の候補
    def available_actions(self, u):
        out = []
        for a in super().available_actions(u):
            sp = a.special
            if sp in PIN_BLOCKED and (u.id in self.pinned or u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp and sp != "hold" and not self.valid_targets(u, a):
                continue
            if sp == "hold" and (u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp == "focus" and (u.ep >= u.d.ep_max or (self.device_on and not self.device_ready(u))):
                continue
            rs = self.reserve.get(u.id)
            if rs and not self._exec_fixed:
                if a.id in self.cast_time:
                    continue                    # 固定された未来の手番より前に、詠唱を始めない（PA-233）
                if rs["uses"] == a.id and u.uses.get(a.id, 0) <= 1:
                    continue
            out.append(a)
        return out

    def valid_targets(self, u, a):
        sp = a.special
        st = self.state
        if sp in BREACH:
            return [t for t in st.target_candidates(u.side.other, u.side)
                    if t.rank is Rank.REAR and self.breach_reach(u, t).ok]
        if sp in ("pin", "push"):
            return [t for t in st.side_units(u.side.other) if t.rank is Rank.FRONT and can_use_melee(u)]
        if sp == "hold":
            return [u]
        if sp == "howl":
            return st.side_units(u.side.other)
        if sp == "observe":
            return st.side_units(u.side.other)
        if sp == "focus":
            return [u]
        if a.kind is ActionKind.ATTACK and a.area == "front":
            return [t for t in super().valid_targets(u, a) if t.rank is Rank.FRONT]      # PA-256 相手の前列全員
        return super().valid_targets(u, a)

    # ------------------------------------------------------------ フック
    def _iv_ok(self, c) -> bool:
        if getattr(self, "precommit", False):
            return False                              # Ver0.17: 割り込む介入はない
        return c.id not in self.pinned and c.id not in self.holding

    # ------------------------------------------------------------ Ver0.16 エーテル防御装置（PA-230/231）
    def defense_allowed(self, c) -> bool:
        if getattr(self, "precommit", False):
            return False                              # Ver0.17: 受ける瞬間の防御はない（先に張った鎧だけ）
        return super().defense_allowed(c)

    def device_ready(self, c) -> bool:
        """装置をいま使えるか（自分の手番から次の自分の手番までに1回）。"""
        return c.id not in self.aegis_used

    def cap_of(self, c):
        cap = self.armor_cap
        if isinstance(cap, dict):
            cap = cap.get(c.id, cap.get("default"))
        return None if cap is None else float(cap)

    def _on_self_defense(self, u):
        if self.device_on:
            self.aegis_used.add(u.id)
            self.stats.c[f"v16_device_self_{u.side.value}"] += 1

    def _adjust_iv_choice(self, choice):
        if self.device_on and choice is not None and choice.interceptor_id:
            choice.mode = "aegis"
        return choice

    def _on_aegis(self, aegis, target, attacker, action, choice):
        """介入者は持ち場を離れる（PA-231）。鎧は守られる側がまとう。"""
        if not self.device_on:
            return
        st = self.state
        side = target.side.value
        before = self.route_snapshot()
        transition(aegis, Stance.INTERVENING, self.emit, f"{target.name}へ装置の鎧を飛ばした（持ち場を離れる）")
        self.recovery.on_intervened(aegis, self)
        transition(aegis, Stance.GUARDING, self.emit, "鎧を飛ばした（次の自分の手番まで持ち場の外・生身）")
        opened = [r.id for r in st.routes_blocked_by(aegis.id)
                  if before[r.id] == "BLOCK" and not route_blocked(r, st.units)]
        self.stats.c[f"intervention_{side}"] += 1
        self.stats.c[f"front_open_{side}"] += len(opened)
        self.stats.c[f"front_open_by_intervention_{side}"] += len(opened)
        for rid in opened:
            self.emit("route_change", route=rid, status="OPEN", cause=f"{aegis.name}が持ち場を離れた")

    def _aegis_block(self, c, raw):
        """介入の鎧（PA-231）: 上限まで、介入者のEPで防ぐ。上限を超えた分は余波として通る。"""
        if not self.device_on:
            return super()._aegis_block(c, raw)
        cap = None if self._layer_self else self.cap_of(c)     # 自分の鎧には上限なし
        self._layer_self = False
        part = raw if cap is None else min(raw, cap)
        over = raw - part
        leak, spent, mode = super()._aegis_block(c, part)
        side = c.side.value
        if over > 0:
            self.stats.c[f"v16_armor_pierce_{side}"] += 1
            self.stats.c[f"v16_armor_over_{side}"] += over
            self.emit("armor_pierce", unit=c.id, raw=round(raw, 1), cap=cap, over=round(over, 1))
            mode = "armor_pierce"
        return leak + over, spent, mode

    def _raw_mult(self, final, attacker=None, target=None) -> float:
        self._last_final = final
        m = self.hold_mult if final.id in self.holding else 1.0
        a = self._cur_action
        if (self.rear_phys_mult != 1.0 and a is not None and a.source == "power" and final.rank is Rank.REAR
                and final.side.value in self.rear_phys_sides):
            m *= self.rear_phys_mult        # PA-215: 後衛は物理攻撃に脆い（庇われた場合は受けた前衛に掛からない）
            self.stats.c[f"v15_rear_phys_hit_{final.side.value}"] += 1
        if attacker is not None and target is not None and attacker.d.group:
            if self.howl.get(attacker.d.group) == target.id and self.howl_by.get(attacker.d.group) != attacker.id:
                m *= 1.0 + self.howl_power          # PA-206: 遠吠えで指名された標的への群れの攻撃は威力+20%
                self.stats.c[f"v15_howl_hit_{attacker.side.value}"] += 1
        return m

    # ------------------------------------------------------------ 手番の始まり・終わり
    def _v08_turn_start(self, actor):
        super()._v08_turn_start(actor)
        if getattr(self, "precommit", False) and actor.id in self.shield_of:
            t = self._remove_layer(actor.id)               # 前の手番で張った鎧は、次の自分の手番で消える
            self.stats.c[f"v17_layer_expired_{actor.side.value}"] += 1
            self.emit("armor_expire", unit=actor.id, target=t)
        if actor.stance is Stance.DIVING and actor.alive:
            before = self.route_snapshot()
            transition(actor, Stance.READY, self.emit, "突撃・回り込みから持ち場へ戻った (PA-201)")
            self.emit("dive_return", unit=actor.id)
            after = self.route_snapshot()
            for rid, s in after.items():
                if before.get(rid) == "OPEN" and s == "BLOCK":
                    self.emit("route_change", route=rid, status="BLOCK", cause=f"{actor.name}が持ち場へ戻った")
        if actor.id in self.holding:
            self.holding.discard(actor.id)
            self.emit("hold_end", unit=actor.id)
        for g, lid in list(self.howl_by.items()):
            if lid == actor.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)
                self.emit("howl_end", unit=actor.id)
        if actor.id in self.pinned:
            self._pin_clear.add(actor.id)
        if actor.id in self.casting and actor.id in self.fixed_info:
            self.fixed_info.pop(actor.id, None)

    def _schedule_next(self, actor):
        super()._schedule_next(actor)
        if actor.id in self._delay_next:
            self._delay_next.discard(actor.id)
            nt = self.next_time.get(actor.id)
            if nt is not None and math.isfinite(nt):
                self.next_time[actor.id] = nt + self.ally_shield_delay      # 仲間に張った代償（PA-242）
        if actor.id in self._pin_clear:
            self._pin_clear.discard(actor.id)
            if self.pinned.pop(actor.id, None) is not None:
                self.emit("pin_end", unit=actor.id)

    # ------------------------------------------------------------ Ver0.17 先に張る鎧（PA-240〜245）
    def layers_on(self, uid):
        return self.layers.get(uid, [])

    def can_shield(self, giver, target) -> bool:
        """PA-248 鎧を張れる範囲。lanes: 自分／前衛どうし／担当の後衛（経路の塞ぎ手＝介入担当範囲）／後衛どうし（PA-248b）。"""
        if target.side is not giver.side or target.hp <= 0:
            return False                                   # 戦闘不能者（HP>0）には張れる。死亡者には張れない
        if giver.id == target.id or self.shield_range != "lanes":
            return True
        if giver.rank is not Rank.FRONT:
            return target.rank is not Rank.FRONT          # PA-248b 後衛は後衛どうしで張り合える（前衛には張れない）
        if target.rank is Rank.FRONT:
            return True
        return any(giver.id in r.blockers for r in self.state.routes[target.side] if target.id in r.protects)

    def _remove_layer(self, giver_id):
        t = self.shield_of.pop(giver_id, None)
        if t is not None and giver_id in self.layers.get(t, []):
            ls = self.layers[t]
            ls.reverse(); ls.remove(giver_id); ls.reverse()          # 同じ者の鎧は1枚だけだが念のため外側から
            return t
        return None

    def _forced_aegis(self, target, attacker, action):
        if not self.precommit:
            return None
        ls = self.layers.get(target.id)
        if not ls:
            self.stats.c[f"v17_hit_bare_{target.side.value}"] += 1
            return None
        gid = ls.pop()                                    # 外側から割れる
        self.shield_of.pop(gid, None)
        g = self.u(gid)
        self._layer_self = gid == target.id
        side = target.side.value
        self.stats.c[f"v17_layer_used_{'self' if self._layer_self else 'other'}_{side}"] += 1
        self.emit("armor_hit", unit=gid, target=target.id, self_layer=self._layer_self, left=len(ls),
                  area=action.area == "all")
        return g

    def run(self):
        if self.precommit and self.prebattle and not getattr(self, "_prebattle_done", False):
            self._prebattle_done = True
            self._pre_battle()
        if self.ambush_first_strike and not getattr(self, "_ambush_done", False):
            self._ambush_done = True
            self._first_strike(Side.ENEMY)
        return super().run()

    def _first_strike(self, side):
        """PA-254 奇襲: side の全員の最初の行動が終わるまで、相手側は動けない。相手側どうしの順番（速さの差）は保つ。"""
        st = self.state
        first = [self.next_time[u.id] for u in st.side_units(side) if math.isfinite(self.next_time.get(u.id, math.inf))]
        others = [u for u in st.side_units(side.other) if math.isfinite(self.next_time.get(u.id, math.inf))]
        if not first or not others:
            return
        t_last = max(first)
        t0 = min(self.next_time[u.id] for u in others)
        for u in others:
            self.next_time[u.id] = t_last + 0.01 + (self.next_time[u.id] - t0)
        self.stats.c[f"v17_first_strike_{side.value}"] += 1
        self.emit("first_strike", side=side.value, until=round(t_last, 4))

    def _pre_battle(self):
        """PA-249 戦闘前の準備: 各自が、最初の自分の手番まで張っておく鎧を決める（プレイヤー・AI）。"""
        for side in (Side.ALLY, Side.ENEMY):
            ctl = self.controllers[side]
            for u in list(self.state.side_units(side)):
                if not u.alive:
                    continue
                if hasattr(ctl, "decide_preshield"):
                    sid = ctl.decide_preshield(u)
                else:
                    sid = u.id if u.ep > 0 else None
                t = self.state.units.get(sid) if sid else None
                if t is None or not self.can_shield(u, t) or u.id in self.casting:
                    sid = None
                self.stats.c[f"v17_pre_{'none' if sid is None else ('self' if sid == u.id else 'other')}_{side.value}"] += 1
                if sid is None:
                    self.emit("shield", unit=u.id, target=None, prebattle=True)
                    continue
                self.layers.setdefault(sid, []).append(u.id)
                self.shield_of[u.id] = sid
                self.emit("shield", unit=u.id, target=sid, layers=len(self.layers[sid]), prebattle=True)

    def _choose_shield(self, actor, dec):
        """手番の行動と一緒に、鎧を張る先を決める（PA-241）。"""
        a = self.actions.get(dec.action_id)
        tags = dec.tags or {}
        if "shield" in tags:
            sid = tags["shield"]
        else:
            ctl = self.controllers[actor.side]
            sid = ctl.decide_shield(actor, dec) if hasattr(ctl, "decide_shield") else (actor.id if actor.ep > 0 else None)
        cast_start = a is not None and a.id in self.cast_time and not tags.get("cast_complete")
        if a is not None and a.special == "focus":
            sid = None                                     # 集中した手番は装置を使えない（PA-235）
        fixed_sid = sid if tags.get("fixed_shield") else None
        if sid is not None:
            t = self.state.units.get(sid)
            if t is None or t.side is not actor.side or t.hp <= 0 or (cast_start and sid == actor.id) \
                    or not self.can_shield(actor, t):
                sid = None                                 # 詠唱を始めた者は自分には張れない（PA-130）・範囲外（PA-248）
        side = actor.side.value
        if fixed_sid is not None and sid is None:
            # 固定された鎧が成り立たない（相手が死亡・範囲外など）→ 鎧は張れずに終わる。行動はそのまま（PA-255 a）
            self.stats.c[f"v17_fixed_shield_broken_{side}"] += 1
            self.emit("fixed_shield_broken", unit=actor.id, target=fixed_sid)
        elif tags.get("fixed_shield"):
            self.stats.c[f"v17_fixed_shield_{side}"] += 1
        if sid is None:
            self.stats.c[f"v17_shield_none_{side}"] += 1
            self.emit("shield", unit=actor.id, target=None)
            return
        self.layers.setdefault(sid, []).append(actor.id)
        self.shield_of[actor.id] = sid
        self.stats.c[f"v17_shield_{'self' if sid == actor.id else 'other'}_{side}"] += 1
        if sid != actor.id and self.ally_shield_delay > 0:
            self._delay_next.add(actor.id)
        self.emit("shield", unit=actor.id, target=sid, layers=len(self.layers[sid]))

    # ------------------------------------------------------------ Ver0.16 前借り（PA-234）・確保（PA-233）
    def blood_capacity(self, u) -> int:
        """HPで払えるEPの量（戦闘不能ラインより上に残る範囲）。"""
        if not (self.blood_on and u.id in self.blood_units) or not u.alive:
            return 0
        floor = math.floor(u.incap_ratio * u.d.hp_max) + 1 if u.incap_ratio > 0 else 1
        return max(0, int((u.hp - floor) / self.blood_rate))

    def spendable_ep(self, u, a=None) -> int:
        e = super().spendable_ep(u, a)
        rs = self.reserve.get(u.id)
        if rs and not self._exec_fixed:
            e -= rs["ep"]
        if a is not None and a.ep_cost > 0:
            e += self.blood_capacity(u)
        return e

    def _can_pay(self, actor, a) -> bool:
        return actor.ep + self.blood_capacity(actor) >= a.ep_cost

    def _pay(self, actor, a) -> int:
        if actor.ep >= a.ep_cost:
            actor.ep -= a.ep_cost
            return a.ep_cost
        paid = int(actor.ep)
        short = a.ep_cost - paid
        hp = int(math.ceil(short * self.blood_rate - 1e-9))
        actor.ep = 0
        actor.hp = max(1, actor.hp - hp)
        self.stats.c[f"v16_blood_{actor.side.value}"] += 1
        self.stats.c[f"v16_blood_hp_{actor.side.value}"] += hp
        self.emit("blood_pay", unit=actor.id, action=a.id, ep=paid, hp=hp, hp_left=actor.hp)
        return paid

    # ------------------------------------------------------------ 観測固定（PA-208）
    def _feasible(self, actor, dec) -> tuple[bool, str]:
        a = self.actions.get(dec.action_id)
        if a is None:
            return False, "不明な行動"
        if a.kind is ActionKind.WAIT:
            return True, ""
        if a.id not in {x.id for x in self.available_actions(actor)}:
            if a.special in PIN_BLOCKED and actor.id in self.pinned:
                return False, "牽制されて使えない"
            if a.ep_cost > self.spendable_ep(actor, a):
                return False, "EP不足"
            return False, "その行動が使えない"
        if dec.target_id is None:
            return True, ""
        t = self.u(dec.target_id)
        if a.kind is ActionKind.ATTACK and a.area in ("all", "front"):
            return (bool([x for x in self.valid_targets(actor, a) if x.alive]), "届く相手がいない")
        if t not in self.valid_targets(actor, a):
            return False, f"{t.name}に届かない／対象にできない"
        if a.kind is ActionKind.ATTACK and not t.alive and not t.incapacitated:
            return False, f"{t.name}がいない"
        return True, ""

    def _decide(self, actor):
        dec = self._decide_v15(actor)
        if self.precommit and actor.alive:
            self._choose_shield(actor, dec)
        return dec

    def _decide_v15(self, actor):
        for a in self.available_actions(actor):          # 記録用: 使える状態だった回数（使用率の分母）
            if a.special or a.id in ("maintain", "curse", "storm", "focus"):
                self.stats.c[f"v15_avail_{a.id}_{actor.id}"] += 1
        fx = self.fixed.get(actor.id)
        if fx is not None:
            left = int((fx.tags or {}).get("obs_left", 1))
            if left > 1:
                # まだその手番ではない（PA-233）: 自由に動くが、固定された未来を自分で壊す行動は選べない
                fx.tags["obs_left"] = left - 1
                self.stats.c[f"v16_fixed_wait_{actor.side.value}"] += 1
                self.emit("fixed_pending", unit=actor.id, action=fx.action_id, target=fx.target_id, left=left - 1)
                return super()._decide(actor)
            self.fixed.pop(actor.id, None)
        self.fixed_info.pop(actor.id, None)
        if fx is not None:
            self._exec_fixed = True
            try:
                ok, why = self._feasible(actor, fx)
            finally:
                self._exec_fixed = False
                self.reserve.pop(actor.id, None)
            if ok:
                self.stats.c[f"v15_fixed_exec_{actor.side.value}"] += 1
                self.emit("fixed_execute", unit=actor.id, action=fx.action_id, target=fx.target_id)
                return Decision(fx.action_id, fx.target_id, reasons=["観測で固定された意思（心変わりできない）"] + list(fx.reasons),
                                tags={**(fx.tags or {}), "fixed": True})
            self.stats.c[f"v15_fixed_broken_{actor.side.value}"] += 1
            self.emit("fixed_broken", unit=actor.id, action=fx.action_id, target=fx.target_id, why=why,
                      mode=self.observe_fail)
            if self.observe_fail == "lose":
                self.stats.c[f"v15_fixed_lost_turn_{actor.side.value}"] += 1
                keep = {"shield": fx.tags["shield"], "fixed_shield": True} if "shield" in (fx.tags or {}) else {}
                return Decision("wait", reasons=[f"固定された意思が成立しない（{why}）→ 迷って手番を失う"], tags=keep)
        return super()._decide(actor)

    def _observe(self, actor, t):
        if t.id in self.casting:
            d = self.casting[t.id]["dec"]
            self.fixed_info[t.id] = d
            self.stats.c["v15_observe_casting"] += 1
            self.emit("observe", unit=actor.id, target=t.id, action=d.action_id, intent_target=d.target_id, casting=True)
            return
        dec = self.controllers[t.side].decide_action(t)
        lo, hi = self.obs_depth
        n = lo if hi <= lo else self.rng_obs.randint(lo, hi)
        dec.tags = {**(dec.tags or {}), "obs_left": n, "obs_depth": n}
        if self.precommit:
            # PA-255 その手番で張る鎧の相手も一緒に固定する（観測した瞬間の状況で決めさせる・公開）
            ctl = self.controllers[t.side]
            sid = ctl.decide_shield(t, dec) if hasattr(ctl, "decide_shield") else (t.id if t.ep > 0 else None)
            dec.tags["shield"] = sid
            dec.tags["fixed_shield"] = True
        self.fixed[t.id] = dec
        self.fixed_info[t.id] = dec
        a = self.actions.get(dec.action_id)
        if n > 1 and a is not None:
            self.reserve[t.id] = {"ep": a.ep_cost, "uses": a.id if a.uses is not None else None}
        self.stats.c[f"v16_observe_depth_{n}"] += 1
        self.emit("observe", unit=actor.id, target=t.id, action=dec.action_id, intent_target=dec.target_id,
                  casting=False, depth=n, shield=(dec.tags or {}).get("shield", "-"))

    # ------------------------------------------------------------ 実行
    def _execute(self, actor, dec):
        a = self.actions[dec.action_id]
        sp = a.special
        side = actor.side.value
        if a.kind is ActionKind.SPECIAL:
            t = self.u(dec.target_id) if dec.target_id else None
            self.stats.c[f"v15_{sp}_{side}"] += 1
            if sp == "hold":
                self.holding.add(actor.id)
                self.emit("hold", unit=actor.id, reasons=dec.reasons)
            elif sp == "howl" and t is not None:
                g = actor.d.group or actor.id
                self.howl[g] = t.id
                self.howl_by[g] = actor.id
                self.emit("howl", unit=actor.id, target=t.id, reasons=dec.reasons)
            elif sp == "observe" and t is not None:
                self._observe(actor, t)
            elif sp == "focus":
                g = min(a.amount, actor.d.ep_max - actor.ep)
                actor.ep += g
                if self.device_on:
                    self.aegis_used.add(actor.id)        # 集中している間は装置を使えない（PA-235）
                self._check_ep(actor)
                self._update_collapse(actor, cause="supply")
                self.emit("focus", unit=actor.id, amount=g, ep=actor.ep, reasons=dec.reasons)
            else:
                self.emit("wait", unit=actor.id, reasons=dec.reasons)
            return
        if sp and not (a.id in self.cast_time and not dec.tags.get("cast_complete")):
            self.stats.c[f"v15_{sp}_{side}"] += 1
        rear_melee = (self.rear_melee_displaces and not sp and a.kind is ActionKind.ATTACK and a.area not in ("all", "front")
                      and a.reach is not None and a.reach.value == "MELEE" and dec.target_id
                      and self.u(dec.target_id).rank is Rank.REAR and not (a.id in self.cast_time and not dec.tags.get("cast_complete")))
        if sp in BREACH or rear_melee:
            target = self.u(dec.target_id)
            r = self.reach(actor, target, a)
            if not sp:
                sp = "rear_melee"
                self.stats.c[f"v15_rear_melee_{side}"] += 1
            if r.via_route and holding_blockers(next(x for x in self.state.all_routes() if x.id == r.via_route),
                                                self.state.units):
                self.stats.c[f"v15_{sp}_thin_{side}"] += 1
            if target.id in self.casting:
                self.stats.c[f"v15_{sp}_on_casting_{side}"] += 1
            before = self.route_snapshot()
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is not None and fin.id != target.id:
                self.stats.c[f"v15_{sp}_intercepted_{side}"] += 1
            if actor.alive and actor.stance is Stance.READY and r.ok:
                transition(actor, Stance.DIVING, self.emit, f"{a.name}で{target.name}へ踏み込んだ（持ち場を離れる）")
                after = self.route_snapshot()
                for rid, s in after.items():
                    if before.get(rid) == "BLOCK" and s == "OPEN":
                        self.stats.c[f"front_open_{side}"] += 1
                        self.stats.c[f"v15_open_by_{sp}_{side}"] += 1
                        self.emit("route_change", route=rid, status="OPEN", cause=f"{actor.name}が{a.name}で持ち場を離れた")
            return
        if sp in ("pin", "push"):
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is None or fin.side is actor.side or not fin.alive:
                return
            if sp == "pin":
                self.pinned[fin.id] = actor.id
                self._pin_clear.discard(fin.id)
                self.emit("pinned", unit=fin.id, by=actor.id)
            else:
                nt = self.next_time.get(fin.id)
                if nt is not None and math.isfinite(nt):
                    self.next_time[fin.id] = nt + self.push_delay
                    self.stats.c[f"v15_push_delay_{side}"] += self.push_delay
                    self.emit("pushed", unit=fin.id, by=actor.id, old=round(nt, 4), new=round(nt + self.push_delay, 4))
            return
        super()._execute(actor, dec)

    def _body_factor(self, final, attacker, action) -> float:
        """PA-216: 物理攻撃（威力が元）が生身に通る分は、受ける側の「肉体」で増減する。
        倍率 = (ref / 肉体)^exponent。肉体が弱いほど深く傷つく。魔法には掛からない（肉体では防げない）。"""
        if not self.body_phys_on or action is None or action.source != "power":
            return 1.0
        b = max(1.0, float(final.d.body))
        return (self.body_phys_ref / b) ** self.body_phys_p

    def recent_hits(self, uid, window):
        """直近 window T の間に、uid が攻撃の対象になった回数（戦場で見えている公開情報）。"""
        t0 = self.cur_time - window
        return sum(1 for t in getattr(self, "hit_log", {}).get(uid, ()) if t >= t0 - 1e-9)

    def _resolve_attack(self, attacker, a, target, dec, no_iv=False):
        if not hasattr(self, "hit_log"):
            self.hit_log = {}
        self.hit_log.setdefault(target.id, []).append(self.cur_time)
        self._cur_action = a
        try:
            return super()._resolve_attack(attacker, a, target, dec, no_iv=no_iv)
        finally:
            self._cur_action = None

    # ------------------------------------------------------------ 戦闘不能
    def _on_ko(self, u, routes_before):
        super()._on_ko(u, routes_before)
        self.fixed.pop(u.id, None)
        self.fixed_info.pop(u.id, None)
        self.reserve.pop(u.id, None)
        self.pinned.pop(u.id, None)
        if self.precommit:
            self._remove_layer(u.id)                       # 倒れた者が張った鎧は消える（維持できない）
            if u.hp <= 0:
                for gid in self.layers.pop(u.id, []):      # 死亡した者が着ていた鎧は消える（戦闘不能者は着たまま）
                    self.shield_of.pop(gid, None)
        self.holding.discard(u.id)
        for g, lid in list(self.howl_by.items()):
            if lid == u.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)


def make_v15_engine(cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
    return V15Engine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
