"""Ver0.15 検証用エンジン（PA-200〜209）。正式仕様ではない。

TimelineEngine（Ver0.12 のイベント方式・方式B）を継承し、Ver0.15 の新しい行動だけを足す。
既存の処理（ダメージ・エーテル防御・介入・持ち場離脱・前線突破・戦闘不能・速度・詠唱）はそのまま使う。

新しい行動（rules.actions の special）:
  dive / flank : 薄い経路（塞ぎ手が thin_route_max 人以下。死守中は hold_blocker_weight 人分）を通って相手のREARを近接攻撃。
                 行動後は DIVING（持ち場を離れる）。次の自分の手番の始めに戻る。防御は可・介入は不可。
  pin          : 相手FRONTを近接攻撃。相手は自分の次の手番が終わるまで、介入・dive/flank/pin/push が使えない。
  push         : 相手FRONTを近接攻撃。相手の次の行動を push_delay T 遅らせる。
  hold         : 自分の次の手番の始めまで、受ける威力×hold_raw_mult・介入不可・塞ぎ手2人分。
  howl         : 群れに標的を指名（リーダーの次の手番の始めまで）。公開情報。
  observe      : 敵1体の「次の行動の意思」をその瞬間に敵AIに決めさせ、固定する（可能性の観測固定）。
                 次の手番で成立すればそのとおりに行動。成立しなければ release（選び直し）/ lose（待機）。
"""
from __future__ import annotations

import math

from ..control.controller import Decision
from ..formation.reach import ReachResult, can_use_melee
from ..formation.route import holding_blockers, route_blocked
from ..model.enums import ActionKind, Rank, Side, Stance
from ..stance.stance_machine import transition
from .timeline_engine import TimelineEngine

BREACH = ("dive", "flank")
PIN_BLOCKED = ("dive", "flank", "pin", "push")


class V15Engine(TimelineEngine):
    def __init__(self, cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
        super().__init__(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
        v = cfg.rules.get("v15", {}) or {}
        self.hold_mult = float(v.get("hold_raw_mult", 0.6))
        self.hold_w = int(v.get("hold_blocker_weight", 2))
        self.thin_max = int(v.get("thin_route_max", 1))
        self.push_delay = float(v.get("push_delay", 0.25))
        self.observe_fail = str(v.get("observe_fail", "release"))
        self.howl_power = float(v.get("howl_power", 0.2))
        self.rear_melee_displaces = bool(v.get("rear_melee_displaces", True))   # PA-201b
        self.pinned = {}          # uid -> 牽制した者のID（自分の次の手番が終わるまで）
        self._pin_clear = set()
        self.holding = set()      # 死守中
        self.howl = {}            # group -> 指名された標的ID
        self.howl_by = {}         # group -> 遠吠えしたリーダーID
        self.fixed = {}           # 観測で固定された意思: uid -> Decision
        self.fixed_info = {}      # 公開情報としての固定（詠唱中の詠唱者を観測した場合も含む）
        self._last_final = None

    # ------------------------------------------------------------ 経路の薄さ
    def route_weight(self, r) -> int:
        return sum(self.hold_w if b in self.holding else 1 for b in holding_blockers(r, self.state.units))

    def breach_reach(self, attacker, target) -> ReachResult:
        if not can_use_melee(attacker):
            return ReachResult(False, reason="後衛は近接攻撃不可")
        if target.rank is not Rank.REAR:
            return ReachResult(False, reason="突撃・回り込みは後衛だけを狙う")
        routes = [r for r in self.state.routes[target.side] if target.id in r.protects]
        if not routes:
            return ReachResult(True, reason="この後衛を守る経路なし")
        best = min(routes, key=self.route_weight)
        w = self.route_weight(best)
        if w <= self.thin_max:
            hb = holding_blockers(best, self.state.units)
            return ReachResult(True, via_route=best.id, reason=f"経路{best.id}が薄い（塞ぎ手{w}）",
                               blocked_by=hb)
        return ReachResult(False, reason=f"経路{best.id}の塞ぎ手が厚い（{w}）")

    def reach(self, attacker, target, action):
        if action.special in BREACH:
            return self.breach_reach(attacker, target)
        return super().reach(attacker, target, action)

    # ------------------------------------------------------------ 行動の候補
    def available_actions(self, u):
        out = []
        for a in super().available_actions(u):
            sp = a.special
            if sp in PIN_BLOCKED and (u.id in self.pinned or u.displaced or u.rank is not Rank.FRONT):
                continue
            if sp and sp != "hold" and not self.valid_targets(u, a):
                continue
            if sp == "hold" and (u.displaced or u.rank is not Rank.FRONT):
                continue
            out.append(a)
        return out

    def valid_targets(self, u, a):
        sp = a.special
        st = self.state
        if sp in BREACH:
            return [t for t in st.target_candidates(u.side.other, u.side)
                    if t.rank is Rank.REAR and self.breach_reach(u, t).ok]
        if sp in ("pin", "push"):
            return [t for t in st.side_units(u.side.other) if t.rank is Rank.FRONT and can_use_melee(u)]
        if sp == "hold":
            return [u]
        if sp == "howl":
            return st.side_units(u.side.other)
        if sp == "observe":
            return st.side_units(u.side.other)
        return super().valid_targets(u, a)

    # ------------------------------------------------------------ フック
    def _iv_ok(self, c) -> bool:
        return c.id not in self.pinned and c.id not in self.holding

    def _raw_mult(self, final, attacker=None, target=None) -> float:
        self._last_final = final
        m = self.hold_mult if final.id in self.holding else 1.0
        if attacker is not None and target is not None and attacker.d.group:
            if self.howl.get(attacker.d.group) == target.id and self.howl_by.get(attacker.d.group) != attacker.id:
                m *= 1.0 + self.howl_power          # PA-206: 遠吠えで指名された標的への群れの攻撃は威力+20%
                self.stats.c[f"v15_howl_hit_{attacker.side.value}"] += 1
        return m

    # ------------------------------------------------------------ 手番の始まり・終わり
    def _v08_turn_start(self, actor):
        super()._v08_turn_start(actor)
        if actor.stance is Stance.DIVING and actor.alive:
            before = self.route_snapshot()
            transition(actor, Stance.READY, self.emit, "突撃・回り込みから持ち場へ戻った (PA-201)")
            self.emit("dive_return", unit=actor.id)
            after = self.route_snapshot()
            for rid, s in after.items():
                if before.get(rid) == "OPEN" and s == "BLOCK":
                    self.emit("route_change", route=rid, status="BLOCK", cause=f"{actor.name}が持ち場へ戻った")
        if actor.id in self.holding:
            self.holding.discard(actor.id)
            self.emit("hold_end", unit=actor.id)
        for g, lid in list(self.howl_by.items()):
            if lid == actor.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)
                self.emit("howl_end", unit=actor.id)
        if actor.id in self.pinned:
            self._pin_clear.add(actor.id)
        if actor.id in self.casting and actor.id in self.fixed_info:
            self.fixed_info.pop(actor.id, None)

    def _schedule_next(self, actor):
        super()._schedule_next(actor)
        if actor.id in self._pin_clear:
            self._pin_clear.discard(actor.id)
            if self.pinned.pop(actor.id, None) is not None:
                self.emit("pin_end", unit=actor.id)

    # ------------------------------------------------------------ 観測固定（PA-208）
    def _feasible(self, actor, dec) -> tuple[bool, str]:
        a = self.actions.get(dec.action_id)
        if a is None:
            return False, "不明な行動"
        if a.kind is ActionKind.WAIT:
            return True, ""
        if a.id not in {x.id for x in self.available_actions(actor)}:
            if a.special in PIN_BLOCKED and actor.id in self.pinned:
                return False, "牽制されて使えない"
            if a.ep_cost > self.spendable_ep(actor, a):
                return False, "EP不足"
            return False, "その行動が使えない"
        if dec.target_id is None:
            return True, ""
        t = self.u(dec.target_id)
        if a.kind is ActionKind.ATTACK and a.area == "all":
            return (bool([x for x in self.valid_targets(actor, a) if x.alive]), "届く相手がいない")
        if t not in self.valid_targets(actor, a):
            return False, f"{t.name}に届かない／対象にできない"
        if a.kind is ActionKind.ATTACK and not t.alive and not t.incapacitated:
            return False, f"{t.name}がいない"
        return True, ""

    def _decide(self, actor):
        for a in self.available_actions(actor):          # 記録用: 使える状態だった回数（使用率の分母）
            if a.special or a.id in ("maintain", "curse", "storm"):
                self.stats.c[f"v15_avail_{a.id}_{actor.id}"] += 1
        fx = self.fixed.pop(actor.id, None)
        self.fixed_info.pop(actor.id, None)
        if fx is not None:
            ok, why = self._feasible(actor, fx)
            if ok:
                self.stats.c[f"v15_fixed_exec_{actor.side.value}"] += 1
                self.emit("fixed_execute", unit=actor.id, action=fx.action_id, target=fx.target_id)
                return Decision(fx.action_id, fx.target_id, reasons=["観測で固定された意思（心変わりできない）"] + list(fx.reasons),
                                tags={**(fx.tags or {}), "fixed": True})
            self.stats.c[f"v15_fixed_broken_{actor.side.value}"] += 1
            self.emit("fixed_broken", unit=actor.id, action=fx.action_id, target=fx.target_id, why=why,
                      mode=self.observe_fail)
            if self.observe_fail == "lose":
                self.stats.c[f"v15_fixed_lost_turn_{actor.side.value}"] += 1
                return Decision("wait", reasons=[f"固定された意思が成立しない（{why}）→ 迷って手番を失う"])
        return super()._decide(actor)

    def _observe(self, actor, t):
        if t.id in self.casting:
            d = self.casting[t.id]["dec"]
            self.fixed_info[t.id] = d
            self.stats.c["v15_observe_casting"] += 1
            self.emit("observe", unit=actor.id, target=t.id, action=d.action_id, intent_target=d.target_id, casting=True)
            return
        dec = self.controllers[t.side].decide_action(t)
        self.fixed[t.id] = dec
        self.fixed_info[t.id] = dec
        self.emit("observe", unit=actor.id, target=t.id, action=dec.action_id, intent_target=dec.target_id, casting=False)

    # ------------------------------------------------------------ 実行
    def _execute(self, actor, dec):
        a = self.actions[dec.action_id]
        sp = a.special
        side = actor.side.value
        if a.kind is ActionKind.SPECIAL:
            t = self.u(dec.target_id) if dec.target_id else None
            self.stats.c[f"v15_{sp}_{side}"] += 1
            if sp == "hold":
                self.holding.add(actor.id)
                self.emit("hold", unit=actor.id, reasons=dec.reasons)
            elif sp == "howl" and t is not None:
                g = actor.d.group or actor.id
                self.howl[g] = t.id
                self.howl_by[g] = actor.id
                self.emit("howl", unit=actor.id, target=t.id, reasons=dec.reasons)
            elif sp == "observe" and t is not None:
                self._observe(actor, t)
            else:
                self.emit("wait", unit=actor.id, reasons=dec.reasons)
            return
        if sp and not (a.id in self.cast_time and not dec.tags.get("cast_complete")):
            self.stats.c[f"v15_{sp}_{side}"] += 1
        rear_melee = (self.rear_melee_displaces and not sp and a.kind is ActionKind.ATTACK and a.area != "all"
                      and a.reach is not None and a.reach.value == "MELEE" and dec.target_id
                      and self.u(dec.target_id).rank is Rank.REAR and not (a.id in self.cast_time and not dec.tags.get("cast_complete")))
        if sp in BREACH or rear_melee:
            target = self.u(dec.target_id)
            r = self.reach(actor, target, a)
            if not sp:
                sp = "rear_melee"
                self.stats.c[f"v15_rear_melee_{side}"] += 1
            if r.via_route and holding_blockers(next(x for x in self.state.all_routes() if x.id == r.via_route),
                                                self.state.units):
                self.stats.c[f"v15_{sp}_thin_{side}"] += 1
            if target.id in self.casting:
                self.stats.c[f"v15_{sp}_on_casting_{side}"] += 1
            before = self.route_snapshot()
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is not None and fin.id != target.id:
                self.stats.c[f"v15_{sp}_intercepted_{side}"] += 1
            if actor.alive and actor.stance is Stance.READY and r.ok:
                transition(actor, Stance.DIVING, self.emit, f"{a.name}で{target.name}へ踏み込んだ（持ち場を離れる）")
                after = self.route_snapshot()
                for rid, s in after.items():
                    if before.get(rid) == "BLOCK" and s == "OPEN":
                        self.stats.c[f"front_open_{side}"] += 1
                        self.stats.c[f"v15_open_by_{sp}_{side}"] += 1
                        self.emit("route_change", route=rid, status="OPEN", cause=f"{actor.name}が{a.name}で持ち場を離れた")
            return
        if sp in ("pin", "push"):
            self._last_final = None
            super()._execute(actor, dec)
            fin = self._last_final
            if fin is None or fin.side is actor.side or not fin.alive:
                return
            if sp == "pin":
                self.pinned[fin.id] = actor.id
                self._pin_clear.discard(fin.id)
                self.emit("pinned", unit=fin.id, by=actor.id)
            else:
                nt = self.next_time.get(fin.id)
                if nt is not None and math.isfinite(nt):
                    self.next_time[fin.id] = nt + self.push_delay
                    self.stats.c[f"v15_push_delay_{side}"] += self.push_delay
                    self.emit("pushed", unit=fin.id, by=actor.id, old=round(nt, 4), new=round(nt + self.push_delay, 4))
            return
        super()._execute(actor, dec)

    # ------------------------------------------------------------ 戦闘不能
    def _on_ko(self, u, routes_before):
        super()._on_ko(u, routes_before)
        self.fixed.pop(u.id, None)
        self.fixed_info.pop(u.id, None)
        self.pinned.pop(u.id, None)
        self.holding.discard(u.id)
        for g, lid in list(self.howl_by.items()):
            if lid == u.id:
                self.howl.pop(g, None)
                self.howl_by.pop(g, None)


def make_v15_engine(cfg, controllers, seed=0, enemy_intel=None, log_enabled=False):
    return V15Engine(cfg, controllers, seed=seed, enemy_intel=enemy_intel, log_enabled=log_enabled)
