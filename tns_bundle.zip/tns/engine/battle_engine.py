"""戦闘エンジン。ルールの解決だけを担当し、判断は Controller に委ねる。

1巡の流れ:
  巡開始 → EP回復 → 行動キュー作成(公開)
  各スロット: 手番開始(復帰判定) → 判断 → 到達判定 → 介入ウィンドウ → 防御判断 → 解決 → 撃破/知能DOWN → 勝敗
  巡終了時に状態はリセットしない。
"""
from __future__ import annotations

import math
from typing import Optional

from ..config_loader import BattleConfig
from ..control.controller import Decision
from ..formation.reach import check_reach, can_use_melee
from ..formation.route import route_blocked, route_status_map
from ..intervention.records import BreachTracker, InterventionWindow
from ..model.actions import load_actions
from ..model.enums import ActionKind, Rank, Reach, Side, Stance
from ..rules.combat_math import EPRegenStrategy, make_damage, make_defense, make_heal
from ..rules.recovery import make_recovery
from ..rules.turn_order import Slot, make_turn_order
from ..stance.stance_machine import transition
from .battle_state import BattleState
from .rng import RngStreams
from .stats import BattleStats


class BattleEngine:
    def __init__(self, cfg: BattleConfig, controllers: dict, seed: int = 0,
                 enemy_intel: Optional[int] = None, log_enabled: bool = False):
        self.cfg = cfg
        rules = cfg.rules
        self.actions = load_actions(rules["actions"])
        self.state = BattleState.build(cfg.party, cfg.encounter, rules, enemy_intel)
        self.rng = RngStreams(seed)
        self.turn_order = make_turn_order(rules.get("turn_order", {}))
        self.recovery = make_recovery(rules.get("recovery", {}))
        self.damage = make_damage(rules.get("damage", {}))
        self.defense = make_defense(rules.get("aether_defense", {}))
        self.heal = make_heal(rules.get("heal", {}))
        self.ep_regen = EPRegenStrategy(rules.get("ep", {}))
        self.defense_blocked = {Stance(s) for s in rules.get("stance", {}).get("defense_blocked_stances", [])}
        self.allow_rear_interceptors = rules.get("intervention", {}).get("allow_rear_interceptors", True)
        self.max_rounds = rules.get("battle", {}).get("max_rounds", 30)
        lcfg = rules.get("leader", {})
        self.intel_drop_steps = lcfg.get("intel_drop_steps", 1)
        self.intel_min = lcfg.get("intel_min", 0)

        for u in self.state.units.values():
            for aid in u.d.action_ids:
                if self.actions[aid].uses is not None:
                    u.uses[aid] = int(self.actions[aid].uses)

        self.log_enabled = log_enabled
        self.events: list[dict] = []
        self.listeners = []
        self._revived_this_round = set()
        self.breach = BreachTracker()
        self.stats = BattleStats(seed=seed, enemy_intel=enemy_intel)
        self._ep_low = {u.id for u in self.state.units.values() if self.defense.exhausted(u)}
        self.action_index = 0
        # Ver0.4: 個体ごとの崩壊トラッキング
        self.track = {u.id: {"first_hp": None, "first_hp_round": None, "half": None, "ep_out": None,
                             "ep_out_round": None, "death": None, "att_before": 0, "opp_before": 0,
                             "att_after": 0, "opp_after": 0, "hits_after": 0}
                      for u in self.state.units.values()}
        self.stats.track = self.track
        self.controllers = controllers
        for side, ctl in controllers.items():
            ctl.bind(self, side)
        self.current_actor = None
        # Ver0.5: 戦線崩壊／復旧・補給EPの行方（PA-41〜PA-44）
        v5 = rules.get("v05", {})
        self.std_hit = float(v5.get("standard_hit", 20))
        self.collapse_hp = float(v5.get("collapse_hp_ratio", 0.5))
        self.collapse_hits = float(v5.get("collapse_ep_hits", 1))
        self.recover_hp = float(v5.get("recover_hp_ratio", 0.5))
        self.recover_hits = float(v5.get("recover_ep_hits", 2))
        self.dying_ratio = float(v5.get("dying_hp_ratio", 0.25))
        # Ver0.6: 生身ダメージ倍率 D（PA-50）。エーテル防御のEP消費には影響しない独立変数
        bd = rules.get("body_damage", {})
        self.body_mult = float(bd.get("multiplier", 1.0))
        self.body_sides = set(bd.get("attacker_sides", ["enemy"]))
        self.side_turns = {"ally": 0, "enemy": 0}
        for u in self.state.units.values():
            self.track[u.id].update({"v6_first_dmg": None, "v6_body_hits": 0, "v6_body_dmg": 0, "v6_full_blocks": 0,
                                     "v6_full_after_hit": 0, "v6_side_at_hit": None, "v6_self_at_hit": None,
                                     "v6_turns": 0, "v6_rw_side": None, "v6_rw_self": None,
                                     "v6_disp_hits": 0, "v6_disp_dmg": 0, "v6_disp_ko": 0})
        self.cstate = {u.id: {"collapsed": False, "first": None, "rec_at": None, "n_col": 0}
                       for u in self.state.units.values()}
        self.packets = {u.id: [[u.ep, -1, 0.0]] for u in self.state.units.values()}   # [残EP, 補給時HP帯(-1=初期EP), 防いだダメージ]
        # Ver0.7: HP＝肉体の状態（PA-60〜PA-63）。既定は無効＝Ver0.6と完全に同じ
        hb = rules.get("hp_body", {}) or {}
        self.speed_on = bool(hb.get("speed_enabled", False))
        self.speed_curve = sorted((float(a), float(b)) for a, b in hb.get("speed_curve", [[1.0, 1.0]]))
        self.hp_body_sides = set(hb.get("sides", ["ally", "enemy"]))
        incap = float(hb.get("incap_ratio", 0.0) or 0.0)
        self.state.incap_targetable_by = tuple(hb.get("incap_targetable_by", []) or [])
        # Ver0.10.2 暫定（シミュ用）: 戦闘不能者も治療の対象。HPが戦闘不能ラインを超えたら戦闘復帰（PA-110）
        self.incap_healable = bool(hb.get("incap_healable", False))
        # Ver0.10.2 暫定: 戦闘不能者への対応を知能別に分ける（PA-111）。"tiered" で有効。既定は従来どおり（補正なし）
        self.incap_ai = str(hb.get("incap_ai", "") or "")
        self.seen_healers = {Side.ALLY: set(), Side.ENEMY: set()}   # 戦場で治療を行ったのが見えた者（公開情報）
        self.seen_revives = {Side.ALLY: 0, Side.ENEMY: 0}            # 戦場で見えた戦闘復帰の回数
        # 詠唱実験（PA-130）: 行動ID -> 詠唱時間（時間軸の単位＝1巡。速度1.0のとき）。既定は空＝詠唱なし（従来どおり即発動）
        self.cast_time = {k: float(v) for k, v in (rules.get("casting", {}) or {}).get("time", {}).items() if float(v) > 0}
        # "actions"（既定）: 詠唱量は「戦場全体の行動回数」で数える。1行動ごとに進行 += 詠唱者の速度倍率（PA-130b）
        # "time": 時間軸（巡）で数える。※この模擬では全員の行動時刻が巡の整数にそろいやすく、0.2〜0.6巡の差がほぼ出ない
        self.cast_unit = str((rules.get("casting", {}) or {}).get("unit", "actions"))
        self.casting = {}        # 詠唱中のユニットID -> 状態
        # 介入担当範囲（PA-160）: True のとき、後衛への介入は「その後衛を守る経路の塞ぎ手」だけ。既定は無効（誰でも介入可）
        self.iv_lanes = bool((rules.get("intervention", {}) or {}).get("lanes_by_route", False))
        for u in self.state.units.values():
            if u.side.value in self.hp_body_sides:
                u.incap_ratio = incap
        self.next_time = {u.id: 1.0 for u in self.state.units.values()}   # 次の行動時刻（1巡＝基礎間隔1）
        # 分析専用（PA-170, 正式仕様ではない）: 初回行動時刻オフセット。既定は無効＝従来と完全に同じ。
        #   初回時刻 = 1.0 + step×(全ユニット最高速度 − 自分の速度) + 一様乱数[0, width)
        #   乱数は専用ストリーム "init_offset" のみ（他の乱数の消費を変えない）。同じseedなら詠唱条件が違っても同じ値。
        self.init_offset = {}
        _off = ((rules.get("analysis", {}) or {}).get("initial_offset") or {})
        if _off:
            _step, _w = float(_off.get("step", 0.0)), float(_off.get("width", 0.0))
            _smax = max(u.d.speed for u in self.state.units.values())
            _r = self.rng["init_offset"]
            for _uid in sorted(self.state.units):
                _u = self.state.units[_uid]
                _d = _step * (_smax - _u.d.speed) + (_r.random() * _w if _w > 0 else 0.0)
                self.init_offset[_uid] = _d
                self.next_time[_uid] = 1.0 + _d
        # Ver0.8 自由設計実験（PA-70〜）。既定はすべて無効＝Ver0.7と完全に同じ
        v8 = rules.get("v08", {}) or {}
        self.regen_ratio = float(v8.get("regen_ratio", 0.0))            # M2: 自分の手番の始めに最大EP×この割合を回復
        self.ward_ratio = dict(v8.get("ward_ratio", {}) or {})          # M3: 役割ごとの外殻（防御専用）の割合
        self.ward_regen_ratio = float(v8.get("ward_regen_ratio", 0.0))  # M3: 手番の始めに外殻最大×この割合を回復
        self.cover_on = bool(v8.get("cover", False))                    # M4: 庇護の構え
        self.aegis_on = bool(v8.get("aegis", False))                    # M5: 遠隔障壁
        self.aegis_mult = float(v8.get("aegis_cost_mult", 1.5))
        self.ward_max = {}
        for u in self.state.units.values():
            if self.ward_ratio:
                r = float(self.ward_ratio.get(u.d.role, self.ward_ratio.get("default", 1.0)))
                u.ward = int(round(u.d.ep_max * r))
            self.ward_max[u.id] = u.ward
        self.cover = {}            # 庇っている前衛 -> 庇われている味方
        self.aegis_used = set()    # 障壁を張った前衛（自分の次の手番まで再介入・自己防御不可）
        self.cur_time = 0.0
        self._last_target = {}
        self._streak = {}
        self._team_last = {}
        self._team_streak = {}

    # ------------------------------------------------------------ logging
    def emit(self, type_: str, **kw):
        if not self.log_enabled and not self.listeners:
            return
        ev = {"t": type_, "round": self.state.round, **kw}
        if self.log_enabled:
            self.events.append(ev)
        for f in self.listeners:
            f(ev, self)

    def u(self, uid):
        return self.state.units[uid]

    # ------------------------------------------------------------ queries (AI/UIからも使う)
    def spendable_ep(self, u, a=None) -> int:
        """行動に使えるEP。M3では外殻（防御専用）を除いた内在の分だけ。"""
        return u.ep - u.ward if self.ward_ratio else u.ep

    def available_actions(self, u):
        out = []
        for aid in u.d.action_ids:
            a = self.actions[aid]
            if a.ep_cost > self.spendable_ep(u, a):
                continue
            if a.kind is ActionKind.COVER and not (self.cover_on and u.rank is Rank.FRONT and u.can_intervene):
                continue
            if a.uses is not None and u.uses.get(aid, 0) <= 0:
                continue
            if a.kind is ActionKind.ATTACK and a.reach is Reach.MELEE and not can_use_melee(u):
                continue
            out.append(a)
        return out

    def valid_targets(self, u, a):
        st = self.state
        if a.kind is ActionKind.ATTACK:
            return [t for t in st.target_candidates(u.side.other, u.side) if check_reach(u, t, a.reach, st).ok]
        if a.kind is ActionKind.HEAL:
            if self.incap_healable:
                return [t for t in st.units.values() if t.side is u.side and t.hp > 0 and t.hp < t.d.hp_max]
            return [t for t in st.side_units(u.side) if t.hp < t.d.hp_max]
        if a.kind is ActionKind.EP_SUPPLY:
            return [t for t in st.side_units(u.side) if t.id != u.id and t.ep < t.d.ep_max]
        if a.kind is ActionKind.COVER:
            return [t for t in st.side_units(u.side) if t.id != u.id and t.rank is Rank.REAR]
        return []

    def has_capable_target(self, u) -> bool:
        """いま使える攻撃のどれかで、戦闘可能な相手に届くか。"""
        return any(t.alive for a in self.available_actions(u) if a.kind is ActionKind.ATTACK
                   for t in self.valid_targets(u, a))

    def capable_first_targets(self, u, a):
        """味方AI用（PA-111）: 戦闘可能な相手に届く限りそちらだけ。戦闘不能者しか狙えないときだけ戦闘不能者も候補。"""
        tg = self.valid_targets(u, a)
        if self.incap_ai != "tiered" or not any(t.incapacitated for t in tg):
            return tg
        if self.has_capable_target(u):
            return [t for t in tg if t.alive]
        return tg

    def reach(self, attacker, target, action):
        return check_reach(attacker, target, action.reach, self.state)

    def defense_allowed(self, c) -> bool:
        return c.alive and self.defense.can_deploy(c) and c.stance not in self.defense_blocked \
            and c.id not in self.aegis_used and c.id not in self.casting      # 詠唱中は自己エーテル防御不可（PA-130）

    def estimate_damage(self, attacker, action, target, defend: Optional[bool] = None, naive: bool = False) -> float:
        """HPへ通る見込みダメージ。
        naive=True: 「負傷で防御効率が落ちる」ことを理解しない見積もり（低知能・通常知能用、PA-36）。
                    相手が防御を張ることは分かるが、効率は無傷のときのものとして計算する。"""
        exp = self.damage.expected(attacker, action)
        if defend is None:
            defend = self.defense_allowed(target) and \
                self.controllers[target.side].predict_defense(target, attacker, action, exp)[0]
        if defend and self.defense_allowed(target):
            if naive:
                hp = target.hp
                try:
                    target.hp = target.d.hp_max
                    exp = self.defense.preview(target, exp)[0]
                finally:
                    target.hp = hp
            else:
                exp = self.defense.preview(target, exp)[0]
        if attacker.side.value in self.body_sides:
            exp *= self.body_mult                  # Ver0.6: 肉体へ通る分に生身ダメージ倍率
        return exp

    # ------------------------------------------------------------ Ver0.8 自由設計実験
    def _v08_turn_start(self, actor):
        """自分の手番の始め: 庇護・障壁の終了、EP呼吸（M2）、外殻の回復（M3）。"""
        if actor.id in self.cover:
            self.emit("cover_end", unit=actor.id, target=self.cover.pop(actor.id))
        self.aegis_used.discard(actor.id)
        if self.regen_ratio > 0 and actor.alive:
            g = min(actor.d.ep_max - actor.ep, int(round(actor.d.ep_max * self.regen_ratio)))
            if g > 0:
                actor.ep += g
                self.stats.c[f"v8_regen_{actor.side.value}"] += g
                self.emit("regen", unit=actor.id, amount=g, ep=actor.ep)
        if self.ward_ratio and self.ward_regen_ratio > 0 and actor.alive:
            wm = self.ward_max[actor.id]
            g = min(wm - actor.ward, int(round(wm * self.ward_regen_ratio)), actor.d.ep_max - actor.ep)
            if g > 0:
                actor.ward += g
                actor.ep += g
                self.stats.c[f"v8_ward_regen_{actor.side.value}"] += g
                self.emit("regen", unit=actor.id, amount=g, ep=actor.ep, ward=actor.ward)

    def _ward_spend(self, u, spent):
        if self.ward_ratio and spent > 0:
            u.ward = max(0, u.ward - spent)
            u.ward = min(u.ward, u.ep)

    def aegis_need(self, c, raw):
        """遠隔障壁で raw を完全に防ぐ必要EP（介入者自身の防御効率 × 距離の倍率）。"""
        return math.ceil(self.defense.required_ep(c, raw) * self.aegis_mult - 1e-9)

    def _aegis_block(self, c, raw):
        need = self.aegis_need(c, raw)
        if c.ep >= need:
            c.ep -= need
            self._ward_spend(c, need)
            self._check_ep(c)
            return 0.0, need, "aegis_full"
        spent = int(c.ep)
        frac = spent / need if need > 0 else 1.0
        c.ep -= spent
        self._ward_spend(c, spent)
        self._check_ep(c)
        return raw * (1 - frac), spent, "aegis_partial"

    def upcoming_slots(self, rounds_ahead: int = 1):
        """現在の手番より後の行動予定（今の巡の残り＋予測される次の巡）。"""
        st = self.state
        rest = [s for s in st.queue[st.queue_pos + 1:] if self.u(s.unit_id).alive]
        for _ in range(rounds_ahead):
            rest += self._predict_next_round()
        return rest

    # ------------------------------------------------------------ Ver0.7: 行動速度（PA-60）
    def speed_mult(self, u) -> float:
        """現在HP率から行動速度倍率を線形補間で求める。HP60%以上は1.0。"""
        if not self.speed_on or u.side.value not in self.hp_body_sides:
            return 1.0
        r = max(0.0, u.hp / u.d.hp_max)
        c = self.speed_curve
        if r <= c[0][0]:
            return c[0][1]
        for (x0, y0), (x1, y1) in zip(c, c[1:]):
            if r <= x1:
                return y0 + (y1 - y0) * (r - x0) / (x1 - x0)
        return c[-1][1]

    def _build_round_queue(self):
        """この巡 [r, r+1) に行動時刻が来るユニットを、時刻→速度→乱数の順に並べる。
        全員の倍率が1なら、Ver0.6までの「速度降順・同速は乱数」と完全に同じ順番・同じ乱数消費になる。"""
        st = self.state
        units = list(st.units.values())
        rng = self.rng["order"]
        keys = {u.id: rng.random() for u in units}
        lim = st.round + 1 - 1e-9
        alive = [u for u in units if u.alive and self.next_time[u.id] < lim]
        base = sorted(alive, key=lambda u: (self.next_time[u.id], -u.d.speed, keys[u.id]))
        return [Slot(u.id, 0) for u in base]

    def _schedule_next(self, actor):
        """行動を終えた時点の現在HP率で、次の行動までの待機時間を決める（待機＝基礎1巡÷倍率）。"""
        t = self.next_time[actor.id]
        m = self.speed_mult(actor) if actor.alive else 1.0
        cs = self.casting.get(actor.id)
        if cs is not None and cs["last_t"] is None and self.cast_unit == "actions":
            # 行動回数で数える詠唱: 時刻では予約しない。完成は _cast_tick が決める
            cs["last_t"], cs["speed"] = t, m
            self.next_time[actor.id] = 1e9
            self._requeue(actor)
            self.emit("schedule", unit=actor.id, time=round(t, 4), next=None, mult=round(m, 4),
                      hp_ratio=round(actor.hp / actor.d.hp_max, 4), casting=True)
            return
        if cs is not None and cs["last_t"] is None:
            # 詠唱開始: 完成は「残り詠唱量 ÷ 現在の速度倍率」後（PA-130）。完成が次の手番になる
            cs["last_t"], cs["speed"] = t, m
            self.next_time[actor.id] = t + cs["remaining"] / m
            self._requeue(actor)
            self.emit("schedule", unit=actor.id, time=round(t, 4), next=round(self.next_time[actor.id], 4),
                      mult=round(m, 4), hp_ratio=round(actor.hp / actor.d.hp_max, 4), casting=True)
            return
        self.next_time[actor.id] = t + 1.0 / m
        if m < 1.0:
            self.stats.c[f"v7_delay_{actor.side.value}"] += 1
        self.emit("schedule", unit=actor.id, time=round(t, 4), next=round(self.next_time[actor.id], 4),
                  mult=round(m, 4), hp_ratio=round(actor.hp / actor.d.hp_max, 4))

    def _predict_next_round(self):
        """次の巡の行動予定（乱数を使わない予測）。倍率1なら従来の predict_queue と同じ。"""
        st = self.state
        nxt = st.round + 1
        out = []
        for u in st.units.values():
            if not u.alive:
                continue
            t = self.next_time[u.id]
            if t < nxt - 1e-9:                      # この巡にまだ行動する（または行動中）→ その次
                t = t + 1.0 / self.speed_mult(u)
            if t < nxt + 1 - 1e-9:
                out.append((t, -u.d.speed, u.id))
        out.sort()
        return [Slot(uid, 0) for _, _, uid in out]

    def actors_before_next_turn_of(self, unit_id: str) -> list[str]:
        out = []
        for s in self.upcoming_slots(1):
            if s.unit_id == unit_id:
                break
            out.append(s.unit_id)
        return out

    def route_snapshot(self):
        return route_status_map(self.state.all_routes(), self.state.units)

    def leader_down_for(self, u) -> bool:
        return bool(u.d.group and self.state.leader_down.get(u.d.group))

    def group_has_leader(self, u) -> bool:
        return any(x.d.is_leader and x.d.group == u.d.group for x in self.state.units.values())

    # ------------------------------------------------------------ main loop
    def run(self) -> BattleStats:
        st = self.state
        self.emit("battle_start", routes=self.route_snapshot())
        while st.winner is None:
            st.round += 1
            if st.round > self.max_rounds:
                st.winner = "draw"
                st.round -= 1
                break
            self.ep_regen.on_round_start(st.units.values())
            st.queue = self._build_round_queue()
            self._revived_this_round = set()
            self.emit("round_start", queue=[s.unit_id for s in st.queue])
            for pos, slot in enumerate(st.queue):
                st.queue_pos = pos
                actor = self.u(slot.unit_id)
                if not actor.alive:
                    continue
                if actor.id in self._revived_this_round:
                    # PA-110: この巡の途中で戦闘不能→復帰した者の、戦闘不能前に組まれていた手番は使わない（次の巡以降に行動）
                    continue
                self.cur_time = self.next_time[actor.id]
                self._take_turn(actor)
                self._schedule_next(actor)
                if self.casting and self.cast_unit == "actions":
                    self._cast_tick(actor)
                self.recovery.on_action_tick(self)
                if self._check_end():
                    break
        self._finalize()
        self.emit("battle_end", winner=st.winner, rounds=st.round)
        return self.stats

    def _check_end(self) -> bool:
        st = self.state
        a = st.side_units(Side.ALLY)
        e = st.side_units(Side.ENEMY)
        if not a or not e:
            st.winner = "ally" if a else ("enemy" if e else "draw")
            return True
        return False

    def _take_turn(self, actor):
        self.current_actor = actor
        self.action_index += 1
        self.side_turns[actor.side.value] += 1
        self.track[actor.id]["v6_turns"] += 1
        nxt = [s.unit_id for s in self.upcoming_slots(0)][:6]
        self.emit("turn_start", unit=actor.id, upcoming=nxt, snap=actor.short(), intel=actor.intel_effective,
                  routes=self.route_snapshot())
        self._v08_turn_start(actor)
        if actor.id in self.casting:
            cs = self.casting.pop(actor.id)
            a = self.actions[cs["dec"].action_id]
            took = self.cur_time - cs["start_t"]
            if actor.ep < a.ep_cost:
                self.stats.c[f"cast_fail_ep_{a.id}"] += 1
                self.emit("cast_fail", unit=actor.id, action=a.id, ep=actor.ep, took=took)
                return
            self.emit("cast_complete", unit=actor.id, action=a.id, took=took, base=cs["base"],
                      actions=self.action_index - cs["start_idx"], hits=cs["hits"])
            self.stats.c[f"cast_done_{a.id}"] += 1
            d = cs["dec"]
            self._execute(actor, Decision(d.action_id, d.target_id, reasons=list(d.reasons) + ["詠唱完了"],
                                          tags={**(d.tags or {}), "cast_complete": True}))
            return
        if not self.recovery.on_own_turn_start(actor, self):
            self.emit("turn_skipped", unit=actor.id, reason="持ち場への復帰に手番を使用")
            return
        dec = self._decide(actor)
        self._execute(actor, dec)

    def _decide(self, actor):
        """判断の窓口（Ver0.15 で観測固定のために差し替え可能にした。既定は従来と同じ）。"""
        return self.controllers[actor.side].decide_action(actor)

    def _iv_ok(self, c) -> bool:
        """Ver0.15 の牽制・死守用フック。既定は常に True（従来と同じ）。"""
        return True

    def _raw_mult(self, final, attacker=None, target=None) -> float:
        """Ver0.15 の死守・遠吠え用フック。既定 1.0（従来と同じ）。"""
        return 1.0

    # ------------------------------------------------------------ execution
    def _execute(self, actor, dec):
        a = self.actions[dec.action_id]
        target = self.u(dec.target_id) if dec.target_id else None
        if a.id in self.cast_time and not dec.tags.get("cast_complete"):
            # 詠唱開始（PA-130）: その場では何も起きない。EPは発動時に消費する
            T = self.cast_time[a.id]
            self.casting[actor.id] = {"dec": dec, "remaining": T, "base": T, "last_t": None, "speed": None,
                                      "start_t": self.cur_time, "start_idx": self.action_index, "hits": 0,
                                      "progress": 0.0}
            self.stats.c[f"cast_start_{a.id}"] += 1
            self.emit("cast_start", unit=actor.id, action=a.id, base=T, hp=actor.hp, ep=actor.ep, reasons=dec.reasons)
            return
        if a.ep_cost:
            actor.ep -= a.ep_cost
            self._consume_packets(actor, a.ep_cost, 0.0)
            self._check_ep(actor)
            self._update_collapse(actor, cause="spend")
        if a.uses is not None:
            actor.uses[a.id] -= 1

        if actor.side is Side.ENEMY and a.kind is ActionKind.ATTACK:
            self._record_enemy_decision(actor, dec, target, a)

        if a.kind is ActionKind.WAIT or target is None:
            self.emit("wait", unit=actor.id, reasons=dec.reasons)
            return
        if a.kind is ActionKind.COVER:
            self.cover[actor.id] = target.id
            self.stats.c[f"v8_cover_{actor.side.value}"] += 1
            self.emit("cover", unit=actor.id, target=target.id, reasons=dec.reasons)
            return
        if a.kind is ActionKind.ATTACK and a.area == "all":
            self.emit("area_attack", unit=actor.id, action=a.id, reasons=dec.reasons)
            for t in [t for t in self.valid_targets(actor, a)]:
                if t.alive and actor.alive:
                    self._resolve_attack(actor, a, t, dec, no_iv=True)
                    if self._check_end():
                        break
            return
        if a.kind is ActionKind.HEAL:
            base_amt = int(round(a.heal_ratio * target.d.hp_max)) if a.heal_ratio else self.heal.amount(actor, a)
            amt = min(base_amt, target.d.hp_max - target.hp)
            sc = self.stats.c
            was_collapsed = self.cstate[target.id]["collapsed"]
            cpd_before = self.defense.required_ep(target, 1.0)
            target.hp += amt
            self.seen_healers[actor.side].add(actor.id)
            if target.stance is Stance.DOWN and target.alive:
                self._revive(target, actor)
            cpd_after = self.defense.required_ep(target, 1.0)
            fs = target.side.value
            sc[f"v5_heal_n_{fs}"] += 1
            sc[f"v5_heal_amt_{fs}"] += amt
            sc[f"v5_heal_cpd_before_{fs}"] += cpd_before            # ⑩ 治療前後の「1ダメージを防ぐ必要EP」
            sc[f"v5_heal_cpd_after_{fs}"] += cpd_after
            if was_collapsed:
                sc[f"v5_heal_on_collapsed_{fs}"] += 1
            if dec.tags.get("gated"):
                sc[f"v5_gated_{fs}"] += 1
            self._update_collapse(target, cause="heal")
            self.stats.c[f"heal_{actor.side.value}"] += 1
            self.emit("heal", unit=actor.id, target=target.id, amount=amt, ep_cost=a.ep_cost,
                      hp=target.hp, reasons=dec.reasons)
            return
        if a.kind is ActionKind.EP_SUPPLY:
            amt = min(a.amount, target.d.ep_max - target.ep)
            target.ep += amt
            sc = self.stats.c
            fs = target.side.value
            band = self._band(target.hp_ratio)
            if amt > 0:
                self.packets[target.id].append([amt, band, 0.0])
            sc[f"v5_sup_n_b{band}_{fs}"] += 1
            sc[f"v5_sup_ep_b{band}_{fs}"] += amt
            if self.cstate[target.id]["collapsed"]:
                sc[f"v5_sup_on_collapsed_{fs}"] += 1
            if dec.tags.get("gated"):
                sc[f"v5_gated_{fs}"] += 1
            self._check_ep(target)
            self._update_collapse(target, cause="supply")
            self.stats.c[f"ep_supply_{actor.side.value}"] += 1
            self.emit("ep_supply", unit=actor.id, target=target.id, amount=amt, ep=target.ep,
                      uses_left=actor.uses.get(a.id), reasons=dec.reasons)
            return
        self._resolve_attack(actor, a, target, dec)

    def _record_enemy_decision(self, actor, dec, target, a):
        if not self.group_has_leader(actor):
            return
        ph = self.stats.ai_phase["post" if self.leader_down_for(actor) else "pre"]
        ph["decisions"] += 1
        if target is not None and target.rank is Rank.REAR:
            ph["target_rear"] += 1
        if target is not None and a.reach is Reach.MELEE:
            r = self.reach(actor, target, a)
            if r.via_route:
                ph["via_open_route"] += 1
                if self.breach.record_for_route(r.via_route) is not None:
                    ph["via_intervention_hole"] += 1
        if dec.tags.get("plan_bait"):
            ph["plan_bait"] += 1

    def _track_targeting(self, attacker, target):
        """標的の集中度（誰を何回・標的変更回数・同一標的への連続攻撃）。"""
        sc = self.stats.c
        aside = attacker.side.value
        sc[f"attacks_{aside}"] += 1
        sc[f"attacks_{aside}_on_{target.rank.value.lower()}"] += 1
        if target.hp < target.d.hp_max:
            sc[f"attacks_{aside}_on_wounded"] += 1
        if target.hp_ratio <= self.dying_ratio:
            sc[f"v5_att_dying_{aside}"] += 1                      # 瀕死対象への攻撃
        prev = self._last_target.get(attacker.id)
        if prev is not None and prev != target.id and self.u(prev).alive:
            sc[f"v5_abandon_{aside}"] += 1                        # 倒し切る前に別標的へ変更
        opp = self.state.side_units(target.side)
        if target.hp_ratio <= min(o.hp_ratio for o in opp) + 1e-9:
            sc[f"attacks_{aside}_on_weakest"] += 1
        for o in opp:
            ph = "after" if self.track[o.id]["first_hp"] is not None else "before"
            self.track[o.id][f"opp_{ph}"] += 1
            if o is target:
                self.track[o.id][f"att_{ph}"] += 1
        last = self._last_target.get(attacker.id)
        if last is None:
            self._streak[attacker.id] = 1
        elif last == target.id:
            self._streak[attacker.id] += 1
        else:
            sc[f"target_switch_{aside}"] += 1
            self.stats.streaks[aside].append(self._streak[attacker.id])
            self._streak[attacker.id] = 1
        self._last_target[attacker.id] = target.id
        tl = self._team_last.get(aside)
        if tl is None:
            self._team_streak[aside] = 1
        elif tl == target.id:
            self._team_streak[aside] += 1
        else:
            sc[f"team_switch_{aside}"] += 1
            self.stats.team_streaks[aside].append(self._team_streak[aside])
            self._team_streak[aside] = 1
        self._team_last[aside] = target.id

    def _resolve_attack(self, attacker, a, target, dec, no_iv=False):
        st = self.state
        sc = self.stats.c
        side = target.side.value
        self.stats.targeted[target.id] += 1
        self._track_targeting(attacker, target)
        reach = self.reach(attacker, target, a)
        self.emit("attack_declared", unit=attacker.id, target=target.id, action=a.id, reach=a.reach.value,
                  reach_ok=reach.ok, reach_reason=reach.reason, via_route=reach.via_route,
                  reasons=dec.reasons, tags=dec.tags)
        if not reach.ok:
            self.emit("attack_failed", unit=attacker.id, reason=reach.reason)
            return

        breach_rec = None
        if reach.via_route:
            sc[f"intrusion_{side}"] += 1
            breach_rec = self.breach.record_for_route(reach.via_route)
            if breach_rec is not None:
                breach_rec.breach_attempts += 1
            self.emit("intrusion", unit=attacker.id, target=target.id, route=reach.via_route,
                      caused_by=breach_rec.interceptor if breach_rec else None)
            plan_id = dec.tags.get("plan_exploit")
            if plan_id is not None and breach_rec is not None:
                for p in self.stats.plans:
                    if p["id"] == plan_id:
                        p["success"] = True

        # ---- 介入ウィンドウ
        eligible = [c for c in st.side_units(target.side)
                    if c.id != target.id and c.can_intervene
                    and (self.allow_rear_interceptors or c.rank is Rank.FRONT)
                    and c.id not in self.aegis_used and c.id not in self.cover and self._iv_ok(c)]
        if self.iv_lanes and target.rank is Rank.REAR and target.side is Side.ALLY:   # 味方側だけ（敵の介入は従来どおり）
            # 介入担当範囲（PA-160）: その後衛を守る経路の塞ぎ手（blockers）に含まれる前衛だけが介入候補
            lane = {b for r in st.routes[target.side] if target.id in r.protects for b in r.blockers}
            eligible = [c for c in eligible if c.id in lane]
        choice = None
        covered_by = None
        if self.cover_on:
            covered_by = next((self.u(c) for c, t in self.cover.items() if t == target.id
                               and self.u(c).alive and not self.u(c).displaced), None)
        if no_iv or covered_by is not None:
            eligible = []
        if eligible:
            win = InterventionWindow(attacker=attacker, action=a, target=target, eligible=eligible, reach=reach)
            self.emit("intervention_window", target=target.id, attacker=attacker.id,
                      eligible=[c.id for c in eligible])
            choice = self.controllers[target.side].decide_intervention(win)
            if target.side is Side.ENEMY and self.group_has_leader(target):
                ph = self.stats.ai_phase["post" if self.leader_down_for(target) else "pre"]
                ph["intervene_windows"] += 1
                if choice and choice.interceptor_id:
                    ph["intervened"] += 1

        final = target
        rec = None
        aegis = None
        if covered_by is not None:
            final = covered_by
            self.stats.c[f"v8_covered_hit_{side}"] += 1
            self.emit("covered", unit=covered_by.id, target=target.id, attacker=attacker.id)
        elif choice and choice.interceptor_id and choice.mode == "aegis" and self.aegis_on:
            aegis = self.u(choice.interceptor_id)
            self.aegis_used.add(aegis.id)
            self.stats.c[f"v8_aegis_{side}"] += 1
            self.emit("aegis", unit=aegis.id, target=target.id, attacker=attacker.id, reasons=choice.reasons)
        elif choice and choice.interceptor_id:
            c = self.u(choice.interceptor_id)
            ctl = self.controllers[target.side]
            prevented = self.estimate_damage(attacker, a, target)               # PA-19
            before = self.route_snapshot()
            transition(c, Stance.INTERVENING, self.emit, f"{target.name}への攻撃に介入")
            self.recovery.on_intervened(c, self)
            opened = [r.id for r in st.routes_blocked_by(c.id)
                      if before[r.id] == "BLOCK" and not route_blocked(r, st.units)]
            rec = self.breach.new(battle_round=st.round, side=side, interceptor=c.id,
                                  original_target=target.id, attacker=attacker.id, action=a.id,
                                  policy=getattr(ctl, "policy_name", ctl.name),
                                  prevented_damage=prevented,
                                  leader_down_at_time=any(st.leader_down.values()))
            self.breach.open(rec, opened)
            sc[f"intervention_{side}"] += 1
            if prevented > 0.5:
                sc[f"iv_prevented_hp_hit_{side}"] += 1
                if target.hp <= target.d.hp_max / 2:
                    sc[f"iv_prevented_collapse_{side}"] += 1
                if prevented >= target.hp:
                    sc[f"iv_prevented_ko_{side}"] += 1
            sc[f"front_open_{side}"] += len(opened)
            sc[f"front_open_by_intervention_{side}"] += len(opened)
            self.emit("intervened", unit=c.id, target=target.id, attacker=attacker.id,
                      reasons=choice.reasons, prevented_est=round(prevented, 1))
            for rid in opened:
                self.emit("route_change", route=rid, status="OPEN", cause=f"{c.name}が持ち場を離れた")
            final = c
        elif choice is not None and eligible:
            self.emit("no_intervention", target=target.id, reasons=choice.reasons)

        # ---- 防御判断
        exp_raw = self.damage.expected(attacker, a)
        allowed = self.defense_allowed(final) and aegis is None
        if aegis is not None:
            want, why = False, f"{aegis.name}の遠隔障壁"
        elif choice and choice.self_defense is not None and final is target:
            want, why = choice.self_defense, "本人対応の選択"
        elif allowed:
            want, why = self.controllers[final.side].decide_defense(final, attacker, a, exp_raw)
        else:
            want, why = False, ("EP不足" if self.defense.exhausted(final) else f"{final.stance.value}中は展開不可 (PA-08)")
        deployed = bool(allowed and want)
        raw = self.damage.raw(attacker, a, self.rng["damage"])
        _rm = self._raw_mult(final, attacker, target)
        if _rm != 1.0:
            raw *= _rm
        red = 0.0
        mode, spent = "none", 0
        fs, fr = final.side.value, final.rank.value.lower()
        hp_before_ratio = final.hp_ratio
        if deployed:
            need_ep = self.defense.required_ep(final, raw)
            hp_f, spent, blocked, mode = self.defense.resolve(final, raw)
            final.ep -= spent
            self._ward_spend(final, spent)
            self._consume_packets(final, spent, blocked)
            red = blocked / raw if raw > 0 else 1.0
            sc[f"defense_{fs}"] += 1
            if mode == "full":
                sc[f"full_block_{fs}"] += 1
            b = 0 if hp_before_ratio > 0.75 else 1 if hp_before_ratio > 0.5 else 2 if hp_before_ratio > 0.25 else 3
            sc[f"def_n_{fs}_{fr}_b{b}"] += 1
            sc[f"def_ep_{fs}_{fr}_b{b}"] += spent
            sc[f"def_raw_{fs}_{fr}_b{b}"] += raw
            sc[f"def_need_{fs}_{fr}_b{b}"] += need_ep
            self._check_ep(final)
        else:
            hp_f = raw
        if aegis is not None:
            hp_f, spent_a, mode = self._aegis_block(aegis, raw)
            spent = spent_a
        if attacker.side.value in self.body_sides:
            hp_f *= self.body_mult                 # Ver0.6 PA-50: 防ぎ切れなかった威力 × D が肉体へ
        dmg = max(0, int(round(hp_f)))
        if mode == "partial" and dmg > 0:
            sc[f"partial_pierce_{fs}"] += 1          # ⑥ 部分防御でHPへ貫通した回数
        before = self.route_snapshot()
        final.hp = max(0, final.hp - dmg)
        if final.id in self.casting and final.alive and dmg > 0:
            self._cast_rescale(final)
        tr = self.track[final.id]
        first_hp_hit_now = False
        if dmg > 0:
            sc[f"hp_hit_{fs}"] += 1
            if not deployed:
                sc[f"unshielded_hit_{fs}"] += 1
            if tr["first_hp"] is None:
                tr["first_hp"], tr["first_hp_round"] = self.action_index, st.round
                first_hp_hit_now = True
        if tr["first_hp"] is not None and not first_hp_hit_now:
            tr["hits_after"] += 1
        # Ver0.6 計測
        if mode == "full":
            tr["v6_full_blocks"] += 1
            if tr["first_hp"] is not None:
                tr["v6_full_after_hit"] += 1                     # ⑪⑫ 直撃後にエーテル防御で完全に防げた
        if dmg > 0:
            tr["v6_body_hits"] += 1
            tr["v6_body_dmg"] += dmg
            if first_hp_hit_now:
                tr["v6_first_dmg"] = dmg / final.d.hp_max       # ④ 初回直撃のHP減少率
                tr["v6_side_at_hit"] = self.side_turns[final.side.value]
                tr["v6_self_at_hit"] = tr["v6_turns"]
        if final.displaced and rec is None:                     # 介入後（持ち場離脱中）に別の攻撃を受けた
            tr["v6_disp_hits"] += 1
            tr["v6_disp_dmg"] += dmg
            if final.hp <= 0:
                tr["v6_disp_ko"] += 1
        if tr["half"] is None and final.hp <= final.d.hp_max / 2:
            tr["half"] = self.action_index
        self.emit("damage", unit=final.id, attacker=attacker.id, action=a.id, raw=round(raw, 1),
                  defense=deployed, defense_reason=why, reduction=round(red, 2), dmg=dmg,
                  hp=final.hp, ep=final.ep, mode=mode, ep_spent=spent,
                  aegis_by=aegis.id if aegis is not None else None, covered=covered_by is not None)

        self._update_collapse(final, cause="hit")
        if rec is not None:
            rec.interceptor_damage_taken = dmg
            if final.alive:
                transition(final, Stance.GUARDING, self.emit, "攻撃を受け止めた（再介入不可）")
        sc[f"dmg_taken_{final.side.value}_{final.rank.value.lower()}"] += dmg
        if reach.via_route and final is target:
            sc[f"intrusion_hit_{side}"] += 1
            sc[f"intrusion_damage_{side}"] += dmg
        if breach_rec is not None and final is target:
            breach_rec.breach_damage += dmg
            breach_rec.breach_hits += 1
            if dmg > 0:
                sc[f"breach_hp_hit_{side}"] += 1
                if first_hp_hit_now:
                    sc[f"breach_first_hp_hit_{side}"] += 1
            if not target.alive:
                breach_rec.breach_kos += 1

        if not final.alive:
            self._on_ko(final, before)

    # ------------------------------------------------------------ Ver0.5 helpers
    @staticmethod
    def _band(r):
        return 0 if r >= 0.75 else 1 if r >= 0.5 else 2 if r >= 0.25 else 3

    def _consume_packets(self, u, spent, blocked):
        """消費EPを、初期EP→補給EPの順（先入れ先出し）に割り当て、防いだダメージを按分する（PA-43）。"""
        if spent <= 0:
            return
        left = spent
        for pk in self.packets[u.id]:
            if left <= 0:
                break
            take = min(pk[0], left)
            if take <= 0:
                continue
            pk[0] -= take
            pk[2] += blocked * take / spent
            left -= take

    def _hit_cost(self, u):
        return self.defense.required_ep(u, self.std_hit)

    def _is_collapsed(self, u):
        return u.alive and (u.hp_ratio < self.collapse_hp or u.ep < self.collapse_hits * self._hit_cost(u))

    def _is_recovered(self, u):
        return u.alive and u.hp_ratio >= self.recover_hp and u.ep >= self.recover_hits * self._hit_cost(u)

    def _update_collapse(self, u, cause=""):
        """戦線崩壊／戦線復旧の判定（PA-41）。"""
        cs = self.cstate[u.id]
        sc = self.stats.c
        key = f"{u.side.value}_{u.rank.value.lower()}"
        if not cs["collapsed"]:
            if self._is_collapsed(u):
                cs["collapsed"] = True
                cs["n_col"] += 1
                sc[f"v5_collapse_{key}"] += 1
                if cs["first"] is None:
                    cs["first"] = self.action_index
                if cs["rec_at"] is not None:                       # ⑬ 復旧→再崩壊
                    sc[f"v5_rec_dur_sum_{key}"] += self.action_index - cs["rec_at"]
                    sc[f"v5_rec_end_recollapse_{key}"] += 1
                    cs["rec_at"] = None
        else:
            if self._is_recovered(u) and cause in ("heal", "supply"):
                cs["collapsed"] = False
                cs["rec_at"] = self.action_index
                sc[f"v5_recover_{key}"] += 1
                sc[f"v5_recover_by_{cause}_{key}"] += 1

    def _close_unit(self, u, how):
        cs = self.cstate[u.id]
        sc = self.stats.c
        key = f"{u.side.value}_{u.rank.value.lower()}"
        if cs["rec_at"] is not None:
            sc[f"v5_rec_dur_sum_{key}"] += self.action_index - cs["rec_at"]
            sc[f"v5_rec_end_{how}_{key}"] += 1
            cs["rec_at"] = None
        if cs["first"] is not None:                              # ⑮ 最初の崩壊からの生存時間
            sc[f"v5_post_collapse_sum_{key}"] += self.action_index - cs["first"]
            sc[f"v5_collapsed_units_{key}"] += 1
            if how == "end":
                sc[f"v5_collapsed_survived_{key}"] += 1
        fs = u.side.value
        for pk in self.packets[u.id]:
            if pk[1] >= 0:
                sc[f"v5_sup_block_b{pk[1]}_{fs}"] += pk[2]       # ⑪ 補給EPで防げたダメージ
                sc[f"v5_sup_waste_b{pk[1]}_{fs}"] += pk[0]       # 使われずに残ったEP
        self.packets[u.id] = []

    def _check_ep(self, u):
        if self.defense.exhausted(u):
            if u.id not in self._ep_low:
                self._ep_low.add(u.id)
                if self.track[u.id]["ep_out"] is None:
                    self.track[u.id]["ep_out"] = self.action_index
                    self.track[u.id]["ep_out_round"] = self.state.round
                self.stats.c[f"ep_exhaust_{u.side.value}"] += 1
                self.emit("ep_exhausted", unit=u.id, ep=u.ep)
        else:
            self._ep_low.discard(u.id)

    def _requeue(self, u):
        """詠唱の完成時刻が変わったとき: この巡の残りの予定から u を外し、完成がこの巡のうちなら時刻順の位置に入れ直す。"""
        st = self.state
        pos = st.queue_pos
        rest = [sl for sl in st.queue[pos + 1:] if sl.unit_id != u.id]
        t = self.next_time[u.id]
        if t < st.round + 1 - 1e-9:
            k = 0
            while k < len(rest) and self.next_time[rest[k].unit_id] <= t:
                k += 1
            rest.insert(k, Slot(u.id, 0))
        st.queue[pos + 1:] = rest

    def _cast_tick(self, actor):
        """行動が1回終わるたびに、詠唱中の者の進行を「その者の速度倍率」ぶん進める。詠唱開始の行動そのものは数えない。"""
        st = self.state
        for uid, cs in list(self.casting.items()):
            if cs["start_idx"] == self.action_index:
                continue
            u = self.u(uid)
            if not u.alive:
                continue
            cs["progress"] += self.speed_mult(u)
            if cs["progress"] >= cs["base"] - 1e-9:
                self.next_time[uid] = self.cur_time
                rest = [sl for sl in st.queue[st.queue_pos + 1:] if sl.unit_id != uid]
                st.queue[st.queue_pos + 1:] = [Slot(uid, 0)] + rest

    def _cast_rescale(self, u):
        if self.cast_unit == "actions":
            cs = self.casting[u.id]
            rem = max(0.0, cs["base"] - cs["progress"])
            old_m, m = cs["speed"] or 1.0, self.speed_mult(u)
            cs["speed"] = m
            cs["hits"] += 1
            # 遅れ（行動数）= 残りを新しい速度で進める場合 − 古い速度の場合
            self.emit("cast_delay", unit=u.id, old=round(rem / old_m, 4), new=round(rem / m, 4), mult=round(m, 4), hp=u.hp)
            return
        """詠唱中に負傷した: それまでの進行を古い速度で確定し、残りを現在HPの速度で進める（巻き戻しなし, PA-130）。"""
        cs = self.casting[u.id]
        now = self.cur_time
        if cs["last_t"] is None:
            return
        cs["remaining"] = max(0.0, cs["remaining"] - (now - cs["last_t"]) * cs["speed"])
        cs["last_t"] = now
        old = self.next_time[u.id]
        m = self.speed_mult(u)
        cs["speed"] = m
        self.next_time[u.id] = now + cs["remaining"] / m
        cs["hits"] += 1
        self._requeue(u)
        self.emit("cast_delay", unit=u.id, old=round(old, 4), new=round(self.next_time[u.id], 4), mult=round(m, 4), hp=u.hp)

    def _revive(self, u, by):
        """Ver0.10.2 暫定（PA-110）: 治療でHPが戦闘不能ラインを超えた → 戦闘復帰。
        持ち場（READY）に戻り、次の行動は治療した者の行動時刻から、通常の待機時間ぶん後。"""
        transition(u, Stance.READY, self.emit, "治療でHPが戦闘不能ラインを超えて戦闘復帰")
        now = self.next_time[by.id]
        self.next_time[u.id] = max(self.next_time[u.id], now + 1.0 / self.speed_mult(u))
        self.seen_revives[u.side] += 1
        if any(sl.unit_id == u.id for sl in self.state.queue[self.state.queue_pos + 1:]):
            self._revived_this_round.add(u.id)
        self.stats.c[f"v10_revive_{u.side.value}"] += 1
        self.emit("revive", unit=u.id, by=by.id, hp=u.hp)

    def _on_ko(self, u, routes_before):
        st = self.state
        if u.id in self.casting:
            cs = self.casting.pop(u.id)
            self.stats.c[f"cast_cancel_{'incap' if u.hp > 0 else 'dead'}"] += 1
            self.emit("cast_cancel", unit=u.id, action=cs["dec"].action_id, reason="戦闘不能" if u.hp > 0 else "死亡",
                      took=self.cur_time - cs["start_t"], actions=self.action_index - cs["start_idx"])
            self.next_time[u.id] = self.cur_time + 1.0          # 復帰した場合に備え、通常の予定に戻す
        if u.stance is Stance.DOWN:
            # 感度確認: 戦闘不能のまま攻撃を受けてHP0になった（戦闘不能→死亡）。離脱の処理は済んでいるので記録だけ
            if u.hp <= 0:
                self.stats.c[f"v7_dead_after_incap_{u.side.value}"] += 1
                self.emit("ko", unit=u.id, incap=False, hp=0, after_incap=True)
            return
        incap = u.hp > 0
        transition(u, Stance.DOWN, self.emit, "HP15%以下で戦闘不能" if incap else "HP0")
        self.stats.c[f"v7_{'incap' if incap else 'dead'}_{u.side.value}"] += 1
        self.stats.ko_round[u.id] = st.round
        self.track[u.id]["death"] = self.action_index
        tr6 = self.track[u.id]
        if tr6["v6_side_at_hit"] is not None:                    # ⑧ Rescue Window
            tr6["v6_rw_side"] = self.side_turns[u.side.value] - tr6["v6_side_at_hit"]
            tr6["v6_rw_self"] = tr6["v6_turns"] - tr6["v6_self_at_hit"]
        self._close_unit(u, "death")
        if u.side.value not in self.stats.first_ko:
            self.stats.first_ko[u.side.value] = {"round": st.round,
                                                 "attacks": self.stats.c.get(f"attacks_{u.side.other.value}", 0)}
        self.stats.c[f"ko_{u.side.value}"] += 1
        self.emit("ko", unit=u.id, incap=incap, hp=u.hp)
        for rec in self.breach.records:
            if rec.interceptor == u.id and not rec.closed:
                rec.interceptor_ko = True
        self.breach.close_for_unit(u.id)
        after = self.route_snapshot()
        for rid, s in after.items():
            if routes_before.get(rid) == "BLOCK" and s == "OPEN":
                side = next(r.side.value for r in st.all_routes() if r.id == rid)
                self.stats.c[f"front_open_{side}"] += 1
                self.stats.c[f"front_open_by_ko_{side}"] += 1
                self.emit("route_change", route=rid, status="OPEN", cause=f"{u.name}が戦闘不能")
        if u.d.is_leader and u.d.group:
            st.leader_down[u.d.group] = True
            self.stats.leader_down_round = st.round
            self.stats.leader_down_ally_hp_ratio = self._hp_ratio(Side.ALLY)
            self.stats.leader_down_enemy_hp_ratio = self._hp_ratio(Side.ENEMY)
            for m in st.units.values():
                if m.alive and m.d.group == u.d.group and m.intel_effective is not None:
                    old = m.intel_effective
                    m.intel_effective = max(self.intel_min, old - self.intel_drop_steps)
                    self.emit("intel_down", unit=m.id, old=old, new=m.intel_effective, leader=u.id)

    def on_unit_returned(self, c):
        """RecoveryStrategy から呼ばれる。介入で開いた経路を閉じる。"""
        for rid in self.breach.close_for_unit(c.id):
            if route_blocked(next(r for r in self.state.all_routes() if r.id == rid), self.state.units):
                self.emit("route_change", route=rid, status="BLOCK", cause=f"{c.name}が持ち場へ復帰")

    # ------------------------------------------------------------ finalize
    def _hp_ratio(self, side):
        us = self.state.side_units(side, alive_only=False)
        return sum(u.hp for u in us) / sum(u.d.hp_max for u in us)

    def _ep_ratio(self, side):
        us = self.state.side_units(side, alive_only=False)
        tot = sum(u.d.ep_max for u in us)
        return sum(u.ep for u in us if u.alive) / tot if tot else 0.0

    def _finalize(self):
        s = self.stats
        s.winner = self.state.winner
        s.rounds = self.state.round
        s.final = {
            "ally_hp_ratio": self._hp_ratio(Side.ALLY), "enemy_hp_ratio": self._hp_ratio(Side.ENEMY),
            "ally_ep_ratio": self._ep_ratio(Side.ALLY), "enemy_ep_ratio": self._ep_ratio(Side.ENEMY),
            "ally_alive": len(self.state.side_units(Side.ALLY)),
            "enemy_alive": len(self.state.side_units(Side.ENEMY)),
            "unit_hp": {u.id: u.hp for u in self.state.units.values()},
            "actions": self.action_index,
            "unit_ep": {u.id: u.ep for u in self.state.units.values()},
        }
        s.interventions = self.breach.records
        for u in self.state.units.values():
            if u.alive:
                self._close_unit(u, "end")
        for uid, n in self._streak.items():
            s.streaks[self.u(uid).side.value].append(n)
        for side, n in self._team_streak.items():
            s.team_streaks[side].append(n)
