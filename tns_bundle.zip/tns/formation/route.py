"""接近経路(ApproachRoute)。
経路の BLOCK / OPEN は保存せず、毎回 blockers の状態から計算する（リセット忘れが原理的に起きない）。

将来拡張:
  - MIDDLE: 経路の連鎖（前衛→中衛→後衛）を表す parent 経路を持たせる
  - 巨大敵: blockers の必要人数（required_blockers）を持たせる
  - 複数経路: 既に protects が複数経路に属せる
"""
from __future__ import annotations

from dataclasses import dataclass

from ..model.enums import Side, Stance


@dataclass(frozen=True)
class ApproachRoute:
    id: str
    side: Side                    # どちらの陣営の経路か（守られる側）
    blockers: tuple[str, ...]     # この経路を塞ぐ前衛
    protects: tuple[str, ...]     # この経路の先にいる後衛

    @staticmethod
    def from_cfg(r: dict, side: Side) -> "ApproachRoute":
        return ApproachRoute(id=r["id"], side=side, blockers=tuple(r["blockers"]), protects=tuple(r["protects"]))


def blocker_is_holding(c) -> bool:
    """持ち場で経路を塞いでいる状態か。"""
    return c is not None and c.alive and c.stance is Stance.READY and not c.displaced


def route_blocked(route: ApproachRoute, units: dict) -> bool:
    return any(blocker_is_holding(units.get(b)) for b in route.blockers)


def holding_blockers(route: ApproachRoute, units: dict) -> list[str]:
    return [b for b in route.blockers if blocker_is_holding(units.get(b))]


def route_status_map(routes, units) -> dict[str, str]:
    return {r.id: ("BLOCK" if route_blocked(r, units) else "OPEN") for r in routes}
