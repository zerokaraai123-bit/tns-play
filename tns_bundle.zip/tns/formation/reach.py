"""到達判定。MELEE は経路のBLOCKを受け、RANGED は無視する。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..model.enums import Rank, Reach
from .route import route_blocked, holding_blockers


@dataclass
class ReachResult:
    ok: bool
    via_route: Optional[str] = None     # MELEEで後衛へ到達した場合の経路
    reason: str = ""
    blocked_by: list = field(default_factory=list)


def can_use_melee(attacker) -> bool:
    """後衛は原則近接攻撃不可（後衛から前に出る仕組みは未実装）。"""
    return attacker.rank is Rank.FRONT


def check_reach(attacker, target, reach: Reach, state) -> ReachResult:
    if reach is Reach.RANGED:
        return ReachResult(True, reason="遠距離: BLOCK無視")
    if not can_use_melee(attacker):
        return ReachResult(False, reason="後衛は近接攻撃不可")
    if target.rank is Rank.FRONT:
        return ReachResult(True, reason="前衛へ直接接近")
    if target.side.value not in state.block_rule_sides:
        return ReachResult(True, reason="BLOCKルール対象外")
    routes = [r for r in state.routes[target.side] if target.id in r.protects]
    if not routes:
        return ReachResult(True, reason="この後衛を守る経路なし")
    blocked_by = []
    for r in routes:
        if not route_blocked(r, state.units):
            return ReachResult(True, via_route=r.id, reason=f"経路{r.id}がOPEN")
        blocked_by += holding_blockers(r, state.units)
    names = "・".join(state.units[b].name for b in blocked_by)
    return ReachResult(False, reason=f"{names}がBLOCK中", blocked_by=blocked_by)
