"""手動操作（テキストCLI）。味方側をプレイヤーが操作する。
完成版UIではない。判断材料（行動順・経路・EP・介入した場合の穴）を見せることだけが目的。
"""
from __future__ import annotations

from ..ai.ally.ally_controller import AllyAutoController
from ..formation.route import holding_blockers, route_status_map
from ..intervention.records import InterventionChoice
from ..model.enums import ActionKind, INTEL_NAMES, Side
from .controller import Controller, Decision


class HumanCLIController(Controller):
    name = "human"
    policy_name = "human"

    def __init__(self, pol_cfg, input_fn=input, auto_defense=False):
        self.helper = AllyAutoController(pol_cfg, "situational")
        self.input = input_fn
        self.auto_defense = auto_defense

    def bind(self, engine, side):
        super().bind(engine, side)
        self.helper.bind(engine, side)

    # ---------------------------------------------------------------- 表示
    def board(self):
        eng = self.engine
        st = eng.state
        print("\n┌─ 戦況 " + "─" * 50)
        for side, label in ((Side.ENEMY, "敵"), (Side.ALLY, "味方")):
            for u in st.side_units(side, alive_only=False):
                intel = f" 知能:{INTEL_NAMES[u.intel_effective]}" if u.intel_effective is not None else ""
                lead = " ★リーダー" if u.d.is_leader else ""
                mark = "✖" if not u.alive else " "
                print(f"│{mark}{label} {u.rank.value:<5} {u.name:<8} HP{u.hp:>4}/{u.d.hp_max:<4} EP{u.ep:>4}/{u.d.ep_max:<4}"
                      f" {u.stance.value:<11}{intel}{lead}")
        rs = route_status_map(st.all_routes(), st.units)
        print("│ 経路: " + "  ".join(
            f"{r.id}={rs[r.id]}({'・'.join(eng.u(b).name for b in r.blockers)}→{'・'.join(eng.u(p).name for p in r.protects)})"
            for r in st.all_routes()))
        nxt = [eng.u(s.unit_id).name for s in eng.upcoming_slots(1)][:10]
        print("│ この後の行動順: " + " → ".join(nxt))
        print("└" + "─" * 57)

    def _ask(self, prompt, valid):
        while True:
            s = self.input(prompt).strip()
            if s in valid:
                return s
            print(f"  入力は {', '.join(v if v else '(Enter)' for v in valid)} のいずれか")

    # ---------------------------------------------------------------- 行動
    def decide_action(self, actor) -> Decision:
        eng = self.engine
        self.board()
        print(f"\n★ {actor.name} の手番")
        opts = []
        for a in eng.available_actions(actor):
            if a.kind is ActionKind.WAIT:
                opts.append((a, None, "待機"))
                continue
            for t in eng.valid_targets(actor, a):
                if a.kind is ActionKind.ATTACK:
                    r = eng.reach(actor, t, a)
                    d = eng.estimate_damage(actor, a, t)
                    via = f" ※経路{r.via_route}から侵入" if r.via_route else ""
                    opts.append((a, t, f"{a.name}({a.reach.value}) → {t.name}  見込み{d:.0f}{via}  EP-{a.ep_cost}"))
                elif a.kind is ActionKind.HEAL:
                    opts.append((a, t, f"{a.name} → {t.name} (HP{t.hp}/{t.d.hp_max})  +{eng.heal.amount(actor, a)}  EP-{a.ep_cost}"))
                else:
                    opts.append((a, t, f"{a.name} → {t.name} (EP{t.ep}/{t.d.ep_max})  残{actor.uses.get(a.id)}回"))
        # 届かない近接標的も理由つきで見せる
        for a in eng.available_actions(actor):
            if a.kind is ActionKind.ATTACK:
                for t in eng.state.side_units(actor.side.other):
                    r = eng.reach(actor, t, a)
                    if not r.ok:
                        print(f"   × {a.name} → {t.name}: {r.reason}")
        if not opts:
            return Decision("wait", reasons=["選択肢なし"])
        for i, (_, _, txt) in enumerate(opts, 1):
            print(f"  {i}) {txt}")
        print("  a) AI(状況判断)に任せる")
        s = self._ask("> ", [str(i) for i in range(1, len(opts) + 1)] + ["a"])
        if s == "a":
            return self.helper.decide_action(actor)
        a, t, _ = opts[int(s) - 1]
        return Decision(a.id, t.id if t else None, reasons=["プレイヤーの選択"])

    # ---------------------------------------------------------------- 介入
    def decide_intervention(self, window) -> InterventionChoice:
        eng = self.engine
        t, atk, a = window.target, window.attacker, window.action
        print(f"\n◇ 介入機会: {atk.name} の {a.name}({a.reach.value}) → {t.name}"
              f"  (このまま受けると見込み{eng.estimate_damage(atk, a, t):.0f})")
        opts = []
        for c in window.eligible:
            d = eng.estimate_damage(atk, a, c)
            holes = [R.id for R in eng.state.routes_blocked_by(c.id) if holding_blockers(R, eng.state.units) == [c.id]]
            before = [eng.u(x).name for x in dict.fromkeys(eng.actors_before_next_turn_of(c.id))
                      if eng.u(x).side is Side.ENEMY]
            hole = f"  ⚠ 経路{','.join(holes)}がOPENに（{c.name}の復帰前に動く敵: {'・'.join(before) or 'なし'}）" if holes else ""
            opts.append(c)
            print(f"  {len(opts)}) {c.name} が介入（見込み被弾{d:.0f}）{hole}")
        print(f"  s) {t.name}本人がエーテル防御で受ける   n) 何もしない（防御せずEP温存）   Enter) 本人の通常判断")
        s = self._ask("> ", [str(i) for i in range(1, len(opts) + 1)] + ["s", "n", ""])
        if s == "s":
            return InterventionChoice(None, self_defense=True, reasons=["本人対応: 防御"])
        if s == "n":
            return InterventionChoice(None, self_defense=False, reasons=["何もしない"])
        if s == "":
            return InterventionChoice(None, reasons=["本人の通常判断"])
        return InterventionChoice(opts[int(s) - 1].id, reasons=["プレイヤーの指示"])

    # ---------------------------------------------------------------- 防御
    def predict_defense(self, defender, attacker, action, expected_raw):
        return self.helper.decide_defense(defender, attacker, action, expected_raw)

    def decide_defense(self, defender, attacker, action, expected_raw):
        if self.auto_defense:
            return self.helper.decide_defense(defender, attacker, action, expected_raw)
        eng = self.engine
        hp_dmg, spend, _, mode = eng.defense.preview(defender, expected_raw)
        s = self._ask(f"  {defender.name}: エーテル防御を展開？ 被弾見込み{expected_raw:.0f}→{hp_dmg:.0f}"
                      f"  EP{defender.ep}→{defender.ep - spend} [Y/n] ", ["", "y", "Y", "n", "N"])
        return (s.lower() != "n"), "プレイヤーの選択"
