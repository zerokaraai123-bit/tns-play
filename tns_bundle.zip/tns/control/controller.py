"""判断の窓口。人間(CLI)・味方自動AI・敵AI が同じインターフェースを実装する。
UE5移植時: UI/入力 がこのインターフェースを実装すれば、エンジン側は変更不要。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..intervention.records import InterventionChoice, InterventionWindow


@dataclass
class Decision:
    action_id: str
    target_id: Optional[str] = None
    reasons: list = field(default_factory=list)   # ログに出す判断理由
    tags: dict = field(default_factory=dict)      # 集計用（plan_bait など）


class Controller:
    name = "controller"

    def bind(self, engine, side):
        self.engine = engine
        self.side = side

    def decide_action(self, actor) -> Decision:
        raise NotImplementedError

    def decide_intervention(self, window: InterventionWindow) -> InterventionChoice:
        return InterventionChoice()

    def decide_defense(self, defender, attacker, action, expected_raw: float) -> tuple[bool, str]:
        """エーテル防御を展開するか。(展開するか, 理由)"""
        return True, "既定: 展開"

    def predict_defense(self, defender, attacker, action, expected_raw) -> tuple[bool, str]:
        """見積もり用（実際の展開はしない）。人間操作では問い合わせずAIの判断で代用する。"""
        return self.decide_defense(defender, attacker, action, expected_raw)
